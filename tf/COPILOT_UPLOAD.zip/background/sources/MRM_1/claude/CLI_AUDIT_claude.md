# CLI and configuration audit — all four entry points

Triggered by finding that `--fp16` cannot take effect in `distributed_finetune.py`. Swept
every entry point for the same class of defect. Everything below verified against source
with line numbers.

**Headline: one of the four scripts implements the correct pattern. The other three do
not — and the fix is already written, in the codebase, in the script that got it right.**

---

## 1 · The precision flags cannot be set in three of four scripts ⭐

### The defect

```python
p.add_argument("--bf16", action="store_true", default=True)     # ← always True
...
if args.fp16:
    config.fp16 = True;  config.bf16 = False
if args.bf16:                                                    # ← always runs
    config.bf16 = True;  config.fp16 = False                     # ← reverses the above
```

`action="store_true"` with `default=True` means `args.bf16` is `True` whether or not the
flag is passed. The `bf16` block runs **after** the `fp16` block and unconditionally
undoes it. With no `--no_bf16` available, **precision is locked to bf16**.

### Where

| Script | Lines | Has `--no_bf16`? | Can you run fp32/fp16? |
|---|---|---|---|
| `scripts/distributed_pretrain.py` | 92, 145–148 | ✗ | **No** |
| `scripts/distributed_finetune.py` | 139, 229–232 | ✗ | **No** |
| `evaluation/fraud_eval.py` | 672, 707–710 | ✗ | **No** |
| `evaluation/pretrain_eval.py` | 871, 893–897 | **✓** | **Yes** |

### The correct pattern already exists

`evaluation/pretrain_eval.py:871` adds the missing flag, and `:893` orders the checks so
they compose:

```python
p.add_argument("--no_bf16", action="store_true", default=False, ...)
...
if args.no_bf16:
    config.bf16 = False
if args.fp16:
    config.fp16 = True;  config.bf16 = False
```

No trailing `if args.bf16` block. That is all three other scripts need.

**This is what makes it a strong finding rather than a nitpick: the team solved it once
and the fix did not propagate.** It is not a misunderstanding, it is an inconsistency.

### Why it matters to you specifically

The fp32 control run — the experiment that would move your reproducibility root cause
from *inferred* to *demonstrated* — **cannot be run from the command line.** Options:

1. Build `FraudEvalConfig(bf16=False, fp16=False)` in Python and call
   `run_fraud_evaluation(config)` directly. Cleanest, no code changes, works today.
2. Add `--no_bf16` to `fraud_eval.py`, copying `pretrain_eval.py:871`. Three lines.
3. Score with `pretrain_eval.py` instead — but that evaluates the language-model head,
   not the fraud classifier, so it does not answer your question.

**Option 1 for the memo.** Option 2 as the recommendation to the developing team.

---

## 2 · Six flags are permanently on; three have no way off

| Flag | Script | Escape hatch | Consequence |
|---|---|---|---|
| `--bf16` | pretrain, finetune, fraud_eval | **none** | Precision locked (§1) |
| `--store_logits` | fraud_eval | **none** | Always writes `eval_logits.npz`. Harmless — and convenient for you |
| `--collect_head_activation_stats` | finetune | **none** | Diagnostics always collected |
| `--track_grad_norm` | pretrain | **none** | Matches the dataclass default, so no divergence |
| `--use_composite_loss` | finetune | `--no_composite_loss` ✓ | Escapable |
| `--amount_weighted_loss` | finetune | `--no_amount_weighted_loss` ✓ | Escapable |
| `--enable_training_diagnostics` | finetune | `--no_training_diagnostics` ✓ | Escapable |

Only `--bf16` has real consequences. The others are either harmless or escapable.

---

## 3 · Two evaluation settings cannot be reached from the CLI at all

`FraudEvalConfig` fields absent from `_apply_cli_overrides`'s `_SCALAR_FIELDS` and from
its boolean handling:

- **`true_fraud_rate`** (default `0.0016`)
- **`outsort_percentiles`** (default `[0.006, 0.01, 0.05]`)

`true_fraud_rate` **linearly scales every `calibrated_fpr` the model reports**. It is a
developer-supplied assumption about portfolio prevalence, it is not validated anywhere,
and **it cannot be changed without editing code or building the config in Python.**

That is V19, and this makes it sharper: the assumption is not merely unvalidated, it is
not even exposed as a knob.

*(Less consequential for you than it looks — your eval set is at ~0.1% natural rate, so
calibration is close to a no-op. But the finding stands for anyone scoring a downsampled
population.)*

---

## 4 · Guide-documented settings that do nothing

Three config fields are documented in the guides and **never consumed anywhere in the
codebase**:

| Field | Config | Guide says |
|---|---|---|
| `amt_tag_col` | `FinetuneConfig` | *"Parquet column for amount-tag branch"* |
| `corn_threshold` | `TrainingConfig` | *"Decision threshold for cumulative probabilities"* |
| `autocompute_corn_pos_weight` | `TrainingConfig` | *"Auto-compute positive weights from data"* |

Setting any of them has no effect. Dead configuration, documented as live.

---

## 5 · The two scripts take opposite approaches to defaults

This is the root of the accumulation confusion, and it is worth stating plainly.

| | `distributed_pretrain.py` | `distributed_finetune.py` |
|---|---|---|
| Scalar CLI defaults | **`None`** throughout | **Concrete values** throughout |
| Which default wins | The **dataclass** | The **CLI** |
| Matches the guide? | **Yes** | **No** |

`distributed_pretrain.py` is written correctly: every scalar default is `None`, the
override loop skips them, and the `TrainingConfig` dataclass values — the ones the
pretraining guide documents — are what actually run.

`distributed_finetune.py` does the opposite: its argparse defaults are concrete, so they
overwrite the dataclass on every run, including a run with no flags at all.

**Consequence:** `FINETUNING_GUIDE.md` documents `FinetuneConfig`, but the script never
uses those values. Anyone reading the guide to understand a default run reads the wrong
numbers. That is exactly what happened with `gradient_accumulation_steps` — guide says 8,
script does 4.

**Two defensible fixes, and the choice is the developing team's:**
- Make the finetune script's scalar defaults `None`, matching the pretrain script. The
  guide then becomes correct.
- Or keep the CLI defaults and update the guide to document them. They *are* the
  production run's settings, which is arguably useful.

Either is fine. The current state — two entry points with opposite conventions and a
guide that describes only one of them — is not.

---

## 6 · Minor: a debug print in the hot path

```python
# scripts/distributed_finetune.py:187-190
val = getattr(args, name, None)
if val is not None:
    print(val)                    # ← left in
    setattr(config, name, val)
```

Every run's log opens with ~40 bare values and no keys. Harmless, but it is evidence the
script was committed from a working state rather than a reviewed one — consistent with
the CLI defaults carrying the production run's settings.

---

## 7 · What to report, and how

Group these as **one finding with several instances**, not six findings. A reviewer reads
"six CLI bugs" as noise; they read "the configuration layer is inconsistent across entry
points, here are the instances" as an assessment.

> **Finding — configuration-layer inconsistency across entry points.**
> The four CLI entry points do not share a convention for how defaults resolve.
> `distributed_pretrain.py` defers to its dataclass; `distributed_finetune.py` overrides
> it. As a result `FINETUNING_GUIDE.md` documents values the script does not use — a
> default run uses `gradient_accumulation_steps=4`, not the documented 8, and
> `pool_strategy=last`, not the documented `dcnv2`.
>
> Separately, `--fp16` cannot take effect in three of the four scripts: `--bf16` carries
> `default=True` and its handler runs after and reverses the `fp16` handler, with no
> `--no_bf16` available. `evaluation/pretrain_eval.py` implements the correct pattern and
> can serve as the fix. **Consequence: model precision cannot be varied from the command
> line, which blocks precision-related reproducibility testing.**
>
> Two evaluation parameters — `true_fraud_rate` and `outsort_percentiles` — are not
> exposed by the CLI at all. `true_fraud_rate` linearly scales every reported
> `calibrated_fpr`.
>
> Three documented config fields (`amt_tag_col`, `corn_threshold`,
> `autocompute_corn_pos_weight`) are consumed nowhere.

**Impact:** low severity individually, but it means **the documented configuration is not
the executed configuration**, which undermines reproducibility from the documentation
alone. That is the sentence that matters to an MRM audience.

**Recommendation:** adopt one convention across all four entry points; propagate the
`--no_bf16` pattern from `pretrain_eval.py`; expose `true_fraud_rate`; remove or
implement the three dead fields.
