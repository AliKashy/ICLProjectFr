# 30-day plan — four weeks, four deliverables

One memo per Monday. Each one closes a question: finding → root cause → impact →
recommendation. That shape is what makes a validation deliverable rather than a status
update.

**Rule for every week:** the memo ships Monday even if the analysis is incomplete.
Mark what is open. A memo with three closed items and two open beats a perfect memo
that arrives in week four.

---

## Week 1 (tomorrow) — Inference replication

**Deliverable:** Memo 01 (template in `WEEK1_MEMO_TEMPLATE_claude.md`)

**Claim:** *Inference replicated. Scoring is not bitwise reproducible by construction;
impact on reported metrics quantified.*

Already done: the run, the discrepancy, the root cause.
Remaining: run `compare_runs_claude.py`, fill the table, ship.

If you only have your own `.npz` and not theirs, run it in single-run mode and compare
against their reported figures in the table by hand. Still a complete deliverable.

**Stretch, if time today:** re-run eval in fp32 (`--bf16` off). If fp32 reproduces
exactly and bf16 does not, the root cause moves from *inferred* to *demonstrated*. That
is a materially stronger memo and it is one extra run.

---

## Week 2 — Fine-tuning replication

**Deliverable:** Memo 02

**Claim:** *Fine-tuning cannot be reproduced on single-GPU hardware. Structural, not
configuration.*

1. Document the effective-batch arithmetic:
   `batch × grad_accum × world_size` → theirs 1024, yours 256 at the same config.
2. Re-run with `gradient_accumulation_steps = 32` to match the effective batch.
   Expect ~4× wall-clock. Start it early in the week.
3. Compare the matched run against theirs. It will still differ — per-rank seeds
   (`seed + rank`), different data sharding, gradient averaging vs accumulation.
4. **Ask the developer for a single-GPU reference run.** The controlled reconstruction
   in `project_communication/` was itself run on one GPU, so the precedent exists.

The deliverable is the *explanation plus the matched attempt*, not a matching number.
"Here is precisely why this cannot match, and here is the closest achievable" is a
complete answer.

---

## Week 3 — Leakage ablations

**Deliverable:** Memo 03 — **this is the highest-value week**

**Claim:** *Reported performance does / does not depend on information unavailable at
scoring time.*

Three runs, each changing one thing:

| Run | Change | Question answered |
|---|---|---|
| A | Baseline (as delivered) | Reference |
| B | `mask_all_txn_labels=True` | Does it depend on historical fraud labels? |
| C | `INACTV_DT` / `days_since_status_dt` removed or masked | Does it depend on the leaky status-date feature? |

Report UDR/VDR at 0.6% for each. **If B or C collapses, that is the most important
finding your team will produce on this model** — and it is the exact concern the
developer themselves raised (COM-013: v22b *"should not be used in current form because
of potential leakage from card inactive date"*).

The ablation switches already exist in `FinetuneConfig`. They were put there so this
question could be answered.

---

## Week 4 — Synthesis

**Deliverable:** Consolidated validation findings

Pull Memos 01–03 into one register. Use the format already in
`project_communication/TFM_V22B_Finalized_Package_PARTIAL.md`: every claim tagged
**Supported / Not verified / Contradicted**, with the evidence path.

Copying that structure is deliberate — it is your organisation's own format, so it
reads as native rather than invented.

---

## Running throughout

**The screenshot list** (`SCREENSHOT_REQUESTS_claude.md`) — whenever you get source
access. Resolves the Group A items so they never reach a write-up as false findings.

**The architecture walkthrough** — 30 minutes to the team on how the TFM works and the
three risks worth watching. Costs you almost nothing new; it is built entirely on
reading already done. Highest visibility-per-hour move available, and it permanently
changes how questions get routed to you.

Pitch it for week 2 or 3, once Memo 01 has established you produce evidence.

---

## What each memo proves about you

| Memo | Demonstrates |
|---|---|
| 01 | You can independently reproduce another team's work and root-cause a discrepancy |
| 02 | You understand distributed training well enough to explain why something *cannot* be done |
| 03 | You can design an experiment that tests the model's central risk |
| 04 | You can synthesise evidence into a defensible position |

That is a complete validation arc in four weeks, and it is a genuinely strong month for
anyone — let alone someone one month into the role.

---

## On learning everything

You will not learn everything in a month, and neither has anyone else on the team —
the Confluence record shows all of them ramping on this simultaneously.

What is achievable in a month: **being the person who understands this specific model
best.** That is a narrow, winnable target, and it compounds — every subsequent question
about the TFM routes through you.

Practical method: **learn against the blocker, not against the topic.** When something
stops you, learn exactly enough to get past it, write down what you learned in the memo,
move on. The depth accumulates as a side effect of shipping. Trying to learn
transformers front-to-back before producing anything is the failure mode — it feels
productive and generates nothing.

The guide is a lookup table. Use it that way.
