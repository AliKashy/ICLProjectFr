# What your run actually used — resolved

You ran `scripts/distributed_finetune.py` as supplied, following the fine-tuning guide
only for batch/accumulation. That is enough to determine your entire configuration,
because of how the script handles defaults.

---

## The mechanism: CLI defaults beat dataclass defaults

`apply_cli_overrides()` applies **any non-`None`** CLI value onto the config:

```python
for name in _SCALAR_FIELDS:
    val = getattr(args, name, None)
    if val is not None:
        setattr(config, name, val)
```

Almost every argparse default is non-`None`. So running the script with **no flags at
all** silently overwrites the `FinetuneConfig` dataclass defaults with the script's own.

**The dataclass defaults documented in `FINETUNING_GUIDE.md` are therefore not what the
script does.** This is the single most important thing to understand about the run.

---

## Your effective configuration

| Parameter | Script CLI default *(what you got)* | Dataclass default *(what the guide documents)* | Controlled run |
|---|---|---|---|
| **`pool_strategy`** | **`last`** | `dcnv2` | **`last`** ✓ |
| **`pos_class_weight`** | **20.0** | 3.0 | — |
| `use_composite_loss` | **True** | False | enabled ✓ |
| `loss_weight_bce` | 1.0 | 1.0 | 1.0 ✓ |
| `loss_weight_pairwise` | **0.5** | 0.0 | 0.5 ✓ |
| `loss_weight_approx_outsort` | 0.0 | 0.0 | 0.0 ✓ |
| `loss_weight_topk_udr` | **2.0** | 0.0 | 2.0 ✓ |
| `amount_weighted_loss` | **True** | False | enabled ✓ |
| `base_learning_rate` | **1e-4** | 1e-5 | 1e-4 ✓ |
| `head_learning_rate` | 1e-4 | 1e-4 | 1e-4 ✓ |
| `weight_decay` | 0.2 | 0.2 | 0.2 ✓ |
| `warmup_steps` | **300** | 500 | 300 ✓ |
| `max_steps` | 10,000 | 50,000 | 10,000 ✓ |
| `batch_size` | 32 | 32 | 32 ✓ |
| **`gradient_accumulation_steps`** | **4** | 8 | **4** ✓ |
| `optimizer` | muon_adamw | muon_adamw | muon_adamw ✓ |
| `eval_every_n_steps` | **500** | 200 | every 500 ✓ |
| `eval_files` | **1** | 5 | one eval file ✓ |
| `window_size` | None | None | None ✓ |
| `bf16` | True | True | BF16 ✓ |
| `files_per_batch` | **100** | 50 | — |
| `hard_negative_start_step` | **1500** | 1000 | — |

**The script's CLI defaults *are* the controlled run's configuration.** Nearly every value
matches the run snapshot in `project_communication/`. That is not a coincidence — the
script was evidently committed with the production run's settings baked in as defaults.

Fields whose CLI default is `None` (`amt_col`, `token_col`, `window_size`) are skipped by
the override loop, so they keep their dataclass values — `amt_col` stays `"amount"`,
`token_col` stays `"token_ids"`. Those are fine.

---

## 1 · Three questions now closed

### `pool_strategy` = `last`, confirmed three ways

The script default, the deck, and the project record all say `last`. So:

- **V16 (the `last_txn` padding defect) does not apply to your run.** It is specific to
  `dcnv2` / `enhanced_mlp`, where `TransactionFeatureExtractor` is instantiated. Under
  `last` pooling that class is never constructed.
- **V12 (cold-start feature zeroing) does not apply either**, for the same reason.
- **V5's ablation switches ARE inert for your run** — confirmed, not speculative.
  `use_txn_labels`, `use_vendor_score` and `use_claim_labels` are all gated on
  `pool_strategy in _SEGMENTED_STRATEGIES`. Setting `mask_all_txn_labels=True` would do
  nothing and return an identical number.

**Keep V16 and V17 in the register anyway** — they are real defects in delivered code, and
if anyone later switches to `dcnv2` they become live. But re-label them: *"applies to the
segmented pooling path, which the delivered model does not use."* That is the honest
framing and it is stronger than overstating their reach.

### `pos_class_weight` = 20.0, not 3.0

Three times the guide's documented value, and it sharpens V11 considerably. A
positive-class weight of **20** on top of training at ~12% fraud and scoring at ~0.1%
means the outputs are very far from calibrated probabilities. They are ranking scores.
Anything downstream consuming them as probabilities is consuming a number that does not
mean what it appears to.

### The composite loss was on, with the record's exact weights

BCE 1.0 · pairwise 0.5 · approx-outsort 0.0 · top-k UDR 2.0, amount weighting on. So
**V17 is live for your run** — the heaviest-weighted term was optimising median
separation rather than the 0.6% operating point.

---

## 2 · Correcting my earlier advice on accumulation

**I told you to set `gradient_accumulation_steps = 32`. That was wrong**, and it was
based on assuming a 4-GPU reference run that the record does not support.

| | batch | accum | GPUs | effective batch |
|---|---:|---:|---:|---:|
| Controlled run *(documented)* | 32 | **4** | **1** | **128** |
| Script default | 32 | **4** | 1 | **128** |
| **Your run** *(guide said 8)* | 32 | **8** | 1 | **256** |
| My earlier bad advice | 32 | 32 | 1 | 1,024 |

**You are 2× off the reference, not 4×, and the fix is to use accumulation 4 — the script
default — not 8 and not 32.**

The guide documents 8 because that is the dataclass default. The script overrides it to 4.
**You followed the guide and the guide disagrees with the code**, which is itself a
documentation finding worth reporting.

**What to do:** re-run with no `--gradient_accumulation_steps` flag at all. The script
default lands you on the controlled run's configuration exactly, at no extra wall-clock
cost. This is much better news than "run a 4× longer job."

---

## 3 · New finding — `--fp16` can never take effect, and there is no fp32 path

```python
p.add_argument("--bf16", action="store_true", default=True)
...
if args.fp16:
    config.fp16 = True;  config.bf16 = False
if args.bf16:                      # ← args.bf16 is ALWAYS True
    config.bf16 = True;  config.fp16 = False
```

`--bf16` has `default=True`, so `args.bf16` is `True` whether or not the flag is passed.
The `bf16` block runs **after** the `fp16` block and unconditionally reverses it. There is
no `--no_bf16` and no fp32 option.

**Consequence: precision cannot be changed from the command line. Every run through this
script is bf16.**

That directly affects the reproducibility test I recommended. **The fp32 control run is
not available via the CLI.** To do it you must either construct `FinetuneConfig` /
`FraudEvalConfig` in Python and set `bf16=False, fp16=False`, or edit the script.

Worth checking whether `fraud_eval.py` has the same pattern before planning that run.

It is also a clean, easily-demonstrated finding in its own right: *a documented CLI flag
that silently cannot take effect.*

---

## 4 · Minor — a debug print left in the override loop

```python
if val is not None:
    print(val)          # ← prints every overridden value to stdout
    setattr(config, name, val)
```

Harmless, but it means the run log opens with ~40 bare values and no keys. Worth one line
in the code-quality section, and it is a small piece of evidence that the script was
committed from a working state rather than a reviewed one — consistent with the CLI
defaults carrying the production run's settings.

---

## 5 · What this changes on the plan

| Item | Before | Now |
|---|---|---|
| **V16** | Possible major finding | **Does not apply** to the delivered model. Keep, re-scoped to the segmented path |
| **V12** | Phase 1, likely finding | **Does not apply.** Drop from Phase 1 |
| **V5** | Design the ablations | **Redesign required** — the injection-path switches are inert under `last`. Leakage must be tested through the token stream: `excl_past_frd`, placeholder remapping, `apply_label_delay` |
| **V11** | Calibration likely off | **Much more likely** — `pos_class_weight=20`, trained 12% / scored 0.1% |
| **V17** | Needed confirming | **Live for your run.** Weight 2.0, confirmed |
| **V2** | Re-run at accum 32, ~4× wall-clock | **Re-run at accum 4** — the script default. No extra cost |
| **Reproducibility** | fp32 control run recommended | **Not possible via CLI.** Needs a Python config or a script edit |

---

## 6 · The one-line version for your memo

> The fine-tuning script's CLI defaults override the documented dataclass defaults, and
> those CLI defaults match the controlled run's configuration exactly. Following the
> fine-tuning guide's documented value for gradient accumulation (8) therefore produced a
> configuration that differs from both the script default and the reference run (4),
> doubling the effective batch size. The guide and the code disagree.
