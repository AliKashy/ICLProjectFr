# Why the rerun didn't match exactly — and why that is a finding

Written to answer three questions: did I run it correctly, is a 0.007 difference a
problem, and why can't I reproduce the fine-tune on one GPU.

---

## 1. The evidence says you ran it correctly

The reported result was: **~84.7% of probabilities identical, ~15% differing, mean
difference ≈ 0.0, max difference ≈ 0.007.**

The **mean being ≈ 0 is the important number**, and it is good news.

A configuration error — wrong flag, wrong architecture, mismatched tokenizer, a head
built differently — produces a **systematic shift**. Scores move consistently in one
direction, or a subset moves a lot. You would see a non-zero mean, or a long tail.

Symmetric noise centred on zero with a small bounded maximum is the signature of
**floating-point non-determinism**, not of a misconfiguration. Those are different
shapes and this one is the benign shape.

Two further confirmations from the code:

- `evaluation/fraud_eval.py:147` calls `model.eval()`, so dropout is disabled. If
  dropout had been left active the differences would be far larger than 0.007 — that
  possibility is ruled out.
- Eval does **not** re-tokenize. It touches the tokenizer only to read three IDs:

  ```python
  pad_id = tokenizer.vocab[tokenizer.config.pad_token]
  gap_id = tokenizer.vocab[tokenizer.config.gap_token]
  bos_id = tokenizer.vocab[tokenizer.config.bos_token]
  ```

  The eval parquets are already tokenized. So the `fill_missing` / `add_mask_token`
  values set to get the tokenizer to load **cannot have affected the scores**. They
  are stored as flags and never consulted during scoring.

  Additionally, `Tokenizer.load()` builds a vocabulary in `__init__` and then
  **overwrites it** with the contents of `vocab.json`:

  ```python
  tokenizer = Tokenizer(config, fill_missing=fill_missing, add_mask_token=add_mask_token)
  tokenizer.vocab = vocab                       # ← loaded file wins
  tokenizer.vocab_size = len(vocab)
  ```

  So those flags cannot shift token IDs either. **The corrections were harmless.**

**Caveat worth keeping:** those flags *do* matter if raw data is ever tokenized through
the pipeline. Harmless for scoring pre-tokenized parquets, not harmless in general.
And the fact that the supplied `config.json` lacked keys the loader requires is itself
worth noting — it suggests the tokenizer was saved by a different code version than the
one supplied.

---

## 2. Why the difference exists

**The codebase sets no determinism flags anywhere.** There is no
`torch.use_deterministic_algorithms(True)`, no `torch.backends.cudnn.deterministic`.
`set_reproducibility_seed()` sets the Python, NumPy and Torch seeds and stops there:

```python
def set_reproducibility_seed(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
```

Seeds control *sampling*. They do not make GPU arithmetic deterministic. Three
mechanisms produce run-to-run variation regardless of seed:

**Floating-point addition is not associative.** `(a + b) + c` and `a + (b + c)` can give
different results in finite precision. GPU reductions sum thousands of values in
whatever order the kernel's thread scheduling produces, and that order is not fixed
between runs. Every matrix multiply and every attention reduction is affected.

**bf16 has very little mantissa precision.** `bf16: bool = True` is the default in
`FraudEvalConfig`. bfloat16 carries roughly 2–3 significant decimal digits. Differences
of 0.007 in a value between 0 and 1 sit comfortably inside bf16's accumulation error.
This is the dominant factor.

**Batch composition changes reduction order.** Sequences are padded to the longest in
their batch. Different batching → different padding → different reduction order →
different last-digit results. **If their run used 4 GPUs and yours used 1, the examples
were sharded differently and every batch had different contents.** That alone explains
the discrepancy.

The 15% / 85% split is consistent with this: most outputs happen to land on the same
representable float, some do not.

---

## 3. Both positions are correct — and that is the finding

**Your instinct** — "a little difference is expected" — is technically right. Given
bf16 on GPU with no determinism flags, bitwise reproduction is not achievable.

**The team's position** — "it should be exactly the same" — is right as a *validation
standard*. Model risk management generally requires that a result can be regenerated on
demand. If it cannot, it cannot be attested to.

These do not contradict each other. The resolution:

> **The model's scoring is not bitwise reproducible, by construction. That is a property
> of the implementation — no determinism controls, bf16 inference — not an error in the
> replication.**

That is a legitimate, reportable validation finding, and it is *stronger* than "the
numbers matched," because it identifies a real gap in the model's operational controls
that nobody had documented.

---

## 4. The test that settles whether it actually matters

0.007 sounds negligible. Whether it *is* negligible depends entirely on one thing:
**does it change the ranking at the outsort cutoff?**

The metric is UDR/VDR at the top 0.6% of scores (Part 1.3 of the main guide). Near that
boundary, scores are densely packed — with a large population, thousands of transactions
may sit within 0.007 of each other. A perturbation that size could move transactions
across the line in either direction.

**So compute the metrics on both runs and compare:**

| | Run A (theirs) | Run B (yours) | Δ |
|---|---|---|---|
| AUC | | | |
| KS | | | |
| **UDR @ 0.6%** | | | |
| **VDR @ 0.6%** | | | |
| FPR @ 0.6% | | | |
| Count of transactions crossing the 0.6% boundary | — | — | |

Two possible outcomes, and **both are a good result**:

- **Metrics identical to 4+ decimal places** → the wobble is cosmetic. You have
  demonstrated that the reported performance is stable under non-determinism, which is
  exactly what a validator needs to say. Finding downgraded to an observation.
- **Metrics move** → the reported UDR/VDR carries an error bar nobody has quantified.
  That is a material finding and a genuinely valuable catch.

You already have what you need: `--store_logits` writes `eval_logits.npz` with
`logits`, `labels`, `amounts` and `fi_transaction_ids`, and the metric functions in
`utils/fraud_metrics.py` are pure NumPy with no model dependency. You can compute this
offline from two `.npz` files without re-running the model.

### If you want to reduce the non-determinism

- Run in **fp32** (`--bf16` off). Slower, much tighter numerically. If fp32 reproduces
  exactly and bf16 does not, that pins the cause precisely — a clean, demonstrable result.
- Set `torch.use_deterministic_algorithms(True)` and
  `torch.backends.cudnn.deterministic = True`.
- Match the batch size and GPU count of the original run.

**Not matching is not a failure.** Demonstrating *why* it does not match, and *whether it
matters*, is the actual work.

---

## 5. Steps vs epochs

Nothing is wrong here — this codebase simply does not use epochs.

**Epoch** = one complete pass through the dataset. **Step** = one parameter update.

`max_steps: 10000` means: perform 10,000 parameter updates, then stop, regardless of how
much data that consumed. Large-model training is specified this way because the dataset
is usually too large to pass through even once — with 5,000 parquet files you will likely
never complete a single epoch, so "epochs" stops being a useful unit.

How much data 10,000 steps actually covers:

```
examples seen = max_steps × batch_size × gradient_accumulation_steps × num_gpus
```

At batch 32, accumulation 8, 1 GPU: `10,000 × 32 × 8 × 1 = 2,560,000` examples.

If the 5,000 parquets hold, say, 5 million rows, that is roughly **half an epoch**. This
is intended. The project record has the developer saying so directly (COM-008): *"TFM
often converges earlier and does not require the full training data."*

---

## 6. Why the fine-tune cannot match on one GPU

**First, a distinction the guides blur.** Running on one GPU *is* documented and
supported. `FINETUNING_GUIDE.md` has a "CLI (Single GPU)" section (line 160) showing
`python src/scripts/distributed_finetune.py` without `torchrun`, and the code handles it
cleanly — `init_distributed()` returns `world_size=1, distributed=False` when `RANK` and
`WORLD_SIZE` are unset, and the trainer skips the DDP wrapper, the per-rank sharding and
the `no_sync` path. Nothing breaks.

What is **not** documented is that a single-GPU run will not produce comparable results
to a multi-GPU run at the same configuration. Neither guide mentions `world_size` in
relation to batch size; the phrase "effective batch size" does not appear in either
document. The only single-GPU guidance in the troubleshooting table reads:

> | **Slow training** | Large model on single GPU | Enable `bf16`, try `use_compile=True`, use `torchrun` with multiple GPUs |

— which advises acquiring more GPUs, not an option when validation hardware is fixed.

So: *how to run on one GPU* is documented. *How to run on one GPU and get results
comparable to theirs* is not, and that is the actual question.

**This gap is itself a reportable finding.** The documentation supports single-GPU
operation without warning that reported metrics are not reproducible under it. Anyone
following the guide as written would reasonably expect comparable numbers and would not
get them.

The underlying issue is structural, not a setting you can simply correct.

With DDP, **the effective batch size multiplies by the number of GPUs**:

```
effective batch = batch_size × gradient_accumulation_steps × world_size
```

| | batch | accum | GPUs | effective batch | examples in 10k steps |
|---|---|---|---|---|---|
| Their run (4 GPUs) | 32 | 8 | 4 | **1024** | 10.2M |
| Your run (1 GPU, same config) | 32 | 8 | 1 | **256** | 2.6M |

Running their config on one GPU trains with a **4× smaller effective batch** and sees
**4× less data** in the same 10,000 steps. Different gradient noise, and a learning-rate
schedule tuned for a different batch size. **Different results are the expected outcome,
not your error.**

### To get closer

Set **`gradient_accumulation_steps = 32`** (their 8 × their 4 GPUs). That restores the
effective batch to 1024 and the data volume to ~10.2M examples. Each step takes ~4×
longer, so the wall-clock time is comparable to their full job — you are trading
parallelism for time, which is the correct trade.

### Why it still will not match exactly

Three reasons, none of them fixable:

1. **Seeds are per-rank.** The trainer calls `set_reproducibility_seed(config.seed + self.rank)`.
   Four GPUs use seeds 42, 43, 44, 45. One GPU uses only 42. Different dropout masks,
   different shuffling.
2. **Data sharding.** `train_examples[start:start + per_rank]` gives each rank a
   contiguous slice after stratified interleaving. With `world_size=1` there is no
   slicing, so examples arrive in a different order and different groupings.
3. **Gradient averaging.** DDP averages gradients across ranks. Accumulation sums them
   locally. Mathematically similar, numerically not identical.

**Exact reproduction of a 4-GPU run on 1 GPU is not achievable with this code.** That is
worth stating plainly in the validation write-up rather than treating as an open item —
and it is worth asking the other team whether they can supply a single-GPU reference run,
since the controlled reconstruction in `project_communication/` was itself run on one GPU
("Effective batch size 128 on one GPU").

---

## 7. What to say to the team

Three statements, all defensible:

1. **Inference was replicated.** 84.7% of scores matched bitwise; the remainder differed
   by at most 0.007 with a mean difference of ≈0. The distribution of differences is
   symmetric noise, which is the signature of floating-point non-determinism rather than
   a configuration mismatch.
2. **The model is not bitwise reproducible by construction.** No determinism controls are
   set anywhere in the codebase, and inference defaults to bf16. This is a gap in
   operational controls, not a replication error.
3. **Metric impact is being quantified.** UDR/VDR at the 0.6% outsort will be computed on
   both runs to establish whether the variation is material or cosmetic.

And one open item:

4. **The fine-tune cannot be reproduced on one GPU.** Effective batch size scales with GPU
   count, so the same config trains differently. A matched-effective-batch run
   (`gradient_accumulation_steps=32`) is the closest achievable, and even that will not
   match exactly because seeds are per-rank and data sharding differs.
