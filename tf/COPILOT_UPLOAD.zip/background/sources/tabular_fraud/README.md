# Tabular Fraud Detection

Fraud detection using FT-Transformer with optional history-aware sequential modeling.

## Project Structure

```
tabular_fraud/
├── src/pytorch_tabular/       # Forked from pytorch_tabular v1.1.0
│   └── models/
│       ├── ft_transformer/    # Existing FT-Transformer
│       └── ft_transformer_seq/  # Phase 2: Sequential FT-Transformer
├── fraud/
│   ├── data/
│   │   ├── parquet_loader.py    # S3 parquet streaming dataset
│   │   └── sequence_builder.py  # Transaction sequence builder
│   ├── configs/
│   │   ├── smoke_test.yaml      # Individual transaction config
│   │   └── sequential.yaml      # History-aware config
│   └── scripts/
│       ├── train_baseline.py    # Phase 1: train on individual transactions
│       └── train_sequential.py  # Phase 2: train with transaction history
├── tests/
├── docs/
├── requirements.txt
└── pyproject.toml
```

## Quick Start

### Phase 1: Baseline (Individual Transactions)

```bash
# Install
pip install -e .

# Train
python fraud/scripts/train_baseline.py --config fraud/configs/smoke_test.yaml \
    data.train_path=/path/to/train.parquet \
    data.val_path=/path/to/val.parquet \
    data.test_path=/path/to/test.parquet
```

### Phase 2: Sequential (History-Aware) — Coming Soon

```bash
python fraud/scripts/train_sequential.py --config fraud/configs/sequential.yaml
```

## Background

See [docs/fraud_detection_plan.md](../saint/docs/fraud_detection_plan.md) for the full project plan and benchmark results.
