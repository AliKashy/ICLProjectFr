# Meeting Notes & Next Steps — Fraud Detection Project

Running notes from discussion (2026-10-05), consolidating points raised about preprocessing,
feature engineering, encoding strategy, training approach, and infrastructure questions.
Companion to the full project write-up: [project_writeup.md](project_writeup.md),
[phase4_progress.md](phase4_progress.md).

---

## 1. Preprocessing artifacts — expand the fitting range

- Currently, preprocessing artifacts (continuous medians/std, categorical vocab) are fit on only
  **5 parquet files** (`part_1..5`), used in full (no row sampling).
- **Proposal:** increase this to more files for more stable medians and better categorical vocab
  coverage (fewer values falling into UNK).
- **Trade-off to flag:** this produces a **new artifact version**. Every checkpoint/result so far
  was trained against artifact version 1 (fit on `part_1..5`) — switching versions means
  **everything trained so far would need to be retrained** against the new artifacts to stay
  comparable. Treat as a deliberate reset point, not a drop-in swap mid-sweep.
- **Status:** not yet done; config-only change (`fraud/configs/preprocessing.yaml`), no code change needed.

---

## 2. Categorical encoding for high-cardinality features (merchant ID, zip code, etc.)

- These fields (`merchant_category_xcd`, `merchant_postal_xcd`, `merchant_state_xcd`,
  `atm_network_xid`, etc.) are **currently excluded entirely** from the 23-feature list —
  deliberately excluded in the original plan due to high cardinality.
- **Front-line has already done work here** — they used **frequency encoding** and **target
  encoding** (encoding each category by its historical fraud rate) on these same kinds of fields.
- **For neural networks specifically, target encoding is said to be the better choice**, because:
  - Frequency encoding only captures how common a category is — no signal about fraud correlation.
  - Target encoding directly hands the network a pre-computed fraud-rate signal per category,
    avoiding a huge/sparse embedding table for rare categories.
  - Target encoding **effectively converts the categorical field into a continuous feature**
    (one numeric value per category) — so technically it would be wired into the continuous
    side of our preprocessing pipeline, not the categorical/vocab side used today.
- **Neither frequency nor target encoding is implemented in this codebase yet** — both are
  documented as pluggable placeholder options only (alongside hashing, capped-vocab+UNK).
- **Staged rollout plan (per Xiaming):** don't fit target encoding on the full historical range
  immediately — pilot it first on a small range (**5–10 parquet files**, matching the scale
  already used elsewhere), validate it, **then** refine/re-fit using all historical files.
- **Feature prioritization:** rather than adding every high-cardinality field at once, use
  front-line's existing feature-importance ranking (**reference: 15298 MDD**) to identify and
  focus on their top features first.
  - **Caveat:** front-line's importance ranking is based on **their own engineered features**,
    but only **raw fields are available at inference time** — each important engineered feature
    needs to be traced back to the raw source column(s) it came from before we can add it here.
  - **Caveat:** the in-house foundation model's feature importances may also be based on
    **derived features** rather than raw ones. Since categorical encoding there can expand one
    raw column into many dimensions, their "top features" could correspond to **a couple hundred
    post-encoding dimensions**, not a couple hundred raw columns — this needs to be unpacked
    before it's usable as a prioritization source.
- **Action items:**
  1. Implement target encoding (fit train-only + smoothing) as a new preprocessing artifact type.
  2. Pilot on 5–10 files first; validate before expanding to full history.
  3. Pull front-line's 15298 MDD feature-importance list; map engineered → raw columns.
  4. Cross-check against the in-house foundation model's importances, accounting for the
     derived/post-encoding dimension-count caveat above.
  5. Optionally implement frequency encoding too, so it can be ablation-tested against target
     encoding on this dataset (does the "target encoding is better for NN" claim hold here).

---

## 5. Infrastructure questions

- **Are we using Spark?** No — confirmed not in `requirements.txt` and not used anywhere in the
  actual pipeline. The only mention is a docstring comment in `score_eval.py` describing Spark as
  a **hypothetical future fallback** for computing metrics if the eval scale ever grows to
  hundreds of millions of rows — not something running today. Current metrics are computed with
  plain `sklearn` over streamed, memory-bounded parquet reads (`s3fs` + `pyarrow`).
- **"Karpathy autoresearch"** — raised as a possible technique/tool to leverage (reportedly used
  by Xiaming for some autoresearch). **Not found anywhere in this workspace**, and not something
  I have reliable/confirmed information about as a specific named tool — asked for
  clarification (link, exact name, or more detail from what Xiaming described) and did not get
  an answer yet. **Open item: needs a source/link before it can be evaluated or acted on.**
  - **Proposed experiment (once clarified):** try using it for **feature-engineering work** —
    i.e., an agent-driven process that suggests candidate features (or combinations/transforms
    of existing raw columns) for us to evaluate, rather than us hand-picking every feature
    manually. Would slot in alongside the §2 feature-prioritization work (front-line's 15298 MDD
    list) as another candidate-generation source, not a replacement for it.

---

## 6. Already-tracked items (cross-reference, not duplicated here)

The following were raised earlier and are already recorded in [project_writeup.md](project_writeup.md)'s
Next Steps section: including more features generally, more training data (scale past 100-file),
larger network (capacity ablation's "large" setting), extracting CLS token embeddings. See that
doc for details — not repeated here to avoid drift between the two documents.

---

## Open items / needs follow-up

1. Get the exact link/name for "Karpathy autoresearch" before evaluating it.
2. Get access to front-line's 15298 MDD feature-importance document.
3. Decide artifact-version strategy (if/when expanding the preprocessing fitting range beyond 5 files) — this is a reset point affecting every existing result.
4. Decide whether target encoding pilot (5–10 files) happens before or after the still-pending
   time-delta/capacity ablations and the h10 100-file confirmation run (sequencing not yet decided).

---

## 7. Meeting with Xiaoming and Yaqun — 2026-10-06

### Raw notes (as given, lightly grouped)

- We want more features; longer transaction histories. Yaqun has this on his document already.
- Look at more features: feature importance **v22_v17**; debit card **15298**, top 10 features;
  **CHP models**; derived transaction-level (and categorical) variables — front-line did
  frequency-based encoding on these. Reference: **Table 2.35, "summary of the top 10 features,"
  page 93**.
- **Xiaoming's warnings:**
  - Target encoding — can't have too many of them, because they end up highly correlated with
    each other.
  - "It might be 94; the XGBoost LOB" (unclear fragment — see open questions below).
  - Need a **chip-card feature**: count how many authorizations have been done for this specific
    chip-enabled card.
  - "Useful one is we need to coarse through" (unclear fragment — see open questions below).
  - Example of a problem case: a counter shows 1000 today but was 2000 yesterday — flagged as an
    issue (exact mechanism not yet clear).
  - Cards can be fake/spoofed — risky to lean on raw card-identifying fields directly as a fraud
    feature for that reason.
  - Proposal raised: for today's transaction, use **yesterday's** feature value (a lagged
    aggregate) instead of a same-day/real-time one.
  - "The content itself does not contain signal" (unclear referent — see open questions below).

### Approach for introducing new features

- Start from the **raw features MMR already provided** (the `tfm_raw_data` / `tfm_EVAL_raw_data`
  source columns, same source the current 23-feature list is drawn from) rather than inventing
  new source columns from scratch.
- Get reference/background knowledge on those raw fields (what each one actually represents,
  how it's generated upstream) before engineering derived features from them — same spirit as
  the 15298 MDD feature-importance document, used as a reference to understand and prioritize,
  not just a list to copy from blindly.

### Follow-up questions raised (not yet answered)

1. What does **"Feature importance v22_v17"** refer to — two model versions being compared, or a
   specific named document?
2. What does **"CHP models"** stand for?
3. What is the full source for **"Table 2.35... page 93"** — presumably within the 15298
   document, but not confirmed.
4. What does **"It might be 94; the XGBoost LOB"** mean in full?
5. Did "coarse through" mean **review/go through** a list, or **coarsen/bucket** a feature?
6. For the counter example (1000 today, 2000 yesterday) — what specifically breaks: a
   non-monotonic/reset counter, a data-quality issue, or a leakage risk?
7. Was "use yesterday's feature value" a decision, or still an open proposal?
8. What does **"the content itself does not contain signal"** refer to (raw card number? raw
   free-text field? something else)?

### Target encoding — introducing it to cover currently-excluded high-cardinality fields

- Current state (per §2 above): high-cardinality categorical fields (merchant ID, zip/postal
  code, state, ATM network, etc.) are **excluded entirely** from the 23-feature list today.
- Proposal: introduce target encoding specifically so these fields **no longer need to be
  excluded** — target encoding avoids the huge/sparse embedding table problem that justified
  excluding them in the first place.
- Xiaoming's caution above applies directly here: don't target-encode too many fields at once,
  since target-encoded columns tend to be highly correlated with each other.

### "Days since" features — checked, not currently included

- Checked `predictors.csv` (23 features) and the sequence pipeline directly: the only time-based
  feature anywhere is `time_delta` in `sequence_builder.py` — log-seconds since the *previous*
  transaction in the current history window.
- There is **no** "days since first transaction" / account-tenure feature anywhere in the
  codebase today. It would need a per-account *first-ever* transaction timestamp, which requires
  a lookup across an account's full history — something the current window-only pipeline doesn't
  have, since `sequence_builder.py` only ever sees the current N-transaction window.
- Not yet designed: where this lookup would be computed (preprocessing-time derived column vs.
  its own artifact step).

### Delta features on raw continuous fields — proposed, not implemented

- Idea: beyond `time_delta` (a delta on *time*), compute deltas on the raw continuous value
  fields themselves, the same way, using the same windowing mechanism already in
  `sequence_builder.py` (`_windows_for_file`).
- Natural candidates from the current 23 features: `transaction_amt`, `total_available_balance_amt`,
  `available_daily_cash_limit_amt`, `avlble_merch_day_cash_lmt_amt`,
  `remain_day_merchandise_lmt_amt`, `external_1_scr`.
- Not yet implemented — would need its own config flag (e.g. `sequence.value_deltas: [...]`) and
  a small addition alongside the existing `time_delta` computation.

### Rolling lookback window (e.g. last 90 days) — proposed, not implemented

- Problem raised: a customer-merchant relationship can be 10 years old, 1 year old, or 90 days
  old. Using a fixed transaction-count history window (h5/h10/h15/h20, as done today) doesn't
  normalize for this — a longstanding account and a brand-new one aren't treated comparably.
- A pure time-since-first-transaction feature (see above) would also run into a related problem:
  if the account's first transaction happened, say, 4 months ago, a fixed window anchored to "the
  beginning" would behave inconsistently across accounts of very different ages.
- Proposal: use a **rolling time-based lookback window** (e.g., "last 90 days" of transactions)
  instead of, or alongside, the current fixed transaction-*count* window — so every account is
  evaluated over the same span of calendar time, regardless of how long it's actually existed.
- Not yet implemented. This would be a real change to the windowing contract in
  `sequence_builder.py`, which currently windows by **transaction count** (`history_len`), not by
  elapsed time — worth a design discussion before building, since it changes how padding, the
  attention mask, and `time_delta` itself would all need to behave (e.g. what padding means when
  the window is time-bounded instead of count-bounded, and how many transactions can actually fall
  inside a fixed time span for a very active vs. very inactive account).

