# Waqas — FT-Transformer Fraud Work (master plan)

> **This folder (`waqas/`) is my work, kept fully isolated from Yaqun's.** Yaqun's base in `fraud/` is never edited. Anything I changed is duplicated into my phase folders; anything of his I use unchanged is imported directly from `fraud/`.

## The project: the best FT-Transformer for fraud

One model, improved along five levers. We do **not** build competing model families — the baseline to beat already exists (the internal XGBoost debit-card model).

| Lever | What it tunes | Options |
|---|---|---|
| Architecture | how transformer consumes history | **4a flat** vs **4b hierarchical** |
| Input representation | how features become tokens | numerical embedding: linear / periodic / PLE |
| Context | what model sees | history h5/h10/h16; time encoding |
| Training recipe | how optimized | optimizer, EMA, loss, sampling (keep-all-fraud + downsample) |
| Pretraining encoder | initialization | from-scratch vs masked-AE (SSL) vs SupCon |

Levers 2–4 are knobs inside 4a/4b. Lever 5 is its own phase.

## Fraud rate (measured, 2026-10-03)

| Range | Fraud rate | Source |
|---|---|---|
| **Train** (`tfm_raw_data`, files 1–100) | **0.1654%** (143,338 / 86,683,008) | `count_train_fraud.py` |
| **Eval** (`tfm_EVAL_raw_data`, files 8000–8010) | **0.155%** (3,818 / 2,466,461) | `score_sequential.py` |

Close to each other — no distribution-shift red flag. Train/eval use separate S3 buckets, no overlap.

### Lever 4 sampling recipe (institutional pattern, adopted)

The payment foundation model team trains with **all fraud rows kept + non-fraud downsampled to ~12% fraud**, then evaluates at the **true undownsampled rate**.

```text
fraud rows (keep all) = 143,338
target fraud fraction = 0.12
non-fraud to sample = 143,338 * (1 - 0.12) / 0.12 = 1,051,813 (~82x downsample)
resulting training set = ~1.2M rows (down from 86.7M)
```

**Must recalibrate scores back to the true rate before comparing valid_ap/eval_ap.** Training at 12% fraud shifts predicted probabilities, so raw outputs are not comparable to a model trained at the true 0.1654% without calibration (e.g. Platt scaling or prior correction). This recipe is **not yet implemented** in phase4a/phase4b; it is an open Lever-4 experiment after the architecture/history sweep settles.

## Folder structure

```text
fraud/                 # Yaqun base — untouched
waqas/
  docs/
    waqas_roadmap.md
    waqas_phase4a_guide.md
    waqas_phase4b_guide.md
    waqas_phase5_guide.md
  phase4a/             # flat FT-Transformer (Architecture A)
    sequential.py
    tokenizer.py
    optim.py
    numerical_embeddings.py
    callbacks.py
    scripts/
    configs/
  phase4b/             # hierarchical FT-Transformer (Architecture B)
    sequential_hier.py
    tokenizer.py
    optim.py
    numerical_embeddings.py
    callbacks.py
    scripts/
    configs/
  phase5_pretrain/     # Lever 5: SSL + SupCon
  scoring/             # leaderboard, temporal eval, calibration
  run_remaining.ps1    # temporary helper for not-yet-completed sweep configs
```

### Isolation rules

- **Unchanged Yaqun files** (data loaders, `sequence_builder`, preprocessing, base callbacks, `log_utils`) → imported from `fraud/`, never copied.
- **Files I changed** (flat model, tokenizer with periodic embeddings, optimizer factory, numerical embeddings, EMA callback) → duplicated into each phase folder that uses them. 4a and 4b each carry their own copies, even if identical.

## What's in / out

- **In scope:** 4a flat, 4b hierarchical, phase5 pretraining (SSL + SupCon), scoring tooling.
- **Baseline to beat:** internal XGBoost debit-card model.
- **Deferred:** payment foundation model — separate tokenized architecture (discrete token IDs, 2048-token cap), not weight-compatible with FT-Transformer. A comparison, not an ingredient.
- **Dropped:** our GBDT, TabM, EmDT (diffusion→tree), THGT (graph transformer), and serving (no real code exists).

## Architecture A vs B

- **Flat (A):** every field-token of every transaction enters one flat sequence (`[CLS] [txn-5 fields] .. [txn0 fields]`). Sequence length = T × fields; attention cost grows with fields × transactions, so full-batch runs OOM past ~h10.
- **Hierarchical (B):** stage 1 encodes each transaction to one vector; stage 2 attends over T transaction-vectors. Length = T; scales with transactions only, like the payment foundation model. Right home for long history.

## History definition

For each scored target, the model sees that **account's N most recent prior transactions**, strictly earlier, left-padded if fewer than N. Limit is transaction **count**, not time. Past transactions contribute features but **not fraud labels**. `history_len=16` = 16 prior + current = 17 total, matching the PFM team's best 17-transaction window.

## Sweep plan

| | 4a flat | 4b hier |
|---|---|---|
| **h5** | done — winner `linear + bidir + adamw`, `valid_ap 0.1365` | to run |
| **h10** | to run (batch 1024×4, memory-safe) | to run (full batch) |
| **h16** | to run (batch 256×16, slow) | to run (full batch) |

- **4a finder:** `ft_decisions.yaml` — embedding × mask × optimizer at h5.
- **4a long history:** `ft_decisions_flat_long.yaml` — winner knobs, h10 + h16.
- **4b:** `ft_decisions_hier.yaml` — winner knobs, h5/h10/h16.

Finding so far: embedding is the only lever that matters (linear > periodic); mask and optimizer are within noise; Architecture A is saturated (~0.12–0.14 valid_ap).

## Reproducibility & already-run tests

Canonical configs define the **full sweep from scratch**. Nothing is hard-wired to resume. A temporary `waqas/run_remaining.ps1` runs only not-yet-completed configs (flat h10, flat h16, all 4b) to avoid recomputing finished flat h5 work; canonical path remains the full configs.
