# Feature metadata — batch 124–248

Source workbook: `meta data ALL features provided by LoB.xlsx`, worksheet `Sheet1`.
Source: [Dropbox photograph batch](https://www.dropbox.com/scl/fo/rxskjaz6d46l27la8gn52/AD6tUcni4l5vqgm2SRVO34Y?rlkey=urhsrbv84nibx1smnf0d12j6x&dl=0) — 212 distinct JPG photographs.
Intended destination: private `AliKashy/tabular_fraud`, `waqas/feature_related/part_124_248/`.

## Files

- `feature_metadata_rows_124_248.xlsx`: original A:G headers and cell addresses on `Sheet1`; compact `Merge_Data` sheet with `original_row`; `Verification` sheet listing exact cell exceptions.
- `feature_metadata_rows_124_248.csv`: 125 records, keyed by original Excel row, with all seven original metadata columns.
- `unresolved_cells.csv`: 10 unobserved rightmost-column values.
- `row_sources.csv`: row-to-photograph index references.
- `source_photographs.csv`: all 212 filenames and SHA-256 hashes.
- `SHA256SUMS.txt`: deliverable hashes.

## Coverage and remaining source gaps

Rows 124–248 are represented exactly once (125 distinct feature names). All 750 positions in A:F are transcribed or visibly blank. Of 125 `MIFM_feature` flags in column G, 115 are transcribed and 10 are unresolved.

Unresolved original cells: `G130`, `G131`, `G132`, `G198`, `G199`, `G212`, `G213`, `G214`, `G215`, `G216`.

These cells are blank and yellow in the workbook and listed in `Verification` and `unresolved_cells.csv`. They are NOT `No` and are NOT confirmed source blanks. Their values were not located in the supplied photographs. No flags were inferred from neighboring rows or feature names.

Known source blanks `C149` and `F149` are preserved separately.

## Merge instructions

`Sheet1` retains original columns A:G and rows 124–248. Rows 2–123 have a collapsed, approximately 0.1-point display height because they are outside this batch; this does not assert that those original rows were blank. No data from other parts is inserted.

`Merge_Data` and the CSV use the explicit `original_row` key. Join on that key, not on the compact sheet's physical row positions. Resolve overlapping records against original photographs; do not silently overwrite another batch.

## Fidelity and validation

This is a visible-cell-text reconstruction, not the original XLSX binary. Source spelling, capitalization, readable multiline descriptions and field-name typos are retained, including `model_dt_*`, `deposite` and `prev_bus_day_txt_count`. Exact invisible whitespace, unshown formulas/metadata, hidden content and original display dimensions cannot be established from photographs. Display formatting is reconstructed for readability.

The exported XLSX was checked against the transcription matrix at all 875 original data positions and every compact merge record. The CSV was checked against the same matrix. Original row IDs are continuous and unique; feature names are unique; original dtype strings are retained. Verification formulas evaluate to 125 rows, 875 positions, 865 transcribed-or-confirmed-blank cells and 10 unresolved cells. The formula-error scan found no errors. Source-data and verification ranges were rendered and visually inspected.

No model runs, source-code changes, or changes to other batches are included.
