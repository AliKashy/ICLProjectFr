# Feature metadata — original rows 249–600

Source: `meta data ALL features provided by LoB.xlsx`, `Sheet1`.
Dropbox: https://www.dropbox.com/scl/fo/j1xqpowvjnt87myev183p/ANCt2eP0oLJlB-gKQ--9_ZI?rlkey=f33cx9mj117ghf34xh6ggopz9&dl=0
Photographs: 119, indexed in `source_photographs.csv` with original filenames and SHA-256 checksums.
Intended repository destination: `waqas/feature_related/part_249_600/` in private `AliKashy/tabular_fraud`.

## Scope and coverage

This batch represents exactly 352 original worksheet rows (249–600), not the entire ~714-row source workbook. It does not alter the earlier 124–248 batch or any later batch.

- 351 rows have all seven A:G source positions captured.
- Row 274 has only G (`No`) captured. A274:F274 remain unresolved, blank, and yellow in the workbooks. They are **not** confirmed source blanks and were not filled by inferring the neighboring naming pattern.
- Total: 2,458 captured or source-confirmed-blank positions out of 2,464. The six exceptions are in `unresolved_cells.csv` and each relevant workbook's `Verification` sheet.
- Source-confirmed blank D291 and F291 are distinguished from the unresolved cells.

## Files and split delivery

- `chunks/rows_249_424/feature_metadata_rows_249_424.xlsx` and matching CSV: first 176 original rows; six exceptions at row 274.
- `chunks/rows_425_600/feature_metadata_rows_425_600.xlsx` and matching CSV: next 176 original rows; no unresolved source positions.
- `feature_metadata_rows_249_600.xlsx` and matching CSV: the two halves combined in original row order. The merged CSV was checked against the concatenation of the two separately saved half CSVs.
- `transcription_checkpoint.json`: persisted value-and-photo-source matrix for recovery or later verification.
- `cell_sources.csv`, `row_sources.csv`, `source_photographs.csv`: auditable source mapping.
- `validation.json`, per-half `validation.json`, and `SHA256SUMS.txt`: structural checks and file identities.

Every workbook contains `Read_Me`, `Sheet1`, `Merge_Data`, and `Verification`. `Sheet1` preserves original A:G headings and Excel row addresses. Rows preceding the scoped range are compressed and outside scope; they are not source blanks. `Merge_Data` and CSV use explicit `original_row` identifiers.

## Fidelity and validation limits

This is a visible-text reconstruction from photographs, not the original XLSX binary. Source spelling, capitalisation, dtype labels, multiline text, and inconsistencies were retained. Examples include A552's `userdata24` versus D552's `userdata14`, the word `importan` in row 549, and the original phrasing in long descriptions. No model code or source feature definitions were repaired or improved.

Invisible whitespace, unshown metadata/formulas, and original workbook dimensions cannot be proven from photographs. Display formatting was recreated for readability. Saved XLSX source/compact cells and exported CSV records were checked against the transcription matrix. Formula summaries evaluated to the expected row and exception counts, and standard-library XML readback found no Excel error cells. Those checks do not constitute an independent rereading of every photographed character.

For later merging, join on `original_row`, not physical row positions in `Merge_Data`. Reject duplicates and inspect the explicit unresolved cells rather than replacing them with default values.

## Transfer packaging

For reliable chunked transfer, the three XLSX ZIP containers were repackaged with stored (uncompressed) members. Every internal workbook XML member is byte-for-byte identical to the previously delivered workbook. No worksheet values, styles, formulas, or source-cell addresses changed. The checksum file identifies these published containers. Source CSVs and transcription records retain their original bytes.
