# feature_importance_v22_v17_highlighted

This folder is an LLM/GitHub-Copilot-friendly reconstruction of the spreadsheet photographed in Dropbox at:

`/tabular_fraud/waqas/Features/feature_importance_v22_v17_highlighted.xlsx`

## Files

- `feature_importance_v22_v17_highlighted.xlsx` — reconstructed Excel workbook.
- `feature_importance.csv` — plain CSV export for scripts, Copilot, and LLM ingestion.
- `feature_importance.md` — the complete 120-row table rendered as Markdown.

## Reconstructed source

The Dropbox folder contained 20 photos of the Excel workbook. All 20 show the `Feature importance` worksheet and together cover ranks 1–120, the `Importance_Pct` values, and the visible yellow highlights.

The workbook UI also visibly showed additional original sheet tabs such as `feature_importance_highlighted`, `summary`, `overlap_features`, and a `v22b_only_new_featu...` tab. Their cell contents were **not** photographed in this Dropbox set, so they are not invented in this reconstruction.

## Visible highlights

The photographed worksheet highlights these Feature_Name cells in yellow:

- Rank 10 — `FALCONDECLINE_INDICATOR`
- Rank 12 — `DERIVED__DAYS_SINCE__CPRCUST__ASTATUSCHGDT`
- Rank 24 — `INACTV_DT`
- Rank 48 — `DERIVED_LE1__USER_INDICATOR_3_XCD_CURRENT_STRAT`
- Rank 60 — `PROCESSOR_REASON`

`Chart` is `V22B Model` for all 120 photographed rows.

## CH readability repair — 2026-10-07

The uploaded XLSX was not a valid ZIP/Excel container (SHA256 `8e0a651dbc2da9cb79031bb0a2e1180887d4724b9d3c4f129d25f2991eb15a94`). This candidate rebuilds it from the existing CSV and verifies all 120 rows and five yellow highlights. The original binary remains in Git history. A **Source notes** sheet records the reconstruction, source hashes and unresolved differences.

CSV and Markdown spelling differs at ranks 50, 92 and 109; the workbook preserves the CSV without guessing the intended business fields. The displayed percentages total **100.49998169%**. Nothing is renormalized or removed. Obtain the native sheet or source confirmation before treating names or totals as authoritative. Other unphotographed tabs remain unavailable.
