# Best Practice in Feature Engineering

**From:** Xiaoming, manager

---

Team,

We have strongly encouraged everyone to engineer additional features and build benchmark models to independently challenge the LOB’s models. However, please be extra careful when using class-specific downsampled data provided by the LOB for feature engineering, especially for cross-row historical aggregation features. These features can be materially distorted and thus biased by the sampling process.

Below are two questions I discussed with Copilot that provide detailed explanations.

1. For a fraud dataset, if we do transaction level down sampling to include all fraud records while keep only 1% good records, then we generate account based features like count of transactions for this account in last seven days, is this engineered feature biased?
2. Why there is no problem to use the class specific downsampled data for estimation, but it is problematic to use the engineered features from the class specific downsampled data for estimation?

This reinforces the validation direction we have been working toward:

1. Engineer features using full population with sufficiently long history. For example, if VAA (10786) provides 3-month retro- data, we have to use the 3-months retro- data for estimation. However, historical or cross-row features should ideally be engineered using a dataset with a longer lookback window and a population that preserves the relevant transaction history. This naturally leads to the question: *Where can we obtain reliable, longer-history data for feature engineering?*
2. Build portfolio-level feature stores to support holistic validation rather than model specific validation. Note, in general, our fraud models are concentrated in a relatively small number of portfolios, e.g., Debit Card, Credit Card, DDA Accounts including Deposit Checks, Inclearing Checks, and Digital Money Movements. Across these portfolios, we already have in-house models and historical data that can potentially serve as the foundation for reusable feature stores.

The longer-term goal should be to move away from repeatedly engineering features within each individual validation dataset and toward **portfolio-based feature stores with sufficiently long, representative histories.** This would allow us to develop stronger benchmark models and conduct more consistent, holistic challenge across related models.

Best,  
Xiaoming

## Prompt

**For a fraud dataset, if we do transaction level... | Try in Copilot Chat**

> For a fraud dataset, if we do transaction level down sampling to include all fraud records while keep only 1% good records, then we generate account based features like count of transactions for this account in last seven days, is this engineered feature biased?

## Response

Yes. **If you first downsample transactions to keep all fraud but only 1% of good transactions, and then calculate “number of transactions for this account in the past 7 days” from that sampled dataset, the feature is strongly biased.**

The key distinction is **when you construct the feature relative to downsampling.**

### Simple example

Suppose an account actually had, during the prior 7 days:

- 200 good transactions
- 2 fraud transactions
- True 7-day transaction count = **202**

After sampling:

- Fraud retention = 100% → keep 2
- Good retention = 1% → expected retained good transactions ≈ 2

If you calculate the feature from the sampled data:

```text
7-day transaction count ≈ 2 + 2 = 4
```

instead of the true value:

```text
202
```

So the feature severely understates the account’s actual transaction activity.

More importantly, the distortion is **class-dependent** because fraud and good transactions have different inclusion probabilities.

### Why this is especially problematic for fraud models

Consider two accounts with the **same true transaction volume**:

| Account history | True 7-day count | Expected count after sampling |
| --- | ---: | ---: |
| 100 good, 0 fraud | 100 | ~1 |
| 98 good, 2 fraud | 100 | ~3 |

They both truly have 100 transactions, but the second account appears to have roughly 3x the activity simply because historical fraud transactions are retained at a higher rate.

Your engineered feature therefore stops representing pure **account activity** and starts partially encoding **historical fraud occurrence and the sampling scheme.**

For model validation, I’d consider that a significant concern because it can create a **sampling-induced relationship** between the feature and target.

### Correct approach

The preferable sequence is:

**1. Start with the full transaction population**

↓

**2. Construct historical/account-level features using the full data**

For transaction at time $t$:

$$
Count7D_i = \sum_j I\left(A, ccount_j = Account_i\; t_i - 7d \le t_j < t_i\right)
$$

↓

**3. Attach those features to each transaction**

↓

**4. Then downsample the modeling observations**

Keep:

- 100% fraud
- 1% good

↓

**5. Train the model**

Now, even though the training dataset is downsampled, a transaction belonging to an account that actually had 202 transactions in the previous 7 days still gets:

```text
transaction_count_7d = 202
```

rather than approximately 4.

---

### An important nuance

Downsampling **doesn’t necessarily make every feature biased.**

For example, features such as:

- transaction amount
- merchant category
- current account balance
- transaction channel
- current transaction time

can remain perfectly valid after transaction-level downsampling because you’re observing their values directly on the retained transaction.

The problem is particularly acute for **aggregated historical features generated from the downsampled population**, such as:

- transaction count in past 7/30 days
- total spend in past 7 days
- average transaction amount
- merchant diversity
- transaction velocity
- decline count
- number of distinct locations/devices
- time since previous transaction

These should generally be calculated from the **unsampled historical transaction stream**, with appropriate point-in-time logic.

### Another issue I’d check in validation

For your fraud model, I’d actually distinguish **two separate risks**:

**Sampling bias:** Was the historical feature calculated from the 1% sample rather than the full transaction history?

**Data leakage:** When calculating the 7-day feature for transaction $t$, were only transactions occurring **before <em>t</em>used?**

So the ideal construction is:

Full population → point-in-time historical feature engineering → downsampling → train/test dataset

rather than:

Full population → downsampling → historical feature engineering → train/test dataset

This distinction is quite important when validating transaction-level fraud models, because even if train/test splitting itself is done correctly, **feature engineering after transaction-level downsampling can materially change the meaning of account-level behavioral features.**

## Prompt

**why there is no problem to use the class specific... | Try in Copilot Chat**

> why there is no problem to use the class specific downsampled data for estimation, but it is problematic to use the engineered features from the class specific downsampled data for estimation?

## Response


The key distinction is between **sampling rows** and **changing the values or meaning of predictors.**

### 1. Class-specific downsampling changes how often rows appear

Suppose the full population follows:

$$
P(Y = 1 \mid X = x)
$$

where:

- $Y = 1$: fraud
- $Y = 0$: good
- $X$: predictors already correctly measured from the full transaction history

You retain:

$$
\begin{aligned}
s_1 &= P(S = 1 \mid Y = 1) = 1 \\
s_0 &= P(S = 1 \mid Y = 0) = 0.01
\end{aligned}
$$

If sampling depends **only on the target<em>Y</em>**, then within each class the sampled transactions are still representative:

$$
P_s(X \mid Y) = P(X \mid Y)
$$

The sample has an artificial fraud rate, but it preserves the relationship between a correctly measured <em>X</em>and $Y$. In logistic regression, conventional case-control sampling can consistently estimate slope parameters, although the intercept and marginal event probability are not directly identifiable without population information or adjustment. \[arxiv.org\], \[link.springer.com\]

In plain language:

Downsampling changes the number of good observations used for estimation, but it does not alter each retained observation’s original feature values.

For many classifiers, this means the model can still learn how fraud and good transactions differ. However, the raw predicted probability generally needs calibration or sampling correction because the training fraud prevalence is artificial.

---

### 2. Building features after downsampling changes the predictor itself

Now consider the true feature:

$$
X_i = \text{number of transactions for account } i \text{ during the prior 7 days}
$$

If it is calculated using the full transaction history, it is a genuine behavioral characteristic at scoring time.

But if you first retain all fraud transactions and only 1% of good transactions, then calculate the feature, the model receives:

$$
X_i^{*} = \text{retained fraud transactions} + \text{retained good transactions}
$$

Approximately:

$$
E[X_i^{*} \mid \text{history}] = N_{\text{fraud},i} + 0.01N_{\text{good},i}
$$

The true feature is:

$$
X_i = N_{\text{fraud},i} + N_{\text{good},i}
$$

Therefore, <em>X<sub>i</sub><sup>*</sup></em>is not simply a smaller but otherwise equivalent version of $X_i$. It applies different weights to the components:

- Historical fraud transaction: weight 1
- Historical good transaction: weight 0.01

The feature’s definition has effectively changed from:

How active was this account?

to:

How many historical fraud transactions plus 1% of its good transactions happened to survive sampling?

That quantity will not exist in the same form when the production model scores full transaction streams.

---

### 3. The central statistical distinction

#### Sampling after feature engineering

$$
(X,Y) \rightarrow S
$$

Here, <em>X</em>is measured correctly first. Sampling determines which complete observations are used to estimate the model.

If:

$$
S \perp X \mid Y
$$

then sampling is random within each class. The class-conditional predictor distributions are preserved.

#### Feature engineering after sampling

$$
(Y,\text{transaction history}) \rightarrow S \rightarrow X^{*}
$$

Now the predictor is a function of the sampling indicator:

$$
X^{*} = g(\text{history},S)
$$

Therefore:

$$
S \perp\! /X^{*} \mid Y
$$

The sampling process is embedded inside the feature itself. This creates **differential measurement error**, because fraud and good historical transactions have different probabilities of appearing in the feature.

---

### 4. Worked example

Consider two accounts with equal actual activity:

| Account | True previous seven-day history | True count | Expected sampled count |
| --- | --- | ---: | ---: |
| A | 100 good, 0 fraud | 100 | 1 |
| B | 98 good, 2 fraud | 100 | 2.98 |

Both accounts have exactly 100 actual transactions.

However, after class-specific downsampling:

$$
\begin{aligned}
E[X_A^{*}] &= 0 + 0.01(100) = 1 \\
E[X_B^{*}] &= 2 + 0.01(98) = 2.98
\end{aligned}
$$

Account B appears approximately three times as active, even though the true activity level is identical. The difference is caused entirely by preserving fraud transactions at a higher rate.

This gives the model an artificial signal related to historical fraud and sampling, rather than a clean measure of transaction velocity.

---

### 5. Why the first case is acceptable, but the second is problematic

The distinction can be summarized as:

| Issue | Downsample rows after features are built | Build features from downsampled history |
| --- | --- | --- |
| Feature values | Remain correct | Become distorted |
| $P(X \mid Y)$ | Generally preserved under random within-class sampling | Changed by the sampling process |
| Fraud prevalence | Artificial | Artificial |
| Slope or ranking estimation | Can remain valid under appropriate assumptions | Can be biased because $X^{*} \ne X$ |
| Probability calibration | Usually requires correction | Calibration alone cannot repair corrupted features |
| Production consistency | Same feature definition | Training-serving mismatch |

The last distinction is important. With ordinary class downsampling, you can often correct probability estimates using sampling weights, intercept correction, or post-model calibration. But when the predictor itself is distorted, fixing the predicted probability does **not** reconstruct the missing account history.

### 6. A useful analogy

Suppose you want to study whether income predicts default.

#### Acceptable approach

1. Measure everyone’s actual income.
2. Keep all defaults and randomly retain 1% of non-defaults.
3. Estimate the relationship using the retained observations.

You reduced the number of observations, but the retained customers’ income values are still correct.

#### Problematic approach

1. Keep all income dollars belonging to defaulters.
2. Keep only 1% of income dollars belonging to non-defaulters.
3. Recalculate each customer’s income from the retained dollars.
4. Estimate default risk using this recalculated “income.”

Now the predictor itself was constructed using a process related to the outcome. It no longer represents actual income.

### 7. Important qualifications

It is slightly too broad to say there is<strong>“no problem”</strong> using class-specific downsampled data. It is acceptable only under conditions such as:

1. **Sampling is random within each class.**
2. **Predictors are measured before sampling and are not changed by it.**
3. **Account, time, merchant, device, and other dependency structures are handled appropriately.**
4. **Evaluation uses an untouched, population-representative validation/test sample.**
5. **Probability estimates are recalibrated or corrected for the sampling fractions.**
6. **The train-test split prevents the same account or overlapping historical windows from creating leakage.**

For logistic regression, class sampling primarily alters the intercept under standard case-control assumptions. For regularized logistic regression, trees, gradient boosting, neural networks, or threshold-based fraud systems, downsampling can also affect optimization, regularization, tree splits, rankings, and calibration. Therefore, the effect is not universally limited to the intercept.

### Bottom line

**Class-specific downsampling is applied to the observations used for estimation. Feature values remain truthful.**

**Feature engineering from class-specific downsampled history applies the sampling mechanism to the predictors themselves. The resulting features no longer truthfully represent account behavior.**

For your account-velocity features, the preferred order is:

$$
\text{Full point} - \text{in} - \text{time history} \rightarrow \text{construct features} \rightarrow \text{split data} \rightarrow \text{downsample training rows only}
$$

The untouched validation and test sets should retain the natural fraud rate and use features built from the full point-in-time-available history.


---

## Owner-supplied follow-up — Jie Chen, director

Recorded by CH on 2026-10-13 UTC. The owner reports that Jie Chen replied to Xiaoming’s email with the following text. The original reply date/time and message file were not supplied; this addition is separate from the original email transcription above.

> If we do time series-based feature engineering, I think it is more appropriate to do account/customer level sampling rather than transaction level sampling.

[Project interpretation and 15298 feature follow-up](../../../bridge/plans/CH/2026-10-12-v22-feature-proposal/SAMPLING_FOLLOWUP_2026-10-13.md) are recorded separately; they are CH’s analysis, not additional words attributed to Jie Chen.
