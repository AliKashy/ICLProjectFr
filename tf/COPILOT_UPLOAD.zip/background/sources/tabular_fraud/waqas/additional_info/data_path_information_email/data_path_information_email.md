# Data path information email

**From:** Sumegha

---

Thank you, Sumegha and Joel, for the efforts. This is very helpful.

Best,  
Xinyu Zhou

---

**From:** Sumegha

Hi all,

The raw data used to pretrain and fine-tune the TFM model has been copied to this shared bucket `s3://mrmcd-analytics-mrm-mmr-dsai/`. Credentials should be the same as your standard mrmcd credentials and can be obtained at NetApp® StorageGRID®.

Training data ranges from 102024 to 052025: `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/`

Testing data for TFM is 062025 but has 052025 histories. Therefore, the testing data here covers 052025 to 062025: `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/`

The data is partitioned by account into 10000 buckets totally (part_1, part_2, ... part_10000) and you will see a subset of these files (we use at most 5000 files for training and 2000 files for testing).

Let us know in case of questions.

Thanks and Regards,  
Sumegha
