# Feature work

## Master feature worksheet

- [Excel workbook](all_possible_features_workbook.xlsx)
- [The same master cells as CSV](all_features_master.csv)

The workbook contains only **`all_features_master`**, the combined feature index requested for this reconstruction. Its populated range is **A1:H312**: one header row and **311 data rows** across eight columns. Other workbook tabs are not recreated.

| Category | Data rows |
| --- | ---: |
| `model_15298_xgboost_feature` | 94 |
| `raw_or_source_column` | 106 |
| `model_15298_crosswalk_row` | 94 |
| `v2_candidate_feature_family` | 17 |

Repeated feature names across categories are retained. Cell text, spelling, capitalization, blank cells, source-artifact names, ranks, coverage statuses, data types, source columns, and notes are preserved from the photographed master worksheet. Ranks remain text, as indicated by the source display. The CSV is a readable companion for repository review; it contains the same cells, in the same order, without Excel formatting.

## Source and scope

Source: [Owner-supplied feature-exploration photo folder](https://www.dropbox.com/scl/fo/ah73pz11dyal3fwyg8ro8/AGiEXLwhDVWkrpbMxqokMGE?rlkey=onoke2zbmhg2pei8l70mzi9c2&dl=0).

The source folder contains 145 photographs. Overlapping and horizontally scrolled views were used to reconstruct the master worksheet, including long notes and wrapped text. The other photographed workbook tabs are outside the requested scope.

This is a reconstruction of the photographed worksheet, not a copy of the original binary Excel file. The visible plain-grid layout, bold headers, and wrapped notes have been reproduced; exact original column widths, hidden workbook metadata, unshown formulas, and original XLSX ZIP bytes are not established by photographs. No unshown formulas or additional tabs have been invented.

## Verification

- Complete rectangular cell coverage: **2,496 cells**, including photographed blanks.
- Exported XLSX cell text compared with the staged transcription: **0 mismatches**.
- CSV read back and compared with the same transcription: **0 mismatches**.
- Workbook renders inspected; no formula-error values found.
- Excel workbook SHA-256: `debbc86c97e8466927bdceff595ef000a08d789bbaf93452d9d5d0134dc4daa7`.

The workbook and CSV are source reconstructions only; they do not implement the listed feature-engineering recipes or change project code.
