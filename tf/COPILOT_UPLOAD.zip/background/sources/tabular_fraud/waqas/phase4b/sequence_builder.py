"""Streaming sequence builder for the history-aware (Phase 4) fraud model.

PHASE-OWNED derivative of ``fraud/data/sequence_builder.py``. The default
single-target window path is preserved. Besides worker sharding, this module
contains an explicit opt-in nonoverlapping-chunk contract for causal
all-position prediction; it is not byte-identical to the original builder.

================================================================================
BUG FIXED HERE (confirmed present in Yaqun's original, inherited unmodified
until this duplicate): multi-worker file sharding is not a real partition.

  Original code:
      def _get_worker_files(self):
          worker_info = torch.utils.data.get_worker_info()
          files = list(self.file_list)
          if self.shuffle:
              np.random.shuffle(files)            # <- each worker shuffles with
                                                    #    ITS OWN np.random state
          if worker_info is not None:
              files = files[worker_info.id :: worker_info.num_workers]
          return files

  Because PyTorch Lightning's ``seed_everything(..., workers=True)`` gives each
  DataLoader worker process a DIFFERENT random seed (that is the whole point of
  the flag), every worker's ``np.random.shuffle(files)`` call produces a
  DIFFERENT random order of the SAME file list. Each worker then takes every
  Nth file from ITS OWN shuffled order (``files[worker_info.id::num_workers]``).
  Since the orders differ across workers, this is NOT a clean N-way partition:
  with 4 workers, ~(3/4)^4 ~= 31.6% of files are selected by ZERO workers (and
  silently skipped that epoch) while some files are selected by 2+ workers (and
  read/trained on twice that epoch). This affects every TRAINING run that uses
  shuffle=True + num_workers>0 (validation/eval use shuffle=False, so they are
  unaffected: the ``if self.shuffle:`` branch never fires there).

FIX: shuffle the file list with a FIXED seed (not the per-worker-reseeded
global numpy RNG), so every worker computes the IDENTICAL shuffled order
before slicing. The subsequent ``files[worker_info.id::num_workers]`` stride
then correctly partitions one single shuffled list into num_workers disjoint,
non-overlapping slices -- zero skipped files, zero duplicated files, while
keeping num_workers>0 (no loss of parallel S3 read throughput, unlike the
"just set num_workers=0" workaround). Trade-off: the shuffled order is now the
same every epoch (seeded, not re-randomized per epoch) instead of varying --
a minor loss of across-epoch order diversity, negligible next to the bug it
removes.

Note: the OTHER ``np.random.shuffle`` call in this file (inside
``_emit_batches``, shuffling the WINDOW BUFFER before batching) is NOT part of
this bug and is left unchanged -- that shuffle only reorders samples within one
worker's own output stream; it does not partition data across workers, so
per-worker-independent randomness there is harmless.
================================================================================

For each target transaction it builds a fixed-length window of the target plus
its ``history_len`` most recent PRIOR transactions from the same account
(strictly causal), left-padded when there is not enough history. Preprocessing
reuses the FROZEN artifacts per transaction; a per-transaction time-delta
(log seconds to the target) is appended as an extra continuous feature.

Equal-timestamp rule (RUN-02, register R-007; OQ-13 decides at the walkthrough):
``history_time_order='strict'`` (default) admits only rows whose parsed timestamp
is strictly before the target's; ``'tiebreak'`` keeps the behaviour before the
option existed, where a same-time row that sorts first by the tie-break id (in
the order pandas sorts ``tie_break_col``: as text when the id is stored as text,
as numbers when it is stored as numbers) can enter the history of the one that
sorts second.

Yields whole-batch tensor dicts (use ``DataLoader(batch_size=None)``):
    {
      "continuous":  FloatTensor[B, T, C],   # C = n_continuous + 1 (time-delta)
      "categorical": LongTensor [B, T, K],   # K = artifact cats + _isna flags
      "mask":        BoolTensor [B, T],      # True = real transaction, False = pad
      "target":      LongTensor [B, 1],      # target transaction's frd_tag
    }
with ``T = history_len + 1`` (target at slot T-1).

Correlation note: with ``stride=1`` an account's windows overlap heavily, so a
window-level shuffle buffer spanning many accounts is used for training.

Opt-in ``emit_target_seq=True`` instead requires
``all_position_layout='nonoverlapping_chunks'`` and stride=1. It returns
``target_seq[B,W]`` (padding=-100; ``W = T`` except for strict chunks wider than T,
see below), right-padded disjoint chunks, the
per-position parsed timestamps ``time_seq[B,W]`` (int64 ns, padding 0) and
optional ``meta_seq[B,W]``. Time deltas must use ``previous_transaction``.
Context is 0..H earlier rows (tiebreak) or the rows of 0..H earlier seconds
(strict) within a chunk and resets at every chunk and file. This is a
separate estimator, not a matched-history ablation.

All-position equal-time rule (V1 build item B9): with ``history_time_order='strict'``
(default) a row's gap is log1p(seconds since the latest strictly-earlier timestamp
in its chunk), zero when there is none, so times [10, 20, 20] give 0, 10, 10; the
model reads ``time_seq`` and lets a row see only strictly earlier rows of its chunk.
``'tiebreak'`` keeps the earlier chunk rule: gap since the previous row of the
chunk (0, 10, 0 for the same times) and positional visibility.

All-position chunk cut (B9 amendment, claude-model-data-1 B1, DESIGN_V1 section 6.3 (b)):
under ``'strict'`` a chunk is cut only between whole seconds and holds up to
``history_len + 1`` distinct seconds of an account (counted by seconds, not rows),
so a same-second sibling can never move a row into another chunk. Such a chunk can
hold more than ``T`` rows when seconds hold ties; every chunk is emitted at width
``max(T, rows)`` and each batch is right-padded to its widest chunk, so ``T`` is
then the minimum width, not the maximum. No row is ever dropped. ``'tiebreak'``
keeps the earlier cut every ``T`` rows and the fixed width ``T``.

Chunk width guard (review R1): the strict width has no built-in limit, so one account with a crowded
second widens its whole batch (stage 1 grows to ``batch_size * W`` rows and the attention mask to
``[batch_size * heads, W + 1, W + 1]``). The optional ``max_chunk_rows`` makes the builder raise when a
chunk holds more rows than the cap. It never truncates or drops a row; ``None`` (the default) keeps the
unbounded width. ``waqas/phase4b/scripts/measure_chunk_widths.py`` reports the widths a cap must admit.
"""

from typing import List, Optional

import numpy as np
import pandas as pd
import pyarrow.parquet as pq
import torch
from torch.utils.data import IterableDataset

from fraud.data.datetime_features import DatetimeConfig, derive_datetime_features
from fraud.data.feature_list import FeatureList
from waqas.base.data.input_contracts import (
    encode_binary_target,
    parse_required_timestamps,
    require_account_ids,
)
from fraud.data.parquet_loader import (
    streaming_categorical_cardinality,
    streaming_categorical_columns,
)
from fraud.data.preprocessing import PreprocessingArtifacts
from fraud.data.s3_utils import make_s3_filesystem, strip_scheme


HISTORY_TIME_ORDERS = ("strict", "tiebreak")


def sequence_continuous_columns(features: FeatureList, time_delta: bool) -> List[str]:
    """Continuous columns the model sees per transaction (+ time_delta last)."""
    cols = list(features.continuous)
    if time_delta:
        cols = cols + ["time_delta"]
    return cols


class SequenceBuilder(IterableDataset):
    """Stream account-grouped causal windows, encoded via frozen artifacts.

    Args:
        file_list: Parquet file paths (with or without ``s3://`` scheme).
        artifacts: Loaded ``PreprocessingArtifacts`` for encode/standardize.
        features: ``FeatureList`` (continuous/categorical order + order_col).
        datetime_config: Config for deriving datetime features per file.
        target_col: Raw target column name.
        account_col: Account/customer id column (groups transactions).
        order_col: Timestamp column for causal ordering.
        history_len: N prior transactions (window length T = N + 1).
        stride: Target subsampling step; fraud targets are never skipped.
        positive_label: Raw value of the positive (fraud) class.
        add_missing_flag: Append ``<col>_isna`` categorical flags.
        time_delta: Append log-seconds-to-target as an extra continuous feature.
        batch_size: Windows per yielded batch.
        shuffle: Shuffle files + window buffer (training) vs deterministic (eval).
        buffer_windows: Window shuffle-pool size (spans many accounts).
        tie_break_col: Secondary sort key for equal timestamps (e.g. txn id).
        history_time_order: 'strict' (only rows with time strictly before the
            target's time enter its history; default) or 'tiebreak' (same-time
            rows ordered before the target by ``tie_break_col`` may enter).
            For all-position chunks: 'strict' gives the strictly-earlier gap and
            the time_seq the model's strict mask reads; 'tiebreak' the
            previous-row gap and positional visibility (module docstring).
        shard_seed: Fixed seed for the worker file-sharding shuffle (see module
            docstring) -- must be the SAME value across all workers, which is
            why it is a plain constructor argument, not derived from global RNG.
        s3_filesystem / s3_cred_path: S3 access (per-worker lazy build if cred).
        emit_target_seq: Opt in to disjoint causal chunks with one target per row.
        all_position_layout: Must explicitly be 'nonoverlapping_chunks' for the
            all-position mode; None for the original single-target windows.
        max_chunk_rows: All-position chunks only. Raise (never truncate) when a
            chunk holds more real rows than this; None (default) sets no cap.
            Must be at least T, so an ordinary chunk is never refused.
        time_delta_reference: 'target' for windows, 'previous_transaction' for
            chunks with a time feature. Chunks reset the gap to zero at start.
    """

    def __init__(
        self,
        file_list: List[str],
        artifacts: PreprocessingArtifacts,
        features: FeatureList,
        datetime_config: DatetimeConfig,
        target_col: str,
        account_col: str,
        order_col: str,
        history_len: int = 5,
        stride: int = 1,
        positive_label=1,
        add_missing_flag: bool = True,
        time_delta: bool = True,
        batch_size: int = 4096,
        shuffle: bool = False,
        buffer_windows: int = 65536,
        tie_break_col: Optional[str] = None,
        id_cols: Optional[List[str]] = None,
        amount_col: Optional[str] = None,
        shard_seed: int = 42,
        s3_filesystem=None,
        s3_cred_path: Optional[str] = None,
        history_time_order: str = "strict",
        emit_target_seq: bool = False,
        all_position_layout: Optional[str] = None,
        time_delta_reference: str = "target",
        max_chunk_rows: Optional[int] = None,
    ):
        self.file_list = file_list
        self.artifacts = artifacts
        self.features = features
        self.datetime_config = datetime_config
        self.target_col = target_col
        self.account_col = account_col
        self.order_col = order_col
        self.history_len = history_len
        self.stride = max(1, stride)
        self.positive_label = positive_label
        self.add_missing_flag = add_missing_flag
        self.time_delta = time_delta
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.buffer_windows = max(buffer_windows, batch_size)
        self.tie_break_col = tie_break_col
        self.id_cols = list(id_cols) if id_cols else []
        self.amount_col = amount_col
        self._emit_meta = bool(self.id_cols or amount_col)
        self.shard_seed = shard_seed
        self.s3_filesystem = s3_filesystem
        self.s3_cred_path = s3_cred_path
        if history_time_order not in HISTORY_TIME_ORDERS:
            raise ValueError(
                f"history_time_order must be one of {sorted(HISTORY_TIME_ORDERS)}, got {history_time_order!r}"
            )
        self.history_time_order = history_time_order
        # All-position labels require unique ownership; overlapping target
        # windows would overweight frequent histories and repeat evaluation IDs.
        self.emit_target_seq = emit_target_seq
        self.all_position_layout = all_position_layout
        self.time_delta_reference = time_delta_reference
        if history_len < 0 or batch_size < 1:
            raise ValueError("history_len must be nonnegative and batch_size positive")
        if emit_target_seq:
            if all_position_layout != "nonoverlapping_chunks":
                raise ValueError("All-position prediction requires explicit all_position_layout='nonoverlapping_chunks'")
            if stride != 1:
                raise ValueError("All-position chunks require stride=1: every real row owns one target")
            if time_delta and time_delta_reference != "previous_transaction":
                raise ValueError("All-position time_delta must reference previous_transaction, never the final target")
            if len(file_list) != len(set(file_list)):
                raise ValueError("All-position file_list must not contain duplicate paths")
        elif all_position_layout is not None or (time_delta and time_delta_reference != "target"):
            raise ValueError("Single-target windows use the original target-relative time_delta and no chunk layout")
        if max_chunk_rows is not None:
            if not emit_target_seq:
                raise ValueError("max_chunk_rows applies to all-position chunks only")
            if int(max_chunk_rows) != max_chunk_rows or max_chunk_rows < history_len + 1:
                raise ValueError(f"max_chunk_rows must be an integer of at least history_len + 1 = {history_len + 1}, "
                                 f"got {max_chunk_rows!r}")
            max_chunk_rows = int(max_chunk_rows)
        self.max_chunk_rows = max_chunk_rows

        self.continuous_cols = sequence_continuous_columns(features, time_delta)
        self.categorical_cols = streaming_categorical_columns(features, add_missing_flag)
        self.categorical_cardinality = streaming_categorical_cardinality(
            artifacts, features, add_missing_flag
        )
        self.T = history_len + 1

        read_cols = list(features.raw_source_columns())
        for extra in [target_col, account_col, order_col, tie_break_col,
                      amount_col, *self.id_cols]:
            if extra and extra not in read_cols:
                read_cols.append(extra)
        self._read_cols = read_cols

    # -- setup ------------------------------------------------------------- #
    def _ensure_fs(self):
        if self.s3_filesystem is None and self.s3_cred_path is not None:
            self.s3_filesystem = make_s3_filesystem(self.s3_cred_path)
        return self.s3_filesystem

    def _get_worker_files(self):
        # FIX (see module docstring): shuffle with a FIXED seed so every worker
        # computes the IDENTICAL order before slicing -- turns the per-worker
        # stride into a true, non-overlapping, nothing-skipped partition.
        worker_info = torch.utils.data.get_worker_info()
        files = list(self.file_list)
        if self.shuffle:
            rng = np.random.RandomState(self.shard_seed)
            rng.shuffle(files)
        if worker_info is not None:
            files = files[worker_info.id :: worker_info.num_workers]
        return files

    # -- per-file encoding ------------------------------------------------- #
    def _encode_file(self, df):
        """Encode a whole file once -> per-row arrays reused by all windows."""
        target = encode_binary_target(df[self.target_col], self.positive_label, self.target_col)
        require_account_ids(df[self.account_col], self.account_col)
        df = df.copy()
        df[self.order_col] = parse_required_timestamps(df[self.order_col], self.order_col)
        if self.emit_target_seq:
            self._validate_chunk_rows(df)
        if self.features.derived:
            if self.datetime_config.order_col != self.order_col:
                df[self.datetime_config.order_col] = parse_required_timestamps(
                    df[self.datetime_config.order_col], self.datetime_config.order_col
                )
            df, _, _ = derive_datetime_features(df, self.datetime_config)

        cont = np.stack(
            [self.artifacts.standardize_continuous(c, df[c]) for c in self.features.continuous],
            axis=1,
        ).astype(np.float32)  # [rows, n_cont]

        cat_arrays = [self.artifacts.encode_categorical(c, df[c]) for c in self.features.categorical]
        if self.add_missing_flag:
            cat_arrays += [df[c].isna().to_numpy().astype(np.int64) for c in self.features.continuous]
        cat = np.stack(cat_arrays, axis=1).astype(np.int64)  # [rows, K]

        times = df[self.order_col].to_numpy(dtype="datetime64[s]").astype("int64")
        meta = None
        if self._emit_meta:
            meta = {c: df[c].to_numpy() for c in self.id_cols}
            if self.amount_col:
                meta[self.amount_col] = df[self.amount_col].to_numpy()
        return cont, cat, target, times, df, meta

    def _validate_chunk_rows(self, df):
        """Reject rows that cannot have an unambiguous chronological ownership."""
        required = [self.account_col, self.order_col, self.target_col]
        if self.tie_break_col:
            required.append(self.tie_break_col)
        if df[required].isna().any().any():
            raise ValueError("All-position chunks require non-null account, time, label and tie-break values")
        identity = [self.account_col, self.tie_break_col or self.order_col]
        if df.duplicated(identity).any():
            raise ValueError(f"Duplicate or ambiguous transaction identity/order: {identity}")

    # -- windowing --------------------------------------------------------- #
    def _account_groups(self, df):
        """Row-position lists per account, sorted by time (+ tie-break)."""
        sort_cols = [self.account_col, self.order_col]
        if self.tie_break_col:
            sort_cols.append(self.tie_break_col)
        ordered = df.reset_index(drop=True)
        if self.emit_target_seq:
            ordered = ordered.assign(**{self.order_col: pd.to_datetime(ordered[self.order_col], utc=True)})
        sorted_pos = (
            ordered
            .sort_values(sort_cols, kind="stable")
            .index.to_numpy()
        )
        acct = df[self.account_col].to_numpy()
        groups = {}
        for p in sorted_pos:
            groups.setdefault(acct[p], []).append(int(p))
        return groups

    def _windows_for_file(self, cont, cat, target, times, df, meta):
        if self.emit_target_seq:
            yield from self._chunks_for_file(cont, cat, target, times, df, meta)
            return
        n_cont = cont.shape[1]
        C = n_cont + (1 if self.time_delta else 0)
        K = cat.shape[1]
        T = self.T
        # The sort key at its stored precision (not the whole-second ``times`` the
        # time channel uses), so 'same time' means the same parsed timestamp.
        order_key = (
            df[self.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
            if self.history_time_order == "strict" else None
        )
        for _acct, rows in self._account_groups(df).items():
            group_start = 0  # strict: first position of the current same-time group of this account
            for pos in range(len(rows)):
                target_row = rows[pos]
                if order_key is not None and pos > 0 and order_key[target_row] != order_key[rows[pos - 1]]:
                    group_start = pos
                is_fraud = target[target_row] == 1
                if (pos % self.stride != 0) and not is_fraud:
                    continue
                # strict: the history ends before the target's same-time group; tiebreak: just before the target
                end = group_start if order_key is not None else pos
                hist = rows[max(0, end - self.history_len):end]
                pad = self.history_len - len(hist)
                slot_rows = ([-1] * pad) + list(hist) + [target_row]

                w_cont = np.zeros((T, C), dtype=np.float32)
                w_cat = np.zeros((T, K), dtype=np.int64)
                w_mask = np.zeros((T,), dtype=bool)
                w_target_seq = np.full((T,), -100, dtype=np.int64) if self.emit_target_seq else None
                t_target = times[target_row]
                for s, r in enumerate(slot_rows):
                    if r < 0:
                        continue
                    w_cont[s, :n_cont] = cont[r]
                    if self.time_delta:
                        w_cont[s, n_cont] = np.log1p(max(0, int(t_target - times[r])))
                    w_cat[s] = cat[r]
                    w_mask[s] = True
                    if self.emit_target_seq:
                        w_target_seq[s] = target[r]
                row_meta = (
                    {c: meta[c][target_row] for c in meta} if meta is not None else None
                )
                yield w_cont, w_cat, w_mask, np.int64(target[target_row]), row_meta, w_target_seq

    def _chunks_for_file(self, cont, cat, target, times, df, meta):
        """Disjoint account-local chunks; context resets at every chunk/file.

        Under ``'tiebreak'`` T is a maximum chunk length, NOT a promise of H prior
        rows per target. Under ``'strict'`` a chunk holds up to T distinct seconds
        (``_chunk_spans``), so it can hold more than T rows; it is then emitted at
        its own width and ``_emit_batches`` pads the batch to its widest chunk.
        Real slots are left aligned, followed by right padding. A transaction is
        a target exactly once, and may see only earlier slots in its own chunk.
        The optional time feature is a backward interarrival gap; slot zero is
        zero. Appending future rows cannot change an existing prefix's inputs.
        Rows are placed in chunks in (time, tie-break id) order. Under
        ``history_time_order='strict'`` the gap of a row is measured to the
        latest strictly-earlier timestamp in its chunk (zero when none), and
        ``time_seq`` lets the model hide same-time neighbours from each other.
        Under ``'tiebreak'`` the gap is measured to the previous row and the
        tie order is treated as availability order; callers must confirm that
        this ordering matches information availability in their data.
        """
        n_cont, K = cont.shape[1], cat.shape[1]
        C = n_cont + int(self.time_delta)
        # The parsed timestamp at its stored precision decides "same time" (as in the
        # single-target strict rule); the gap value itself stays in whole seconds.
        order_key = df[self.order_col].to_numpy(dtype="datetime64[ns]").astype("int64")
        for rows in self._account_groups(df).values():
            for start, end in self._chunk_spans(times[rows]):
                chunk_rows = rows[start:end]
                n = len(chunk_rows)
                if self.max_chunk_rows is not None and n > self.max_chunk_rows:
                    raise ValueError(
                        f"strict chunk of account {df[self.account_col].iloc[chunk_rows[0]]!r} holds {n} rows > "
                        f"max_chunk_rows={self.max_chunk_rows}; no row is dropped, raise the cap or measure the data")
                width = max(self.T, n)  # only a strict chunk whose seconds hold ties can exceed T rows
                w_cont = np.zeros((width, C), dtype=np.float32)
                w_cat = np.zeros((width, K), dtype=np.int64)
                w_mask = np.zeros(width, dtype=bool)
                labels = np.full(width, -100, dtype=np.int64)
                w_cont[:n, :n_cont] = cont[chunk_rows]
                w_cat[:n] = cat[chunk_rows]
                w_mask[:n] = True
                labels[:n] = target[chunk_rows]
                w_time = np.zeros(width, dtype=np.int64)
                w_time[:n] = order_key[chunk_rows]
                if n > 1 and (np.diff(w_time[:n]) < 0).any():
                    raise ValueError("Chunk timestamps are not chronological")
                if self.time_delta and n > 1:
                    w_cont[1:n, n_cont] = np.log1p(self._chunk_gaps(times[chunk_rows], w_time[:n]))
                seq_meta = None
                if meta is not None:
                    # Object padding preserves mixed string/numeric IDs; only
                    # real slots are ever selected for output.
                    seq_meta = {key: np.full(width, None, dtype=object) for key in meta}
                    for key in seq_meta:
                        seq_meta[key][:n] = meta[key][chunk_rows]
                yield w_cont, w_cat, w_mask, None, seq_meta, labels, w_time

    def _chunk_spans(self, seconds):
        """(start, end) row spans of one account's chunks; ``seconds`` is its sorted whole-second times.

        tiebreak: every T rows, as before B9's amendment. strict (DESIGN_V1 6.3 (b)): cut only between
        distinct seconds, T distinct seconds per chunk (the last chunk of the account may hold fewer).
        A row's chunk then depends only on which seconds the account has, never on how many rows share
        a second, so adding, removing or reordering a same-second sibling cannot move it. Seconds holding
        ties make the chunk longer than T rows; no row is dropped.
        """
        n = len(seconds)
        if self.history_time_order != "strict":
            return [(start, min(start + self.T, n)) for start in range(0, n, self.T)]
        seconds = np.asarray(seconds)
        if n > 1 and (np.diff(seconds) < 0).any():
            raise ValueError("Chunk timestamps are not chronological")
        second_index = np.cumsum(np.r_[True, seconds[1:] != seconds[:-1]]) - 1  # ordinal of each row's second
        chunk_index = second_index // self.T
        starts = np.flatnonzero(np.r_[True, chunk_index[1:] != chunk_index[:-1]])
        return list(zip(starts.tolist(), np.r_[starts[1:], n].tolist()))

    def _chunk_gaps(self, seconds, order_key):
        """Gap in seconds for chunk positions 1..n-1 (position 0 is always 0).

        strict: seconds since the latest row whose timestamp is strictly earlier, 0 when
        none ([10, 20, 20] -> 0, 10, 10). tiebreak: seconds since the previous row
        ([10, 20, 20] -> 0, 10, 0), the rule before B9.
        """
        if self.history_time_order != "strict":
            gaps = np.diff(seconds)
        else:
            # Vectorised: each row's same-time group starts at first[pos]; the latest strictly-earlier
            # row is the one just before that start (none for the chunk's opening group).
            n = len(seconds)
            starts = np.r_[True, order_key[1:] != order_key[:-1]]
            first = np.maximum.accumulate(np.where(starts, np.arange(n), 0))
            latest_earlier = first - 1
            gaps = np.where(latest_earlier >= 0,
                            seconds - seconds[np.maximum(latest_earlier, 0)], 0).astype(np.int64)[1:]
        if (gaps < 0).any():
            raise ValueError("Chunk timestamps are not chronological")
        return gaps

    # -- iteration --------------------------------------------------------- #
    @staticmethod
    def _pad_chunks(chunk):
        """Right-pad strict chunks to the widest chunk of the batch (B9 amendment). A no-op, returning
        the same objects, when every chunk already has one width (always for tiebreak chunks; default-B
        windows never reach it)."""
        width = max(w[2].shape[0] for w in chunk)
        if all(w[2].shape[0] == width for w in chunk):
            return chunk
        padded = []
        for w_cont, w_cat, w_mask, target, seq_meta, labels, w_time in chunk:
            extra = width - w_mask.shape[0]
            if seq_meta is not None:
                seq_meta = {key: np.concatenate([values, np.full(extra, None, dtype=object)])
                            for key, values in seq_meta.items()}
            padded.append((
                np.pad(w_cont, ((0, extra), (0, 0))), np.pad(w_cat, ((0, extra), (0, 0))),
                np.pad(w_mask, (0, extra)), target, seq_meta,
                np.pad(labels, (0, extra), constant_values=-100), np.pad(w_time, (0, extra)),
            ))
        return padded

    def _emit_batches(self, buffer):
        if self.shuffle:
            np.random.shuffle(buffer)  # window-level shuffle only -- not the sharding bug, left as-is
        for start in range(0, len(buffer), self.batch_size):
            chunk = buffer[start:start + self.batch_size]
            if self.emit_target_seq:
                chunk = self._pad_chunks(chunk)
            out = {
                "continuous": torch.from_numpy(np.stack([w[0] for w in chunk])),
                "categorical": torch.from_numpy(np.stack([w[1] for w in chunk])),
                "mask": torch.from_numpy(np.stack([w[2] for w in chunk])),
            }
            if self.emit_target_seq:
                out["target_seq"] = torch.from_numpy(np.stack([w[5] for w in chunk]))
                out["time_seq"] = torch.from_numpy(np.stack([w[6] for w in chunk]))
            else:
                out["target"] = torch.from_numpy(
                    np.array([w[3] for w in chunk], dtype=np.int64).reshape(-1, 1)
                )
            if self._emit_meta:
                keys = list(chunk[0][4].keys())
                key = "meta_seq" if self.emit_target_seq else "meta"
                out[key] = {k: np.array([w[4][k] for w in chunk]) for k in keys}
            yield out

    def __iter__(self):
        fs = self._ensure_fs()
        buffer: list = []
        for filepath in self._get_worker_files():
            path = strip_scheme(filepath) if fs is not None else filepath
            df = pq.ParquetDataset(path, filesystem=fs).read(columns=self._read_cols).to_pandas()
            cont, cat, target, times, df, meta = self._encode_file(df)
            for window in self._windows_for_file(cont, cat, target, times, df, meta):
                buffer.append(window)
                if len(buffer) >= self.buffer_windows:
                    yield from self._emit_batches(buffer)
                    buffer = []
        if buffer:
            yield from self._emit_batches(buffer)
