# Paired analysis report (V1 build item B12)

- **Every interval:** whole accounts resampled with replacement, 1000 joint draws from seed 0, 95%
  percentile; it covers account sampling only, for fixed trained models (not training seeds), and
  holds for its own line only (pointwise).
- Difference = mean AP of the X seeds minus mean AP of the Y seeds (the mean of the per-seed
  differences when the seeds match), never the AP of averaged predictions.
- **Label rule (X minus Y):** 'consistent positive' needs the overall evaluation interval wholly
  above zero AND the validation direction positive: with validation predictions, the overall
  validation interval wholly above zero (and each validation seed difference above zero); without
  them, the difference of the runs' training valid_ap above zero. 'consistent negative' is the
  mirror. Anything else is 'not resolved'; with neither validation predictions nor valid_ap it is
  'not resolved (no validation)', and with validation predictions for only part of the contrast it
  is 'not resolved (validation incomplete)'. With one seed per side, direction disagreement does not
  apply.
- **evaluation rows in the raw files:** 2466461; scored by every run: 2466461

## Cohorts

- evaluation: 11 raw files, 2466461 raw rows (0 duplicate raw ids); cohort 2466461 rows, 3818
  frauds, 31474 accounts; 15 of 15 runs join cleanly

## Join check (composite id: transaction id plus account id)

- every run holds exactly the cohort ids with the same labels; no duplicate or unmatched id

## Contrasts (X minus Y)

### `H05-VS-H00`

- **Comparison:** A-H05 [42] minus A-H00 [42]

- **label:** not resolved (validation seeds and the evaluation interval point opposite ways);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** +0.005862
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0728 minus 0.0816 = -0.0088 [-0.0169, -0.0013]
  - per seed 42-42:-0.008786 (by seed)
  - AUROC 0.9409 vs 0.9351
  - undefined draws 0

### `H10-VS-H05`

- **Comparison:** A-H10 [42] minus A-H05 [42]

- **label:** consistent positive (every validation seed above zero; interval(s) wholly above zero);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** +0.004567
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0824 minus 0.0728 = +0.0096 [0.0006, 0.0194]
  - per seed 42-42:+0.009587 (by seed)
  - AUROC 0.9408 vs 0.9409
  - undefined draws 0

### `GAP-H05`

- **Comparison:** A-H05 [42] minus A-GAP05-OFF [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.009944
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0728 minus 0.0767 = -0.0038 [-0.0093, 0.0012]
  - per seed 42-42:-0.003844 (by seed)
  - AUROC 0.9409 vs 0.9430
  - undefined draws 0

### `GAP-H10`

- **Comparison:** A-H10 [42] minus A-GAP10-OFF [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.000934
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0824 minus 0.0808 = +0.0016 [-0.0031, 0.0064]
  - per seed 42-42:+0.001588 (by seed)
  - AUROC 0.9408 vs 0.9425
  - undefined draws 0

### `H05-VS-REF`

- **Comparison:** A-H05 [42] minus REF-SINGLE [42]

- **label:** consistent negative (every validation seed below zero; interval(s) wholly below zero);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** -0.003657
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0728 minus 0.0925 = -0.0197 [-0.0276, -0.0127]
  - per seed 42-42:-0.019663 (by seed)
  - AUROC 0.9409 vs 0.9487
  - undefined draws 0

### `B-VS-A-H05`

- **Comparison:** B-H05 [42] minus A-H05 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.017230
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0674 minus 0.0728 = -0.0054 [-0.0122, 0.0013]
  - per seed 42-42:-0.005411 (by seed)
  - AUROC 0.9388 vs 0.9409
  - undefined draws 0

### `B-H05-VS-H00`

- **Comparison:** B-H05 [42] minus B-H00 [42]

- **label:** consistent negative (every validation seed below zero; interval(s) wholly below zero);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** -0.011715
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0674 minus 0.0822 = -0.0148 [-0.0248, -0.0065]
  - per seed 42-42:-0.014795 (by seed)
  - AUROC 0.9388 vs 0.9322
  - undefined draws 0

### `MASK-H05`

- **Comparison:** A-H05 [42] minus A-MASK05-C [42]

- **label:** consistent negative (every validation seed below zero; interval(s) wholly below zero);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** -0.005146
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0728 minus 0.0779 = -0.0051 [-0.0087, -0.0022]
  - per seed 42-42:-0.005104 (by seed)
  - AUROC 0.9409 vs 0.9436
  - undefined draws 0

### `H15-VS-H10`

- **Comparison:** A-H15 [42] minus A-H10 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.006276
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0928 minus 0.0824 = +0.0104 [-0.0009, 0.0232]
  - per seed 42-42:+0.010423 (by seed)
  - AUROC 0.9437 vs 0.9408
  - undefined draws 0

### `H20-VS-H15`

- **Comparison:** A-H20 [42] minus A-H15 [42]

- **label:** not resolved (validation seeds and the evaluation interval point opposite ways);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** +0.000465
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0817 minus 0.0928 = -0.0111 [-0.0184, -0.0038]
  - per seed 42-42:-0.011129 (by seed)
  - AUROC 0.9339 vs 0.9437
  - undefined draws 0

### `B-H10-VS-H05`

- **Comparison:** B-H10 [42] minus B-H05 [42]

- **label:** consistent positive (every validation seed above zero; interval(s) wholly above zero);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** +0.007220
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0904 minus 0.0674 = +0.0230 [0.0122, 0.0395]
  - per seed 42-42:+0.022963 (by seed)
  - AUROC 0.9475 vs 0.9388
  - undefined draws 0

### `B-H15-VS-H10`

- **Comparison:** B-H15 [42] minus B-H10 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.018134
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0904 = +0.0051 [-0.0070, 0.0156]
  - per seed 42-42:+0.005095 (by seed)
  - AUROC 0.9473 vs 0.9475
  - undefined draws 0

### `B-H20-VS-H15`

- **Comparison:** B-H20 [42] minus B-H15 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.013085
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0955 = +0.0000 [-0.0110, 0.0113]
  - per seed 42-42:+0.000006 (by seed)
  - AUROC 0.9520 vs 0.9473
  - undefined draws 0

### `B-VS-A-H00`

- **Comparison:** B-H00 [42] minus A-H00 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.000347
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0822 minus 0.0816 = +0.0006 [-0.0075, 0.0094]
  - per seed 42-42:+0.000598 (by seed)
  - AUROC 0.9322 vs 0.9351
  - undefined draws 0

### `B-VS-A-H10`

- **Comparison:** B-H10 [42] minus A-H10 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.014577
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0904 minus 0.0824 = +0.0080 [-0.0051, 0.0237]
  - per seed 42-42:+0.007965 (by seed)
  - AUROC 0.9475 vs 0.9408
  - undefined draws 0

### `B-VS-A-H15`

- **Comparison:** B-H15 [42] minus A-H15 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.002719
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0928 = +0.0026 [-0.0090, 0.0140]
  - per seed 42-42:+0.002637 (by seed)
  - AUROC 0.9473 vs 0.9437
  - undefined draws 0

### `B-VS-A-H20`

- **Comparison:** B-H20 [42] minus A-H20 [42]

- **label:** not resolved (validation seeds and the evaluation interval point opposite ways);
  direction disagreement: not applicable (one seed)
- **validation seed differences (valid_ap column):** -0.016269
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0817 = +0.0138 [0.0008, 0.0287]
  - per seed 42-42:+0.013772 (by seed)
  - AUROC 0.9520 vs 0.9339
  - undefined draws 0

### `REF-VS-A-H15`

- **Comparison:** A-H15 [42] minus REF-SINGLE [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.007186
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0928 minus 0.0925 = +0.0003 [-0.0127, 0.0137]
  - per seed 42-42:+0.000347 (by seed)
  - AUROC 0.9437 vs 0.9487
  - undefined draws 0

### `REF-VS-B-H15`

- **Comparison:** B-H15 [42] minus REF-SINGLE [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.004467
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0925 = +0.0030 [-0.0084, 0.0172]
  - per seed 42-42:+0.002984 (by seed)
  - AUROC 0.9473 vs 0.9487
  - undefined draws 0

### `REF-VS-B-H20`

- **Comparison:** B-H20 [42] minus REF-SINGLE [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** -0.008618
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0955 minus 0.0925 = +0.0030 [-0.0134, 0.0203]
  - per seed 42-42:+0.002990 (by seed)
  - AUROC 0.9520 vs 0.9487
  - undefined draws 0

### `A-H15-VS-B-H20`

- **Comparison:** A-H15 [42] minus B-H20 [42]

- **label:** not resolved (evaluation interval includes zero); direction disagreement: not
  applicable (one seed)
- **validation seed differences (valid_ap column):** +0.015804
- evaluation overall        rows 2466461, frauds 3818, fraud rate 0.00155, accounts 31474, fraud
  accounts 1026; full history h5 0.942, h10 0.893, h15 0.847, h20 0.804
- **Metrics:** AP 0.0928 minus 0.0955 = -0.0026 [-0.0188, 0.0128]
  - per seed 42-42:-0.002643 (by seed)
  - AUROC 0.9437 vs 0.9520
  - undefined draws 0

## Seed rule for seeds 45 and 46 (the design reads it for A h5 minus A h0; validation when scored)

### `H05-VS-H00 on evaluation`

- **Comparison:** one seed: not computed

### `H10-VS-H05 on evaluation`

- **Comparison:** one seed: not computed

### `GAP-H05 on evaluation`

- **Comparison:** one seed: not computed

### `GAP-H10 on evaluation`

- **Comparison:** one seed: not computed

### `H05-VS-REF on evaluation`

- **Comparison:** one seed: not computed

### `B-VS-A-H05 on evaluation`

- **Comparison:** one seed: not computed

### `B-H05-VS-H00 on evaluation`

- **Comparison:** one seed: not computed

### `MASK-H05 on evaluation`

- **Comparison:** one seed: not computed

### `H15-VS-H10 on evaluation`

- **Comparison:** one seed: not computed

### `H20-VS-H15 on evaluation`

- **Comparison:** one seed: not computed

### `B-H10-VS-H05 on evaluation`

- **Comparison:** one seed: not computed

### `B-H15-VS-H10 on evaluation`

- **Comparison:** one seed: not computed

### `B-H20-VS-H15 on evaluation`

- **Comparison:** one seed: not computed

### `B-VS-A-H00 on evaluation`

- **Comparison:** one seed: not computed

### `B-VS-A-H10 on evaluation`

- **Comparison:** one seed: not computed

### `B-VS-A-H15 on evaluation`

- **Comparison:** one seed: not computed

### `B-VS-A-H20 on evaluation`

- **Comparison:** one seed: not computed

### `REF-VS-A-H15 on evaluation`

- **Comparison:** one seed: not computed

### `REF-VS-B-H15 on evaluation`

- **Comparison:** one seed: not computed

### `REF-VS-B-H20 on evaluation`

- **Comparison:** one seed: not computed

### `A-H15-VS-B-H20 on evaluation`

- **Comparison:** one seed: not computed

