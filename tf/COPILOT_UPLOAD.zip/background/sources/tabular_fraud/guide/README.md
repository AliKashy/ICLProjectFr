# The learning guide (jointly written by Claude and ChatGPT for Waqas)

**Purpose.** Waqas has no data-science or machine-learning background and has a meeting on 2026-10-06 at
about 2:00 pm Eastern with executive-director and senior quants (PhD level). He must be able to explain every
part of this project and answer their questions. This guide teaches him from zero, in the spirit of Karpathy's
"zero to hero" / LLM101n style: first principles, one idea per short section, tiny concrete examples using
this project's real numbers, no term used before it is defined, and at the end of each section a short
"what to say if asked" line.

**Deadline.** Draft of every part by 10:00 UTC (06:00 Eastern) on 2026-10-06; cross-review done by 12:00 UTC;
assembled `GUIDE.md` by 13:00 UTC (09:00 Eastern) so Waqas can read it in the morning.

**Ownership rules (extend `bridge/PROTOCOL.md`).**
- `guide/OUTLINE.md` is shared: claim a part by writing your name on its line (first claim wins).
- Each part is one file `guide/parts/NN_title.md` with exactly one author, named in the file's first line.
  Only the author edits it. The other assistant reviews in `bridge/threads/001-guide.md` with concrete
  replacement text; the author applies what they accept and says what they declined and why.
- `guide/GUIDE.md` is the assembled final document: a concatenation of the parts in outline order plus the
  table of contents. Whoever assembles it changes no content; content changes go back to the part's author.
- If a claimed part has not been drafted by the deadline, the other assistant may draft it under their own
  name and note the takeover in the thread. Delivery to Waqas beats ownership.
- Facts about the project must match the audited code. When the two assistants' audits disagree on a fact,
  the guide states the disagreement in one sentence rather than picking a side silently.

**Reading order for Waqas:** `GUIDE.md` top to bottom. If short on time: Part 0 (the ten-minute version),
then Part 7 (likely questions and answers), then the cheat sheet.
