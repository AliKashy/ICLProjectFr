# Complete Reviewer Context Since Package 005

Prepared: 2026-10-15. Owner: Waqas (K194855). Pod project root:
`/home/jovyan/k194855/tabular_fraud`.

## 0. Why this handoff exists

Your last full report, `REVIEWER_REPORT_005_full.txt`, was written while the 15 V1 cells were training. Since then:

1. V1 completed and was scored and statistically analysed.
2. B-H15 and B-H20 required clean manual retrains and separately traced scores.
3. Yaqun's untouched implementation, logs and reported results were audited.
4. A statement that Yaqun never evaluated his sequential model was corrected: he did.
5. The all-position B implementation and scoring semantics were audited.
6. A gated sliding-scoring experiment and 18 tests were created, but not run on the pod.
7. Browser research recommendations were checked against code and literature.
8. MMR data-owner emails resolved the raw-data periods, partitioning and TFM history policy.
9. PFM/TFM replication threads clarified the prepared benchmark, account structure, duplicates and reproducibility.
10. Cross-team emails clarified the decision-model idea and made full-stream, point-in-time feature construction a
    binding rule for V2.
11. Nengfeng confirmed the manager-level objective: validate reusable embedding signal through downstream fraud
    models and define a standardized feature-store asset.
12. The execution plan was reduced from 35-45 planned training runs to a lean L1-L9 path. The current plan is
    packaged as `V2_EXECUTION_PLAN.md` and supersedes the older ordered plan below.

This document is the authoritative delta. Please re-audit rather than assuming our interpretation is correct.

---

## 1. Evidence hierarchy and preservation

Use evidence in this order:

1. Frozen configs, checkpoint contracts, score metadata, prediction IDs and raw data contracts.
2. Executable code and focused tests.
3. V1 analysis outputs and the final V1 report.
4. Source emails/Teams statements, clearly labelled as external claims.
5. Our interpretations and proposed future work.

Historical files are preserved, including known mistakes. Do not silently reconcile conflicts. Report them.

### Known superseded statements in older material

| Older statement | Correct statement now |
|---|---|
| Yaqun did not score evaluation | He did. His H5 AP/AUROC: 0.0871/0.9475 on 10 files and 0.0965/0.9544 on 100 files. |
| About 127K frauds in 100 raw files | Unsupported extrapolation; frauds beyond file 10 have not been counted. |
| All-position H5 chunks are six rows; average row sees about 2.5 prior rows | Chunks span up to H+1 distinct seconds and can contain more rows. Only 394,669 eval rows (16.6%) sat at position 5. |
| All-position is the only past-only/cacheable design | False. Sliding-target B can also use past-only input. Neither produces a context-independent reusable account state automatically. |
| `seq_CLS` is untrained | It is not directly supervised and is not the all-position head input; its layers still receive gradients. Per-row export must use `out[:, 1:]`. |
| A July 2025+ holdout can be used | The supplied raw data ends in June 2025. No July holdout exists. |
| `cross-file-8000-8200...` proves overlap with raw eval files 8000-8010 | False. It is a prepared artifact name, not a raw-file mapping. Only an ID join can establish overlap. |
| The prepared 952,905-row benchmark has one target per account | False. It has 317,672 accounts; 213,644 have multiple targets; maximum 60. |
| TFM scores were exactly reproduced | Aggregate metrics were very close, but row scores differed. Two reruns in Waqas's fixed stack were exactly equal to each other. |
| July/test and benchmark work should drive the current model search | No. PFM/TFM results are external baselines and sources of design lessons, not the center of this FT project. |

The older browser-response review is deliberately omitted from this lean package because it contains several of
these superseded proposals. `daily_update/README.md` sections 9 and 13-15 retain the correction history without
requiring the reviewer to reconcile another stale document.

---

## 2. Final V1 state

### 2.1 Data

| Split | Raw files | Period | Rows | Frauds | Accounts/use |
|---|---|---|---:|---:|---|
| Train | 1-10 | 2024-10 to 2025-05 | 8,622,629 | 12,757 | Fit model |
| Validation | 4950-4954 | 2024-10 to 2025-05 | 4,292,059 | 7,285 | Epoch/model selection |
| Evaluation | 8000-8010 | 2025-05 to 2025-06 | 2,466,461 | 3,818 | Reported V1 evaluation |

Accounts are disjoint across these file sets. No account occurs in two raw files. Training was at natural prevalence;
there was no fraud/good class downsampling in V1.

New limitation learned from MMR: training raw data ends in May; the TFM eval protocol treats May rows as history and
June rows as targets. V1 scored both May and June, so its evaluation is unseen-account but only June is fully
out-of-time. Approximately 48.7% of its rows are June. V1 metrics remain valid for the stated mixed-period cohort,
but must not be described as a fully out-of-time June test.

### 2.2 Results

| Cell | Evaluation AP | Evaluation AUROC |
|---|---:|---:|
| REF-SINGLE | 0.092476 | 0.9487 |
| Best A: A-H15 | 0.092822 | 0.943693 |
| Best B: B-H20 | 0.095465 | 0.9520 |
| B-ALLPOS-H5 | 0.092670 | 0.945736 |
| A-H05 | 0.0728 | 0.9409 |

No sequential finalist was statistically better than REF-SINGLE under V1's account bootstrap. A and B were tied at
H0/H5/H10/H15. B held its level at H20 while A dropped, so B beat A there on evaluation, but validation ranked them
oppositely. Validation/evaluation rank correlation across 15 cells was 0.11. Most runs selected epochs 0-3.

One same-seed clean restart moved validation AP by about 0.019, which is larger than most architecture gaps. The V1
bootstrap reflects evaluation-account sampling, not training-seed variation.

### 2.3 Run incidents that remain part of the evidence

- B-H15 and B-H20 were stopped accidentally and retrained from scratch with identical resolved config and seed.
- Their full 10-epoch reruns were scored separately; the run table patches those traced results after checkpoint
  verification. Ledger rows remain `train_failed` for the stopped runner attempts.
- A-H15, A-H20 and A-GAP10-OFF used smaller H200 micro-batches with accumulation; effective batch remained 4,096.
- Excluded attempts and exact chosen attempts are in `v1/analysis_outputs/RUNS.md`.
- Your file-sharding fix and the test code you wrote remain in place and were not reverted.

Read `v1/V1_COMPLETE_REPORT.md` and all supplied analysis outputs before accepting these summaries.

---

## 3. Yaqun audit

This handoff does not duplicate Yaqun's source files. We performed a read-only audit of an untouched local copy from:

- internal GitHub repository: `https://github.wellsfargo.com/k016730/tabular_fraud`;
- branch `main`, copied under `github_tabular_fraud/main/tabular_fraud-main`;
- branch `yw_seq`, copied under `github_tabular_fraud/yw_seq/tabular_fraud-yw_seq`;
- Yaqun's pod directory copy under `pod_dir/k016730` (scripts, configs, logs, metrics and surviving artifacts).

No fixes were applied to those copies. We compared their code/configs/logs/metrics with V1 and recorded the findings
below. The raw copies are excluded from this reviewer package because they add hundreds of files and large model
artifacts without being necessary to understand the delta. They remain in the local workspace if a targeted source
check is later requested.

### Verified evaluation results on the same V1 files 8000-8010

| Model | Train files | AP | AUROC |
|---|---:|---:|---:|
| Single transaction | 10 | 0.0792 | 0.9471 |
| Single transaction | 100 | 0.0940 | 0.9514 |
| Flat sequential H5 | 10 | 0.0871 | 0.9475 |
| Flat sequential H5 | 100 | 0.0965 | 0.9544 |

His 100-file H5 result is evidence that scale may matter, but his “history beats single” difference is one run per
arm with no uncertainty interval.

### Audited differences/gaps

- Both original loaders had a multi-worker file-sharding bug: workers independently shuffled then strided, causing
  skipped and duplicated files. V1 uses the fixed path.
- His sequence history allowed same-second rows; V1 excludes them.
- His sequential validation most likely used one file.
- His runs show about twice V1's batches per epoch.
- His code had a causal-mask CLS leak in a path not used for his reported bidirectional run.
- Fixed output paths and incomplete logs weakened provenance.

The 0.0871 Yaqun H5 versus 0.0728 V1 A-H05 gap is not explained. Candidate factors are scale per epoch caused by the
loader, same-second history, validation selection, and run variance. Do not label his number wrong.

---

## 4. All-position B and the unrun sliding experiment

### 4.1 Existing checkpoint

- Cell: `B-ALLPOS-H5`.
- Checkpoint SHA-256:
  `39d9709e6e0bf7a6b2f9b96b9a96dd5f28810ebdd73e003d5c3c9409a6d8a554`.
- V1 overall evaluation AP: 0.092670.
- On the 394,669-row subset at position 5, ALLPOS AP 0.0876 versus default B-H05 AP 0.0669.

### 4.2 Mechanics resolved from code

- A chunk contains up to H+1 distinct seconds, not H+1 rows.
- Position is the number of strictly earlier rows, clamped to H.
- Same-second rows cannot attend to each other.
- Gap is seconds to the latest strictly earlier row in the chunk; first second gets zero.
- The head scores each row's output `out[:, 1:]`; `seq_CLS` is not the head input.
- Loss is summed over real rows and divided by the number of real rows.
- `max_chunk_rows` raises; it never truncates.

Non-overlapping V1 chunks leave many rows with less available history than their account has. That motivates scoring
the same frozen checkpoint with a target-ending sliding window.

### 4.3 New package

`sliding/allpos_sliding_experiment.py` provides `inspect`, `verify`, `score --resume`, and `report`. It preserves the
checkpoint contract and writes new run directories. `verify` checks repeatability, padding, batch composition and a
CPU cross-check. `report` reuses V1 paired account-bootstrap code.

There are 18 tests. On the local Windows machine only two standard-library tests ran and passed; 16 skipped because
numpy/pandas/torch are absent. Python compilation and CLI help passed. The sliding files have not been uploaded or
run on the pod. The reviewer last saw the V1 results before this sliding method existed and should inspect the
code/tests/runbook before pod execution.

Current decision: run this H5 scoring diagnostic first. The lean path next trains all-position B at H20 only if the
inventory passes, and scores H20 in sliding form plus chunked form for V1 continuity. H0 is deferred because the
immediate question is all-position H20 versus the existing B-H20; the existing all-position H5 result provides a
no-new-training history comparison.

---

## 5. Data-owner facts and proposed split redesign

MMR states:

- `tfm_raw_data/` covers October 2024-May 2025.
- `tfm_EVAL_raw_data/` contains June targets with May history.
- Accounts are binned into 10,000 buckets; each account occurs in exactly one raw file.
- Up to 5,000 files were used for TFM training and 2,000 for testing; files 5001-7999 were unused.
- TFM v22b used the last 17 transactions, no time lookback, padded within a 2,048-token sequence.
- Production must store recent transaction token IDs; fewer than 17 would be operationally cheaper.
- The TFM often converged before consuming all available training data.

### Proposed FT split, subject to pod file/date verification

| Split | Source | Targets | History |
|---|---|---|---|
| Train | selected `tfm_raw_data` files | Oct 2024-Apr 2025 | strictly earlier rows |
| Validation | different `tfm_raw_data` files | May 2025 | earlier Oct-Apr rows in those account files |
| Test | unused `tfm_EVAL_raw_data` files | June 2025 only | May plus earlier June rows strictly before target |

Accounts remain disjoint. Preprocessing parameters fit on training targets only. Rows outside a split's target period
remain available as causal history and receive no loss. `month` is unseen in May/June by design; test dropping it or
cyclical encoding rather than leaking future periods into training.

No July holdout exists. June must be protected from iterative model selection. A June-only re-analysis of V1 is a
useful descriptive correction but does not make already-used files an untouched test.

---

## 6. PFM/TFM context: useful baseline, not project redirection

The payment foundation model was fraud-fine-tuned with a distributed 10,000-step run after adding a fraud head;
10,243,344 target rows were presented. The supplied prepared OOT population has 952,905 unique targets, 1,418
frauds and 317,672 accounts. Accounts can have multiple targets: mean 3, median 2, maximum 60.

We have the fraud-fine-tuned developer-model logits/results and XGBoost aggregate results. They are external system
baselines, not the driver of the FT architecture search.

### Reproduction facts

- Supplied output: 952,908 physical rows, 952,905 unique transaction IDs.
- Three identical non-fraud duplicates were consistent with distributed sampler padding; deduplicate before metrics.
- Waqas's two same-stack reruns were exactly equal to each other.
- Supplied versus Waqas rerun: 84.2891% exact probability matches; mean absolute probability difference 0.00013460;
  maximum 0.01409278.
- Sumagha's separate one-GPU rerun differed from both. Different repository versions confound GPU/device effects.
- The tokenizer config lacked fields required by the provided loader. Adding `mask_token="<MASK>"`,
  `add_mask_token=False`, `fill_missing=False` did not change vocabulary/token IDs or pre-tokenized rows.
- Exact replication requires the cleaned shared repository plus pinned runtime; aggregate closeness is not exact score
  reproduction.

v22b is legacy BMG and MMR says it includes non-production fraud proxies such as status/card-inactive date with
potential leakage. v30 is the production-relevant comparator, but our current project does not pivot to reproducing
it.

Important correction: `cross-file-8000-8200-seed-42_1.parquet` is a prepared artifact name. It does not map to raw
bucket files 8000-8200. Infer no V1 overlap from the name.

---

## 7. New cross-team emails and their effect

The full normalized source record is in `SOURCE_THREADS_20261015.md`.

### 7.1 Decision-model / Tabular FM email

The proposal is an off-the-shelf decision tool for routing, risk classification, policy gating, confidence,
escalation and model challenge. Xiaoming argues for a tabular-native backbone to avoid generic token-conversion loss
and expects fine-tuning to outperform direct pretrained use.

Impact:

- Our typed FT numerical/categorical embeddings are aligned with the tabular-native principle.
- Our fraud fine-tuning, per-row score, embedding export and XGBoost consumer are a concrete fraud case study.
- The proposed Q/K “alignment” mechanism is unverified and not an experiment-selection rule.
- Add a later transfer test: frozen encoder + new head versus end-to-end fine-tuning on encoder-unseen data.
- We are not yet a Tabular FM or off-the-shelf decision model: one schema, portfolio and supervised task are
  insufficient. Broader contribution requires transfer across tasks/portfolios, adapters/heads and cost/latency data.

### 7.2 Full-history, point-in-time feature-engineering email

This directly applies. Cross-row features computed after class-specific transaction downsampling are distorted.
Full-window extrema also leak future activity and post-fraud closure. The required order is:

`full raw account stream -> chronological point-in-time features -> split/target selection -> optional training-target downsampling -> model`

V1 did not use class downsampling and already builds strictly earlier sequence history from raw account files. A
finite H cap is an intentional model context, not sampling corruption, if reproduced online.

Binding V2 requirements:

1. Build velocity/count/spend/diversity/recency features from the unsampled stream before target sampling.
2. Omitted training targets remain eligible history for later targets when they existed online.
3. Fit preprocessing parameters on training targets only; do not confuse history availability with fitting scope.
4. Validation/test stay at natural prevalence.
5. Use explicit cold-start/no-history flags rather than conflating zero with no history.
6. Chronological replay test: adding a future row cannot change an earlier target.
7. History-deletion test: dropping a row as a target cannot erase it from later history.
8. Treat activity span, recency, inactivity and tenure as closure-sensitive; define them as of target time.
9. If targets are class-downsampled later, record inclusion rates and recalibrate on natural prevalence.

Our sequential FT is the transformer approach Xiaoming described for within-account serial correlation. Planned V2
features and embeddings could contribute to a portfolio feature store, but the current experiment pipeline is not a
production feature store.

---

## 8. Current ordered plan

1. Run pod tests for the H5 sliding package, then `inspect`, `verify`, `score`, `report`; stop if verification fails.
2. Inventory raw buckets and freeze SELECT, DS_SELECT and FINAL roles before new model results.
3. Train all-position B at H20 under the V1 protocol only if the inventory passes; score it with generalized sliding
   context and chunked context, then compare against B-H20.
4. Export and technically validate B-H20 embeddings; no outcome metrics during export engineering.
5. Build the benchmark pipeline without comparative scoring and run the raw-vs-score-vs-embedding downstream study.
6. Remove the untrained June `month` input for the final encoder, then scale to 100 files only if evidence supports it.
7. Run conditional recipe work only when L3/L6 evidence opens that gate; limit candidates and confirm matched seeds.
8. Freeze the encoder and downstream arm, score FINAL and BENCH once, then define the embedding contract and readiness.

### Manager-aligned representation workstream

After the data split and encoder are fixed:

1. Export the actual per-row prediction representation and score, using `out[:, 1:]` for all-position B.
2. Align FT embeddings, available PFM/TFM embeddings and existing model scores by transaction ID.
3. Measure correlations and PCA explained variance as diagnostics, fitting PCA/scalers on downstream training rows
   only.
4. Compare raw features only, raw + FT score, raw + FT embedding, compressed FT embedding and available TFM-offset
   variants using encoder-unseen downstream training rows.
5. Report predictive lift, calibration, account-clustered uncertainty, latency, storage width and missing-embedding
   fallback.
6. Specify embedding version, checkpoint hash, input/history contract, output dimensions, dtype, scaler/PCA hashes,
   valid-from time, freshness SLA, ID key and rollback behavior.

The PFM/TFM benchmark and decision-model work remain external comparison/context. They do not move ahead of fixing
our data and validation design.

---

## 9. Open questions that can change design

### Data and point-in-time contract

- Exact raw files present in each bucket and per-file periods/fraud counts.
- Label definition, as-of timestamp and maturity.
- Whether same-second transactions are available at decision time and their deterministic order.
- Whether `external_1_scr` is an upstream fraud score and its production timestamp.
- Exact pre-Falcon/segment eligibility only if we perform a formal prepared-benchmark comparison.

### Modeling and production

- Rows-based versus distinct-seconds production history cap.
- Whether H20 provides enough lift to justify account state and latency.
- Which V2 fields are truly available at authorization time.
- Whether feature-store histories can be computed online identically to chronological backfill.
- Training seed variation after the split is fixed.

### External comparison only

- Exact DR/VDR/FPR@0.006 definitions.
- Row-level LoB scores only if paired system analysis is required.
- v30 production-available feature/results package if a matched comparison is pursued.

---

## 10. Requested independent review

Please return findings first, ordered by severity, with file/line references and a pass/fail/blocked verdict for each
area:

1. Reconcile final V1 claims with configs, score metadata and supplied analysis outputs.
2. Review the stated Yaqun provenance, methods and findings for unsupported conclusions. His raw repository/pod copy
   is intentionally not packaged; request a specific source file only if one finding requires re-verification.
3. Audit all-position mechanics stated here against code.
4. Audit the new sliding implementation and all 18 tests; identify any checkpoint-contract, alignment, causality,
   batching, resume, overwrite or statistical-reporting defect before pod use.
5. Review the proposed split for temporal leakage, account leakage, preprocessing leakage and target/history errors.
6. Review the point-in-time V2 feature rules, especially target sampling versus history retention.
7. Flag every conflict between this handoff and an included older document.
8. Separate verified facts, source-team claims, our inference and future proposals.
9. Identify the cheapest missing tests/checks that could falsify the current plan.
10. State whether the package is sufficient to proceed to pod verification; do not bless training merely because
    documentation is complete.

Do not edit the historical reviewer report or V1 artifacts. Proposed code changes should be minimal and separately
listed.