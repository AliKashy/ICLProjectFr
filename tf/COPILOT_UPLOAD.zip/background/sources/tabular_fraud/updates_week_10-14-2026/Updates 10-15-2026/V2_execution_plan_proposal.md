# V2 Execution Plan: Lean Path to an FT Fraud Encoder and a Tested Embedding (2026-10-16)

Owner: Waqas (k194855). Status: **plan only. No new source file has been written and nothing below has been run.**

This version replaces the 35-45-run P1-P7 plan with a lean, evidence-first path. The core sequence is:

1. Finish the all-position H5 sliding diagnostic.
2. Train all-position B at history 20 and compare it with the existing B-H20.
3. Export embeddings and test whether they add value downstream.
4. Compare with the frontline XGBoost model and the TFM.
5. Expand only where the evidence calls for it.

Expected FT training: **2-5 runs near term; about 5-12 in total**, with recipe work only if a gate opens.

Read with: `README.md` sections 7 and 13-15, and `reviewer_update_20261015/COMPLETE_REVIEWER_CONTEXT.md`.

---

## 0. Rules that apply to every stage

### 0.1 Protection
1. **V1 is frozen.** No file under `waqas/phase4a/`, `waqas/phase4b/`, `waqas/base/`, `fraud/`, `src/` or
   `runbook/2026-10-07/` is edited. New code lives in `waqas/v2/` and `waqas/embedding_work/`; new configs in
   `waqas/v2/configs/`. V1 checkpoints must stay loadable.
2. **The in-flight sliding script is not edited.** `waqas/phase4b/scripts/allpos_sliding_experiment.py` records its
   own code hash in the running H5 experiment's fingerprint; editing it would break that run's resume and verify
   compatibility. New sliding scoring imports its functions instead.
3. **Protected paths (never written):** V1 attempt directories under `ablations/`, every V1 `best.ckpt`, V1 S3
   prediction parquets, artifact version 1, `waqas/scoring/allpos_sliding_h5/<existing runs>`,
   `reviewer_update_v1_20261013/`, `pod_review/`.
4. **New outputs are versioned and never overwritten**; every script refuses an existing destination.
5. **Manifests are generated on the pod only.** **No credentials** in any file, log or report.

### 0.2 Evaluation discipline
1. **Populations and roles are fixed in L2 before any new model result** (table in L2.3).
2. **Checkpoint (epoch) selection** inside training uses V1's validation files 4950-4954, exactly as V1 did, so new
   runs stay comparable with V1 checkpoints.
3. **Design decisions** (architecture, month handling, any recipe change, scale) use **SELECT** only: June targets
   of untouched eval-folder files.
4. **Downstream decisions** (score vs embedding, PCA size) use **DS_SELECT** only.
5. **DEV_OOT (V1 files 8000-8010) is descriptive only**, never a tie-breaker.
6. **FINAL is scored once**, after the encoder and the downstream configuration are frozen.
7. **The 952,905-row benchmark is scored comparatively once**, after the freeze. Before it, at most one designated
   checkpoint may be scored as a plumbing check, labelled as such.
8. **No label-based metric is computed for embedding variants during export engineering (L4).**
9. **Every comparison is pre-registered** in `runbook/v2/DECISIONS.md` before its result is seen. No cell is added
   because an early result looks interesting.

**Disclosed trade-off of this design.** Selection uses June labels from accounts disjoint from FINAL. FINAL remains
an unbiased estimate for the frozen model. Design choices may be slightly tuned to June, which a real deployment
would not see before going live. The alternative (May validation with date-window training code) is kept in section
6 if a reviewer requires selection blind to June.

### 0.3 Statistical language and decision rules
1. **Paired comparisons:** candidate minus reference AP on identical rows, whole-account bootstrap (1,000 draws,
   seed 0, 95% percentile interval), reusing `runbook/2026-10-07/paired_report.py` through `paired_v2.py`.
2. **Labels:** interval wholly above 0 = *resolved improvement*; wholly below 0 = *resolved degradation*;
   includes 0 = *not resolved*. "Equivalent" only with a margin declared before the run.
3. **Seed variability and account-sampling variability are reported separately**, never merged.
4. **Adoption rule (declared now):**
   - **Direction:** mean paired difference across matched seeds above 0, **and** above 0 in at least 2 of 3 seeds,
     **and** identical row coverage.
   - **Practical margin for every adoption:** a lower margin for changes adding no inference, storage or maintenance
     cost; a higher margin for changes adding complexity, runtime or data (all-position at H20, PLR, Muon split,
     width, depth, more training files). Margins are written in `DECISIONS.md` **before** the first matched-seed
     result is viewed, using V1 seed and interval evidence (the B-H15 same-seed restart moved validation AP by
     about 0.019; V1 resolved 0.0138 but not 0.003 on 3,818 frauds).
   - Below the margin but in the right direction: **candidate**, not adopted, unless a separate documented benefit
     applies (downstream embedding value in L6, operating-point fraud capture).
   - **Pre-declared exception:** removing `month` (L7) is adopted unless it is a resolved degradation, because it
     removes an input that is undefined for every June row (F19).
5. **One-seed results are screens.** Nothing is adopted on one seed.
6. **Unresolved after matched seeds:** keep the existing reference, or choose by **measured** cost.

### 0.4 Pod conventions
```bash
export PY=/home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI/bin/python
cd /home/jovyan/k194855/tabular_fraud
```
One training run per GPU (`train_sequential.py` refuses `WORLD_SIZE > 1`; `devices=1`).

---

## 1. Code and data facts this plan depends on (verified in the local copy)

| # | Fact | Where | Consequence |
|---|---|---|---|
| F1 | Splits are whole contiguous file ranges (`build_file_list(base, start, end)`); every row is a target | `waqas/phase4b/scripts/train_sequential.py`, `score_sequential.py` | Lean path keeps V1 training; the June-only restriction is applied at analysis time |
| F2 | Model and scorer require `labels != -100` to equal the real-row mask | `sequential_hier.py` `_step`; `score_sequential.py` `_select_predictions` | Date-window *training* would need a separate target mask (section 6 only) |
| F4 | All-position chunks are non-overlapping per account and file; a chunk never sees another chunk | `sequence_builder.py` `_chunks_for_file`, `_chunk_spans` | Chunked all-position scoring often gives a target less context than its account has; sliding scoring is needed for a fair H20 comparison |
| F6 | REF-SINGLE uses `ParquetStreamingDataset` (no history) | `waqas/base/data/parquet_loader.py` | Not retrained in the lean path |
| F7 | V1 artifacts were fit on all rows of files 1-5 (Oct 2024-May 2025) | `fraud/configs/preprocessing.yaml` | Valid for V1-protocol training (training also covers those months); no leakage into June |
| F8 | `month`, `day`, `hour`, `day_of_week` are categorical derived features; `cyclical` encoding would replace them with sin/cos columns | `fraud/configs/predictors.csv`; `fraud/data/datetime_features.py` | Feature-list changes need a new artifact version |
| F10 | Single-target B: head reads `seq_CLS` | `sequential_hier.py` `forward` | B-H20 export = the head input |
| F11 | All-position B: head reads per-row outputs `out[:, 1:]` | `sequential_hier.py` `forward` | All-position export = the head input of each real row |
| F12 | Existing periodic option: one shared `Linear(2F, d)`, no ReLU, sigma 1.0, also on the time gap | `waqas/phase4b/numerical_embeddings.py`, `tokenizer.py` | Not PLR; a proper PLR is new code (section 5 only) |
| F13 | `build_optimizer` sends all parameters to one optimizer; no Muon/AdamW split | `waqas/phase4b/optim.py` | Muon split is new code (section 5 only) |
| F14 | EMA exists and swaps EMA weights in for validation | `waqas/phase4b/callbacks.py` | No new code needed |
| F15 | Stage 1 of B runs batch x width rows in one CUDA launch; the V1 H20 single-target runs used batch 2048 x accumulate 2 to stay under 65,535 | `waqas/phase4b/configs/ft_decisions_hier_long.yaml` | All-position H20 batch size is set from measured chunk widths |
| F16 | `measure_chunk_widths.py` reads `data.train_*`, `data.val_*`, `eval.*` and accepts dotlist overrides | `waqas/phase4b/scripts/measure_chunk_widths.py` | Usable as is |
| F17 | `paired_report.map_run` maps predictions onto all raw rows of the files | `runbook/2026-10-07/paired_report.py` | `paired_v2.py` filters to June targets **after** history counts are computed |
| F18 | V1 B-H20: `ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887`, scored via `manual_score/20261013T142910Z`; V1 specs: `ft_decisions_hier_long.yaml` (h20 axis) | `analysis_outputs/RUNS.md` | Reference model; reruns at new seeds copy its spec exactly |
| F19 | Categorical vocab reserves index 0 = UNK; unseen values map to UNK. V1 training months are Oct-May, so **every June row's `month` is UNK**. No training row uses UNK, so its embedding row gets zero gradient and stays at its random initialization (apart from negligible weight decay) | `fraud/data/preprocessing.py` `encode_categorical`; V1 report (48.7% of eval rows unseen month) | Every June evaluation carries a random `month` input. Same for all compared models, so comparisons stay fair; the final encoder drops `month` (L7) |
| F20 | `run_ablations.py --config <spec>` accepts a spec from any folder and writes a new attempt directory with provenance; run directly it skips the runbook preflight and ledger | `waqas/phase4b/scripts/run_ablations.py` | New V1-protocol runs use specs in `waqas/v2/configs/specs/`; run `preflight_pod.py --skip-data` first |
| F21 | The sliding script hard-codes V1 gates (`eval_files_are_v1_8000_8010`), its experiment root `allpos_sliding_h5`, and records its code hash in each run's fingerprint | `allpos_sliding_experiment.py` | Generalized sliding scoring is a **new** script importing its functions |
| F22 | `fraud/configs/predictors.csv`: 24 lines, SHA-256 `635153390b266201651303e65e3b9222b77450a5523de81afa88a682c6f69bce` (local copy) | local repo | The pod copy is hash-checked before L7 derives a no-month list |

---

## 2. Stages at a glance

| Stage | Content | Starts | FT training runs | Gate to the next stage |
|---|---|---|---:|---|
| **L1** | Finish H5 sliding scoring and report | Now | 0 | Report gates pass |
| **L2** | Lean data inventory and population allocation | Now | 0 | Populations frozen |
| **L3** | All-position H20 vs B-H20 | After L2 | 1, then up to 4 | Matched-seed decision |
| **L4** | B-H20 embedding export engineering | Now | 0 | Validation passes |
| **L5** | Benchmark pipeline (no comparison) | After L2 | 0 | Pipeline checks pass |
| **L6** | First downstream study (raw vs score vs embedding) | After L2 + L4 | 0 | DS_SELECT result |
| **L7** | Final encoder: month removal and scale | After L3 | 1-6 | Frozen encoder |
| **L8** | Final event: FINAL, downstream, benchmark | After L6 + L7 | 0 | Report |
| **L9** | Embedding contract and readiness | After L8 | 0 | Only if value holds |
| - | Conditional recipe work (section 5) | Only if a gate opens | 2-6 | - |

---

## L1. Finish the ALLPOS-H5 sliding experiment

| Item | Content |
|---|---|
| Question | Does the existing B-ALLPOS-H5 checkpoint score better with target-ending sliding context than with V1 chunks? |
| Files | Existing only: `allpos_sliding_experiment.py`, `tests/test_allpos_sliding_experiment.py`, `runbook/2026-10-14/ALLPOS_H5_SLIDING_RUNBOOK.md` |
| Commands | Runbook sections 2.0-2.11 |
| Outputs | `waqas/scoring/allpos_sliding_h5/<run id>/` (`verify_result.json`, predictions, `SCORE_COMPLETE`, `report/REPORT.md`, `slices.csv`, `report.json`) |
| Gate | 18 passed, 0 skipped; all `verify` gates; all report gates |
| Decision | Resolved improvement or not resolved: L3 reports sliding as the **target-ending decision-time-context** result and chunked for continuity. Resolved degradation: investigate before L3 (unexpected). Sliding is not called production-ready before L9. |
| Caveat | Files 8000-8010 influenced V1 selection: exploratory |

---

## L2. Lean data inventory and population allocation

### L2.1 New files
| File | Purpose |
|---|---|
| `waqas/v2/__init__.py`, `waqas/v2/scripts/__init__.py` | Package markers |
| `waqas/v2/scripts/data_inventory.py` | Read-only; four columns only (`fi_transaction_id`, `Nmap_account_reference_xid`, `transaction_dttm`, `frd_tag`) |
| `waqas/v2/scripts/select_splits.py` | Applies the L2.3 rules to the inventory; writes `waqas/v2/configs/split_v2.yaml` |
| `waqas/v2/configs/population_roles_v2.yaml` | Exposure table (L2.4) |
| `tests/v2/test_select_splits.py` | Synthetic inventories: expected blocks; refusal on overlap or too few frauds; byte-identical rerun |

### L2.2 Inventory behaviour and commands
- `--list-only`: every key under `tfm_raw_data/` and `tfm_EVAL_raw_data/` (names and sizes).
- Per file: rows, frauds, accounts, fraud accounts, min/max time, timestamp dtype/timezone; rows, frauds and fraud
  accounts per month; duplicate IDs; nulls; June targets with at least 0/1/5/10/20 earlier rows in the file.
- Cross-file accounts: salted SHA-256 with **one salt per run, shared by all files**; salt never written; counts only.
- `--benchmark-ids <parquet>`: benchmark IDs per inspected file (counts only).
- Never writes raw IDs.
```bash
STAMP=$(date -u +%Y%m%dT%H%M%SZ); OUT=runs/v2/L2_inventory/$STAMP
$PY waqas/v2/scripts/data_inventory.py --bucket train --list-only --out $OUT
$PY waqas/v2/scripts/data_inventory.py --bucket eval --list-only --out $OUT
$PY waqas/v2/scripts/data_inventory.py --bucket train --start 1 --end 100 --out $OUT
$PY waqas/v2/scripts/data_inventory.py --bucket train --start <block B start> --end <block B end> --out $OUT
$PY waqas/v2/scripts/data_inventory.py --bucket eval --start <first eval file after 8010> --end <+60> --out $OUT \
    --benchmark-ids s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondeline/eval/cross-file-8000-8200-seed-42_1.parquet
$PY waqas/v2/scripts/select_splits.py --inventory $OUT --out waqas/v2/configs/split_v2.yaml
```
Ranges are set from the listing; the ranges shown are proposals. Also delivers fraud counts for files 11-100.

### L2.3 Populations (fixed before any new model result)

| Population | Role | Source | Targets analysed | Rule |
|---|---|---|---|---|
| ENC_TRAIN_10 | Encoder training (V1 protocol) | `tfm_raw_data` 1-10 | all rows (Oct-May), as V1 | Same as V1 |
| ENC_TRAIN_100 | Scale (L7) | `tfm_raw_data` 1-100 | all rows | Contains ENC_TRAIN_10 |
| EPOCH_VAL | Epoch/checkpoint selection inside training | `tfm_raw_data` 4950-4954 | all rows | Same as V1 |
| SELECT | Design decisions (L3, L7, section 5) | `tfm_EVAL_raw_data` block S | **June targets only**; May rows are history | Untouched files after 8010; at least 2,000 June frauds; fewest benchmark IDs available |
| DS_TRAIN | Downstream consumer fit | `tfm_raw_data` block B | all rows (Oct-May) | Disjoint from 1-100 and 4950-4954; encoder never sees these accounts |
| DS_SELECT | Downstream decisions | `tfm_EVAL_raw_data` block S2 | June targets only | Disjoint from S and F; at least 2,000 June frauds |
| DEV_OOT | Descriptive continuity | `tfm_EVAL_raw_data` 8000-8010 | June targets (and V1's full view) | Never used for decisions |
| FINAL | One-time final evaluation of encoder and downstream consumer | `tfm_EVAL_raw_data` block F | June targets only | Disjoint from S and S2; at least 3,000 June frauds; named FINAL only once confirmed |
| BENCH | External system comparison | Prepared 952,905-row parquet | June 2025 | Overlap with S, S2, F, DEV_OOT reported |

- Thresholds (2,000 / 3,000) come from V1: on 3,818 frauds a 0.0138 AP difference was resolved and 0.003 was not.
  They may be raised; they are never lowered after a model result.
- V1 suggests roughly 170 June frauds per eval file, so S, S2 and F need about 12, 12 and 18 files. These figures
  are only for planning: the inventory's measured counts decide.
- `month` for June rows is UNK for all models (F19); this is equal across compared models and is removed in L7.

### L2.4 Exposure table (`population_roles_v2.yaml`)
Rows = populations; columns = epoch selection, design selection, downstream training, downstream selection,
artifact fit, PCA fit, final evaluation, benchmark scoring. Each run also writes its own `exposure.json` in its
attempt directory (no shared file written by parallel runs); records are collected into `runs/v2/EXPOSURE_LOG.csv`
after each stage.

### L2.5 Gates
| Gate | Action on failure |
|---|---|
| Both listings recorded | Stop |
| Observed coverage matches MMR's description (training folder Oct 2024-May 2025; eval folder May-June 2025) | Stop automatic selection; document; revise rules before any model run |
| **Zero accounts in more than one file among selected files** | **Stop: the current builder assumes file-contained accounts;** redesign history construction first |
| Fraud thresholds met | Enlarge blocks; record before any model run |
| Sharp fraud-rate drop in the latest months | Flag possible label immaturity; ask the data owner (D1) |
| `split_v2.yaml` (with SHA-256) and the exposure table written | Stop |

Compute: CPU only.

---

## L3. All-position H20 versus B-H20

| Item | Content |
|---|---|
| Question | Does all-position training at history 20 match or beat the existing B-H20 when both see target-ending context? |
| Hypothesis | All-position's dense supervision helped at H5 (B-ALLPOS-H5 0.0927 vs B-H05 0.0674 V1 evaluation AP); it may also help at H20. |
| Frozen | V1 protocol exactly: files 1-10, EPOCH_VAL 4950-4954, artifact version 1, predictor list v1, linear embedding, AdamW (lr 3e-4, wd 1e-5), 10 epochs, patience 5, causal strict all-position (as the V1 B-ALLPOS-H5 spec). |
| Variable | `sequence.history_len=20`; batch size from measurements (below). |

### L3.1 New files
| File | Purpose |
|---|---|
| `waqas/v2/configs/specs/L3_allpos_h20_v1protocol.yaml` | `base_config: waqas/phase4b/configs/sequential_hier_allposition.yaml`; the `common_overrides` of `ft_decisions_hier_allpos.yaml`; axis `h20: [sequence.history_len=20, training.batch_size=<measured>, sequence.max_chunk_rows=<measured>]`; `output_root: runs/v2/L3/allpos_h20`; seed axis 42 (43 and 44 added only by L3.4) |
| `waqas/v2/configs/specs/L3_b_h20_seeds.yaml` | Copy of the `ft_decisions_hier_long.yaml` h20 cell with seeds 43 and 44 only (`output_root: runs/v2/L3/b_h20`); used only if L3.4 opens |
| `waqas/v2/scripts/score_allpos_sliding.py` | Generalized sliding scorer: imports `plan_account_windows`, `encode_window`, `collate`, `run_model`, `score_encoded`, `load_checkpoint_with_contract` and the verify helpers from `allpos_sliding_experiment.py`; adds `--attempt-dir`, `--eval-base`, `--file-start/--file-end`, `--experiment-root`. Same inspect/verify gates as L1 with the V1-file gate generalized; output under `waqas/scoring/allpos_sliding_v2/<run id>/` |
| `tests/v2/test_score_allpos_sliding.py` | At H5 on synthetic data reproduces the L1 module's windows exactly; H20 window rules; exactly-once emission; refuses an existing run directory |
| `waqas/v2/analysis/paired_v2.py` | Copy of `paired_report.load_raw` that keeps the timestamp; filters raw rows to the June target window **after** history counts; reuses `map_run`, `draw_multiplicities`, `line_aps`, `compare` |
| `tests/v2/test_paired_v2.py` | Unbounded window equals `paired_report`; bounded window still counts history over all rows |

### L3.2 Commands
```bash
$PY -m pytest -q tests/v2 tests/test_allpos_sliding_experiment.py
$PY runbook/2026-10-07/preflight_pod.py --skip-data
# measure chunk widths at H20 on the training and epoch-validation files
$PY -m waqas.phase4b.scripts.measure_chunk_widths --config waqas/phase4b/configs/sequential_hier_allposition.yaml \
    sequence.history_len=20 data.train_start=1 data.train_end=10 data.val_start=4950 data.val_end=4954 --splits train val
# set batch_size and max_chunk_rows in the L3 spec (rules below), then train seed 42
CUDA_VISIBLE_DEVICES=<free> nohup $PY waqas/phase4b/scripts/run_ablations.py \
    --config waqas/v2/configs/specs/L3_allpos_h20_v1protocol.yaml > runs/v2/L3/allpos_h20_seed42.out 2>&1 &
```
Batch rules: batch (chunks) x maximum chunk width < 65,535 (F15); peak GPU memory below 80%; target rows per
optimizer update close to B-H20's 4,096 (use `training.accumulate_grad_batches` if needed); `max_chunk_rows` = the
measured maximum (it raises, never truncates).

### L3.3 Scoring and comparison (all on SELECT June targets; DEV_OOT reported)
| Model | Scoring |
|---|---|
| B-ALLPOS-H20 (new) | `score_allpos_sliding.py` on blocks S and 8000-8010 (primary); chunked via `score_sequential.py` (continuity) |
| B-H20 (V1 checkpoint) | `score_sequential.py --config <its resolved scoring config> eval.base=.../tfm_EVAL_raw_data eval.file_start=<S> eval.file_end=<S> eval.predictions_base=<new path>` (single-target scoring is already target-ending) |
| B-ALLPOS-H5 (V1 checkpoint) | `score_allpos_sliding.py` on block S: within-all-position history effect (H20 vs H5) at no training cost |

Contrasts in `paired_v2.py` on June targets of S: ALLPOS-H20 (sliding) - B-H20; ALLPOS-H20 - ALLPOS-H5 (sliding).
Also recorded: training target rows per second, scoring rows per second, peak memory, batch-1 latency.

### L3.4 Decision (pre-registered)
- Seed 42 **resolved degradation** vs B-H20: stop the all-position branch; B-H20 is the encoder.
- Otherwise: train ALLPOS-H20 at seeds 43 and 44 **and** B-H20 at seeds 43 and 44 (the matched seeds do not exist
  for B-H20); apply rule 0.3.4 with the higher margin (all-position adds a different serving path).
- Not adopted: B-H20 remains the reference encoder.
- Compute: 1 run, then up to 4 more.

---

## L4. B-H20 embedding export engineering (can start now)

| Item | Content |
|---|---|
| Question | Can we extract exactly the vector the fraud head consumes, aligned to transaction IDs, reproducibly? |
| Rule | No label-based metric on any population. |

### L4.1 New files
| File | Purpose |
|---|---|
| `waqas/embedding_work/__init__.py` | Package marker |
| `waqas/embedding_work/export_embeddings.py` | Loads a checkpoint with its own resolved config through the V1 factory and contract check. Captures the **input to `model.head`** with a forward pre-hook; this is by definition what the head consumes, in both modes (`seq_CLS` [B, d] for single-target B; `out[:, 1:]` [B, T, d] for all-position, keeping real target rows only). Writes per file: IDs, account, `target_time`, `source_file`, prior rows in file, score, `e_0 ... e_47` (float32), and `manifest.json` (checkpoint SHA-256, config hash, artifact version and hash, extraction policy, code hash, torch/CUDA versions, batch size). Refuses an existing destination. For all-position, reuses the L3 sliding windows so each target's vector comes from its target-ending window. |
| `waqas/embedding_work/validate_embedding_export.py` | Structural: one row per intended target; no padding; dimension 48; finite. Numeric, each reported separately: **(1) same-pass reconstruction:** `softmax(head(e))[:,1]` equals the same pass's score (<= 1e-6); **(2) repeat extraction:** identical inputs and batching, difference recorded; **(3) V1 score reproduction:** at V1's scoring batch size (2048 for B-H20) where possible, within `max(1e-6, 10 x max(repeat, extra-padding, batch-composition))`, with padding and batch-composition sensitivity measured on an equivalence sample (the L1 tolerance rule). Writes `validation.json`. |
| `waqas/embedding_work/embedding_diagnostics.py` | Label-free: per-dimension mean and std, near-constant dimensions, PCA explained variance, component-score correlations |
| `tests/embedding_work/test_export_alignment.py` | IDs, order and counts align; padding never exported |
| `tests/embedding_work/test_head_reconstruction.py` | Tiny models in both modes: `head(hooked input)` equals logits |
| `tests/embedding_work/test_export_contract.py` | Manifest complete; refuses mismatched checkpoint/config; refuses overwrite |

### L4.2 Commands
```bash
$PY -m pytest -q tests/embedding_work
CUDA_VISIBLE_DEVICES=<free> $PY waqas/embedding_work/export_embeddings.py \
    --attempt ablations/arch_b_hier/history_h15_h20/B-H20-1dfa4d00fd924637950e7c6f02c3f887 \
    --eval-base s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data --file-start 8000 --file-end 8000 \
    --out runs/embedding_work/L4_bh20/<stamp>
$PY waqas/embedding_work/validate_embedding_export.py --export runs/embedding_work/L4_bh20/<stamp> \
    --v1-predictions <B-H20 prediction path from its manual_score metadata>
```
File 8000 is used because V1 scores exist there to check against; this is an engineering check, not evaluation.
Gate: all tests and every `validation.json` check pass. Compute: 1 short GPU pass.

---

## L5. Benchmark pipeline (no comparison before the freeze)

New files: `waqas/v2/scripts/benchmark_v2.py`, `tests/v2/test_benchmark_v2.py`.
1. Benchmark IDs from the prepared parquet; overlap with S, S2, F and DEV_OOT (from L2).
2. History for each benchmark target from its raw eval file (join by ID; the artifact name is not a file map).
3. **Duplicate audit:** count duplicate IDs and compare every non-key field. Collapse only exact copies (the three
   known TFM-output duplicates were audited as exact). Any conflict in label, score, amount or metadata stops the
   comparison until the artifact owner resolves it; never keep an arbitrary row. Save `duplicate_audit.csv`.
4. Align labels and amounts; align FL and TFM row-level scores by `fi_transaction_id`; confirm DR, VDR and
   FPR@0.006 definitions with Xinyu (D5).
5. Optional: score one designated checkpoint, labelled "plumbing only", no comparison.

---

## L6. First downstream study (after L2 and L4)

| Item | Content |
|---|---|
| Question | Does the FT representation carry fraud signal beyond its own score? |
| Encoder | B-H20 (V1 checkpoint). Repeated with ALLPOS-H20 only if L3 adopts it. |
| Populations | DS_TRAIN (fit), DS_SELECT (June targets; decisions). FINAL is **not** touched here. |
| Arms | (1) raw features; (2) raw + FT score; (3) raw + full 48-d embedding. PCA-k (k = 8, 16) reported as secondary diagnostics, fit on DS_TRAIN only. |
| Raw features | The 23 V1 predictors **without `month`** (June values are unseen in DS_TRAIN, F19). |
| Scope label | "Incremental value over our raw fields." It does not answer whether the embedding improves the incumbent feature set (D6). |

New files: `waqas/embedding_work/downstream_xgb.py`, `tests/embedding_work/test_downstream_split.py`.
- Deterministic consumer: fixed seed, no row or column subsampling, CPU `hist`, identical hyperparameters and
  budget for all arms; one arm trained twice to prove repeatability (if not identical; matched consumer seeds,
  reported separately). All arms compared on identical rows.
- Test: PCA, scaler and consumer never see DS_SELECT or FINAL rows during fit;
  `--final` refused without `runbook/v2/FROZEN_MODEL.json`; arms differ only in representation.
- Dependency: `$PY -c "import xgboost"` (D8).
- Decision: embedding arm vs score arm on DS_SELECT under 0.3.2 labels. This
  decides whether L8 includes a downstream arm and whether embedding value is a "separate documented benefit"
  in L3/L7 decisions.
---

## L7. Final encoder: month removal and scale

1. **Month removal (pre-declared, F19).**
   - New files: `waqas/v2/configs/predictors_nomonth.csv` (the `month` row removed from the hash-checked
     `fraud/configs/predictors.csv`) and `waqas/v2/configs/preprocessing_nomonth.yaml` (same fit files 1-5 as V1,
     `output_base: s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/artifacts`, a new version identifier).
   - Command: `$PY fraud/scripts/build_preprocessing_artifacts.py --config waqas/v2/configs/preprocessing_nomonth.yaml`
     (existing builder; no code change; refuse if the version exists).
   - Train the L3 encoder without `month` at seeds 42-44 (its with-month seeds exist from L3). Adopt unless a
     resolved degradation on SELECT (0.3.4 exception).
2. **Scale.** Train the frozen recipe on files 1-100 at seed 42 (artifacts unchanged, so only training rows
   change).
   - Resolved degradation: stop; keep 10 files.
   - Otherwise: seeds 43 and 44, then rule 0.3.4 with the higher margin. Never promoted on one seed.
3. Record the frozen encoder in `runbook/v2/DECISIONS.md`.
- Compute: 3 runs (month) + 1-3 runs (scale).

---

## L8. Final event (once)

1. Write `runbook/v2/FROZEN_MODEL.json`: encoder checkpoint SHA-256, config hash, artifact version and hash,
   `split_v2.yaml` hash, code manifest hash, scoring policy, downstream arm selected in L6 (re-fit with the frozen
   encoder on DS_TRAIN and re-selected on DS_SELECT if the encoder changed after L6).
2. Score FINAL (encoder and downstream arm) and BENCH once.
3. Report: AP, AUROC, KS, DR, VDR, FPR at the agreed operating point; coverage; common-valid population; unique fraud
   capture and fraud-value overlap vs FL and TFM; FT/FL/TFM score correlations; calibration; slices by history depth,
   amount and targets per account. Account-clustered intervals throughout. V22b proxy-leakage caveat stated.
4. If overlap or missing artifacts make the benchmark comparison invalid, document the gap explicitly.

---

## L9. Embedding contract and readiness (only if L6/L8 show downstream value)

- `waqas/embedding_work/embedding_contract.md`: version, checkpoint hash, input schema, history policy (row cap,
  same-second rule), dimension, dtype, scaler/PCA hashes, valid-from, ID key, freshness, rollback.
- Readiness for the frozen variant only: history row cap, same-second availability (D2), latency and throughput
  (from L3), state size per account, cold-start behaviour, versioning.
- TFM embedding comparison and FT+TFM arms once D7 is available, selected on DS_SELECT, reported in the same format.

---

## 5. Conditional recipe work (only if a gate opens)

**Gate** (any one, recorded in `DECISIONS.md` with the evidence):
- L3 is promising but not resolved after matched seeds;
- L6 shows downstream value worth improving;
- training instability limits conclusions (seed spread comparable to the effects being tested);
- a specific diagnosed weakness points to a specific intervention.

**Ranked candidates (one seed each first, then matched seeds for the best only):**
1. Proper PLR vs linear numerical embedding.
2. AdamW vs Muon + AdamW split.
3. EMA, only if seed instability remains material.

**Rules if this section runs:**
- Pre-register every cell. At most the top two candidates advance to matched
  seeds, ranked on SELECT by seed-42 paired difference, with identical coverage and no unresolved correctness or
  runtime issue. A positive seed-42 difference alone is not sufficient.
- If more than six cells would be screened, split SELECT into SELECT_SCREEN and SELECT_CONFIRM (disjoint files,
  each at least 2,000 June frauds) before the first run.
- Adoption under 0.3.4 with the higher margin.

**Files (built only when this section runs):**
| File | Content |
|---|---|
| `waqas/v2/numerical_embeddings_v2.py` | `PLREmbedding`. Input `[N, C_tx]` (transaction continuous features only); learned frequencies `[C_tx, F]` initialised `N(0, sigma^2)`; periodic expansion `[N, C_tx, 2F]`; **per-feature** projection weights `[C_tx, 2F, d]` plus bias `[C_tx, d]` (one projection per feature, via `einsum`); ReLU; output `[N, C_tx, d]`. The time-gap column keeps the linear embedding. `sigma`, `F` configurable and recorded in the contract. |
| `waqas/v2/tokenizer_v2.py`, `waqas/v2/sequential_hier_v2.py`, `waqas/v2/factory_v2.py` | Tokenizer with `linear` / `periodic_v1` / `plr_feature_specific`; model subclass that only swaps the tokenizer and records `v2_recipe` in the contract; factory accepting the subclass |
| `waqas/v2/optim_v2.py` | Muon for 2-D weight matrices inside the transformer blocks; AdamW for embeddings, CLS tokens, position embeddings, head, norms, biases. Uses `torch.optim.Muon` if present, else `pytorch_optimizer.Muon`, else refuses (D9). |
| `tests/v2/test_recipe_v2.py` | PLR: each feature owns distinct projection parameters; changing one feature changes only its own token; the time-gap token is unchanged; feature order stable; output shape `[N, C_tx, d]`. Optimizer: every parameter in exactly one group; 2-D block weights in Muon. Flags off: contract equals V1. |

Compute: 2-6 runs.

---

## 6. Alternative kept on file: May validation with date-window training

Use only if a reviewer requires design selection blind to June labels. Train on Oct-Apr targets with May as
validation and June as FINAL. This needs the code from the previous plan version:
- `target_window.py`;
- `SequenceBuilderV2` with a separate `target_mask_seq` (F2);
- `ParquetStreamingDatasetV2`;
- `FTTransformerHierV2` with masked loss;
- `train_v2.py`, `score_v2.py`;
- an artifact refit on rows before May.

Note that May would then also be an unseen `month` value, so the no-month predictor list becomes mandatory. That
specification (plan v2, package P3B) was replaced by this version and is not kept as a separate file; the list above
is its complete file set.

---

## 7. Run budget

| Work | Initial runs | Conditional runs |
|---|---:|---:|
| L1 H5 sliding | 0 | 0 |
| L3 all-position H20 | 1 | 4 (ALLPOS-H20 x2, B-H20 x2 matched seeds) |
| L4 export | 0 (1 GPU pass) | 0 |
| L6 downstream | 0 (consumer fits) | 0 |
| L7 month removal | 3 | 0 |
| L7 scale | 1 | 2 |
| Section 5 recipe | 0 | 2-6 |
| **Total** | **5** | **up to about 12 more** |

---

## 8. Unresolved dependencies

| # | Dependency | Owner | Blocks |
|---|---|---|---|
| D1 | Label definition, as-of date, maturity | Data owner | L2 maturity flag; final interpretation |
| D2 | Same-second transactions available at decision time? | Data owner | L9 |
| D3 | Is `external_1_scr` an upstream fraud score, and when is it available? | Data owner | Interpretation of all results |
| D5 | DR / VDR / FPR@0.006 definitions | Xinyu | L5, L8 |
| D6 | FL features or approved consumer interface; FL row-level scores | Xinyu | L8 incumbent comparison; L6 scope |
| D7 | TFM embeddings for our downstream rows; offset implementation | Xinyu | L9 TFM arms |
| D8 | `xgboost` on the pod | Platform | L6 |
| D9 | `torch.optim.Muon` or `pytorch_optimizer` on the pod | Platform | Section 5 only |
| D10 | Eval-folder numbering and qualifying S, S2, F blocks | L2 | L3 onward |
| D11 | Benchmark overlap with S, S2, F | L2 | L5, L8 |
| D12 | Reviewer sign-off on L3 and L4 code | Reviewer | L3 training, L6 |
| D13 | Hash of `fraud/configs/predictors.csv` on the pod matches F22 | Waqas (pod) | L7 |

---

## 9. Change log

| Version | Change | Reason |
|---|---|---|
| 2026-10-16 v1 | 18-stage S0-S17 plan | First full plan |
| 2026-10-16 v2 | P1-P7 packages; 31 corrections (selection discipline, statistics, PLR, Muon, export by mode, duplicates, exposure) | Two external audits |
| 2026-10-16 v3 (this) | Lean L1-L9 path; 5 initial runs instead of 35-45 | Answer the core questions first |
| v3 | Design selection on untouched June eval blocks (SELECT, DS_SELECT); V1-protocol training; June filter at analysis time | Removes the date-window training code from the critical path; trade-off disclosed in 0.2 |
| v3 | B-H20 matched seeds 43-44 added to L3 | Matched-seed comparison needs both arms; budget is up to 5, not 3 |
| v3 | `month` removal pre-declared for the final encoder | June maps to an untrained UNK embedding (F19) |
| v3 | Practical margin for every adoption (two tiers) | Direction alone passes about half the time under no effect |
| v3 | Bounded advancement and screen/confirm split in conditional recipe work | Limits selection on SELECT |
| v3 | Export through a forward pre-hook on `model.head` | Exactly the head input in both modes; no model subclass needed |
| v3 | New sliding scorer imports the existing module instead of editing it | Editing would change the code hash recorded by the in-flight H5 run (F21) |
| v3 | Explicit PLR tensor contract and per-feature tests | Prevent a shared-projection reimplementation |
| v3 | `predictors.csv` path confirmed with SHA-256 (F22) | An external audit claimed it was missing; it exists |
| v3 | REF-SINGLE retrain and all-position H0 deferred | Not needed for the immediate decision; ALLPOS-H5 vs H20 on SELECT gives a free within-family history contrast |
