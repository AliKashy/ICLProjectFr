# Request 1 — FT-Transformer fraud project rundown

Prepared 1 November 2026.

## Contents

- [Overview and current direction](#overview)
- [Models, experiments and results](#experiments)
- [Substantive implementation changes](#changes)
- [Features, research, embeddings and downstream work](#research)

---

<a id="overview"></a>

# Overview and current direction

Owner-facing rundown, 1 November 2026.

**The project has moved from a working single-transaction/flat-transformer starting point to a completed baseline comparison, a second study of how history is used, a repeat-seed comparison, and a selected model to take into feature development.** We have also built much of the machinery for feature screening, embedding export and downstream comparison. Those later capabilities have different completion states; available code is not a measured improvement.

This account focuses on changes that affect model correctness, learning, evidence, or the next deliverable. Each detailed section links its sources. It consolidates the substantive work visible in the repository and returned reports; it is not a claim that every unreported pod command is known.

**Source-identity clarification, 1 November:** the returned installation comparison reports that native original dependencies matched Yaqun's supplied copies, with 10 `fraud/` and 48 `src/` differences from the repository snapshot. Reported fits read version1 artifacts from the owner's storage; equality with Yaqun's artifact contents remains unestablished. The corrected [handoff companion](../request_3/ANSWER.md) records these distinctions, lagging copies and remaining source findings.

## Read this first

| Question | Answer at this snapshot |
|---|---|
| Did we train many models? | Yes: **22 retained fitted models in the documented V1 + L3 + seed-follow-up set**: 15 V1 cells, three later seed-42 fits, and four additional seed-43/44 fits. Historical preliminary experiments and failed/restarted attempts are separate. This is not 22 different architectures. |
| Did we do more than train? | Yes: data/cohort checks, repeat scoring on different populations, paired statistical comparisons, analysis of history/position/time effects, feature research and implementation, embedding/downstream tools and reproducible execution. |
| What goes forward? | The owner selected **Architecture B, H20, all-position chunk training**, with target-ending validation/scoring. B-H20 stays as a reference. |
| Does that mean the production model is finished? | No. The next feature version, final scale-up, downstream benefits, protected final evaluation and production evidence remain unfinished. |
| What happens to the old results? | They remain the baseline. New features, preprocessing and training policies get identifiable new versions. |
| What is the latest feature direction? | The next feature model drops month and retains the time gap, hour, day of week and day of month. The owner declined a separate no-month-only study. |
| Are extra seed studies still queued? | No. The owner closed that study. Earlier proposed eight-run queues and additional-repeat commands are historical proposals. |
| Has Claude agreed with this new rundown? | Yes. CL reviewed the full rundown; its corrections are folded in. |

The recorded numbers below are from returned project reports. We have checked their source and scope; this documentation task did not rerun bank training or independently reopen native checkpoint/prediction files.

## The complete account, by subject

1. [Models, experiments and results](#experiments): every retained model in the completed studies; original/reference comparisons; chunk versus sliding history; repeated seeds; rescoring and statistical limitations.
2. [Substantive implementation changes](#changes): sharding, attention, chronology, training targets and losses, checkpoint consistency, and scoring/analysis integrity. Each entry explains why it matters.
3. [Features, research and downstream work](#research): feature inventories and engineering, optimizer/model-size/tokenization proposals, screening tools, embeddings, the store, downstream consumers, and which ideas remain unrun.

## 1. What the models are

All of these aim to give the current transaction a fraud score. The current transaction's available features are inputs; its fraud label is the answer used for training, not an inference input.

| Model | Plain-language distinction | What our experiments ask |
|---|---|---|
| REF-SINGLE | Yaqun's single-transaction FT-Transformer recipe, rerun through the corrected owner implementation | How much value do our history models add over a useful single-transaction reference? |
| Architecture A, flat | Feature tokens from the current transaction and its eligible history attend within one flat transformer structure | Can direct interactions across features and transactions help? |
| Architecture B, default | One transformer summarizes each transaction's features; a second models relationships between transaction summaries; one target is scored per window | Does separating within-transaction and across-transaction reasoning work better? |
| Architecture B, all-position | The hierarchical family uses causal per-transaction outputs and can learn from every eligible target in a chunk | Does a different allocation of training targets and context improve learning and efficiency? |

**Chunk versus sliding is a training/scoring choice as well as an architecture question.** A chunk-trained model can be validated and scored with one target-ending window for each transaction. This is the hybrid actually studied. It does not feed yesterday's predicted fraud score back into today's input by default.

The strict all-position implementation groups equal whole-second timestamps. Consequently, H20 can involve more than 20 history rows; a separate row cap controls allocated width. The experiment record states the history, training targets, validation policy, scoring policy and cap together.

## 2. The substantive progression

| Stage | What happened | What it contributed |
|---|---|---|
| Starting point | Yaqun's features, frozen preprocessing, single-transaction recipe, flat history model and written guide provided the foundation | A concrete fraud task and working reference direction |
| Correctness work | Worker coverage, causal attention, padding, strict chronology, all-position semantics and score/checkpoint consistency were repaired | More trustworthy training and comparisons; see the changes chapter for exact scope |
| Preliminary experiments | Early history, optimizer and embedding grids were recorded before the controlled V1 study | Exploration; their results are retained separately because settings and reporting differed |
| V1 | Fifteen seed-42 cells covered REF, A/default-B histories 0/5/10/15/20, time-gap controls, causal A, and all-position B at H5 | A completed fixed-feature baseline, not a hypothetical plan |
| Data and history investigation | Account/file overlap, timestamp ties, history support, feature coverage, training curves and chunk-position behavior were examined | Evidence about what the model can legitimately see and which comparisons are meaningful |
| L3 follow-up | Three seed-42 fits tested ALLPOS-H20-SLIDE, ALLPOS-H20-CHUNK and ALLPOS-H5-SLIDE; existing models were also rescored | A direct test of training-window and scoring-window choices |
| Repeated seeds | B-H20 and all-position H20 chunk were each trained at seeds 43 and 44, alongside retained seed 42 | Evidence that the selected chunk recipe's advantage was not confined to a single seed; uncertainty still matters |
| Feature/downstream preparation | Candidate features, research, screening, export, consumer and store components were developed | The next capability exists in parts, but bank-side benefit has not yet been demonstrated |
| Current direction | Owner chose H20 chunk, closed seed work, set the next feature direction, and requested a clean model-based pod layout | A focused continuation rather than restarting the entire baseline ladder |

## 3. What we learned from the data

The L2 inventory reports **416 inspected files**, **86,320 file-pair checks**, no shared accounts across those inspected distinct files, and no duplicate IDs or nulls in its four inspected identity/time/label columns. That supports the file-contained-account assumption on the inspected population; it is not a claim about every column or every future dataset.

The recorded development populations are explicit:

| Role | Files / scope | Recorded rows | Why it exists |
|---|---|---:|---|
| Small encoder training | Training 1–10 | 8,622,629 | Baseline and follow-up training population |
| Larger encoder training | Training 1–100 | 86,683,008 | Prepared scale-up population; a completed 100-file fit is not established |
| Epoch validation | Training 4950–4954 | 4,292,059 | Choose checkpoints and monitor learning |
| V1 evaluation / all-month DEV_OOT | Evaluation 8000–8010 | 2,466,461 | Common V1 comparison; later reused as development evidence |
| SELECT | June targets, evaluation 8206–8216 | 1,215,218 | Architecture/recipe comparisons |
| Downstream training | Training 4001–4010 | 8,707,510 | Fit later consumers on a separate account population |
| DS_SELECT | June targets, evaluation 8217–8227 | 1,184,642 | Compare downstream consumers |
| FINAL | June targets, evaluation 8260–8277 | 1,979,989 | Protected final model-performance reading; inventory counts are not model scores |

The recorded files contain time ranges, not a date encoded by their file number. More files primarily add account groups; selecting a later file number does not by itself create a later-time test. May rows can supply eligible history for June targets.

Data findings included same-second transactions, substantial available long history, varying fraud prevalence, a missing originally proposed downstream file range, and a need to align benchmark IDs and scores. Label maturity, feature availability at decision time and exact clock meaning still require the appropriate domain evidence; successful parsing cannot establish them.

**Same-second groups were disproportionately fraud-heavy.** In the returned ten-file training diagnostic, 170,956 of 8,622,629 rows (**1.98%**) belonged to equal-time groups within an account. Those groups contained 852 of 12,757 frauds (**6.68%**), giving **3.37 times the overall training fraud prevalence**. That makes the history-order rule consequential: an arbitrary tiebreak can expose a same-time peer that is not established as earlier. These counts do not measure an AP gain from allowing that access. [Returned counts](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/releases/tf-stage1-v0.1.0/returns/run-001/latest_run_results/data_coverage.json#L95).

Source: [L2 inventory and populations](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_1.md#L340).

## 4. The important results, without overstating them

- **History did not improve every configuration.** In V1, default B at H5 underperformed REF-SINGLE. Longer default-B histories performed better on that evaluation population. This motivated inspecting training/validation behavior and testing different context policies.
- **The single-transaction reference remained competitive.** REF-SINGLE's V1 evaluation AP was about 0.0925, versus about 0.0955 for B-H15/B-H20. This comparison also changes model recipe, capacity and learning rate; it does not isolate history alone.
- **Training and scoring on sliding windows everywhere was not automatically better.** In the seed-42 follow-up, **ALLPOS-H20-SLIDE** scored below **ALLPOS-H20-CHUNK** on both DEV_OOT and June-only SELECT. Both were validated and scored on target-ending windows; their training layouts differed. That result motivates the selected hybrid; it does not establish one universal cause of the difference.
- **Across seeds 42/43/44, H20 chunk had the higher DEV_OOT AP each time.** Reported mean AP was 0.098172 versus 0.081665 for default B-H20, a difference of about 0.016508, calculated from the displayed values. The seed-42 paired interval included zero, and a completed combined three-seed account interval is not in the reviewed record.
- **Evaluation populations must stay separate.** Full-file May/June AP, June-only SELECT AP, and training-time validation AP answer different questions. Tables that mix them cannot support a ranking.
- **Incumbent scores are not yet a matched benchmark.** TFM's reported AP on its prepared evaluation population cannot be directly compared with our V1/DEV_OOT AP. The same-transaction benchmark and downstream lift are separate unfinished work.
- **AP is ranking quality, not accuracy or fraud capture at a chosen alert rate.** Operating-point capture, calibration and business outcomes remain additional measurements.

Both chunk and sliding training supplied approximately 8.6 million labelled transaction targets per epoch in the later comparison. The chunk result cannot be explained simply as “it saw more labels”; context layout, sample grouping and gradient aggregation changed together.

The full model tables, paired comparisons and caveats are in [EXPERIMENTS.md](#experiments). Three positive seed comparisons support a practical choice but do not prove production superiority. DEV_OOT has influenced selection and should no longer be described as untouched final confirmation.

## 5. Work completed beyond training

| Workstream | What exists | What has not been established |
|---|---|---|
| Correctness | Repaired data-worker coverage, attention/history semantics and model/scorer compatibility | That any repair alone explains a particular AP change |
| Measurement | Common-cohort scoring, paired account analysis, per-position/history diagnostics and data inventory | That one seed's account interval includes training randomness |
| Reproducible execution | Configuration/checkpoint receipts, resumable training and scoring records | Continuous automatic execution by the assistants, or live pod state from GitHub alone |
| Feature engineering | Feature catalogues, source-list mapping, point-in-time prototypes and screening code | Completed feature-screen results or a trained expanded-feature winner |
| Embeddings | Target-ending export and model-identity contracts; comparison/diagnostic tooling | Bank-side exported-vector benefit to another model |
| Downstream models | Transaction-level XGBoost consumer and benchmark tooling; later 15298 offset/TFM correlation direction | Measured downstream lift or a completed incumbent comparison |
| Store | A separately implemented and tested embedding-store candidate, with exact-version evidence | Its installation/use on the bank pod; the old 14-day account consumer is now withdrawn |
| Research | Literature-backed alternatives and proposed comparisons for optimizers, representation, sampling, capacity and scale | A completed broad optimizer/capacity sweep or confirmed benefit from those proposals |

The detailed chapter marks whether each deliverable was proposed, implemented, shipped or reported run. Functional and synthetic tests provide implementation evidence; their number is not a count of fraud experiments.

**Pod reorganization was delivered as version 3:** `pod_reorg_20261027_v3.zip`, containing `tools/organize_pod.py`. It produces a file plan, hashes, a move receipt and a verification report. The October 28 code tour records it as delivered but not run; no plan output was available in that record. The owner has since reported moving, renaming and deleting files, so that dated status does not establish today's layout. The new recovery snapshot and any `shared/reorg/` receipts will establish what is present, moved or missing. [Delivered tool](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/releases/pod-reorg/README.md), [dated status](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/code_tour/06_runs_and_pod.md#L226).

## 6. What is current, superseded or unfinished

The latest owner resolutions are the governing direction, even where an older plan still contains different commands:

- **Carry forward:** all-position H20 chunk, with the matched target-ending scoring policy; preserve default B-H20 and the completed V1 evidence.
- **Next feature version:** drop month, keep time gap/hour/day-of-week/day-of-month, evaluate additional raw and engineered features. No separate no-month-only study is scheduled by this rundown.
- **Seed study:** closed. Earlier proposals to train more architectures at additional seeds remain historical.
- **Embedding uses:** transaction-level raw + score + vector comparison; a 15298 offset model; correlation/complementarity against TFM embeddings and existing scores. The next-14-day account consumer has been withdrawn.
- **Later scale-up:** approximately 100 training files after feature/recipe work. Earlier scale-first instructions were superseded.
- **Parked:** Phase 5 pretraining and optional research branches without a current execution decision.

The substantive unfinished deliverables are:

1. Consolidate the actual working training/scoring recipe and installed pod adaptations into the next reproducible source/package version, preserving the existing compatible results.
2. Complete the next feature schema and training-fitted preprocessing version; connect selected feature families to the actual model inputs and run matched comparisons.
3. Finish the feature-screen and model-ablation readings, then make the feature selection explicit. Importance alone is not a measured gain from adding a feature.
4. Run the selected larger-data recipe and compare it with the same recipe trained on fewer files.
5. Verify the chosen encoder's export on real inputs, then evaluate the current downstream uses on their declared populations.
6. Reconcile final-evaluation/handover tooling with the latest owner decisions, perform the protected final readings, and complete business/production evidence: available-at-decision-time inputs, calibration/operating point, serving parity, measured runtime, monitoring and rollback.

This is the remaining project work, not authorization to launch new workloads. The owner runs bank-side code. A deployment-latency target is not imposed retroactively on completed V1 R&D.

## 7. Terms used in this account

| Term | Meaning here |
|---|---|
| Fit / trained model | One training run that produces learned weights. The same architecture trained with another seed is another fit. |
| Seed | A number controlling random choices such as the model's starting weights. Repeat seeds help expose training variability. |
| Epoch | A pass through the training examples emitted by the chosen data loader. |
| Checkpoint | Saved learned weights and, where supported, the state needed to continue training. |
| Rescore | Apply an existing checkpoint to a population or scoring policy; it does not train new weights. |
| AP | Average precision: how well frauds rank ahead of genuine transactions. It depends on the evaluated population and is not percentage accuracy. |
| AUROC | A second ranking measure: how often a random fraud ranks above a random genuine transaction. In rare-fraud work it should be read alongside AP and operating-point results. |
| Paired account interval | Uncertainty estimated by resampling whole accounts while comparing both models on the same rows. It keeps related transactions together. |
| Embedding / vector | The model's learned numerical representation of a transaction and its permitted context, which another model may use. |
| Frozen preprocessing artifacts | The saved vocabulary, scaling and related transformations that define exactly how raw fields become model inputs. |
| Feature store | A versioned way to materialize and retrieve features or vectors for a stated entity and time; its existence alone does not demonstrate predictive lift. |

## 8. Sources and versions

Source snapshot: main **d711d92b61dec0c3e452dbedec544d071bf6d111**; V2 branch **dda4d4a07b371e0c980d65ec5caf016077d1acb9**; installed package009's source **60232e98db78b562ab1a073da3968730887b8a0f**, plus separately reported pod adaptations. A published package, a source branch and the actual current pod are distinct versions.

Primary source families covered:

- Yaqun's guide, existing models, EDA and feature/preprocessing definitions.
- The preliminary experiment workbook, later V1 complete/paired reports, and the corrected reference comparison.
- `updates_10_23_2026/` L2/L3/seed reports and CL's October24 result reconciliation.
- Implemented owner code on main and V2 integration, PR28 store and PR29 proposed queue/seed candidates.
- CH/CL feature catalogues, feature metadata/importance, research matrices and recipe proposals.
- Latest October24–27 roadmap and owner resolutions, including D-012's downstream-use change.

---

<a id="experiments"></a>

# Models, experiments and results

Prepared 1 November 2026 by CH from repository evidence at `d711d92b61dec0c3e452dbedec544d071bf6d111`. This chapter counts substantive model work and records what it taught us.

The numbers below are **reported bank-side results in the committed returns**. Reading these reports does not independently rerun training or verify the current pod's files. Later complete tables supersede earlier partial tables; proposed experiments are not counted as completed fits.

## 1. How much model work is actually recorded?

| Work | Count supported by the record | What the count means |
|---|---:|---|
| V1 baseline and controls | 15 | One retained trained model per experiment, seed 42 |
| Later all-position training-layout experiments | 3 | ALLPOS-H20-SLIDE, ALLPOS-H20-CHUNK, ALLPOS-H5-SLIDE, seed 42 |
| Seed follow-up | 4 | Default B H20 and all-position H20 chunk, each retrained at seeds 43 and 44 |
| **Retained V1 plus these follow-up fits** | **22** | 15 + 3 + 4; not the project's lifetime count of launches |
| Architecture A rescoring | 24 model/population rows | Eight existing checkpoints, each scored on three populations; no new fits |
| H5 chunk-to-sliding rescore | 1 documented policy comparison | Same trained checkpoint, two scoring layouts |
| Early pre-V1 workbook | 10 reported experiment rows | Eight embedding/mask/optimizer combinations plus H10/H15; separate historical evidence |

Restarts, interrupted runs, duplicate launches, score retries and synthetic tests are deliberately not counted as additional retained models. Yaqun's earlier baseline/streaming studies are also separate. A lifetime GPU-job count cannot be reconstructed reliably by adding these categories: some records are summaries, and some restarts replaced earlier attempts.

Sources: [V1 experiment matrix](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/results_from_pod/v1_results_2026-10-13/V1_COMPLETE_REPORT.md#L112), [completed 15-run paired cohort](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/results_from_pod/v1_results_2026-10-13/reviewer_update_v1/analysis_outputs/paired_report_finalist.md#L23), [three later fits and A rescoring](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L594), [four extra-seed fits](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/Seed_results.md#L43).

## 2. What the different models are

| Model | Information processing | Question it answers |
|---|---|---|
| REF-SINGLE | Feature tokens for the current transaction only | Can transaction history improve on the established single-transaction recipe? |
| Architecture A, flat | One Transformer processes all feature tokens from the target and its history | Does direct interaction between features across transactions help? |
| Default Architecture B, hierarchical | First summarize each transaction's features, then process those transaction summaries; one target score per window | Can the history be modeled more efficiently through transaction summaries? |
| All-position B | Hierarchical model with causal per-transaction outputs; a chunk can supply many training targets | Can we learn efficiently by predicting every real transaction in a chunk? |
| All-position B trained on sliding windows | Same all-position model family, but training loss is taken on each window's final target | How much does the training layout change the result? |

Default A/B history is expressed as prior transaction rows under the strict time rule. Strict all-position construction groups transactions by whole-second timestamps; H20 uses up to 20 earlier distinct time groups, subject to the configured target-ending row cap. These are not always the same amount of context. Chunk training resets history at chunk boundaries; target-ending scoring reconstructs eligible history for each scored transaction. Predicting all positions does not mean feeding earlier fraud guesses into later predictions.

Source: [model families and settings](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/results_from_pod/v1_results_2026-10-13/V1_COMPLETE_REPORT.md#L74), [strict all-position contract](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/ALL_POSITION_CONTRACT.md).

## 3. Earlier work before V1

Yaqun's notes contain **two different single-transaction results reported as AP 0.0940**:

| Historical model | Evaluation files | Rows / frauds | AP | AUROC |
|---|---|---:|---:|---:|
| In-memory baseline | `part_8000` only | 228,043 / 290 | 0.0940 | 0.9521 |
| 100-file streaming, shuffle on | `part_8000..8010` | 2,466,461 / 3,818 | 0.0940 | 0.9514 |
| 100-file streaming, shuffle off | `part_8000..8010` | 2,466,461 / 3,818 | 0.0923 | 0.9508 |

The detailed baseline record reports AUROC 0.9521; the streaming-plan summary rounds it to 0.952. The **streaming** evaluation range matches our Test 1 / DEV_OOT range; the in-memory baseline uses only its first file. The initial history-model H5 value **0.1293** is a **validation** AP, not an evaluation AP.

On the same recorded evaluation files, **ALLPOS-H20-CHUNK** reached AP **0.102004** at seed 42 (mean **0.098172** across seeds 42/43/44), trained on 10 files versus Yaqun's 100. Training size and implementation differ, including the original loader's sharding defect, so this is a descriptive comparison rather than a controlled test of architecture alone. Yaqun's 100-file results are inherited experiments, not a new 100-file fit completed by our current feature programme.

Sources: [baseline evaluation](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/docs/fraud_detection_plan_detailed.md#L135), [streaming scaling](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/docs/phase3_streaming_plan.md#L21), [initial H5 validation](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/docs/phase4_sequential_plan.md#L287).

The pre-V1 workbook records an eight-way experiment crossing numeric embedding, attention direction and optimizer, plus H10/H15:

| Numeric embedding | Attention | Optimizer | Reported evaluation AP |
|---|---|---|---:|
| Linear | Bidirectional | AdamW | 0.073300 |
| Linear | Bidirectional | RAdam | 0.077500 |
| Linear | Causal | AdamW | 0.080500 |
| Linear | Causal | RAdam | 0.078100 |
| Periodic | Bidirectional | AdamW | 0.090700 |
| Periodic | Bidirectional | RAdam | 0.097100 |
| Periodic | Causal | AdamW | 0.088300 |
| Periodic | Causal | RAdam | 0.088600 |
| H10 history comparison | — | — | 0.080100 |
| H15 history comparison | — | — | 0.090500 |

This proves optimizer and embedding experiments were reported, so “we have never tried another optimizer” would be wrong. It does **not** establish that periodic embeddings or RAdam improve the selected current model: this is an earlier pipeline/runner, and the historical runner could select best AP and AUROC from different epochs. Keep this as exploratory evidence, not a current matched winner.

Source: [historical experiment table](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/ablations/current_run_results_10062026/results.md#L9).

## 4. V1: all 15 retained experiments

V1 held the feature list and preprocessing fixed. Training used files **1–10** (8,622,629 rows; 12,757 frauds), validation **4950–4954** (4,292,059 rows; 7,285 frauds), and evaluation **8000–8010** (2,466,461 rows; 3,818 frauds). Seed was 42. This evaluation population is later called DEV_OOT or Test 1.

The reference retains Yaqun's own width, depth, learning rate and batch recipe. It shares the cohort and epoch budget with A/B, but it is not parameter-count- or optimizer-recipe-matched to them. H0 A/B and REF-SINGLE are therefore different controls.

| Experiment | What changed | Evaluation AP | Evaluation AUROC |
|---|---|---:|---:|
| REF-SINGLE | Current transaction only, reference recipe | 0.092476 | 0.948739 |
| A-H00 | A, no history | 0.081598 | 0.935059 |
| A-H05 | A, history 5 | 0.072812 | 0.940916 |
| A-H10 | A, history 10 | 0.082399 | 0.940833 |
| A-H15 | A, history 15 | 0.092822 | 0.943693 |
| A-H20 | A, history 20 | 0.081693 | 0.933941 |
| A-GAP05-OFF | A H5 without the time-gap input | 0.076656 | 0.942964 |
| A-GAP10-OFF | A H10 without the time-gap input | 0.080812 | 0.942513 |
| A-MASK05-C | A H5 with causal attention | 0.077917 | 0.943619 |
| B-H00 | Default B, no history | 0.082196 | 0.932224 |
| B-H05 | Default B, history 5 | 0.067401 | 0.938787 |
| B-H10 | Default B, history 10 | 0.090364 | 0.947534 |
| B-H15 | Default B, history 15 | 0.095459 | 0.947306 |
| B-H20 | Default B, history 20 | 0.095465 | 0.952000 |
| B-ALLPOS-H5 | Causal all-position B; chunk training and chunk scoring | 0.092670 | 0.945736 |

Sources: [V1 numerical tables](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/results_from_pod/v1_results_2026-10-13/V1_COMPLETE_REPORT.md#L174), [later completed A-H20 and A rescores](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/Seed_results.md#L133). The early V1 report's “14 of 15” and pending A-H20 cells are historical status, superseded by the completed 15-run paired table and later reports.

What this established:

- H5 was weak in both default architectures. H10 improved on H5: A's AP difference was **+0.0096**, account-bootstrap interval **[+0.0006, +0.0194]**; B's was **+0.0230 [ +0.0122, +0.0395 ]**.
- A H5 causal attention improved over its bidirectional version: about **+0.0051 AP**, with the reported interval excluding zero.
- Removing the time gap did not yield a resolved difference at H5 or H10. That is an inconclusive comparison, not proof the feature has no value.
- B H15/H20 and A H15 were near the reference on evaluation. Their supplied finalist intervals versus REF-SINGLE included zero. No architecture-wide superiority or statistical equivalence follows.
- A H20's evaluation AP fell below A H15 despite slightly better validation AP. B H20 also exceeded A H20 on evaluation while validation favored A. This demonstrated that validation and evaluation rankings can disagree.
- Longer history was not monotonically better: the A ladder peaked at H15 in this run. The B H15/H20 evaluation difference was only 0.000006 AP.

The final paired report joins all 15 models to the same transaction/account IDs and labels and resamples **whole accounts**, 1,000 times. Its 95% intervals describe evaluation-account variation for these fitted checkpoints; they do not include training-seed variation or adjust all comparisons jointly. Its historical “consistent” label also requires the validation direction to agree. Therefore an evaluation interval excluding zero and a protocol label “not resolved” can both be true. Read the interval and the rule separately.

Source: [finalist paired report, including controls and reference contrasts](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/results_from_pod/v1_results_2026-10-13/reviewer_update_v1/analysis_outputs/paired_report_finalist.md).

## 5. Diagnostics and scoring work after V1

These were substantive investigations, but they were not new model fits:

| Investigation | What it did / what was learned |
|---|---|
| Learning curves and saved epochs | Confirmed that B H5's best validation was epoch 0; later epochs did not rescue it. Examined whether early peaks, rather than missing history inputs, explained the weak run. |
| Split/account overlap | Checked training/validation/evaluation identity separation and measured the available histories. |
| Same-second chronology | Measured tied timestamps and fraud concentration, supporting the strict-earlier-time treatment. |
| Balance/limit timing | Tested accounting relationships; these checks could not establish whether every field is available before the transaction. A measured equation is not a data-owner availability definition. |
| Chunk-position comparisons | Compared all-position H5 with reference and history models within chunk-position subsets; no resolved difference from REF-SINGLE or the strongest long-history models across the reported positions. |
| Inventory and population freeze | Defined training, validation, development, design-selection, downstream and final populations with counts and benchmark overlap. |
| Arch A rescoring | Eight existing A checkpoints × validation/DEV_OOT/SELECT = 24 rows; added June-specific scores and top-budget capture metrics. |

Sources: [quick checks and population freeze](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_1.md#L116), [24 A scores and fraud-capture tables](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/Seed_results.md#L133).

For example, A H15 caught **1,120 of 2,081 June frauds** when allowing the top 1% of scores as alerts (12,153 alerts; 53.82% capture). That led the supplied A models at that budget. Equivalent H20-chunk budget metrics were not supplied in that table, so it does not identify the overall operational winner.

## 6. Chunk training versus sliding training/scoring

The first hybrid observation reused **the existing V1 H5 chunk-trained checkpoint**. Chunk scoring gave AP **0.092670**; target-ending sliding scoring gave **0.093420** on DEV_OOT, a change of **+0.000750**. This was a scoring-policy comparison, not another training run and not evidence that a longer history had been learned.

Next, three new seed-42 fits were reported. They kept the original features/artifacts, including month; the no-month configuration present in the package was not the feature set used by these active pod runs.

| New fit | Training | Validation/scoring | DEV_OOT AP | June SELECT AP |
|---|---|---|---:|---:|
| ALLPOS-H20-SLIDE | One target-ending window per target; loss on final target | Target-ending windows | 0.074347 | 0.061503 |
| ALLPOS-H20-CHUNK | Non-overlapping chunks; loss on every real chunk target | Target-ending windows | 0.102004 | 0.110288 |
| ALLPOS-H5-SLIDE | One target-ending window per target; loss on final target | Target-ending windows | 0.086608 | 0.092341 |

ALLPOS-H20-SLIDE used a 32-row target-ending cap; ALLPOS-H5-SLIDE used 8. The ALLPOS-H5-SLIDE full-file SELECT receipt is **0.084451**, which differs from the **June-only 0.092341** in the table. Both are legitimate metrics for different populations and must not be substituted for each other.

The central paired findings were:

| Comparison | DEV_OOT AP difference [95% account interval] | June SELECT difference [95% account interval] |
|---|---|---|
| ALLPOS-H20-CHUNK minus ALLPOS-H20-SLIDE | **+0.027656 [+0.017010, +0.038389]** | **+0.048785 [+0.027621, +0.074480]** |
| ALLPOS-H20-CHUNK minus V1 default B-H20 | +0.006538 [-0.007767, +0.019007] | +0.017535 [-0.001265, +0.038192] |
| ALLPOS-H5-SLIDE minus ALLPOS-H20-SLIDE | +0.012260 [+0.000279, +0.024905] | +0.030838 [+0.001323, +0.077476] |

ALLPOS-H20-CHUNK exceeded ALLPOS-H20-SLIDE on both reported comparison populations for these fitted seed-42 checkpoints. Its advantage over V1 default B-H20 was not resolved by the supplied intervals. ALLPOS-H5-SLIDE versus ALLPOS-H20-SLIDE had evaluation-positive intervals but an inconsistent validation direction in the historical S1 label.

Both chunk and sliding training supervise approximately **8.6 million transaction targets per epoch** here. Chunk training did not win simply by having more labels. It changed the context-depth distribution, sample grouping and gradient aggregation; this comparison does not isolate which mechanism caused the gain. For the H20 comparison, about 2,103 chunk optimizer updates versus 2,106 sliding updates per epoch were recorded.

Sources: [H20 comparison and H5 follow-up](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L205), [active feature contract](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L608), [H5 same-checkpoint rescoring](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L281).

## 7. Seed stability: completed, then closed by the owner

Two models received seeds 43 and 44: **default B H20** and **all-position H20 chunk**. That is four new fits. The previously prepared eight-job seed plan for four candidates was a proposal, not evidence that all eight ran. A H15's later rows were rescoring, not independent seeds.

| Seed | H20 chunk DEV_OOT AP | Default B H20 DEV_OOT AP | Chunk minus default B |
|---|---:|---:|---:|
| 42 | 0.102004 | 0.095465 | +0.006539 |
| 43 | 0.091165 | 0.074252 | +0.016913 |
| 44 | 0.101348 | 0.075277 | +0.026071 |
| Mean | 0.098172 | 0.081665 | +0.016508 |
| Sample standard deviation | 0.006078 | 0.011962 | — |

Means and sample standard deviations here are recomputed from the six-decimal reported values; final-digit differences from other summaries can reflect rounding.

This is an approximately **20.2% relative AP increase in the reported three-seed mean**, not a 20.2-percentage-point increase or a guarantee on future data. Chunk leads in each of these three runs and has lower observed spread. Three seeds do not establish universal robustness.

The holdout checks also favor chunk within each seed:

| Seed | Holdout rows counted | Chunk AP | Default B AP |
|---|---|---:|---:|
| 42 | June only: 1,215,218 rows / 2,081 frauds | 0.110288 | 0.092753 |
| 43 | Full May/June files: 2,504,003 rows / 4,187 frauds | 0.100102 | 0.066634 |
| 44 | Full May/June files: 2,504,003 rows / 4,187 frauds | 0.099506 | 0.075645 |

Do not calculate a three-seed holdout mean from those mixed populations. Within-seed comparisons use the same reported population; DEV_OOT uses the same full-file scope across all three seeds.

The earlier suspicion that 4,213 batches versus about 2,107 optimizer updates proved a different B-H20 recipe was withdrawn: accumulation 2 explains that count. The reported original manual-retrain settings/checkpoint-identity gap remains narrower than that withdrawn allegation. This is a qualification to attribution, not a new request for seed runs.

**Current decision:** the owner selected **Arch B H20 chunk** and closed the seed study on October 24/26. No outstanding seed proposal in an older plan should silently reopen it.

Sources: [consolidated seeds and populations](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/Seed_results.md#L1), [count clarification and model selection](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L399), [seed study closed](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L415).

## 8. What was proposed, but should not be described as completed

| Proposal | Current reading |
|---|---|
| Eight new seed fits across REF, B H15, B H20 and H5 all-position | A prepared earlier plan. Actual later evidence supplies four new fits for B H20 and H20 chunk; owner closed the study. |
| Complete no-month architecture tournament | Earlier V2 plan/package capability. The reported later H5/H20 fits retained the old features. On October 27 the owner rejected a separate no-month test and directed the next feature model to omit month while retaining gap/hour/day-of-week/day-of-month. |
| Train selected feature model on 100 files | Next scaling stage after feature mapping, new preprocessing, 10-file retest and selection. No completed current feature-model 100-file result in these returns. |
| Overlapping chunks / read-only historical lead-in | Proposed method to supply history across chunk boundaries without repeatedly supervising every context row; not demonstrated by the completed comparison. |
| Chunk-to-window fine-tuning or mixed chunk/window loss | Proposed ways to align training with target-ending scoring; no completed result in the reviewed record. |
| More optimizer, learning-rate, size/depth, loss-weight and embedding sweeps on the selected model | Research candidates; the historical eight-way sweep is not a current selected-model study. |
| H5 checkpoint scored with H20 context | Discussed as an exploratory rescore. It is not H20 training; learned position limits and out-of-training context need to be recognized. No new retained fit counted. |
| Phase 5 pretraining | Parked, outside the active completion path. |

Sources: [programme order and hybrid proposals](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L590), [latest month direction](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L145), [current training/feature sequence](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md#L110).

## 9. The tests that have different purposes

- **Epoch validation:** files 4950–4954 choose a checkpoint within a fit.
- **Test 1 / DEV_OOT:** files 8000–8010 provide the main comparative results so far. Repeated model selection has made this a development comparison set, not an untouched final claim.
- **SELECT / holdout:** files 8206–8216 were used for design comparisons and feature-selection planning; June-only versus full-file metrics must be explicit. It is held out from training, but not untouched by model selection.
- **Test 2 / TFM benchmark:** 952,905 TFM-evaluation transaction IDs from files 8000–8200, a planned same-row benchmark. The reported TFM AP **0.2737** is not directly comparable with our Test 1 AP. The L2 table records 52,202 overlapping benchmark transactions in the June DEV_OOT subset alone; the reused Test 1 population and benchmark are therefore not independent.
- **FINAL:** frozen June population at files 8260–8277, 1,979,989 rows and 3,044 frauds. Its selection is recorded; a complete final selected-model result is not supplied by this experiment inventory.

Source: [frozen populations](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_1.md#L388), [Test 1/Test 2 naming and overlap](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md#L94).

The substantive progress is a completed baseline ladder, controlled mask/time-gap comparisons, diagnosis of short-history weakness, a direct chunk-versus-sliding training comparison, repeat-seed evidence and a chosen model for the feature stage. Feature lift, larger-data performance, downstream embedding value and production readiness still require their own completed evidence.


---

<a id="changes"></a>

# Substantive implementation changes

This is the part of the project history that changes what a model learns, what information it can use, how it is evaluated, or whether a reported result belongs to the intended experiment.

Reviewed source: main `d711d92b61dec0c3e452dbedec544d071bf6d111`; V2 integration `dda4d4a07b371e0c980d65ec5caf016077d1acb9` (package 009 runtime source `60232e98db78b562ab1a073da3968730887b8a0f`). A source change proves implementation. The experiment inventory separately identifies where returned evidence reports that implementation running.

## 1. Made training cover the intended data

**Worker sharding was corrected.** Before the correction, each data-loader worker could shuffle the complete file list differently and then select its portion. Different workers could therefore choose the same file while no worker chose another file. With four independent shuffles, the expected missing-file fraction is about 31.6%; that figure is a mathematical expectation, not a direct measurement of every bank epoch.

The A/B loaders now construct one common shuffled file order before assigning disjoint worker portions. The single-transaction loader first assigns disjoint file portions, then shuffles inside each portion. Both preserve parallel loading without letting workers overlap their assignments. A/B's file order is fixed by its shard seed rather than newly randomized each epoch; the within-worker sample buffer still shuffles.

Why this matters: history and reference models can be compared on a defined training population rather than on an accidental worker-dependent subset. It does not tell us the direction or size of the resulting AP change. Validation and evaluation paths that already used unshuffled file order were outside the original shuffled-worker failure.

Evidence: [A loader explanation and implementation][sharding-a]; [single-transaction loader][sharding-base].

## 2. Made the history models obey their intended information rules

| Meaningful change | What changed and why it matters | Scope |
|---|---|---|
| Causal attention | Earlier transaction representations can no longer read the sequence CLS token, which could already contain later transaction information from the previous layer. This closes a route around the intended causal mask from layer two onward. | Causal mode. Bidirectional A/default-B remains a separately named experiment. This is not evidence that fraud labels leaked or that every final-target prediction saw data occurring after its target. |
| Padding in causal attention | The attention mask handles padding while retaining a finite self-attention route for padded queries. This avoids NaN outputs for short histories after the causal fix. | A and B causal paths; padding does not become a real transaction or training label. |
| Strict history | A target uses only same-account transactions with strictly earlier parsed timestamps. A same-time row cannot become history merely because its ID sorts first. | The strict setting is explicit; the older tie-break interpretation remains a different policy, not an interchangeable result. |
| Parsed chronology | Grouping and ordering use parsed event times instead of relying on the order of raw timestamp text. | History construction. The code retains file-local account history; it does not claim account history spanning arbitrary input files. |
| Input meaning | Missing labels are rejected instead of being converted to non-fraud; missing account IDs and missing/unparseable times cannot silently change account membership or chronology. Numeric time units and timezone consistency must be explicit. | Missing predictor values still follow preprocessing. Non-null labels are encoded as configured-positive versus other observed labels; this is not an exhaustive allowed-label-vocabulary check. |
| Time features | Calendar features are constructed when the feature list asks for them, avoiding unnecessary derivation and supporting the selected encoding configuration. | Feature derivation; this does not establish that a particular calendar encoding improves performance. |

Evidence: [A causal mask and checkpoint hook][a-model]; [input semantics][input]; [A history builder][sharding-a].

## 3. Built a distinct all-position B experiment

All-position B is substantive additional model functionality. It should not be presented solely as repairs to Yaqun's original implementation.

Default B produces one score for the target in a history window. All-position B produces a score at every real position in a chunk, with a causal time mask. The completed implementation introduced or corrected:

- **One target contribution per real transaction in a chunk:** disjoint chunks avoid repeatedly attaching the same transaction's label to overlapping chunk-training windows. Padding contributes neither a target nor a metric.
- **Time gaps available at prediction time:** the gap is to the latest strictly earlier timestamp within the chunk, rather than to a later target transaction. A causal mask cannot repair a feature that already contains future information.
- **Same-time consistency:** strict chunks break between whole-second groups. A same-time peer cannot change the target's permitted history merely by moving a row across a row-count boundary. Position indices count strictly earlier real rows, with the declared clamp, rather than using a same-time peer's slot order.
- **A precise meaning of history:** in strict all-position mode, a chunk holds up to `H + 1` distinct whole-second groups. It can contain more than `H + 1` rows. A position has only the earlier groups within its own chunk; its context restarts at a chunk boundary. This differs from default B's last-H-row windows.
- **Explicit loss accounting:** weighted cross-entropy is summed across real targets and divided by their count; epoch aggregation follows real-target counts. With fraud weight 1 it is ordinary transaction-average cross-entropy. With nonunit weighting, its normalization differs from default B's class-weight-normalized mean.
- **Bounded chunk execution:** an optional chunk-width limit rejects an oversized chunk rather than silently deleting rows. A batch can be wider than H+1 when seconds contain several transactions.

These choices define a different training experiment, not just a faster way to obtain the same default-B predictions. Its history/reset behavior and its supervision differ, so performance must be compared using the specified scoring policy.

Evidence: [complete all-position contract, including time, ownership and loss][allpos].

## 4. Made training recipes and saved models interpretable

| Improvement | Practical consequence | Important qualification |
|---|---|---|
| One-device training contract | Corrected trainers pin one device and reject distributed launches because the iterable data is not partitioned across training ranks. | This is a runtime correctness fix. |
| Microbatch and accumulation settings | Longer histories can train within the implementation's GPU/shape limits while retaining the intended nominal effective batch. | `1024 × 4` or `2048 × 2` gives nominal 4096, not a guarantee of numerically identical optimization. Record the actual settings and real-target counts. |
| Matched single-transaction reference | The single-transaction recipe can be retrained and compared on the experiment's declared training and evaluation populations. | Yaqun already had validation: streaming used 4950–4954; the history config used 4950 only. The actual V1 A/B specs broadened history-model validation to 4950–4954. A later, differently trained reference is not automatically the same experiment as his historical score. |
| Expanded evaluation population | The V1 comparison uses evaluation files 8000–8010, rather than relying on a single file. | Population size/composition changes affect AP; compare models on identical rows and retain the split definition. |
| Fraud-weight reconstruction | The scorer reconstructs the model with the configured fraud weight instead of assuming an unweighted loss setup. | A compatibility fix; not evidence that weighted training improves AP. |
| Checkpoint input contracts | New checkpoints record feature ordering, preprocessing identity, model mode and history rules so a shape-compatible but semantically wrong scoring setup can be rejected. | Legacy single-target A/B checkpoints can still load with warnings and reduced identity verification. Incompatible or uncontracted all-position checkpoints are rejected. Separately, the base sequential/history model refuses causal checkpoints without its corrected mask-contract marker. |
| EMA lifecycle | When enabled, averaged weights update once per optimizer step, including partial accumulation groups; validation/inference weights and checkpoint contents agree; raw and averaged states are retained for resuming. | EMA was off in the documented V1 configs. V2 training explicitly excludes EMA. It is implemented optional functionality, not a measured V1 improvement. |

Evidence: [V1 B trainer][b-train]; [matched reference and original configuration][training-tour]; [model factory][factory]; [EMA implementation][ema]; [checkpoint contract][allpos].

## 5. Added train-on-chunks / score-on-target-windows functionality

The project moved beyond comparing A versus B. It also investigated **how the same B family is trained and how much history it receives when scored**.

V2 introduced a target-ending builder: each transaction receives its own window ending at that transaction, and only that final real position is the target. The strict all-position attention, gaps and positional rules remain in force. This allows a chunk-trained model to be evaluated with a fresh history window for every transaction rather than inheriting the shorter context near each disjoint chunk's beginning.

This is a legitimate separately specified hybrid: train on chunks; validate/score on target-ending windows. The shipped V2 trainer validates chunk models on target-ending windows and records that policy in the checkpoint. The shipped V2 scorer requires the compatible recorded policy. Older V1 chunk-checkpoint rescoring used separate dedicated tools; those exploratory rescores must not be confused with a V2 model whose checkpoint was selected using target-ending validation.

**The two limits differ:** the chunk safety cap rejects oversized training chunks. V2 `max_window_rows` deliberately keeps the most recent capped rows, including the target, in target-ending windows. The reported cap was 8 for ALLPOS-H5-SLIDE and 32 for ALLPOS-H20-SLIDE; there is no universal 32-row model limit. Natural and retained window sizes are recorded for interpretation.

V2 also adds resume from the last completed epoch with model, optimizer, scheduler, loop and random states restored under a compatible recipe. It records seeds, determinism settings, source/config/checkpoint identities and resume events. This is not arbitrary mid-batch recovery or a promise of bitwise equality across GPU environments.

The subsequent pod-installed training patches added target-ending windows **during training**, selected loss only at each window's labelled target, and routed chunk batches back to the original chunk training step. They let the owner test chunk training against sliding training explicitly. Their reported application and code blocks are in the uploaded records; they are not integrated into the checked PR24 runtime/package. Those patches therefore belong in the substantive history with their deployment status, not silently treated as the original 009 code.

Evidence: [V2 target-ending semantics and cap][target-ending]; [V2 trainer][v2-train]; [V2 scoring-policy check][v2-score]; [pod patch and experiment record][pod-patches].

## 6. Replaced loose score tables with comparable experiment evidence

The statistical and reporting work is a meaningful deliverable of its own:

1. **One checkpoint, one metric pair.** AP and AUROC are read from the saved checkpoint's epoch/step instead of independently selecting each metric's best epoch. A summary cannot imply that one saved model achieved two peaks reached at different times.
2. **Selection and descriptive reporting are separated.** The V1 sweep runner and selection leaderboard rank successful experiments by validation AP. Later evaluation tables can describe performance on declared populations; a descriptive ranking is not automatic permission to repeatedly tune against an untouched test set.
3. **Run identity is preserved.** Attempts have their own paths, predictions and source/config/checkpoint records. Failed or incomplete attempts are retained as such rather than becoming leaderboard successes. Scoring/export attempts include receipts even on failure paths.
4. **Comparison rows must match.** Model comparisons align transaction-plus-account identities, require consistent labels, and reject missing/extra/duplicate cohort rows. A difference in AP should describe the model difference, not a different set of transactions.
5. **Uncertainty respects account dependence.** Paired comparisons resample whole accounts together for both models. The resulting account-bootstrap interval describes sampling uncertainty conditional on the trained checkpoints; it does not include all training-seed variation, and each interval is pointwise rather than a guarantee across all searched comparisons.
6. **History availability and time are inspected.** Analysis separates rows by available prior history, calendar period and, where appropriate, depth-matched chunks. V2 constructs history from complete input files before selecting a target-date range, preserving earlier context for later targets.
7. **Seed variability is separate evidence.** Mean AP across fitted seeds is a mean of model metrics, not an ensemble prediction or a new encoder. Older adaptive seed-trigger rules in retained code are historical; they do not reopen the owner-closed seed study.
8. **Business-facing reads were implemented.** Reporting extends beyond AP/AUROC to fraud capture/precision at descriptive alert fractions, amount-related metrics when supported, and history-depth slices. Alert fractions are exploratory reporting settings until the bank specifies an operating policy. Amount bands, where used, are fitted on training data rather than the evaluated rows.

Evidence: [same-checkpoint pairing and run identity][runner]; [V1 paired account analysis][paired-v1]; [V2 paired/cohort/time analysis][paired-v2]; [business metrics][business].

The code and existing tests establish implemented mechanisms. Actual performance conclusions, executed model counts, failed/retried runs and retained future proposals are documented separately in the experiment and research inventories.

[sharding-a]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4a/sequence_builder.py#L28
[sharding-base]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/data/parquet_loader.py#L127
[a-model]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4a/sequential.py#L91
[input]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/base/data/input_contracts.py#L13
[allpos]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/ALL_POSITION_CONTRACT.md
[b-train]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/train_sequential.py#L55
[training-tour]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/code_tour/04_training_scoring.md#L62
[factory]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/factory.py#L58
[ema]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4a/callbacks.py#L39
[target-ending]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/target_ending.py#L1
[v2-train]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/scripts/train_v2.py#L1
[v2-score]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/scripts/score_v2.py#L56
[pod-patches]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md#L165
[runner]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/phase4b/scripts/run_ablations.py#L116
[paired-v1]: https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/runbook/2026-10-07/paired_report.py#L29
[paired-v2]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/analysis/paired_v2.py#L1
[business]: https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/analysis/business_metrics.py#L1


---

<a id="research"></a>

# Features, research, embeddings and downstream work

CH evidence inventory, 2026-11-01. Source snapshot: main `d711d92b61dec0c3e452dbedec544d071bf6d111`; shipped V2 source `60232e98db78b562ab1a073da3968730887b8a0f`, reviewed integration branch `dda4d4a07b371e0c980d65ec5caf016077d1acb9`; experimental store candidate `3b3162ca907ee363790e0bcbd2173811dcc77b37`. This is a substantive account of work and ideas. A written proposal, implemented code and a bank experiment are different states.

## 1. What the models actually received

The V1 baseline and reported V2 architecture/seed experiments retained the original **23 configured predictors: six numerical fields, thirteen categorical transaction codes and four calendar fields**. The numerical fields include transaction amount, `external_1_scr` and four balance/limit fields. Calendar fields were month, day of month, hour and day of week. Time-gap and missing-value representations exist in addition to that predictor count. The 48-dimensional learned representation is not a count of business features.

The supplied `v22_v17` importance file contains **120 ranked V22B rows**. The later field inventory interprets these as **about 117 underlying input fields**: time appears as three tokens (time gap, hour, day of week), and one chart row appears twice. This is an approximate field reconciliation, not a finalized feature schema. [Count reconciliation](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md#L125). The owner directed attention to V22, not V17. These are inputs to feature research, not 120 additional inputs already trained into our transformer. CH examined every row and its possible mapping to existing inputs, additional raw fields, availability timing and intended engineering. The initial review recorded 21 possible baseline mappings and 90 rows with no established mapping; those are historical mapping results, not a claim that every unresolved field is absent from the bank.

The 15298 master index adds **94 ranked model features, 94 crosswalk records, 106 raw/source entries and 17 proposed families**: 311 records with repeated names across categories, rather than 311 independent model inputs. Metadata rows 124–600 are now present in separate tables; older notes saying rows 249–600 were missing are superseded. Importance ranks identify leads to investigate; they do not measure incremental lift in our model.

Sources: [V22 feature proposal](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CH/2026-10-12-v22-feature-proposal/README.md), [15298 index](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/feature_work/README.md), [metadata 124–248](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/feature_related/part_124_248/feature_metadata_rows_124_248.csv), [metadata 249–600](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/waqas/feature_related/part_249_600/feature_metadata_rows_249_600.csv).

## 2. Feature proposals and what was built

The work developed from CH's initial family list and CL's joint research into an implementation of strictly prior per-account aggregation, a 23-candidate catalogue and an XGBoost screening tool. The later October 26 presentation proposes a broader pool of **166 added inputs: 90 V22B, 60 additional 15298 and 16 engineered features**, approximately 189 including the old 23. That is a **proposed pool before mapping and selection**, not an implemented 189-input model or an observed improvement. The October 27 decision to remove month in the next feature model also means189 is not the final schema count.

| Workstream | Concrete features and purpose | State supported by the records |
|---|---|---|
| Current-transaction context | MCC, merchant/terminal/channel details, verification/authentication, device/token/login and account-profile fields | Inventoried and proposed; actual availability and timing must be mapped per field before model inclusion. |
| Capacity and cash-out | Amount/balance, amount/remaining limit, headroom bands, 24-hour balance drain | Code/prototypes exist in the feature modules and screen. Bank screen has not run. Before/after balance semantics and compatible units determine which formulas are valid. |
| Velocity and coverage | Counts over 5 minutes, 1 hour, 24 hours, 7 days and 30 days; spend totals; card-present 5-minute and e-commerce 24-hour bursts; observation-coverage indicators | Strict-window primitives and groups implemented. They look beyond the transformer's count-bounded history. No bank feature-lift result is recorded. |
| Familiarity and unusual spending | New MCC/merchant/state; recent category frequency; current amount versus prior median/rank; recency and dormancy | Several groups implemented for screening; others remain proposals depending on stable keys and event definitions. |
| Geography | Distance from prior in-person transaction; implied travel speed; distance from usual location; home distance | F20–F23 implemented as screening candidates, with synthetic location tests. Postal centroids and physical-presence definitions are needed; home/profile availability is a separate issue. No measured bank lift. |
| Incumbent engineered fields | 30-day merchant claim rates; 14-day customer/card spend; 24/48-hour recency and counts; recent logins/profile events | Mapped in the October 26 proposal. Claims must have been known before the transaction; account/card/customer scopes are not interchangeable. |
| Decision/status fields | Prior declines/advice signals; inactivity/status-change dates | Proposed handling separates earlier known decisions from the current transaction's outcome. The presentation excludes seven suspected outcome-related status fields. Their exclusion is a design decision, not a fitted importance result. |
| Encoding | Raw categorical vocabularies; frequency/ordered target encoding; linear/periodic/PLE/PLR numerical representations | Existing linear/periodic switches and later research exist. Supervised category encoding and new fitted numerical bins need their own train-only artifacts and implementation; they are not silently active. |

The catalogue F01–F23 and the later 16 engineered inputs are **different groupings**, not two extra lists to add together. Likewise, the six/23/120/166/189 counts refer to different things.

The screen was built to compare a feature family against the same base data using account-grouped XGBoost comparisons, noise controls, time-split/history-lite checks and strict-future-invariance tests. Synthetic planted-signal tests establish tool behavior, not fraud-model improvement. The October 23 environment report says **XGBoost was not installed**, and the October 28 code tour records the feature screen as not run. No later bank screen output was found in this reviewed snapshot.

Sources: [F01–F23 catalogue](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/assist/features/CATALOGUE.md), [166-input proposal and appendices](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md#L112), [screen source](https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/waqas/v2/screen/run_screen.py), [actual dependency report](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/updates_10_23_2026/M01_V2_results__through_l3.part_1.md#L74).

## 3. Sampling, history and month: decisions that changed the design

- **Xiaoming/Jie sampling advice:** preserve sufficient history before constructing behavioral features. Selecting whole accounts/customers can reduce the working population without randomly removing their needed transactions. Sampling targets can also work if their complete eligible histories come from a separate retained source. Customer/card/account/merchant aggregates have different source populations. This reasoning was documented; no new account-sampling training comparison is reported as completed.
- **Time availability:** historical features are computed from eligible strictly earlier events; same-time peers do not update one another's state. Current amount can enter a current-row ratio, but cannot enter a feature defined as prior-only. Late-arrival/label-maturity facts remain distinct from merely sorting event timestamps.
- **Month:** the reported architecture and seed experiments used the month-in version1 artifacts. The no-month builder/checker and five-fit no-month configs were implemented but not run as planned. The owner's October 27 resolution is **no separate no-month experiment; remove month in the next feature model while retaining time gap, hour, day of week and day of month**. Older three-seed no-month proposals are superseded. Removal has not yet produced a measured gain.
- **Feature selection:** compare retrained feature-family additions/removals, with their new preprocessing versions. Imported importance, attention weights or zeroing a feature in an already-trained model do not replace this comparison. No final retained expanded feature set exists in the reviewed evidence.

Sources: [sampling interpretation and email](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CH/2026-10-12-v22-feature-proposal/SAMPLING_FOLLOWUP_2026-10-13.md), [latest owner resolutions](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/OWNER_QA.md#L184), [no-month implementation and actual status](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/code_tour/05_v2_tools.md#L147).

## 4. Research programme: what was investigated, not automatically run

CH's October 14 literature pass recorded 29 sources, including 28 papers and the fraud-detection handbook. The later WP7 review reconciled 116 citation records: 89 arXiv identifiers, 22 non-arXiv records, 4 additions and 1 incomplete citation. All 89 arXiv records were opened; 30 records had selected primary-text review and 78 were metadata-only. These are research-coverage counts, not experiments, and neither implies every numerical claim was reproduced.

| Research area | Alternatives considered and what they would test | Delivery/execution state |
|---|---|---|
| Numerical tokenization | Existing linear vs periodic; faithful per-feature PLR; train-fitted PLE | Research and existing switches. Historical pre-V1 periodic runs belong in the experiment register; no new controlled bank PLE/PLR result in this snapshot. |
| Optimizers | AdamW tuning/decay exclusions; role-routed Muon+AdamW; Schedule-Free; RAdam/NAdam; SAM, Lion, Adan, Sophia, SGD, Lookahead | Research with applicability/cost notes. Muon private candidate existed; no bank win or integration into the recorded selected model established. Optimizer name alone does not define its LR/scaling/decay recipe. |
| Training dynamics | EMA, learning-rate schedules/warmup, dropout, weight decay, clipping, batch/accumulation, capacity/width/depth | Bounded comparisons proposed. V1 EMA infrastructure was fixed; that does not mean EMA was enabled, nor that V2 supports every proposed option. No broad sweep completion is claimed. |
| Rare-fraud objectives | Natural-prevalence cross-entropy, positive weighting, focal loss, AP surrogate, logit adjustment, calibration | Research/design only beyond the actual CE baseline. A calibration improvement is not automatically a ranking/AP gain. Weighted all-position/default-B normalization differs. |
| Sequence policy | Chunk vs target-ending scoring/training; partial-overlap chunks; offset randomization; context age/dropout; richer elapsed-time encoding | Chunk/target-ending experiments actually ran and are covered in EXPERIMENTS.md. Half-overlap and random-offset ideas received synthetic analysis; this is not a bank comparison. Richer time encoding remains proposed. |
| Data scale and sampling | Ten-file to 100-file training; intermediate learning curves; whole-account sampling with inclusion weights; target thinning/hard-negative mining | Scale tools/config generators exist. The owner's next-feature/selection/then100-file order supersedes old scale-first paths. No completed 100-file fit is evidenced for the current selected recipe. |
| Alternative learners | Matched XGBoost/LightGBM, TabM/RealMLP; tabular foundation models; graph/HMM features | Literature/challenger proposals, not proved superior on this project. External15298 metrics are not a matched same-data training control. |
| Model combinations | Seed-score ensembles, frozen neural-vector+XGBoost, distillation, SWA/model soups | Downstream vector consumer implemented; bank execution pending. Other combinations remain proposed. Averaging independently initialized checkpoint weights was not adopted. |
| Self-supervision | CoLES/sequence pretraining and earlier single-row pretraining | Parked Phase5 scope; does not delay current feature/model delivery. |

The research includes original FT-Transformer/numerical-embedding papers, fraud aggregation/sequence studies, tabular optimizer benchmarks and temporal/grouped benchmark evidence. Papers motivate comparisons; their AP values, sampling prevalence or reported relative gains do not forecast this bank's AP. Historical WP7 budget/tier documents describe then-current proposals and are not a newly adopted training budget.

Sources: [October 14 synthesis](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CH/2026-10-14-literature-methods/README.md), [WP7 programme](https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/bridge/assist/research/CH/2026-10-21-recipe/RECIPE_PROGRAMME.md), [WP7 evidence depth](https://github.com/AliKashy/tabular_fraud/blob/dda4d4a07b371e0c980d65ec5caf016077d1acb9/bridge/assist/research/CH/2026-10-21-recipe/STATUS.md), [joint methods register](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/assist/research/METHODS.md).

**Autoresearch:** Karpathy's loop was evaluated as an experiment-management pattern: propose a bounded change, train, measure, retain/discard and record. The proposal reuses this project's trainer and metrics rather than importing its language-model task or five-minute budget. Optuna and Featuretools were considered for separate search/feature-generation roles. An autonomous bank-connected autoresearch system was not built or shown running. [Study](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/plans/CH/2026-10-09-feature-engineering/STUDY_AND_TOOLING.md).

## 5. Embeddings, downstream models and the feature store

The purpose is to turn the chosen fraud model into a reusable information source: its 48-number transaction vector and fraud score. The vector is captured immediately before the prediction head and checked by reproducing that head's score. It is not a new supervised feature label.

| Deliverable | Meaningful capability | State at reviewed evidence |
|---|---|---|
| Label-free transaction export | Transaction keys, score, history support and 48-dimensional vector; head-score agreement and immutable encoder identity | Implemented and shipped in 009; export/L4 bank run not recorded. |
| Four-arm downstream XGBoost | Raw; raw+score; raw+vector; raw+score+vector. The main incremental comparison is the last versus raw+score. PCA 8/PCA 16 variants use transforms fitted on downstream training only | Implemented/shipped; not run on bank, with XGBoost missing in returned environment. |
| Vector diagnostics | Per-dimension spread, near-constant dimensions, PCA explained variance, relation to score | Implemented; no returned bank diagnostics. Correlation alone does not establish redundancy or business value. |
| Paired/business analysis | Same-target account-cluster uncertainty; AP/AUROC; count/value detection at alert fractions, reliability, temporal/depth slices | Paired architecture analysis ran. Full FINAL business reading remains unrun. Amount-weighted detection is not automatically realized financial savings. |
| Benchmark comparison | Align incumbent and new scores on the same benchmark transaction IDs; compare frozen artifacts | Implemented/shipped but unrun. Returned benchmark file lacked a directly usable score column; separate incumbent logits need an aligned score table. |
| Versioned vector store | Immutable snapshots, earlier-time lookup, latest vector and transaction-weighted 30-day mean; frozen scaler/PCA; refresh/backfill equivalence and rollback | Implemented/tested private candidate PR28 at 3b3162c, not included in 009 or demonstrated deployed. Event-time lookup is not proof of knowledge-time/online availability. |
| Original second consumer | Account fraud in next 14 days, weekly snapshots, five XGBoost arms | Implemented in PR28 and exercised on synthetic fixtures, **withdrawn as the project use case by D-012**. |
| Current second consumer | 15298's score as a fixed starting prediction; an XGBoost correction using our vector; measure lift versus 15298 on matched targets | Owner-approved direction, not demonstrated implementation/run in inspected sources. Needs 15298 scores for those targets. |
| Current comparison with TFM | Correlation/complementarity of our vectors and scores with TFM V22B embeddings and incumbent scores | Owner-approved direction, not a returned result. Incremental predictive testing is needed alongside correlation. |

Sources: [V2 export and downstream implementation map/status](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/code_tour/05_v2_tools.md#L229), [store implementation](https://github.com/AliKashy/tabular_fraud/blob/3b3162ca907ee363790e0bcbd2173811dcc77b37/waqas/v2/store/README.md), [corrected store completion](https://github.com/AliKashy/tabular_fraud/issues/7#issuecomment-6339765679), [D-012](https://github.com/AliKashy/tabular_fraud/blob/d711d92b61dec0c3e452dbedec544d071bf6d111/bridge/DECISIONS.md#L176).

## 6. What this work established and what remains

**Established:** a comprehensive candidate inventory, explicit history/availability definitions, implemented feature-engineering and screening components, a literature-backed menu of controlled recipe experiments, transaction export/downstream/benchmark tooling, and a tested experimental vector store. These are real deliveries beyond the model fixes.

**Not yet established:** which additional features improve this bank model, an expanded-feature training result, an optimizer/capacity optimum, the chosen recipe's 100-file outcome, measured value of exported vectors to 15298 or TFM, a deployed production store, or final untouched-cohort production performance. The latest owner direction is the chosen H20 chunk model, next-feature preprocessing/selection (month removed, time gap retained), then scale and downstream evaluation; completed seed work is not reopened by this inventory.

The final retained feature count, verified metadata mappings and implemented D-012 consumer remain part of the next feature/downstream deliverable.
