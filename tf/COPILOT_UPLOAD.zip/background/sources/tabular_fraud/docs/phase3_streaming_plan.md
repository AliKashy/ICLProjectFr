# Phase 3 Plan — Streaming Training at Scale

Enable training on thousands of parquet files that cannot fit in memory by streaming batches from S3 and applying frozen preprocessing artifacts, while reusing the FT-Transformer through a PyTorch Lightning Trainer with custom DataLoaders.

**Status:** VALIDATED end-to-end (2026-09-08). Builds on the Phase 1–2 baseline (test AUROC 0.952 / AP 0.094).

## Smoke-test results (2026-09-08, H200)

Trained on `part_1..part_10`, val `part_4950`, artifacts v1, 2 epochs, ~142K params.

| Stage | AUROC | AP | Notes |
|---|---:|---:|---|
| Streaming validation (epoch 1) | 0.9414 | 0.1085 | full-val `valid_ap`; best checkpoint |
| Streaming score `part_8000` | 0.9479 | 0.0732 | artifact scoring; 228,043 rows, 290 positives |
| Baseline `part_8000` | 0.9521 | 0.0940 | in-memory reference |

Parity confirmed: streaming AUROC (~0.948) ≈ baseline (~0.952), validating frozen-artifact preprocessing and the hand-built `InferredConfig`. Full flow: streaming train → `valid_ap` checkpointing → artifact scoring → S3 predictions.

Bring-up fixes: wrap `InferredConfig` with `OmegaConf.structured`; yield 2-D target `[B,1]`; use `torch.load(weights_only=False)` for the OmegaConf-bearing checkpoint.

## Scaling results (2026-09-09, H200)

Same model (~142K params), AdamW `weight_decay=1e-5`, `ReduceLROnPlateau`, early stopping on `valid_ap`.

| Run | Train | Val | Best valid_ap | Best valid_auroc |
|---|---|---|---:|---:|
| 10-file, 2 epochs | `part_1..10` | `part_4950` | 0.1085 | 0.9414 |
| 10-file, 10 epochs | `part_1..10` | `part_4950` | 0.1131 (ep 7) | 0.9481 |
| 100-file, early-stopped | `part_1..100` | `part_4950..4954` | 0.1247 (ep 2) | 0.9493 |

Eval on `part_8000..8010` (2,466,461 rows, 3,818 positives):

| Model | AUROC | AP |
|---|---:|---:|
| 100-file streaming, shuffle on | 0.9514 | 0.0940 |
| 100-file streaming, shuffle off | 0.9508 | 0.0923 |
| Baseline, `part_8000` only | 0.952 | 0.094 |

### Findings

- Row shuffling closes the final baseline gap: AP 0.0923 → 0.0940; AUROC 0.9514 ≈ 0.952.
- Without in-block row shuffle, consecutive account/time-clustered rows correlate mini-batches. At batch 512 training collapsed (~0.5 AUROC); at batch 8192 large blocks masked it. `shuffle_rows` shuffles a 65,536-row read block before mini-batching.
- Batch 8192 with shuffle: `valid_ap=0.1249`, essentially shuffle-off 0.1247.
- More data helps modestly: validation AP ~0.11 → ~0.125 from 10 to 100 files.
- Metrics plateau around epochs 2–5 with train/valid loss ~0.008: feature-limited rather than epoch/capacity-limited.
- Next lever: Phase 4 transaction history.

## Why not TabularModel.fit

`TabularModel.fit` requires a full in-memory DataFrame and fits its own preprocessing. The model itself only needs batch dictionaries, so Lightning can consume streaming DataLoaders while reusing training logic.

## Decisions

| Area | Decision |
|---|---|
| Model construction | Hand-build `InferredConfig` from frozen artifacts. |
| Cardinality | Artifact categorical cardinalities + 2 per `_isna` flag. |
| Preprocessing | Frozen `PreprocessingArtifacts`. |
| `_isna` flags | Derived pre-impute; fixed `{False:0, True:1}`; appended after artifact categoricals. |
| Class imbalance | CrossEntropyLoss; configurable `pos_weight`, default 1. |
| Monitor | Full-stream `valid_ap`, mode=max. |
| Evaluation | Lightning checkpoint + `artifacts/<v>`. |
| Smoke | Train `part_1..10`, val `part_4950`, artifacts v1, 1–2 epochs, workers=4, buffer shuffle. |

## Components

### Streaming dataset — fraud/data/parquet_loader.py

`ParquetStreamingDataset` streams Arrow batches; derives datetime features; computes raw missing flags; encodes categoricals; standardizes continuous values; maps the target; yields whole tensor batches with `DataLoader(batch_size=None)`. Continuous order follows `FeatureList.continuous`; categorical order is artifact categoricals + missing flags. Worker file sharding and in-memory row shuffle are supported.

### Model builder

Build `FTTransformerConfig` plus an `InferredConfig` with continuous/categorical dimensions, categorical cardinalities, and binary output. Instantiate the FT-Transformer with AP/AUROC metrics and optional weighted CE.

### Validation metrics

Accumulate predictions/targets over the complete validation stream; compute AP/AUROC at epoch end; log `valid_ap` and `valid_auroc`; reset. Early stopping/checkpointing monitor `valid_ap`.

### Training and scoring

- `fraud/scripts/train_streaming.py` + `fraud/configs/streaming.yaml`: streaming train/val, CSV metrics, early stopping, optional TensorBoard, Lightning checkpoint.
- `fraud/scripts/score_streaming.py`: load checkpoint + frozen artifacts, stream eval range, apply identical preprocessing, write predictions.

## Verification

1. Smoke `part_1..10` / `part_4950`: decreasing loss, sane AP/AUROC, bounded RSS.
2. Parity with baseline AUROC (~0.93–0.95).
3. Unseen categories map to UNK without error.

## Out of scope

- Phase 4 sequential model.
- Global/full shuffling.
- Class weighting enabled by default.

## Implemented files

- `fraud/data/parquet_loader.py`
- `fraud/streaming_model.py`
- `fraud/callbacks.py`
- `fraud/scripts/train_streaming.py`
- `fraud/configs/streaming.yaml`
- `fraud/scripts/score_streaming.py`

## How to run

```bash
git pull
python fraud/scripts/train_streaming.py --config fraud/configs/streaming.yaml 2>&1 | tee logs/streaming_$(date +%Y%m%d_%H%M%S).log
python fraud/scripts/score_streaming.py --config fraud/configs/streaming.yaml 2>&1 | tee logs/streaming_score_$(date +%Y%m%d_%H%M%S).log
python fraud/scripts/show_progress.py --file checkpoints/streaming/training_metrics.csv
```
