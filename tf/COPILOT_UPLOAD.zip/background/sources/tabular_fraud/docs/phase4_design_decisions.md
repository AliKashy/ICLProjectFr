# Phase 4 — Design Decisions Log

Record of the design discussion for the history-aware (sequential) fraud model. Companion to [phase4_sequential_plan.md](phase4_sequential_plan.md). Date: 2026-09-25.

Context: Phase 3 established that a **single-transaction FT-Transformer** is at its signal ceiling (~0.95 AUROC, ~0.09–0.12 AP) — confirmed **feature-limited** (bigger models and more epochs/data don't move it). Phase 4 adds **transaction history per account** as *new signal*.

## Decisions (confirmed)

| # | Topic | Decision | Rationale |
|---|---|---|---|
| 1 | Architecture (v1) | **Flat SEP-token** sequence (approach a). Document **hierarchical (b)** for future. | Simplest path to parity; matches the original plan. |
| 2 | Historical `frd_tag` as a feature | **Excluded** in v1. | Prior-transaction fraud labels may not be available at inference time → leakage risk. Revisit only if label availability is confirmed. |
| 3 | Sample definition | `target = txn[i]`, `history = txn[i-N .. i-1]` (same account, strictly prior). **N = 5, stride = 1**, both YAML-configurable. **Never skip a fraud transaction as a target.** | Every transaction can be a target; stride only subsamples abundant non-fraud targets. |
| 4 | Time features | **Add time-delta features** (elapsed time between transactions / to target). | Velocity/recency is strong fraud signal — likely a primary source of Phase 4 lift. |
| 5 | Short histories | **Left-pad** to N with a PAD token + attention mask. | Early-account transactions (fewer than N priors) are still valid "little/no history" samples; can't discard them (fraud is rare). |
| 6 | Model capacity | **Configurable; start moderate** (e.g. `input_embed_dim=48–64`, `num_attn_blocks=4`) and **re-run a capacity sweep.** | Unlike single-txn (feature-limited), the sequential task has richer cross-transaction interactions to learn, so capacity may now help. Deeper needs lower LR (use the `learning_rate` knob). |
| 7 | Attention direction | **Configurable** (<code>attention_mask: bidirectional &#92;&#124; causal</code>), **default bidirectional.** | Classification of the target (not autoregressive); all history is legitimately observed and features aren't labels, so bidirectional is leakage-safe and richest. Causal = block-causal at the transaction level, needed only for the future "predict every transaction at once" scheme. |
| 8 | Position encoding | **Transaction-level position embedding only** — added to every feature token of a transaction. **No intra-transaction positional encoding** (features are an unordered set, per FT-Transformer). Complemented by the time-delta feature. | Feature identity comes from the feature tokenizer; only *transaction order* needs positional signal. Position = ordinal slot; time-delta = actual elapsed time (complementary). |

## Carried over from Phase 3

- **Each account is fully contained in one parquet file** → sequences build within a file, no cross-file joins.
- **Frozen preprocessing artifacts** encode each transaction's features identically.
- **Same eval harness** (`valid_ap`/`valid_auroc`, artifact-based scoring) → compare Phase 4 AP directly against the single-transaction ceiling.
- **Streaming + Lightning** training pattern (memory-bounded, GPU-confirmed) reused.

## Follow-up notes (2026-09-25)

| # | Topic | Decision |
|---|---|---|
| 9 | Sample correlation | `stride=1` windows overlap by construction (worse than Phase 3). Mitigate with a **window-level shuffle buffer spanning many accounts** + large-ish batch; `train_stride>1` optional. Training-only concern (val/test aggregate over full set). |
| 10 | Train vs eval stride | Separate keys: `train_stride` (default 1, may raise) and **`eval_stride` = 1 always** (score every transaction, mirrors production). Eval deterministic, no shuffle. |
| 11 | Memory / OOM safety | Phase 4 attention ≈ O(batch × heads × L²), L~180 (~36× Phase 3). Default `precision: bf16-mixed`, start **batch ~4096**, watch `nvidia-smi`; use `accumulate_grad_batches` to grow effective batch safely. Watch **host-RAM shuffle buffer** (`read_batch_size × num_workers`). CUDA OOM aborts the run (checkpoints safe). |

## Deferred / future work

- **Hierarchical architecture (b)** — encode each transaction independently (reuse the validated single-txn FT-Transformer as the token encoder), then a sequence transformer over transaction vectors. Cheaper attention, scales to longer histories.
- **Causal / "predict every transaction at once"** — one forward pass yields a fraud prediction for each transaction (each seeing only its past). Training-efficient; needs block-causal masking.
- **Historical `frd_tag` as a feature** — only if inference-time label availability is confirmed.
- **Longer histories (N > 5)** — trivially via config once the pipeline works.
