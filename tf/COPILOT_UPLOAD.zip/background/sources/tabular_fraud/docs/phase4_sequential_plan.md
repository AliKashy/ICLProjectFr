# Phase 4 Plan — Sequential (History-Aware) Fraud Model

Add **transaction history per account** to the FT-Transformer so fraud is scored using the
target transaction **plus its N most recent prior transactions** from the same account.
Builds on Phase 3 (streaming, frozen artifacts, Lightning training, artifact-based eval).

Decisions log: [phase4_design_decisions.md](phase4_design_decisions.md).
Status: **planning** (2026-09-25). No code yet.

---

## 1. Why Phase 4

The single-transaction model is **feature-limited** (~0.95 AUROC / ~0.09–0.12 AP; capacity,
epochs, and data don't move it). History adds genuinely new signal — behavioral context,
velocity, and drift per account — that a single transaction can't express.

---

## 2. Sample construction

For each account (sorted by `transaction_dttm`, deterministic tie-break on `transaction_id`),
a training/inference sample is **one target transaction + its N prior transactions**:

```
Account timeline (oldest -> newest):
  t0   t1   t2   t3   t4   t5   t6   t7  ...

N = 5, stride = 1:
  target = t5  ->  history = [t0 t1 t2 t3 t4]
  target = t6  ->  history = [t1 t2 t3 t4 t5]
  target = t7  ->  history = [t2 t3 t4 t5 t6]
  ...
  target = t2  ->  history = [PAD PAD PAD t0 t1]   (short history -> left-pad)
```

Rules:
- **Strictly causal:** history is always *prior* to the target (`time < target_time`).
- **N** (history length) and **stride** are YAML-configurable (start `N=5`, `stride=1`).
- **Never skip a fraud transaction as a target** — stride only subsamples non-fraud targets.
- **Left-pad** short histories to N with a PAD token + attention mask.
- Per transaction: the same **23 frozen-artifact features** (no `frd_tag`) **+ time-delta
  feature(s)**. Label = the **target's** `frd_tag`.

### 2.1 Sample correlation & shuffling (training)

With `stride=1` the windows for one account **overlap by construction** (`[t0..t4]→t5` and
`[t1..t5]→t6` share 4/5 history + adjacent targets), so an account emits many near-duplicate
samples. This is *stronger* than the Phase 3 row correlation. Mitigations:
- **Window-level shuffle buffer spanning many accounts** — accumulate a large pool of windows
  (across many accounts in the read block) and shuffle before batching, so an account's windows
  spread across batches. `read_batch_size` = size of this window pool (must be ≫ windows/account).
- **Larger batch → more accounts per batch → decorrelated gradients** (memory permitting).
- **`train_stride > 1`** optionally reduces overlap/redundancy (still never skips fraud).

This is a **training-only** concern; val/test metrics aggregate over the whole set, so order
(and correlation) don't affect them, and shuffling is off for eval.

### 2.2 Train vs eval stride

- **`train_stride`** (default 1) may be raised to cut correlation/redundancy; fraud targets
  are always kept.
- **`eval_stride` = 1 always** — validation/test score **every** transaction as a target
  (mirrors production, which scores every transaction). Deterministic, no shuffle. Early
  transactions are scored with left-padded history (realistic cold-start). Each account is
  fully within one file, so eval per file is self-contained.

---

## 3. Per-transaction features

- **23 features** encoded via the frozen artifacts (continuous standardized, categorical
  UNK/MISSING vocab) — identical to Phase 3, applied per transaction.
- **`_isna` flags** as in Phase 3.
- **Time-delta feature(s)** (new): elapsed time to the previous transaction and/or to the
  target (e.g. log-seconds), giving explicit recency/velocity signal.
- **No historical `frd_tag`.**

---

## 4. Architecture A — Flat SEP-token (v1, chosen)

All transactions' feature tokens are concatenated into **one sequence** with `SEP` between
transactions and a `CLS` whose output predicts the target's fraud probability. A single
transformer attends across the whole window (bidirectional by default).

```mermaid
flowchart LR
    CLS["[CLS]"] --> TF
    subgraph HIST["history txns (feature tokens) + SEP"]
      H1["txn t0<br/>feat tokens"]
      H2["txn t1<br/>feat tokens"]
      HD["... SEP ..."]
      H5["txn t4<br/>feat tokens"]
    end
    subgraph TGT["target txn"]
      T["txn t5<br/>feat tokens"]
    end
    HIST --> TF
    TGT --> TF
    TF["Transformer encoder<br/>(bidirectional, multi-block)"] --> C["CLS embedding"]
    C --> HEAD["Linear head"] --> P["P(fraud) of target"]
```

Token layout (each transaction contributes ~29 feature tokens; a shared
**transaction-position embedding** is added to all tokens of that transaction):

```
position:   0        1..29      30      31..59    ...     SEP      target block
tokens:   [CLS]  [t0 feat...] [SEP]  [t1 feat...] ...    [SEP]   [t5 feat...]
pos-emb:    p*      p0          p0      p1          ...    -        pN(target)
```

- **No intra-transaction position encoding** (features are an unordered set).
- **Transaction-position embedding** carries temporal order; **time-delta feature** carries
  actual elapsed time (complementary).
- Sequence length ≈ (N+1) × 29 + specials ≈ **~180 tokens** — fine for attention (O(L²)).

**Pros:** simplest; one model; direct parity comparison with Phase 3.
**Cons:** attention cost grows with N; less structured than (b) for long histories.

---

## 5. Architecture B — Hierarchical per-transaction (future)

Encode **each transaction independently** with a shared FT-Transformer (reusing the
validated single-transaction backbone) into one vector per transaction, then run a small
**sequence transformer** over those N+1 transaction vectors (with transaction-position +
time-delta) to predict the target.

```mermaid
flowchart LR
    subgraph ENC["shared FT-Transformer encoder (per transaction)"]
      direction TB
      X1["txn t0 features"] --> V1["vec t0"]
      X2["txn t1 features"] --> V2["vec t1"]
      XD["..."] --> VD["..."]
      XT["target txn features"] --> VT["vec target"]
    end
    V1 --> SEQ
    V2 --> SEQ
    VD --> SEQ
    VT --> SEQ
    SEQ["Sequence transformer<br/>(over txn vectors + pos/time)"] --> CT["target/CLS vector"]
    CT --> HEAD2["Linear head"] --> P2["P(fraud) of target"]
```

**Pros:** cheaper attention (O((N+1)²) over vectors, not tokens); reuses the ceiling-proven
single-txn model as a component; scales to long histories.
**Cons:** two-stage; more moving parts. Documented for later exploration.

---

## 6. Attention direction

- **`attention_mask: bidirectional` (default)** — every token attends to every other. Safe:
  the target's *features* (not its label) are known at inference, and all history is prior.
- **`attention_mask: causal`** — block-causal at the **transaction** level (txn *i* attends to
  txns ≤ *i*). Needed only for the future "predict every transaction at once" scheme.

Configurable; v1 uses bidirectional.

---

## 7. Planned components (no code yet)

| Component | Role |
|-----------|------|
| `fraud/data/sequence_builder.py` (rewrite) | Stream a parquet file, group by account, sort by time, emit causal (target + N-history) windows with padding + time-deltas; yields batched tensor dicts. Reuse frozen artifacts. |
| `fraud/models/ft_transformer_seq/` | Flat SEP-token model: per-feature tokenizer + transaction-position embedding + configurable-mask transformer + CLS head. |
| `fraud/scripts/train_sequential.py` (rewrite) | Lightning training over the streaming sequence dataset; reuse `StreamingBinaryMetrics`, `CSVMetricsCallback`, early stopping on `valid_ap`. |
| `fraud/scripts/score_sequential.py` | Artifact-based scoring over an eval range (sequence windows), writes predictions to S3. |
| `fraud/configs/sequential.yaml` (rewrite) | `history_len`, `stride`, `attention_mask`, model size, LR, file ranges, artifacts version. |

---

## 8. Configuration (planned keys)

```yaml
sequence:
  history_len: 5          # N prior transactions
  train_stride: 1         # target subsampling for training (never skips fraud)
  eval_stride: 1          # val/test score every transaction
  attention_mask: bidirectional   # bidirectional | causal
  time_delta: true        # add elapsed-time feature(s)

model:
  input_embed_dim: 48     # start moderate; sweep
  num_attn_blocks: 4
  num_heads: 8
  attn_dropout: 0.1
  ff_dropout: 0.1

training:
  learning_rate: 3.0e-4   # lower for the deeper/richer model
  batch_size: 4096        # start moderate (~6x sample size vs Phase 3); watch nvidia-smi
  precision: bf16-mixed   # ~halve memory + faster on H200
  accumulate_grad_batches: 1   # raise to grow effective batch without more memory
  read_batch_size: 65536  # window shuffle pool (host RAM per worker) — span many accounts
  # ... shuffle_rows, num_workers, monitor=valid_ap, etc. (as Phase 3)
```

---

## 9. Verification

1. **Smoke:** a few files, N=5, 1–2 epochs — loss decreases, `valid_ap`/`valid_auroc` sane,
   RSS bounded, causal windows correct (no future leakage; spot-check a few samples).
2. **Parity/lift:** compare `valid_ap` and 11-file eval AP against the single-txn ceiling
   (~0.125 / ~0.094). **Phase 4 succeeds if it clears that ceiling.**
3. **Ablations:** `history_len` (0 vs 5), time-delta on/off, bidirectional vs causal — to
   attribute the lift.
4. **Leakage check:** confirm history excludes the target and any `time >= target_time`.

## 9.1 Memory, batch size & OOM safety (shared pod)

Phase 3 used a **trivial** slice of the H200 (~150 MB logged at inference; tiny 142K model).
Phase 4 grows the sequence from ~30 to **~180 tokens**, and **standard attention memory is
O(batch × heads × L²)** — so L² is ~36× larger. Rough order at batch 8192 / L=180 / 8 heads /
4 blocks: **~40–60 GB** — fits in 140 GB but no longer negligible.

Guardrails (to avoid crashing the shared server):
- **Default `precision: bf16-mixed`** on the H200 — ~halves activation memory and is faster.
- **Start `batch_size ≈ 4096`**, watch `nvidia-smi` peak on epoch 0, then raise toward 8192
  only if there's headroom. Check `nvidia-smi` for *other users'* usage first.
- **`accumulate_grad_batches`** keeps a large *effective* batch while the *per-step* batch
  (and memory) stays small — the safe way to decorrelate without OOM.
- **Host-RAM caution:** the window shuffle buffer lives in CPU RAM **per worker**
  (`read_batch_size × num_workers`). Too large → the process is `Killed` (host OOM, no CUDA
  traceback). Keep it within pod memory.
- **OOM behavior:** CUDA OOM raises a `RuntimeError` and aborts the run (checkpoints are safe,
  just rerun smaller). No auto-recovery with the raw `pl.Trainer`.
- Levers if OOM: bf16 → smaller batch → grad-accumulation → shorter N → smaller model →
  (later) memory-efficient/SDPA attention.

---

## 10. Open items / future

Ordered roughly by expected impact-to-effort. The N=5 lift over the single-transaction
baseline is real but modest, so the theme is: **give the model more signal (data, history,
features) and enough capacity to use it**, then re-tune.

### A. Scale the training data
- More files: **100 → 200 → 500+** `part_N`. Streaming is memory-safe, so this is mostly wall-clock.
  Watch for diminishing returns on `valid_auroc` and plateauing `train_loss`.
- Confirm the **validation set grows with it** (e.g. `val_end=4954` → wider) so epoch selection
  stays stable on the rare positive class.

### B. Longer history (the main sequence lever)
- Sweep **N = 5 → 10 → 15 → 20**. Longer context is the most direct way to beat the single-txn
  ceiling; `T = N+1` so cost scales with sequence length.
- Pair larger N with a **larger shuffle buffer** and watch GPU memory (bf16 already helps).

### C. Enlarge the network
- More `num_attn_blocks` (4 → 6 → 8) and larger `input_embed_dim` (48 → 64 → 96/128); possibly
  more `num_heads`.
- **Re-tune together** — bigger models need a **lower LR** + **warmup** and more regularization
  (`attn_dropout` / `ff_dropout`, `weight_decay`) to avoid overfitting the rare class.
- Earlier single-txn capacity tests were feature-limited; the richer sequential task may now
  reward capacity — verify by watching whether `train_loss` actually drops.

### D. More / richer features
- **More transaction-level features** (any available raw columns not yet in `predictors.csv`).
- **High-cardinality categoricals** (e.g. merchant / device / zip) with appropriate encoding —
  hashing for very large spaces, or frequency/target-
  aware encoding.

### E. Imbalance & objective
- Tune `pos_weight`

### F. Architecture
- Account-level pooling / two-level (transaction-encoder → sequence-encoder) design.
- **Causal/hierarchical model:** predict **every transaction at once** with a block-causal mask
  (one forward pass per account instead of one per window) — much more training-efficient,
  enables longer effective history.


### G. Methodology / infra
- **Hyperparameter sweep** (N, depth, width, LR, dropout, `pos_weight`) once the bigger-data
  pipeline is stable, rather than one-off runs.
- Feature-importance / ablation to prune low-value inputs before scaling capacity.
- Multi-GPU (DDP) **if** throughput becomes the bottleneck — needs rank-aware file sharding in
  `SequenceBuilder` + metric all-gather in `StreamingBinaryMetrics` (pod currently has 1 GPU).


## Preliminary results (2026-09-28, H200)

+ early stopping on `valid_ap`.

|Architecture |Run | Train files | Val files | Best `valid_ap` | Best `valid_auroc` |
|-----|-----|-------------|-----|-----------------|--------------------|
| Single transaction |10-file, 2 epochs | `part_1..10` | `part_4950` | 0.1085 | 0.9414 |
| Single transaction |10-file, 10 epochs | `part_1..10` | `part_4950` | 0.1131 (ep 7) | 0.9481 |
| Single transaction |100-file, 10 epochs, early-stopped | `part_1..100` | `part_4950..4954` | 0.1247 (ep 2) | 0.9493 |
| Target transaction + History (5) | 10-file  , 10 epochs, early-stopped | `part_1..10` | `part_4950..4954` | **0.1293 (ep 5)** | **0.9509** |
