# Bank Dataset Benchmark Results

## Dataset

- **Source:** UCI Bank Marketing Dataset (`bank-full.csv`)
- **Total samples:** 45,211
- **Features:** 9 categorical, 7 numerical
- **Target:** `y` (binary: yes/no for term deposit subscription)
- **Class imbalance:** ~88% no, ~12% yes
- **Platform:** OCP GPU — NVIDIA H200 (144GB), PyTorch 2.13.0+cu130, Python 3.12.9

## Data Splits

| Model | Train | Val | Test | Split Method |
|---|---|---|---|---|
| SAINT / SAINT_S | 29,388 (65%) | 6,781 (15%) | 9,042 (20%) | Sequential shuffle, seed=1234 |
| FT-Transformer / CategoryEmbedding | 27,126 (60%) | 9,042 (20%) | 9,043 (20%) | sklearn train_test_split, seed=1234 |

> Note: Test sizes are similar (~9K) but not identical samples. Splits use different methods.

## Results Summary

| Model | Test AUROC | Test Loss | Params | Speed (it/s) | Overfitting? |
|---|---|---|---|---|---|
| SAINT (intersample) | 0.822 | 0.491 | 66.9K | 33 | Yes |
| SAINT_S (self-attn only) | 0.851 | 0.468 | 40.8K | 55 | Yes |
| CategoryEmbedding (MLP) | 0.921 | 0.212 | 15.5K | 112 | No |
| **FT-Transformer** | **0.935** | **0.199** | **138K** | **68** | **No** |

## Model Settings

### SAINT (intersample attention)

- **Framework:** Custom PyTorch Lightning
- **Architecture:** Self-attention + intersample attention encoder
- **Preprocessing:** Manual label encoding, z-normalization, CLS token insertion
- **Settings:**
  - `model: saint`
  - `embed_dim: 32`
  - `num_heads: 8`
  - `num_layers: 6`
  - `d_ff: 256` (feed-forward dimension)
  - `dropout: 0.0`
  - `dropout_ff: 0.8`
  - `optimizer: AdamW`
  - `lr: 1e-4`
  - `weight_decay: 1e-5`
  - `batch_size: 32`
  - `max_epochs: 10`
  - `loss: BCEWithLogitsLoss`
  - `sampler: WeightedRandomSampler (replacement=False)`

### SAINT_S (self-attention only)

- Same as SAINT above except:
  - `model: saint_s`
  - No intersample attention layers → fewer params (40.8K vs 66.9K)

### FT-Transformer (PyTorch Tabular)

- **Framework:** PyTorch Tabular (library)
- **Architecture:** Feature Tokenizer + Transformer encoder with CLS token
- **Preprocessing:** Automatic (handled by PyTorch Tabular — normalization, embedding)
- **Settings:**
  - `input_embed_dim: 32`
  - `num_heads: 8`
  - `num_attn_blocks: 3`
  - `attn_dropout: 0.1`
  - `ff_dropout: 0.1`
  - `optimizer: AdamW`
  - `weight_decay: 1e-5`
  - `lr_scheduler: ReduceLROnPlateau (patience=3, factor=0.5)`
  - `batch_size: 256`
  - `max_epochs: 10`
  - `early_stopping: valid_loss (patience=5)`
  - `loss: CrossEntropyLoss`

### CategoryEmbedding (PyTorch Tabular)

- **Framework:** PyTorch Tabular (library)
- **Architecture:** Categorical embeddings → concatenation with numericals → MLP
- **Preprocessing:** Automatic (handled by PyTorch Tabular)
- **Settings:**
  - `layers: 128-64-32`
  - `activation: ReLU`
  - `dropout: 0.1`
  - `optimizer: AdamW`
  - `weight_decay: 1e-5`
  - `lr_scheduler: ReduceLROnPlateau (patience=3, factor=0.5)`
  - `batch_size: 256`
  - `max_epochs: 10`
  - `early_stopping: valid_loss (patience=5)`
  - `loss: CrossEntropyLoss`

## Important Caveat

**No hyperparameter tuning was performed.** All models were trained for 10 epochs with default/minimal settings. Results are directional — with proper tuning (learning rate search, dropout optimization, batch size, more epochs with early stopping), all models could improve. However, the relative ranking is likely to hold.

## Key Observations

1. **FT-Transformer is the clear winner** — highest AUROC (0.935), lowest loss (0.199), no overfitting
2. **Even a simple MLP (CategoryEmbedding) beats SAINT** by 7-10 points — proper preprocessing and regularization matter more than architecture complexity
3. **Intersample attention hurts** — SAINT_S outperforms SAINT while being faster and simpler
4. **SAINT overfits significantly** — train AUROC 0.946 vs test 0.822/0.851, likely due to lack of dropout in attention layers and smaller batch size
5. **PyTorch Tabular's auto-preprocessing** (normalization, embedding, LR scheduling) provides a strong baseline with minimal code
6. **Batch size matters** — SAINT uses 32 vs PyTorch Tabular's 256, affecting both speed and generalization

## Recommendation

Use **PyTorch Tabular with FT-Transformer** for production. Benefits:

- Higher accuracy with less tuning
- Built-in preprocessing pipeline
- Easy model swapping via config
- Better regularization out of the box
- Faster training
