# Baseline Smoke Test Plan — Transformer Fraud Detection

This plan covers the path from feature selection to a validated individual-transaction FT-Transformer baseline, then scaling, then the sequential history-aware model.

## Context

- **Project:** `tabular_fraud` (forked PyTorch Tabular). FT-Transformer chosen after benchmark (~0.935 AUROC).
- **Label:** `frd_tag` (binary).
- **Order key:** `transaction_dttm`.
- **Account:** `Nmap_account_reference_xid`.
- **Train data:** `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/` (`part_1.parquet` … `part_5000.parquet`).
- **Eval data:** `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/` (`part_8000.parquet` … `part_10000.parquet`).
- **EDA notebook:** `notebooks/eda.ipynb` (`candi_cols` + `stats_df`).

## Key technical finding

The fork's `handle_missing_values` flag imputes categorical columns but does **not** automatically impute continuous NaNs. Continuous NaNs must be handled before `fit()`.

## Final decisions

- **Missing values:** continuous → median impute + `<col>_isna` missing indicator.
- **Validation:** smoke test `part_4950.parquet`; larger training uses `part_4950..part_5000` from the training bucket.
- **Metrics:** PR-AUC / average precision drives model selection; ROC-AUC is also reported.
- **Datetime:** derive `month`, `day`, `hour`, `day_of_week` from `transaction_dttm`; optional `is_weekend`. Default low-cardinality categorical; cyclical sin/cos is configurable. Raw timestamp remains an ordering key rather than a model feature.
- **Config-driven:** imputation strategy, missing flags, datetime fields/encoding, validation range, metrics, and monitor are configured in YAML.
- **Predictor list:** versioned CSV source of truth at `s3://mrmcd-analytics-mrm-users/K016730/tabular_fraud/predictors.csv`, with feature/type/source/version/description. Training derives continuous/categorical lists from this CSV rather than hardcoding them.

## Predictors — version 1

19 base features + 4 datetime-derived = 23.

### Continuous (6)

| Feature | Source | Description |
|---|---|---|
| `transaction_amt` | raw | Transaction amount |
| `external_1_scr` | raw | Visa external fraud score |
| `avlble_merch_day_cash_lmt_amt` | raw | Available daily merchandise limit |
| `available_daily_cash_limit_amt` | raw | Remaining daily cash ATM limit |
| `remain_day_merchandise_lmt_amt` | raw | Remaining daily merchandise limit |
| `total_available_balance_amt` | raw | Available balance before transaction |

### Categorical, low cardinality (13)

- `transaction_type_xcd` — transaction type
- `segment` — transaction category
- `transaction_category_xcd` — method used for transaction
- `transaction_pos_condition_xcd` — POS condition
- `avs_request_xcd` — AVS request indicator
- `pos_security_xflg` — transaction security indicator
- `transaction_pin_verify_xcd` — PIN verification
- `cardholder_present_xflg` — cardholder-present indicator
- `pos_card_capture_xflg` — terminal card-capture capability
- `cvv_verify_xcd` — CVV outcome
- `authzn_rqst_crypto_valid_xflg` — authorization cryptogram result
- `pos_off_premises_xflg` — off-premises terminal indicator
- `pos_terminal_attend_xflg` — unattended terminal indicator

### Datetime-derived (4, default categorical)

| Feature | Source | Description |
|---|---|---|
| `month` | `derived:transaction_dttm` | Month |
| `day` | `derived:transaction_dttm` | Day of month |
| `hour` | `derived:transaction_dttm` | Hour |
| `day_of_week` | `derived:transaction_dttm` | Day of week (Mon–Sun) |

### Deliberately excluded

- Identifiers: `fi_transaction_id`, `Nmap_account_reference_xid`, `Nmap_merchant_xid`.
- Raw order key: `transaction_dttm` (derive datetime features; use as Phase 4 order key).
- High-cardinality candidates including merchant/category/postal/state/network/device-IP fields.
- `prior_action_db_expiration_dt`.
- `transaction_advice_xcd`.
- Prune any categorical whose EDA `unique_non_null` is unexpectedly high.

## Phases

### Phase 1 — Lock predictors & preprocessing

1. Confirm cardinality and missingness from `stats_df`.
2. Write the version-1 predictor CSV.
3. Define continuous/categorical lists and missing rules from the CSV.
4. Derive datetime features.
5. Run `fraud/scripts/build_preprocessing_artifacts.py` on a configurable file set (initially first five parquets in full, no row sampling), fitting stats in configurable feature batches and writing `manifest.json` + per-feature artifacts.

### Phase 2 — Smoke test

- Small S3 pandas loader reads selected `part_N` files and concatenates them.
- `fraud/scripts/train_baseline.py` reads predictor CSV, derives datetime fields, imputes continuous values, adds missing flags, configures PyTorch Tabular, and computes full-split AP/AUROC.
- `fraud/configs/smoke_test.yaml` supplies target, features, train/val/test ranges, one-epoch smoke settings, imputation and monitor controls.

### Phase 3 — Scale

The full dataset cannot fit in memory and `TabularModel.fit()` expects a DataFrame. Freeze preprocessing artifacts and use a streaming `IterableDataset`/Lightning path that applies the same encoders and statistics to each batch. See `phase3_streaming_plan.md`.

### Phase 4 — History-aware model

Build causal per-account target + history windows using the same frozen artifacts. See `phase4_sequential_plan.md`.

## Preprocessing artifacts

Artifacts are versioned under:

`s3://mrmcd-analytics-mrm-users/K016730/tabular_fraud/artifacts/<artifact_version>/`

The manifest records artifact/predictor versions, fit-file provenance and feature list. Per-feature files store continuous statistics or categorical vocabulary/encoder information.

Categorical reserved indices:

- `0 = UNK/OOV`
- `1 = MISSING`
- known categories start at 2

This keeps unseen categories distinct from missingness and makes train/eval/inference preprocessing deterministic.

High-cardinality encoder methods are intended to remain pluggable/versioned (vocab initially; hashing/frequency/target-style alternatives can be added later).

## Repository pieces

- `fraud/configs/predictors.csv` — feature source of truth.
- `fraud/data/preprocessing.py` — continuous imputer + frozen artifact store.
- `fraud/scripts/build_preprocessing_artifacts.py` — standalone artifact builder.
- `fraud/scripts/train_baseline.py` — in-memory baseline smoke path.
- `fraud/scripts/score_eval.py` — standalone scoring using saved model + persisted imputer.
- `fraud/data/parquet_loader.py` — streaming artifact-based dataset for Phase 3+.
- `notebooks/eda.ipynb` — candidate columns and EDA statistics.

## Verification

1. One-epoch run completes; train/val loss plus test PR-AUC/ROC-AUC are produced without NaNs.
2. Zero NaNs remain in continuous features after imputation; base feature count = 23.
3. Fraud rate is sane and predictions are not degenerate.

## Smoke-test results (2026-09-03, NVIDIA H200)

Configuration:

- 1 epoch
- train: `part_1`, `part_2` — 1,676,127 rows
- validation: `part_4950` — 882,259 rows
- test: `part_8000` from eval bucket — 228,043 rows
- FT-Transformer ~142K params: `input_embed_dim=32`, `num_heads=8`, `num_attn_blocks=3`
- AdamW, `weight_decay=1e-5`, batch 256
- continuous median imputation + missing flags; categorical missing/unknown handling; continuous normalization

Ranking metrics are computed over the **full split** from `predict()` outputs using sklearn; checkpointing monitors `valid_loss`.

| Split | Rows | Positives | Fraud rate | ROC-AUC | PR-AUC (AP) |
|---|---:|---:|---:|---:|---:|
| Validation (`part_4950`) | 882,259 | 1,332 | 0.151% | **0.9275** | **0.1051** |
| Test (`part_8000`) | 228,043 | 290 | 0.127% | **0.9521** | **0.0940** |

- Random-baseline AP is the fraud prevalence (~0.0013–0.0015), so test AP 0.094 is roughly 60–75× chance.
- ROC-AUC ~0.93–0.95 after one epoch shows strong ranking separation.
- GPU scoring confirmed (`cuda:0`, roughly 149–169 MB allocated).
- `fraud/scripts/score_eval.py` re-scored `part_8000` from the saved model + persisted imputer and reproduced ROC-AUC 0.9521 / AP 0.0940, confirming no train/eval preprocessing drift.
- Per-file predictions include IDs, `frd_tag`, score, prediction and transaction amount and are written to the baseline prediction area.

## Metric methodology note

At ~0.15% prevalence, most 256-row mini-batches contain zero fraud cases. Per-batch PR-AUC/ROC-AUC is therefore undefined or collapses toward zero when averaged. Ranking metrics are computed once over the complete split using sklearn `average_precision_score` and `roc_auc_score`; `valid_loss`, which averages correctly, drives early stopping/checkpoint selection.
