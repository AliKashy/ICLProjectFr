# Monitoring & Evaluation Guide

Reference for the two helper scripts used during and after baseline training:

- **`fraud/scripts/show_progress.py`** — view training metrics in the terminal (text only).
- **`fraud/scripts/score_eval.py`** — score a trained model over an S3 parquet range and write predictions.

All commands are run from the project root on a **GPU pod** (`~/k016730/projects/tabular_fraud`),
unless noted. Remember: `git pull` first to get the latest scripts.

---

## 1. `show_progress.py` — training progress viewer

Prints per-epoch (or per-step) metrics as an aligned text table. No plots, no browser.

### Metric sources

| Source | Flag | Written by | Cadence | Always available? |
|--------|------|------------|---------|-------------------|
| CSV (default) | `--source csv` | `CSVMetricsCallback` in `train_baseline.py` | per-epoch | Yes |
| TensorBoard | `--source tensorboard` | TB event files (needs `experiment.enabled=true`) | per-step or per-epoch | Only if TB was enabled |

- **CSV** is written to `checkpoints/baseline/training_metrics.csv` (i.e. `<output.checkpoint_dir>/training_metrics.csv`).
- **TensorBoard** event files are written under `tb_logs/` (i.e. `<experiment.project_name>/`).

### Arguments

| Arg | Default | Meaning |
|-----|---------|---------|
| `--source` | `csv` | `csv` or `tensorboard`. |
| `--file` | `checkpoints/baseline/training_metrics.csv` | CSV path (source=csv). |
| `--logdir` | `tb_logs` | TensorBoard log dir (source=tensorboard). |
| `--granularity` | `step` | `step` (fine) or `epoch` (coarse). TensorBoard only. |
| `--follow` | off | Keep polling and print new rows as they appear. |
| `--interval` | `5.0` | Polling seconds when `--follow` is set. |
| `--stop-when-idle` | `0` | In `--follow`, auto-exit after N seconds with no new rows (`0` = never; use `Ctrl+C`). |

> `--follow` is an infinite loop by design. Exit with **Ctrl+C**, or set `--stop-when-idle`
> to a value comfortably longer than one epoch so it doesn't quit mid-training.

### Examples

```bash
# One-shot snapshot from the CSV (per-epoch)
python fraud/scripts/show_progress.py

# Live-follow the CSV, refresh every 10s
python fraud/scripts/show_progress.py --follow --interval 10

# TensorBoard, per-epoch table, auto-exit 30s after the last epoch
python fraud/scripts/show_progress.py --source tensorboard --granularity epoch \
    --follow --interval 10 --stop-when-idle 30

# TensorBoard, fine per-step view
python fraud/scripts/show_progress.py --source tensorboard --granularity step --follow
```

### Column notes

- `train_loss_0` / `valid_loss_0` are the per-target loss (target index 0); identical to the
  aggregate `train_loss` / `valid_loss` since there is a single target — ignore them.
- `*_accuracy` ~0.998 is just the majority-class rate (fraud ~0.15%); judge the model with
  PR-AUC / ROC-AUC from `score_eval.py`, not accuracy.

---

## 2. `score_eval.py` — score a model & write predictions

Loads a trained model + its saved imputer, streams an S3 parquet range **one file at a time**
(memory-safe), applies the same preprocessing as training, scores on GPU, and writes per-file
prediction parquet files. Optionally prints AP / AUROC over the range.

### Prerequisites

- A training run completed **after** the imputer-saving change, so these exist:
  - `checkpoints/baseline/` (the saved `TabularModel`)
  - `checkpoints/baseline/continuous_imputer.joblib`
- Config: `fraud/configs/eval.yaml`.

### Config keys (`eval.yaml`)

| Key | Meaning |
|-----|---------|
| `data.base` | S3 base for the parquet range to score. |
| `data.file_start` / `file_end` | Inclusive `part_N` range. |
| `data.target_col` | Label column (`frd_tag`). |
| `data.positive_label` | Raw value of the fraud class (`1`). |
| `data.id_cols` | Columns copied into the output (e.g. transaction + account id). |
| `data.amount_col` | Raw amount kept in the output (pre-imputation). |
| `preprocess.imputer_path` | Path to `continuous_imputer.joblib`. |
| `model.dir` | Directory of the saved model. |
| `output.base` | S3 prefix for per-file prediction parquet. |
| `output.compute_metrics` | If true, accumulate + print range AP / AUROC. |
| `s3.cred_path` | S3 credentials (GPU pod path). |

### Output

- One parquet per input file at `<output.base>/part_N.parquet`, containing:
  `id_cols…`, `frd_tag` (true), score (fraud probability), prediction, `transaction_amt`.
- These feed downstream threshold tuning, PR/ROC curves, and Spark metrics at scale —
  without re-running the model.

### Examples

```bash
# Score the range in eval.yaml (smoke: single file)
python fraud/scripts/score_eval.py --config fraud/configs/eval.yaml

# Override the file range on the CLI
python fraud/scripts/score_eval.py --config fraud/configs/eval.yaml \
    data.file_start=8000 data.file_end=8010

# Capture a log
python fraud/scripts/score_eval.py --config fraud/configs/eval.yaml \
    2>&1 | tee logs/score_$(date +%Y%m%d_%H%M%S).log
```

### What to look for

- `Scoring device: cuda | GPU: NVIDIA H200` and `GPU confirmed: model on cuda:0, … MB allocated`.
- One line per file written to `s3://…/predictions/baseline/part_N.parquet`.
- If `compute_metrics: true`: a final `Range metrics …` line — should match the training test
  metrics for the same file (parity check, confirms no preprocessing drift).

---

## Typical end-to-end workflow (GPU pod)

```bash
source ~/k016730/scripts/setup_gpu.sh
git pull

# 1) (once) build frozen preprocessing artifacts — CPU pod
#    python fraud/scripts/build_preprocessing_artifacts.py --config fraud/configs/preprocessing.yaml

# 2) train (writes model + imputer + CSV metrics; optional TensorBoard)
python fraud/scripts/train_streaming.py --config fraud/configs/streaming.yaml \
    training.max_epochs=2 experiment.enabled=true \
    2>&1 | tee logs/smoke_$(date +%Y%m%d_%H%M%S).log

# 2b) in a second terminal — watch progress
python fraud/scripts/show_progress.py --source tensorboard --granularity epoch --logdir tb_logs

# 3) score a parquet range -> predictions on S3
python fraud/scripts/score_streaming.py --config fraud/configs/streaming.yaml \
    2>&1 | tee logs/score_$(date +%Y%m%d_%H%M%S).log
```
