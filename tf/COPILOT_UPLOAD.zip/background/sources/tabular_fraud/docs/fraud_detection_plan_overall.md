# Tabular Fraud Detection — Project Plan

## Background

We evaluated multiple transformer-based models for tabular data on the UCI Bank Marketing dataset:

- **SAINT** (custom implementation): Test AUROC 0.822–0.851
- **FT-Transformer** (PyTorch Tabular): Test AUROC 0.935
- **CategoryEmbedding MLP** (PyTorch Tabular): Test AUROC 0.921

> FT-Transformer outperformed all others with better accuracy, faster training, no overfitting, and minimal configuration.
> See [benchmark_results.md](benchmark_results.md) for full details.

We are adopting **PyTorch Tabular with FT-Transformer** as the foundation for our fraud detection work.

## Problem Statement

> Our fraud detection system operates on **individual transaction records**. Each record has categorical features (merchant category, transaction type, etc.)
> and numerical features (amount, time since last transaction, etc.). The target is binary: fraud or not.

> We hypothesize that **historical transaction context** can improve fraud detection. A fraudulent transaction may look normal in isolation
> but suspicious when viewed alongside the account's recent transaction history.

## Goals

1. **Baseline model**: Train FT-Transformer on individual transactions using PyTorch Tabular
2. **Sequential model**: Develop a new model that combines historical transactions with the target transaction, using separation tokens, to capture temporal patterns
3. **Data pipeline**: Build a streaming data loader for large-scale parquet files stored in S3 buckets

## Why Fork PyTorch Tabular

The baseline (Goal 1) could work with PyTorch Tabular as a pip dependency. However, the sequential model (Goal 2) requires modifications to core components that cannot be achieved through configuration or subclassing:

| Component | Current behavior | Required change |
|-----------|------------------|-----------------|
| `FTTransformerBackbone` | Single row → feature tokens → transformer | Sequence of rows → feature tokens + SEP tokens → transformer |
| `Tokenizer` / `Embedding2dLayer` | Embeds one transaction's features | Must embed multiple transactions and insert SEP/CLS tokens |
| `TabularDatamodule` | One row = one sample | One sample = target transaction + N historical transactions |
| Attention masking | None (all tokens attend to all) | Optional causal mask (target attends to history, not reverse) |
| Input shape | `(batch, num_features)` | `(batch, num_transactions × num_features + sep_tokens)` |
| Data loading | Loads full DataFrame into memory | Must stream from S3 parquet files, group by account |

These changes touch the model architecture, data pipeline, and training loop — too deep for plugin-style extension.

## Architecture

### Baseline: Individual Transaction FT-Transformer

Standard FT-Transformer as provided by PyTorch Tabular:

```
[feature_1] [feature_2] ... [feature_N] [CLS]
     ↓           ↓             ↓       ↓
 embedding   embedding     embedding  CLS token
     ↓────────────────────────────────↓
              Transformer Encoder
                       ↓
              CLS → Linear → fraud/not-fraud
```

### Sequential: History-Aware FT-Transformer

New model that concatenates tokenized historical transactions with the target transaction:

```
[TX_hist_1 features] [SEP] [TX_hist_2 features] [SEP] ... [SEP] [TX_target features] [CLS]
        ↓                 ↓             ↓                 ↓             ↓                 ↓
   FT embedding      SEP token    FT embedding    SEP token    FT embedding    CLS token
        ↓───────────────────────────────────────────────────────────────────────
                              Transformer Encoder (with optional causal mask)
                                                   ↓
                                           CLS → Linear → fraud/not-fraud
```

Key design decisions:
- **SEP tokens** separate transactions so the model can distinguish boundaries
- **CLS token** at the end aggregates information for classification
- **Positional encoding** indicates temporal order of transactions (most recent last)
- **Optional causal masking** allows the target transaction to attend to history but not vice versa
- **Variable-length history** handled via padding and attention masks
- **Max history length** configurable (e.g., last 10 transactions)

# Data Pipeline

## Challenge
- Training data is large (millions of transactions), stored as multiple parquet files in S3
- Cannot fit entire dataset in memory
- For the sequential model, need to group transactions by account and order by time

### Approach
- **S3 streaming**: Use `s3fs` + `pyarrow` to read parquet files without full download
- **IterableDataset**: Stream data file-by-file, yielding batches
- **Account grouping**: For sequential model, pre-sort data by account + timestamp, or maintain an index mapping account → file/row offsets
- **Multi-worker**: Split files across DataLoader workers to avoid duplication

## Project Structure

```
tabular_fraud/
├── src/
│   └── pytorch_tabular/           # forked from pytorch_tabular (existing code)
│       ├── models/
│       │   ├── ft_transformer/    # existing FT-Transformer
│       │   └── ft_transformer_seq/  # NEW: sequential FT-Transformer
│       ├── tabular_datamodule.py  # existing
│       └── ...
├── fraud/                         # our custom code
│   ├── data/
│   │   ├── parquet_loader.py      # S3 parquet streaming IterableDataset
│   │   └── sequence_builder.py    # groups transactions by account, builds sequences
│   ├── configs/
│   │   ├── smoke_test.yaml        # individual transaction config
│   │   └── sequential.yaml        # history-aware config
│   └── scripts/
│       ├── train_baseline.py      # train individual transaction model
│       ├── train_sequential.py    # train history-aware model
│       └── evaluate.py            # compare models
├── tests/
├── docs/
├── requirements.txt
├── pyproject.toml
└── README.md
```

## Implementation Phases

### Phase 1: Baseline
- Fork PyTorch Tabular
- Build S3 parquet streaming data loader
- Train FT-Transformer on individual transactions
- Establish baseline AUROC on fraud detection dataset

### Phase 2: Sequential Model
- Implement `FTTransformerSeqBackbone` with SEP/CLS token support
- Implement sequence builder (account grouping, history windowing)
- Implement attention masking for variable-length sequences
- Train and compare against baseline

### Phase 3: Optimization
- Hyperparameter tuning
- Experiment with history length, masking strategies
- Scale to full dataset
- Production deployment considerations

## Open Questions

1. **Max history length**: How many past transactions to include? (5? 10? 20?)
2. **History features**: Same features as target transaction, or a reduced set?
3. **Time encoding**: How to represent time gaps between transactions? (Separate feature? Positional encoding?)
4. **Data partitioning**: How are parquet files organized in S3? (By date? By account? Random?)
5. **Inference latency**: For real-time fraud detection, how fast does the sequential model need to be?
