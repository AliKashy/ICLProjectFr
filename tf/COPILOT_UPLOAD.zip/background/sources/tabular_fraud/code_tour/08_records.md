# Chapter 08: the records and which documents to read

This chapter covers the non-code folders: `bridge/`, `chatgpt/`, `claude/`, `explainer/`, `guide/`, `business_guides/`, `reconstruction/`, `Update Overview/`, the three update folders, Yaqun's `docs/`, and the record folders inside `waqas/`. None of them is run by the pod. They are records, plans and explanations. Words are in the glossary in [README.md](README.md#glossary).

## Read these ten, in this order

| # | Document | Why | Time |
|---|---|---|---|
| 1 | `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html`, sections 02 to 06 (lines 115-260) | The best single current overview: the story, the data splits, the model, what won, why the comparison is trusted | 45 min |
| 2 | `explainer/04_HOW_THE_MODEL_WORKS.md` (lines 8-128) | Raw file to tokens to Arch A and B to AP, with a reason for each step | 45 min |
| 3 | `bridge/OWNER_QA.md` lines 120-440 | Your own answers of 10-26 to 10-28: chunk versus sliding, model names, month, seed study closed, D-012 | 45 min |
| 4 | `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md` | The seed check, the chosen model's full specification, the data sets, the features to add, the embedding export | 45 min |
| 5 | `explainer/11_V1_RESULTS.md` | V1's 15 runs, and why "not resolved" is not "tied" | 20 min |
| 6 | `updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md` | The main source on what code the pod runs today, the patches and the L3 results | 1 h |
| 7 | `updates_10_23_2026/Seed_results.md` | Seeds 43 and 44, and the population-scope corrections | 30 min |
| 8 | `bridge/reviews/CL/2026-10-24-results-l3-seeds/README.md` | The checked reading of the 10-23 upload, its inconsistencies, what is still owed | 20 min |
| 9 | `bridge/plans/CL/2026-10-24-roadmap/ROADMAP.md`, with `bridge/DECISIONS.md` lines 176-181 (D-012) | What comes next | 20 min |
| 10 | `bridge/plans/CL/2026-10-27-pod-cleanup/README.md` | What is on the pod and the proposed layout | 20 min |

Runners-up: `updates_10_23_2026/M01_V2_results__through_l3.part_1.md` (data facts and frozen populations) and `updates_week_10-14-2026/current_new_architectures/ARCHITECTURE_RUNS.md` (summary of the V1 architectures).

Skip unless you are auditing history: `chatgpt/`, `claude/`, the results parts of `guide/`, `business_guides/`, `reconstruction/`, `Update Overview/`, and in `bridge/`: `audits/`, `assurance/`, `overnight/`, `communication/`, `baseline/`, `tools/`, `buildouts/`, `proposals/`, `evidence/`, threads 000 to 008, `memory/`, `reviews/REGISTER/`, and explainer chapters 07 to 10.

---

## `bridge/`: the coordination folder

Written by Claude (CL) and ChatGPT/Codex (CH), mostly append-only under `bridge/PROTOCOL.md`. 2,720 files in git. Your words are copied verbatim into `bridge/OWNER_QA.md`.

### `bridge/OWNER_QA.md`

- **What it is:** the one list of open questions for you, with your answers copied word for word and the recorder named. 2,567 lines, newest first in section B. Your answers are binding instructions to both assistants.
- **Look at:** rules (5-16); section A, mostly closed (18-117); section B from line 118: 120-126 (10-28: learn the whole project, this code tour); 136-151 (10-27 month: no separate test, the next model drops month and keeps the time gap; pod clean-up first); 161-172 (D-012 embedding uses); 174-235 (pod reorganisation rules, with two short notes on Gemini and Codex); 329-368 (your chunk versus sliding questions and the answers: chunks of 21, history 0 to 20 restarting, scoring identical); 398-407 (seed test closed; month not removed, per the 10-26 view); 409-415 (provenance of 0.0955 never verified); 417-427 (names "Arch B H20 sliding" and "Arch B H20 chunk"); 1952 (section C, earlier answers still in force); 1973 (section D, what Yaqun's docs answer).
- **Read:** the 10-19 to 10-28 entries.

### `bridge/DECISIONS.md`

- **What it is:** the append-only decision log. A decision binds only with both assistants' acknowledgement; several ChatGPT slots are blank. The latest entries are yours: D-010 (Gemini), D-011 (Gemini withdrawn), D-012 (embedding uses).
- **Look at:** D-001 protocol (3-8); D-004 fix first (39-51); D-008 one Q&A file (115-127); D-006 run protocol (129-144); D-009 joint roadmap, still "proposed" (146-152); D-010 and D-011 (155-174); **D-012** (176-181): transaction-level XGBoost, the 15298 offset model, a correlation check; the 14-day account-level use is withdrawn.
- **Note:** `runbook/v2/DECISIONS.md` (commit `60232e9`) is a separate V2 rule file (chapter 05).

### `bridge/PROTOCOL.md`

- The working agreement between the two assistants. You need only section 1: who owns what (8-15): `claude/` and `chatgpt/` frozen, `bridge/` append-only, code goes live only through a pull request the other assistant has reviewed and you merge, or through you applying it on the pod yourself. No secrets or bank data (66-67).

### `bridge/STATUS.md`

- One section per assistant. Claude's stops at 2026-10-11 (line 5) and is stale. ChatGPT's is current to 10-27 (line 22): pod clean-up first; keep the V1, L3 and seed bundles and the patch evidence; the original package 009 must not overwrite the patched source; the seed study is closed and H20 chunk goes forward; automatic month removal is not current.

### `bridge/threads/`

- Ten topic threads. 000 to 008 (10-05 to 10-07) cover kickoff, the guide, the first code review, plan 1.0, handoff. `000-kickoff.md` lines 3-12 list the eight first audit findings: sharding, SupCon, the CLS causal leak, EMA, packaging, the evaluation range, prediction overwrite, override precedence. **Read 009 only:** `009-pod-reorganization.md` (10-27), the clean-up plan and versions 2 and 3 of `organize_pod.py`.

### `bridge/plans/`

- Dated plan folders: CL (14), CH (17), and the shared V2 plan. Only the CL folders of 10-24 to 10-27 describe the current state.
- `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html`: the 10-25 briefing for your meeting with senior quants. Story (115-139), problem and splits (142-164), model (167-205: 30 tokens of width 48, transaction encoder 2 blocks, sequence encoder 4 blocks with a strict time mask, windows of 20 earlier timestamps capped at 32 rows, 171,506 weights; chunk training versus scoring; family tree), what was tested (208-247), why the comparison is trusted (250-260), limits (263-275), next steps (278-293), hard questions (296-341), glossary and numbers (344-377). **Outdated parts:** step 2 "Remove month" as its own test, and the 14-day account XGBoost; both were superseded on 10-27. The folder also holds `qa_ml.md`, `qa_risk.md`, `qa_stats.md`.
- `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md`: your weekly presentation: summary (5-20); seed table (22-54); why chunk (56-68: the same model trained sliding scored 0.0743, difference +0.028 [0.017, 0.038]); specification (70-84); data sets (86-111); features to add: 23 today plus 90 from TFM V22B plus 60 from 15298 plus 16 built, with 7 status fields left out (113-147); appendices with feature lists (167-405); embedding export and the three uses (406-437). **Conflict:** line 119 lists month as a kept input, while `bridge/OWNER_QA.md` line 150 says the next model drops it. A public copy was published and then deleted (`bridge/OWNER_QA.md` lines 293-307).
- `bridge/plans/CL/2026-10-24-roadmap/ROADMAP.md`: the road from the winning model to production, as numbered steps 0 to 8 (21-31): step 0 closes stage 2 (the seed stage); step 1 is the code of record and package 010 (adopt the three pod patches byte for byte); step 2 is stage 3, the no-month test, superseded on 10-27 (line 25); then features (stage 4), scale to 100 files (stage 5), embeddings and the feature store, input certification, freeze, FINAL and BENCH, handover. Open for you: importance method, code appendix, patch receipts, the pod's real `fraud/` and `src/` (50-55).
- `bridge/plans/CL/2026-10-27-pod-cleanup/`: chapter 06.
- `bridge/plans/CH/2026-10-27-pod-cleanup/README.md`: ChatGPT's 8 inventory findings (7-14), including the three patched files `train_v2.py`, `models.py`, `select_splits.py` (item 7).
- `bridge/plans/2026-10-19-v2-one-gpu/PLAN.md`: the V2 governing plan, version 6.2 (line 3). Your words: one GPU, no post-run experiments, test chunk at H5 and H20 (13-17). Line 25: every new fit without month, which the pod did not follow. Line 26: post-hoc sliding rescoring out of scope. **Status:** partly superseded; after L3 the programme follows your 10-22 order and the roadmap.

### `bridge/reviews/`

- Reviews by CL (17 folders) and CH (38), the ranked register (`REGISTER/`, version 2.1, 104 findings from 10-09), and an independent auditor (`AUDIT/`, 10-14).
- **Read:** `bridge/reviews/CL/2026-10-24-results-l3-seeds/README.md`: the upload is screenshot transcriptions (3); three-seed DEV_OOT table (9-19); 4,213 batches equal 2,107 updates at accumulation 2 (20-24); the patched `models.py` routes every V1 strict chunk batch to V1's training step (27-30); `make_v2_contracts.py` line 397 refuses month (32-35); inconsistencies in the upload (37-46); next steps, including a reviewed pull request of the three pod patches and the pod's real `fraud/` and `src/`, 58 files differing (48-67); what is needed from you (69-76).
- Also useful: `bridge/reviews/CL/2026-10-21-pkg009-gate/GATE.md` (the package 009 gate), `bridge/reviews/CL/2026-10-13-v1-results-audit/AUDIT.md` (the V1 audit behind `explainer/11`), `bridge/reviews/CL/2026-10-20-end-to-end/COVERAGE.md` (V2 end-to-end coverage).

### `bridge/memory/`

- Each assistant's continuity notes (CL, CH, AUDIT). Not for you. `CL/START_HERE.md` lines 74-79 explain that every comment shows the same GitHub account (yours). Authors are told apart by content: Claude's comments end with a "Generated by Claude Code" line, and each assistant marks its commits in its own way.

### `bridge/releases/`

- Every package sent to the pod. See chapter 06. The READMEs hold private install values; never copy them anywhere public.

### The rest of `bridge/` (history)

| Folder or file | What | Status |
|---|---|---|
| `bridge/evidence/` | Captured outputs of 10-05 to 10-11 (harness runs, your answers, stage 1) | Record |
| `bridge/assist/` | The 10-19 assist team (research pair, audit pair, features session), their logs, the feature catalogue. `features/CATALOGUE.md` and `catalogue.csv` (F1 to F23) still feed the roadmap's feature step | Record |
| `bridge/assurance/` | Reports of five reviewer sessions and one judge session (10-09 and 10-10) that fed register 2.1 | Record |
| `bridge/audits/` | The 10-05 to 10-07 mutual audits and reviews | Record |
| `bridge/errata/` | Corrections to the frozen `claude/` and `chatgpt/` folders. E-001: sweep evaluations used one file, part 8000, not 11 | Record |
| `bridge/overnight/`, `bridge/communication/` | Overnight message files of 10-07 to 10-09 and the channel rules | Record |
| `bridge/baseline/`, `bridge/tools/` | The 10-09 baseline: your own latest uploads with assistant edits left out (branch `baseline/waqas-uploads-2026-10-09`), and the tools that build it | Record |
| `bridge/buildouts/`, `bridge/proposals/` | ChatGPT's runtime candidate of 10-07 (later moved into `waqas/base`) and early patch proposals | Record |
| `bridge/RUN_PROTOCOL.md`, `REQUIREMENTS_TO_EVIDENCE.md`, `CHANGES_2026-10-06_to_10-08.md`, `OPERATING_MODEL.md`, `WORKBOARD.md`, `JOINT_PLAN.md`, `ASK_WAQAS.md`, `ONBOARDING_PROMPTS.md`, `PROJECT_MAP_2026-10-07.md` | V1-preparation documents. `RUN_PROTOCOL.md` version 2.2 governed V1 runs. `JOINT_PLAN.md` still lists no agreed item ("none agreed yet"). `ASK_WAQAS.md` is replaced by `OWNER_QA.md` | Superseded |

---

## `updates_10_23_2026/`: the V2 pod results

Your 10-23 upload. Transcriptions of pod screenshots, written by your work-laptop Copilot and pod sessions. The only record of what the pod ran in V2.

### `updates_10_23_2026/00_REVIEWER_DELIVERY_INDEX.md`

- The send list: completed versus configured work (15-43), documentation list (51-60), pod tools and patches (64-78), what was running and the seed command (80-102).
- **Watch out:** the listed `pod_tools/`, `patches/` and numbered documents are not in the repository, and its "no seed result yet" is outdated by `Seed_results.md`.

### `updates_10_23_2026/M01_V2_results__through_l3.part_1.md`

- Install of package 009 (37-58), data look (59-115), quick checks (116-203), V1 recomputation and all-position by chunk position (204-290), the DS_TRAIN patch (293-323), frozen populations (388-412), data facts (443-460), L3 setup (461-487; line 484: V1 predictors and artifact version 1, with month).

### `updates_10_23_2026/M01_V2_results__through_l3.part_2_and_3.md`

- The two training patches (3-19); H20-SLIDE results (21-125); the change ledger with patch 3 (127-212); H20-CHUNK (214-235); H5-SLIDE (237-256); the full leaderboard and reading (258-291); Arch A rescoring (293-338); pod tools (430-448) and paths (450-495); package 009 audit and runtime patches (520-577); completed versus pending (594-606); data contract (608-653); seed setup (665-686); open items (687 on).
- **Watch out:** `part_2.md` and `part_3.md` are contained in this file (lines 1-502 equal part 2; from line 486 it equals part 3). Read this one only, and do not count results twice.

### `updates_10_23_2026/Seed_results.md`

- Seeds 43 and 44 for B-H20 and ALLPOS-H20-CHUNK, all complete. Corrections (27-32); population rules (34-42); all six H20 results (44-54); DEV_OOT ranking (56-74); three-seed means (76-83); SELECT and Arch A tables (85-153); evidence identities (154 on). Written to you by an unnamed assistant.

---

## The two 10-14 update folders

### `updates week_10-14-2026/` (with a space)

- Your laptop Copilot record of 2026-10-14, marked "All updates are proposals made from github copilot", transcribed from 195 screenshots.
- `updates 10-14-2026/readme.md`: scope (3-14); Yaqun's untouched copy and its audit (36-46); a correction to the V1 report (48-57: Yaqun did score history 5 on 8000-8010); why a sliding experiment (99-110); the bank's models compared on the out-of-time benchmark set (243-253: TFM, LOB XGBoost and the offset model); data facts (554-594); lessons from other teams (595-699); cross-team emails, including the feature-store direction (700-849, especially 808).
- **Status:** record. Useful for business context.

### `updates_week_10-14-2026/` (with underscores)

- `Updates 10-15-2026/readme.md`: the Copilot handoff (1-12, 38-45). `complete_reviewer_context.md` (line 26: the authoritative delta). `V2_execution_plan_proposal.md` (the lean plan of 10-16, superseded by PLAN 6.2). `allpos_h5_sliding_runbook.md`. `architecture_run_inputs.py`: a reference list, "not a launcher" (1-5); data contract (13-22).
- `Updates 10-15-2026/allpos_sliding_experiment.py`: rescored V1's B-ALLPOS-H5 checkpoint on sliding windows without retraining. It ran once on the pod around 10-19: AP 0.093420 against 0.092670 on chunks (`bridge/OWNER_QA.md` lines 909-919). Its test file has 18 tests. **Status:** superseded (PLAN 6.2 line 26 puts post-hoc rescoring out of scope).
- `current_new_architectures/ARCHITECTURE_RUNS.md`: a compact summary of the V1 architectures and their results (evaluation contract 6-15; REF-SINGLE 18-32, Arch A 33-57, Arch B 58-87, B-ALLPOS-H5 88-116).
- **Watch out:** the data bucket name in `architecture_run_inputs.py` line 14 differs from the one in other records. Do not copy paths from photographed files without checking.

---

## `explainer/`: the plain-English explainer

Written 10-12 to 10-14 by a separate Claude session ("Project explainer E1"). Reading order and times in `explainer/README.md` lines 15-29.

| File | Still right? |
|---|---|
| `01_ONE_PAGE.md` | Lines 3-21 yes; the "latest" paragraph at line 23 is outdated |
| `02_GLOSSARY.md` | Yes as background (23 features including month, line 22; all-position B, line 91) |
| `03_STORY_SO_FAR.md` | Yes up to 10-13 |
| `04_HOW_THE_MODEL_WORKS.md` | Yes, the clearest basic explanation. Outdated only on all-position at H5 (81-82) and the result table. Line 99 says the learning rate halves "after 3 epochs"; the code acts on the 4th epoch without improvement |
| `05_CHANGES_FROM_YAKUN.md` | Yes (15-97) |
| `06_V1_STUDY.md` | Yes (the 15 runs, 30-47) |
| `07` | Outdated: packages 004 to 006 only (63-94, 142) |
| `08` | Outdated: decisions to 10-14 only |
| `09` | Outdated: the 10-12 team (6-35) |
| `10_WHATS_NEXT.md` | Fully outdated |
| `11_V1_RESULTS.md` | Yes, the right V1 record. B-H15 and B-H20 remain provisional |
| `CHANGE_JOURNAL.md` | Stops at 10-14 |

- **Watch out:** the explainer cites `OWNER_QA.md` line numbers at commit `160fd51` (README line 37). New answers are added near the top, so today's lines differ. To open the old version, run `git show 160fd51:bridge/OWNER_QA.md` from the top folder of your clone, or open `https://github.com/AliKashy/tabular_fraud/blob/160fd519062787b18cd9133286f915b34a12947f/bridge/OWNER_QA.md`.
- **Neither the explainer nor the guide knows the V2 outcome.**

---

## `guide/`: the learning guide

- Written 10-05 to 10-07 for the 10-06 quant meeting. Claude wrote all ten parts (each part names its author at the top); ChatGPT reviewed them in `bridge/threads/001-guide.md`.
- **Still good basics:** `guide/parts/01_foundations.md` (a model 12, training 57, overfitting 81, why accuracy is useless 109, PR-AUC and ROC-AUC 148, how sure a number is 184, weighting, calibration and leakage 224, the XGBoost baseline 258) and `guide/parts/02_neural_nets_and_transformers.md` (embeddings 27, attention 53, CLS and head 85, FT-Transformer 99, history tokens, positions and masks 129, a GPU run 155, optimizer and learning rate 194). `guide/parts/03_data_and_yakun_pipeline.md` (the data and Yaqun's pipeline) and `guide/parts/09_glossary.md` (the glossary) also carry no "superseded" mark and are still useful background. One claim in part 03 (lines 63-66, which fields are most often missing) is qualified by a later ChatGPT review (`bridge/reviews/CH/2026-10-12-run001-part2/README.md` line 71).
- **Outdated:** result numbers from before the bug fixes, one seed, one evaluation file (`GUIDE.md` marks them at lines 71, 1017 and 1680); Phase 5 (parked); histories 5, 10, 16; the result table in part 00 (line 50) and parts 04 to 08.
- **Status:** superseded as a project description.

## `business_guides/`

- Two business-use guides of 10-05, one by ChatGPT (`business_guides/chatgpt/README.md`), one by Claude (`business_guides/claude/README.md`). Purpose: better alert ranking against the production XGBoost. Numbers are from before the fixes. Replaced by the weekly and the briefing. **Status:** superseded.

## `chatgpt/` and `claude/`

- Each assistant's independent audit of commit `8431f30` on 10-05. Frozen.
- `chatgpt/AUDIT.md` lines 19-98: top findings: worker file sharding, reproducibility, SupCon pairs, masked self-supervision, evaluation on 1 file instead of 11, prediction overwrite.
- `claude/AUDIT_FINDINGS_claude.md`: verdict (lines 16-35) and 28 findings C-01 to C-28 (table at lines 44-71); `claude/README_claude.md` lines 21-33: the patch table (sharding, the causal CLS leak, EMA, SupCon, packaging, the ablation runner).
- Their findings were fixed in `waqas/base` and the V1 code. **Status:** record.

## `reconstruction/`

- Metadata of the AI worker that rebuilt source files from your Dropbox photos (10-02 to 10-07): instructions (`WORKER.md` 1-25), status (`STATUS.md` 3-11: recovery of docs, notebooks and seven source groups unfinished), handoff (`HANDOFF.md`), queue and run evidence.
- **Why it matters:** it explains why main's `fraud/` and many `waqas/` files are photo transcriptions (main's `src/pytorch_tabular/` is not: it is the library's public 1.1.0 source, commits `6650d40` and `f126860`), and why errors like the one-underscore file name could exist anywhere. **Status:** record.

## `Update Overview/`

- `Changes Made - 2026-10-06 11-02 AM ET.md`: a Copilot write-up of the 10-06 fixes in phase4a and phase4b: sharding with a fixed seed (13-21), the CLS mask leak and padding NaN (23-36), EMA (38-40), and the decision to use AdamW only. `fraud/` was not modified. `bridge/OWNER_QA.md` line 59 (question OQ-12 b) asks whether it counts as yours. **Status:** record.

---

## Yaqun's `docs/`

| File | What | Status |
|---|---|---|
| `docs/fraud_detection_plan_overall.md` | The overall plan: baseline, history model, streaming loader; "Why Fork" (30-43) | Docs. The fork reasoning does not match the code: the history model is plain PyTorch, and the fork is used only by the single-transaction path |
| `docs/fraud_detection_plan_detailed.md` | Label, keys, the 23 predictors (28-75), missing-value and datetime decisions, artifact layout with UNK 0 and MISSING 1 (101-117), the 2026-09-03 smoke results (135-158) | Docs |
| `docs/phase3_streaming_plan.md` | Streaming design and results: hand-built settings, frozen artifacts, whole-stream `valid_ap`, row shuffling fixing a collapse at batch 512; the model trained on 100 files scored AUROC 0.9514 and AP 0.0940 on evaluation files 8000-8010 (21-37); "Why not TabularModel.fit" (48-50) | Docs |
| `docs/phase4_design_decisions.md` | The Phase 4 decision log of 2026-09-25 (7-18): flat model first, no past fraud labels as inputs, history 5, stride 1, never skip fraud, time gap, left pad plus mask, bidirectional by default, each account in one file (20-25) | Docs. Read it: it is the basis of phase4a and phase4b |
| `docs/phase4_sequential_plan.md` | Detailed Phase 4 plan: samples, Arch A (81-122), Arch B (124-153), memory (215-236), open items, an early result (287-296: `valid_ap` 0.1293 versus 0.1247 single-transaction) | Docs. Line 8 "planning, no code yet" is stale |
| `docs/monitoring_and_eval.md` | How to use `show_progress.py` and `score_eval.py`, and the GPU workflow (128-148) | Docs |
| `docs/tabular_transformer_models.md` | A model comparison on a public bank-marketing dataset (not bank fraud data): FT-Transformer ahead, no tuning | Docs (background for choosing FT-Transformer) |

- **Watch out:** `README.md` links a plan under `../saint/`, and the overall plan links a `benchmark_results.md`; both links are broken.

## Record folders inside `waqas/`

| Folder or file | What | Status |
|---|---|---|
| `waqas/results_from_pod/v1_results_2026-10-13/` | The V1 record: `V1_COMPLETE_REPORT.md` (cohort 27-35, features and gaps 41-66, model families 72-97, roster 103-119, deviations 142-159, results 166-194), `reviewer_update_v1/README.md` (results in brief 18-28, points needing attention 30-42), `reviewer_update_v1/analysis_outputs/RUNS.md`, and four helper scripts used for the V1 analysis (`reviewer_update_v1/runbook/2026-10-07/`) | Record. B-H20 here is the V2 reference |
| `waqas/docs/` | `waqas_roadmap.md`, `waqas_current_standing.md`, `waqas_phase4a_guide.md`, `waqas_phase4b_guide.md`, `waqas_phase5_guide.md`, `meeting_notes.md`, from 10-03 to 10-06, before the fixes. `meeting_notes.md` has feature ideas (target encoding, days-since and delta features) | Record, stale. `waqas_phase4b_guide.md` line 17 ("h10/h16 run at full batch 4096") conflicts with the note in `waqas/phase4b/configs/ft_decisions_hier_h16.yaml` (lines 6-12): at batch 4096, history 15 and longer hit a hard GPU (CUDA) limit, so those runs use batch 2048; `waqas_phase5_guide.md` (lines 15-23) points to `waqas/phase5_pretrain/`, which is no longer in the repository. `CHANGES_TO_UPLOAD.txt` lines 200-209 says these were deleted, but they are still on main |
| `waqas/feature_related/`, `waqas/feature_work/`, `waqas/features/feature_importance_v22_v17_highlighted/` | Photo reconstructions of the feature metadata workbook, the master feature index, and the V22B feature-importance top 120 | Record. Not code; inputs to the feature plan |
| `waqas/additional_info/` | Transcribed emails: data paths and dates (`waqas/additional_info/data_path_information_email/data_path_information_email.md` lines 18-24) and a warning that features built from downsampled data are biased (`waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md` lines 9-27) | Record |
| `waqas/CHANGES_TO_UPLOAD.txt` | Your 10-08 change and upload log; Claude added lines on the B9 change on 10-12 (commit `0b269eb`). Lines 104-109 say `build_leaderboard.py` ranks by evaluation AP; the code ranks by validation AP | Record |

---

## The month story, in one place

The documents disagree about month because the decision moved:

1. The explainer (10-14) treats month as a known V1 limit that "moves to V2" (`explainer/04` line 36, `explainer/05` line 92).
2. PLAN 6.2 (`bridge/plans/2026-10-19-v2-one-gpu/PLAN.md` line 25): every V2 fit without month.
3. The pod's L3 fits ran **with** month (`M01 part_1` line 484). The no-month artifact was never built.
4. The 10-25 briefing still plans a separate "Remove month" test (lines 265, 283 and 291).
5. Your answer of 10-26: "i dont think we're removing month" (`bridge/OWNER_QA.md` line 403).
6. Your answer of 10-27: no separate no-month test; the next model (the v2 feature model) drops month and keeps the time gap (`bridge/OWNER_QA.md` lines 136-151; `ROADMAP.md` line 25).
7. The weekly (line 119) still lists month as a kept input.
8. The V2 handover code refuses month (`waqas/v2/scripts/make_v2_contracts.py` line 397, per the 10-24 review).

The latest instruction is step 6.

## Pitfalls when reading records

- The repository is not exactly what runs on the pod: main's `fraud/` is a photo transcription, `src/` is the library's public 1.1.0 source rather than the pod's own copy, and a review says 58 files in `fraud/` and `src/` differ from the pod's.
- The update files are screenshot transcriptions; some hashes are quoted differently in different sections.
- Do not average SELECT across seeds (June-only for seed 42, full files for 43 and 44). DEV_OOT is the comparable population.
- Names collide: "Arch B H20 sliding" is V1 B-H20; "ALLPOS-H20-SLIDE" (also written "H20-SLIDE") is the chunk design trained on sliding windows; "Arch B H20 chunk" is ALLPOS-H20-CHUNK.
- Status pages go stale: Claude's `bridge/STATUS.md` section stops at 10-11, and `bridge/JOINT_PLAN.md` lists no agreed item. Use `OWNER_QA.md` section B and the dated CL plans.
- Copilot material in `Update Overview/` and the 10-14 folders calls itself proposals needing audit, and says "reviewer" when it means the assistants.

## Check yourself

1. Which single document gives the best current overview?
   Answer: `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html`, sections 02 to 06, skipping the outdated "Remove month" step.
2. Where are your own decisions recorded, and are they binding?
   Answer: in `bridge/OWNER_QA.md` section B, word for word. Yes, they are binding instructions to both assistants.
3. Which explainer chapters are still right?
   Answer: 01 (most of it) to 06, and 11. Chapters 07 to 10 predate V2.
4. What is the latest instruction on month?
   Answer: your 10-27 answer: no separate no-month test; the next model drops month and keeps the time gap.
5. Should you read `M01_V2_results__through_l3.part_2.md` and `part_3.md`?
   Answer: no. `part_2_and_3.md` contains both; read only that one.
