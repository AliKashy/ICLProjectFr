# Code tour: start here

This tour walks through every folder and code file in the repository `AliKashy/tabular_fraud`. It is written for you, the project owner. You do not need to be a programmer to follow it. Every technical word is explained in the glossary further down this file. Each chapter ends with "check yourself" questions.

The tour was written by reading the code and the records of every folder. Each fact was then checked against the code. Where the records disagree, or a fact could not be settled, the tour says so. It does not guess.

## The short answer: where do I start?

1. Learn the words first. Read the glossary below (45 minutes).
2. Read the big picture in plain English: `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html`, sections 02 to 06 (lines 115-260), then `explainer/04_HOW_THE_MODEL_WORKS.md`.
3. Read chapter 01 to learn what each top-level folder holds.
4. Then read the code in the order the data flows: raw files, then features, then history windows, then the model, then training, then scoring, then comparison. Chapters 02, 03 and 04 follow that order.
5. Then read the rest of the V2 tools and what actually ran (chapter 05), and how code reaches the pod and how results come back (chapter 06).
6. Then read what the tests prove (chapter 07).
7. Leave the records (chapter 08) for last. Most of them are history.

## Reading order with time estimates

Times assume you read the chapter and open the code it points to. They are estimates, not measurements.

| Step | What to read | Time | What you should know after it |
|---|---|---|---|
| 0 | This README, especially the glossary | 45 min | The words used everywhere else |
| 1 | `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html` lines 115-260 | 45 min | The story: what was tested and what won |
| 2 | `explainer/04_HOW_THE_MODEL_WORKS.md` lines 8-128 | 45 min | Raw file to tokens to Arch A and B to AP |
| 2b | Only if the basics are new: `guide/parts/01_foundations.md` and `guide/parts/02_neural_nets_and_transformers.md` | 2 h | What a model, training, attention and PR-AUC are |
| 3 | [01_folders.md](01_folders.md) | 30 min | What every top-level folder holds, live or historical |
| 4 | [02_data_pipeline.md](02_data_pipeline.md) with the code | 3 to 4 h | How raw parquet becomes model inputs |
| 5 | [03_models.md](03_models.md) with the code | 4 to 5 h | The bundled library model, the single-transaction model, Arch A, Arch B, all-position, the V2 subclass, chunk versus sliding |
| 6 | [04_training_scoring.md](04_training_scoring.md) with the code | 3 to 4 h | How models are trained, validated, scored and compared by AP, in V1 and V2 |
| 7 | [05_v2_tools.md](05_v2_tools.md) | 3 h | The rest of V2 in run order, and what actually ran |
| 8 | [06_runs_and_pod.md](06_runs_and_pod.md) | 2 h | Packages, installer, runbooks, pod folders, clean-up, how results come back |
| 9 | [07_tests.md](07_tests.md) | 1 to 2 h | What the tests prove and how to run them |
| 10 | [08_records.md](08_records.md) and the ten documents it lists | 1 h plus reading | Which non-code documents matter |

Total: about 25 to 30 hours. Spread it over two weeks. Do steps 4 to 6 of this table (chapters 02 to 04) with the code open beside the chapter.

## Every top-level folder on one screen

"Read" means read it with this tour. "Skim" means look at the parts named. "Skip" means history you can ignore unless you are auditing.

| Folder or file | What it holds | Advice | Why |
|---|---|---|---|
| `fraud/` | Yaqun's original package, rebuilt from photos | Read | Its data layer (files, features, artifacts, datetime, AP callback) still runs on the pod |
| `src/pytorch_tabular/` | A bundled copy of the pytorch_tabular library, version 1.1.0 | Skim | Only the V1 single-transaction model used it. Read only `models/ft_transformer/`, `models/base_model.py`, `config/config.py` |
| `tests/` | One test file for Yaqun's data layer | Read | Short runnable examples of the preprocessing rules |
| `scripts/` | One maintenance tool | Skip | Never runs on the pod |
| `notebooks/` | Yaqun's data look and two check notebooks | Skim | Background on the data and the history windows |
| `docs/` | Yaqun's plans and design decisions | Skim | `docs/phase4_design_decisions.md` explains the history-window choices |
| `waqas/` | Your package: Arch A, Arch B, corrected copies, scoring, tests | Read | Holds the V2 model core that runs on the pod |
| `waqas/v2/` (not on main) | The V2 layer: trainer, scorer, step-1 tools, analysis | Read | Runs on the pod today. Open it from commit `60232e9` |
| `runbook/2026-10-07/` | The V1 launch harness | Skim | How V1 ran. `paired_report.py`, `analysis_runs.py` and `collect_returns.py` are still loaded by V2 tools |
| `runbook/2026-10-19/`, `runbook/v2/` (not on main) | V2 quick checks and the V2 runbook | Read | The V2 steps in order. Open from commit `60232e9` |
| `ablations/` | Photo transcription of results from before V1 | Skip | Old runner, not comparable with V1 |
| `bridge/` | Coordination records, plans, reviews, releases | Skim | Read `bridge/OWNER_QA.md` section B and the plans dated 10-24 to 10-27 |
| `updates_10_23_2026/` | V2 pod results, transcribed from screenshots | Read | The only record of what the pod ran in V2, and of the pod patches |
| `explainer/` | Plain-English explainer, written 10-12 to 10-14 | Skim | Read chapters 04 and 11. Chapters 01 to 06 are still good background; 07 to 10 predate V2 |
| `guide/` | Learning guide of 10-05 to 10-07 | Skim | Parts 01, 02, 03, 09 are good basics. Results are out of date |
| `updates week_10-14-2026/` (with a space) | Copilot record of 10-14 | Skim | Business context only |
| `updates_week_10-14-2026/` (with underscores) | The 10-15 handoff and a V1 architecture summary | Skim | `current_new_architectures/ARCHITECTURE_RUNS.md` is a compact summary of the V1 models |
| `business_guides/` | Two business guides of 10-05 | Skip | Superseded by the 10-25 briefing and 10-26 weekly |
| `chatgpt/`, `claude/` | The two assistants' first audits, 10-05, frozen | Skip | Their findings were fixed in `waqas/base` and V1 |
| `reconstruction/` | Metadata of the photo-to-code worker | Skip | Explains why main's files are transcriptions, nothing more |
| `Update Overview/` | One Copilot write-up of 10-06 | Skip | History of the 10-06 fixes |
| `README.md`, `pyproject.toml`, `requirements.txt` | Yaqun's project files, rebuilt from photos | Skim | Original intent and dependency list |
| `AGENTS.md`, `CLAUDE.md` | Start files for the assistants | Skip | Rules for the assistants, not for learning the project |

## How to open V2 files

The V2 code is not on main. It exists only at commit `60232e98db78b562ab1a073da3968730887b8a0f` (short form `60232e9`), on branch `claude/v2-integration-2026-10-19`. Package 009 (`bridge/releases/tf-v2.1.0/package/009_20261021_180056_UTC.zip`) was built from that commit.

Three ways to open a V2 file, none of which changes anything. Run the two commands from the top folder of your own clone of the repository. If git says it does not know `60232e9`, run `git fetch origin` once and try again.

1. **Print one file in the terminal:**
   `git show 60232e9:waqas/v2/target_ending.py`
   Replace the path after the colon with any V2 path. Add `| less -N` to see line numbers.
2. **List the V2 files:**
   `git ls-tree -r --name-only 60232e9 waqas/v2 runbook/v2 runbook/2026-10-19`
3. **On GitHub:** open the repository `AliKashy/tabular_fraud`, switch the branch selector to `claude/v2-integration-2026-10-19`, then browse to the file. GitHub shows line numbers. Note: the branch's newest commit is `dda4d4a`, three commits after `60232e9`. Those three commits change only `runbook/v2/RUNBOOK.md` and `waqas/v2/tests/test_business_metrics.py`, so for those two files the branch view differs from what package 009 was built from. To see exactly `60232e9` on GitHub, open `https://github.com/AliKashy/tabular_fraud/tree/60232e98db78b562ab1a073da3968730887b8a0f`. A link to a single file looks like this: `https://github.com/AliKashy/tabular_fraud/blob/60232e98db78b562ab1a073da3968730887b8a0f/waqas/v2/target_ending.py`.

Line numbers in this tour for V2 files refer to commit `60232e9`. Line numbers for main files refer to main at commit `111a8c3` (2026-10-28). On GitHub, put the full commit id `111a8c399db25d9085281e60ee493f87ba66afdf` in a link in place of `main` to see those exact lines.

Remember: three V2 files on the pod were changed after install by four small patch scripts run on the pod (`waqas/v2/scripts/train_v2.py` once, `waqas/v2/models.py` twice, `waqas/v2/scripts/select_splits.py` once). The patch scripts are not in the repository; the records quote the changed lines. So commit `60232e9` shows the code before the patches. Chapter 04 describes the patches from the records.

## What runs on the pod today, in one picture

```
S3 parquet files (part_<n>.parquet)
  fraud/data/s3_utils.py              builds the file list, opens S3
  fraud/configs/predictors.csv        the 23 input features
  fraud/data/feature_list.py          reads that list
  fraud/data/datetime_features.py     month, day, hour, day of week from the timestamp
  fraud/data/preprocessing.py         frozen artifacts, version 1: scaling and code books
  fraud/data/parquet_loader.py        three column helpers only (column order, cardinality, missing flags)
  waqas/base/data/input_contracts.py  checks labels, accounts, timestamps before use
        |
  waqas/phase4b/sequence_builder.py   training: non-overlapping chunks of 21 time points
  waqas/v2/target_ending.py           validation and scoring: one window ending at each transaction
        |
  waqas/phase4b/sequential_hier.py    Arch B model, all-position mode
  waqas/v2/models.py (patched)        V2 subclass: target-slot validation, routed training step
        |
  waqas/v2/scripts/train_v2.py (patched)   training run, checkpoints, resume, manifest
  fraud/callbacks.py                       validation AP over the whole validation stream
        |
  waqas/v2/scripts/score_v2.py        scores a checkpoint, writes predictions and a receipt
  waqas/v2/analysis/paired_v2.py      paired AP comparison between models, by account
```

The chosen V2 model is "Arch B H20 chunk": hierarchical (Arch B), causal, every transaction a target, history of 20 time points, trained on non-overlapping chunks of 21 time points, scored with one window per transaction. Its reference is "Arch B H20 sliding", which is V1's B-H20 model.

## Status labels used in this tour

| Label | Meaning |
|---|---|
| Runs on the pod today | The pod runs this code now, or code that runs now imports it. Some step-1 tools ran once and are finished; the tour says so |
| V1 only | Ran in V1 (2026-10-13). V2 does not use it |
| Superseded | Replaced by a newer copy or route. Not used now |
| Parked | Exists, sometimes even shipped to the pod, but no record shows it running |
| Test | Automated checks on fake data |
| Config, docs, record | Settings files, explanations, and records of what happened |

## Safety rules for reading

- Never open, copy or share any file named `test.yaml`. On the pod it holds the S3 credentials. It is not in the repository. Configs name the credentials file in a setting called `s3.cred_path`: your configs under `waqas/` name `test.yaml`, and Yaqun's configs under `fraud/configs/` name a file called `S3_credentials.yml`. You can read a config; do not open the file it names.
- The git commands in this tour only read (and `git fetch` only downloads). None of them changes your files.
- Some release notes under `bridge/releases/*/package/README.md` hold private install values. Do not copy them anywhere public.

## Glossary

Grouped by topic. Each chapter uses these words without explaining them again.

### Data

- **Transaction, row:** one card transaction. One row in a data file.
- **Account:** the card account a transaction belongs to. History is always built per account.
- **Label, `frd_tag`:** 1 if the transaction was fraud, 0 if not. This is what the model learns to predict.
- **Prevalence, fraud rate:** the share of transactions that are fraud. About 0.15% here. So a model that guesses at random gets an AP of about 0.0015.
- **Parquet:** a compressed table file format. Each data file is `part_<n>.parquet`.
- **S3:** the bank's file store, where the parquet files live. **s3fs** and **pyarrow** are the Python libraries that read it.
- **File range:** a run of file numbers, for example 1-10 (training), 4950-4954 (validation), 8000-8010 (evaluation).
- **Feature, predictor:** one input column given to the model. There are 23.
- **Continuous feature:** a number, such as an amount. 6 of the 23.
- **Categorical feature:** a code, such as a merchant type. 13 raw ones plus 4 made from the timestamp (month, day, hour, day of week).
- **`transaction_dttm`:** the transaction timestamp column. History order and the 4 datetime features come from it.
- **Missing value:** an empty cell.
- **`_isna` flag:** an extra 0/1 input saying "this continuous value was missing". One per continuous feature.

### Preprocessing

- **Preprocessing artifacts:** statistics fitted once on training files 1-5 and then frozen: mean, standard deviation and median for each continuous feature, and a code book for each categorical feature. Every run uses the same frozen set, so training and scoring see identical inputs. Saved in a numbered **version** folder; the runs use version 1.
- **Vocabulary, vocab, code book:** the list of known values of a categorical feature, each with a number. Number 0 is **UNK** (a value never seen when fitting), 1 is **MISSING**, known values start at 2, most frequent first.
- **Median imputation:** filling a missing number with the median.
- **Standardize, z-score:** subtract the mean, divide by the standard deviation, so numbers sit around 0.
- **Cardinality:** how many different codes a categorical feature can take, including UNK and MISSING.

### Configuration and code

- **Config, YAML:** a settings file. **OmegaConf** is the library that reads it. A **dotlist override** is a setting changed on the command line as `key=value`. `???` in a config means "must be filled in before running".
- **Script:** a Python file you run. **Module:** a Python file other files import. **Function, class:** named pieces of code inside a file; the tour gives their line numbers.
- **Import:** one file using code from another.
- **Commit:** a saved state of the repository, named by a hash such as `60232e9`. **Branch:** a named line of commits. **main:** the main branch.
- **Hash, SHA-256:** a fingerprint of a file's bytes. If one byte changes, the hash changes. Used to prove a file is unchanged.
- **Manifest:** a file listing what was used (files, hashes, settings).

### History and windows

- **History:** the earlier transactions of the same account, shown to the model with the transaction being scored.
- **Target:** the transaction whose fraud label the model is predicting.
- **H, history length:** how much history. In V1 and default Arch B it counts earlier **rows**. In the chunk model it counts earlier **time points** (distinct whole seconds).
- **Time point:** all transactions of an account in the same whole second. They count as one point.
- **Strict time order:** a row's history holds only rows with an earlier timestamp. Rows with the same timestamp never see each other. **Tiebreak** order (older code) let same-time rows that sort earlier by an id enter the history.
- **Window:** one target plus its history, as one model input.
- **Sliding window, target-ending window:** one window per transaction, ending at that transaction. Every transaction gets its own full history. The records use "sliding" for these.
- **Chunk:** a non-overlapping block of an account's rows. In the chunk model a chunk holds 21 time points (an account's last chunk may hold fewer). Every row in it is a target, and its history is only the earlier rows inside the same chunk, so history restarts at each chunk.
- **Padding:** empty slots added so all windows in a batch have the same length. **Left padding** puts them before the history; **right padding** after.
- **Mask:** a table of yes/no saying which slots are real and which slots may look at which others.
- **Time gap, `time_delta`:** an extra input: the log of the seconds between a history row and the target (V1 sliding windows), or since the previous time point (chunks, and also the chosen model's target-ending windows, so that a window and a chunk give the same score).
- **Cap, `max_window_rows`, `max_chunk_rows`:** the most rows a window or chunk may hold. The chosen model's windows are capped at 32 rows.
- **Stride:** take every n-th window. Stride 1 means every transaction.

### Models

- **Model, weights:** a function with many adjustable numbers (weights). Training adjusts them.
- **Neural network:** a model built from layers of simple maths operations.
- **Token:** one small item the model reads. Here each feature of each transaction becomes one token, so one transaction is 30 tokens (7 continuous including the time gap, plus 23 categorical including the 6 `_isna` flags).
- **Embedding:** a list of numbers (width 48 in the main configs) that stands for a token.
- **Tokenizer:** the code that turns features into tokens.
- **Attention:** the step where each token looks at other tokens and mixes in what it finds.
- **Transformer, encoder, block, layer:** a stack of attention steps. One block is one attention step plus a small feed-forward step. **Pre-norm** and **GELU** are standard choices inside a block.
- **CLS token:** an extra token added to the sequence whose output is used as the summary. The model's answer is read from it.
- **Head:** the last small layer that turns a summary into two numbers (**logits**), one for "not fraud", one for "fraud". **Softmax** turns them into a probability.
- **Bidirectional attention:** every token may look at every other token in the window.
- **Causal attention:** a token may look only at earlier transactions (and itself), never later ones.
- **Leak:** information from a later transaction reaching an earlier one when it should not.
- **FT-Transformer:** a transformer for tables: one token per feature, then attention, then a CLS readout.
- **pytorch_tabular:** a library that provides an FT-Transformer for single rows.
- **Single-transaction model, REF-SINGLE:** Yaqun's model that sees one transaction, no history. The V1 reference.
- **Arch A (flat):** every feature of every transaction in the window becomes a token, all in one long sequence, one transformer over all of it.
- **Arch B (hierarchical):** first a small transformer turns each transaction into one vector (2 blocks), then a second transformer runs over those vectors (4 blocks).
- **Default B, single-target:** Arch B that scores only the last transaction of each window.
- **All-position B, ALLPOS:** Arch B that gives a score at every transaction in the input. Needs causal attention.
- **Run names:** V1 names its runs by architecture and history, for example A-H05 (Arch A, history 5) or B-H20 (default B, history 20). B-ALLPOS-H5 is V1's all-position B at history 5. In V2, ALLPOS-H20-CHUNK is all-position B at history 20 trained on chunks (the chosen model, "Arch B H20 chunk"), and ALLPOS-H20-SLIDE is the same model trained on one window per transaction. Chapter 03, part 6, has the full table.

### Training

- **PyTorch:** the maths library the models are written in. **Lightning** is a layer on top that runs the training loop. Its **Trainer** runs it; a **LightningModule** is a model with its training steps; a **callback** is code that runs at fixed points (for example after each validation).
- **Batch:** a group of windows or chunks processed together. **Micro-batch and gradient accumulation:** process several smaller batches and add up their effects before one weight update, to fit in GPU memory. "2048 x 2" means batches of 2048, two per update.
- **Epoch:** one pass over the training files.
- **Loss, cross-entropy:** the number training tries to make small. It is large when the model is confident and wrong. **pos_weight** gives fraud rows more weight in the loss.
- **Optimizer, AdamW:** the rule that updates the weights. **Learning rate (LR):** how big each update is. **ReduceLROnPlateau:** halves the learning rate when the validation loss stops improving for a set number of epochs (patience 3 here, so it acts on the 4th epoch without improvement).
- **Validation:** checking the model on held-out files (4950-4954) after each epoch.
- **Early stopping:** stop training when validation has not improved for a set number of epochs (patience).
- **Checkpoint:** a saved copy of the weights. `best.ckpt` is the best epoch by validation AP; `last.ckpt` is the last.
- **bf16-mixed:** a faster, lower-precision number format on the GPU.
- **Seed:** the starting number for randomness. Same seed, same random choices. V1 used seed 42; V2 added 43 and 44.
- **Deterministic:** a setting that forces the GPU to give identical results on reruns.
- **Resume:** continue a stopped training run from its saved state.
- **IterableDataset, DataLoader, worker:** PyTorch's way to stream data. A **worker** is a helper process that reads files in parallel. **Sharding** is splitting files between workers.

### Scoring and comparison

- **Score:** the model's fraud probability for one transaction.
- **AP, average precision, PR-AUC:** rank all transactions by score, then measure how well frauds come near the top. 1.0 is perfect; random is about the fraud rate. This is the main measure in this project. It must be computed over the whole file range at once, not per batch.
- **AUROC, ROC-AUC:** another ranking measure. It looks good even for weak models when fraud is rare, so it is secondary here.
- **Prediction parquet:** the file of scores a scorer writes, one row per scored transaction.
- **Receipt:** a small JSON file a V2 scorer writes with hashes and the AP of the scored range.
- **Paired comparison:** compare two models on exactly the same transactions.
- **Bootstrap:** resample the data many times to see how much a number could move by chance. **Whole-account bootstrap** resamples whole accounts, because rows of one account are related.
- **Interval, "resolved", "not resolved":** the bootstrap gives a range for the AP difference. If the range does not include 0, the difference is "resolved". If it includes 0, it is "not resolved", which does not mean the models are tied.
- **Ablation, sweep, spec, cell:** a planned grid of runs that change one thing at a time. A **spec** file describes the grid; each run in it is a **cell**.
- **XGBoost:** a tree-based model type. The bank's debit-card fraud model, called 15298 in the records, is an XGBoost model (`bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md` line 121). The briefing's "benchmark against the incumbent" is the BENCH reading below, on the transactions TFM V22B was evaluated on, not a test against 15298.
- **Embedding export:** saving the model's internal summary vector per transaction so another model can use it.

### Populations (V2 names for groups of files)

- **ENC_TRAIN_10, ENC_TRAIN_100:** training files 1-10 and 1-100.
- **EPOCH_VAL:** validation files 4950-4954.
- **DEV_OOT, Test 1:** evaluation files 8000-8010, all months.
- **SELECT, holdout:** files 8206-8216, used to choose between models (decision AP on June targets).
- **DS_TRAIN, DS_SELECT:** files for the downstream XGBoost step. DS_TRAIN became 4001-4010 on the pod; DS_SELECT is 8217-8227.
- **FINAL:** files 8260-8277, kept unread for the final reading.
- **BENCH, Test 2:** the transactions the bank's foundation model TFM V22B was evaluated on.

### Operations

- **Pod:** the bank's GPU machine where the real data can be read.
- **GPU:** the chip that does the model maths. The pods have H200 GPUs.
- **Package:** a numbered ZIP of reviewed code sent to the pod, for example package 009.
- **Placeholder:** a stand-in word in the public ZIP (for example `YOUR_PACKAGE`) replaced with the real value before install.
- **Personalize, install:** the two steps that fill placeholders and copy files into place, with hash checks.
- **Runbook:** a written list of commands to run, in order.
- **L2, L3, L4:** stage names from the V2 plan that the pod records use. L2 is the data inventory and the frozen populations, L3 the first architecture test (the runs that produced the chosen model), L4 the export check, not yet run.
- **Pre-flight:** a read-only check run before training, to catch problems early.
- **Ledger:** a CSV log of runs and their status.
- **Attempt folder:** a fresh folder for one run, never overwritten.
- **Test, pytest:** an automated check. **pytest** is the tool that runs them. **Synthetic data:** fake data made for tests.

## Where the facts come from, and limits

- Facts come from reading the code and the records. They were checked against the code at main (`111a8c3`) and at `60232e9` on 2026-10-28. Line numbers refer to those two commits. If a file changes, lines move.
- main's `fraud/`, `pyproject.toml`, `requirements.txt` and `README.md` were rebuilt from photographs. `src/pytorch_tabular/` is not a photo copy: early partial photo rebuilds were replaced by the library's public source (commit `6650d40`), then pinned to its 1.1.0 release (commit `f126860`). A review says the pod's real `fraud/` and `src/` differ from the repository in 58 files (`bridge/reviews/CL/2026-10-24-results-l3-seeds/README.md` lines 63-65). Treat main's copies as close approximations.
- The pod results in `updates_10_23_2026/` are transcriptions of screenshots. Some hashes are quoted differently in different sections.

## Check yourself

1. Where is the V2 code, and how do you print `waqas/v2/models.py`?
   Answer: at commit `60232e9` (branch `claude/v2-integration-2026-10-19`). From the top folder of your clone, run `git show 60232e9:waqas/v2/models.py`. Or open it on GitHub at that commit.
2. Does commit `60232e9` show exactly what runs on the pod?
   Answer: no. Three files were changed on the pod after install by patch scripts, and those scripts are not in the repository.
3. What does "history 20" mean for the chosen model?
   Answer: up to 20 earlier time points (distinct whole seconds) of the same account, capped at 32 rows.
4. Which of Yaqun's code still runs on the pod?
   Answer: the data layer in `fraud/data/` (files, features, datetime, artifacts, three column helpers in the loader), the feature list `fraud/configs/predictors.csv`, `fraud/callbacks.py` and `fraud/log_utils.py`. His models and scripts do not.
5. Which file must you never open?
   Answer: any file named `test.yaml`.
