# Chapter 05: the rest of V2, in run order

Chapter 04 covered the V2 trainer and scorer. This chapter covers every other V2 file, in the order of the V2 runbook: look at the data, count it, freeze the populations, measure windows, compare models, export, build contracts, run the downstream XGBoost, and benchmark. For each step it says what actually ran on the pod. Words are in the glossary in [README.md](README.md#glossary).

**Every file in this chapter is at commit `60232e9`, not on main,** except `waqas/phase4b/scripts/measure_chunk_widths.py`. From the top folder of your clone, open a file with:

```
git show 60232e9:<path>
```

List them all with `git ls-tree -r --name-only 60232e9 waqas/v2 runbook/v2 runbook/2026-10-19`. On GitHub, one file at that commit is at `https://github.com/AliKashy/tabular_fraud/blob/60232e98db78b562ab1a073da3968730887b8a0f/<path>`. The branch `claude/v2-integration-2026-10-19` shows almost the same files: its newest commit, `dda4d4a`, differs from `60232e9` only in `runbook/v2/RUNBOOK.md` and one test file (see [README.md](README.md#how-to-open-v2-files)).

## The plan and what ran, side by side

| Runbook step | Planned | What the pod did (records) |
|---|---|---|
| 0 | Set up, install, confirm | Ran, with package 009 (the runbook at `60232e9` still names 008; the branch's newest commit names 009) |
| 1a | Data look | Ran once, exit 0 |
| 1b | Quick checks a to g | Ran a, b, c, f, g; e failed then reran; d not run |
| 1c | Inventory and split freeze | Ran (L2), after a pod patch to `select_splits.py` |
| 1d | V1 source and checkpoint facts | No record |
| 1e | Build and check the no-month artifact | Not run; the artifact does not exist |
| 1f | Measure window rows and chunk widths | Measurement files exist under L3, not under step 1; the records do not name the tools |
| 1g | Feature screen | Not run (XGBoost not installed) |
| 2 | V1 continuity scoring and export check | Partly: B-H15 and B-H20 rescored through `score_v2.py`; export not run |
| 3 | Five-fit architecture test without month | Not run as written; the pod ran L3 instead (chapter 04) |
| 4 | Export, contracts, downstream XGBoost | Not run |
| 5 | S1 feature fit | Not run |
| 6 | M3 on files 1-100 | Not run |
| 7 | Data-owner certification | Open questions |
| 8 | Amount bins, freeze, FINAL and BENCH readings | Not run |
| 9 | Handover contracts | Not run |

Sources: `updates_10_23_2026/M01_V2_results__through_l3.part_1.md` and `part_2_and_3.md` (cited below as M01 part_1 and M01 part_2_and_3), and `updates_10_23_2026/Seed_results.md`. All are transcriptions of pod screenshots.

The records use the V2 plan's stage names L1 to L9 beside the runbook's step numbers: L2 is the inventory and frozen populations, L3 the first architecture test, L4 the export check (M01 part_1 lines 16-19, part_2_and_3 line 703).

---

## The two governing documents

### `runbook/v2/RUNBOOK.md`

- **What it is:** the one end-to-end V2 runbook (2026-10-20). Every command from install to handover, what each step returns, and where to stop.
- **Look at:** kinds of step and "one folder per step" (lines 7-14); step 0 (16-79), whose install text at `60232e9` still names package 008 (30-58; the branch's later commit `e044a09` changed it to package 009, so the GitHub branch view shows different text and line numbers for this file); step 1 parts 1a to 1g (85-241) and its gate (243-245); steps 2 to 9 (247-512); questions only a person can answer (514-527); glossary (529-553), which explains default B, chunk model, target-ending scoring, history units and populations.
- **Status:** docs. Not shipped to the pod; read on GitHub. `waqas/v2/tests/test_step1_commands.py` checks that every command line in it parses.

### `runbook/v2/DECISIONS.md`

- **What it is:** the frozen decision record of 2026-10-20: every rule and threshold set before any SELECT reading.
- **Look at:** fits table: B05, B05r, C05, B20, C20, S1 (the base plus one feature family), M3 (the final recipe on files 1-100); no month; deterministic; at most 10 epochs, patience 5 (13-33). Populations (35-43). Validity gate: B05 at least 0.0731, B20 at least 0.0854 (45-55). Window-cap rule (57-67). Screen formula, the noise threshold a difference must clear, `1.645 * sqrt(sd_pair^2 + v * sd_run^2)` with a floor of 0.013 for `sd_run` (69-74). Rule A: keep the chunk model only if it beats default B by more than the screen (76-85). Rule B: choose the higher; a tie keeps H5 (87-92). Tiers (94-108). S1 nomination (110-137). Downstream arm (185-187). Section 17, an account-level 14-day consumer (189-244). Results log (246-250), still **empty**.
- **Watch out:** the "Arch B H20 chunk" choice is not recorded here; it comes from the update records ("current reading, not a final decision", M01 part_2_and_3 line 284). Section 17's 14-day account-level use was replaced on 10-27 by D-012 (`bridge/DECISIONS.md` lines 176-181). Section 3 (line 38) still names DS_TRAIN as 5001-5010, which the pod could not use.
- **Status:** docs.

### `runbook/v2/STEP1.md`

- **What it is:** a three-line pointer saying step 1 moved into `RUNBOOK.md`. **Status:** superseded.

---

## Step 0: set up and install

Covered in chapter 06 (packages and installer). The pod installed package 009, receipt `009_20261021_180056_UTC_5ctj616u`, status `installed_and_verified` (M01 part_1 lines 26 and 37-45). The runbook's confirm line is `data_look --only environment,package` (`RUNBOOK.md` line 76). The pod record shows a short data look over the sections pod, environment, package and credentials (`data_look_20261021T231108Z`) before the full run (M01 part_1 lines 61-63).

---

## Step 1a: look at the data

### `waqas/v2/scripts/data_look.py`

- **What it does:** one read-only CPU pass that records counts only: the pod environment, package hashes, the **names** of credential keys (never values), both S3 file listings, storage (benchmark, artifacts, predictions), parquet file footers, row profiles per population, and months per file. It writes `SUMMARY.txt`, `env_additions.sh` (settings for later steps such as `EVAL_END` and `BENCH`) and `privacy_check.json`.
- **Why it exists:** to learn the facts of the data before any model reads it, without copying any data out.
- **Look at:** docstring with sections and privacy rules (1-40); `SECTIONS` (66); default training ranges still include 5001:5010 (84); June targets (88); `SELECTION_POOL_START = 8011`, files from there on are never profiled (95); `Store` (200-257); `listings_facts` (406-444), with the rule for `EVAL_END` (430-440); `storage_facts` (529); `schema_facts` (615); `profile_file` (1115); `months_facts` (1181-1237); `privacy_scan` (1410); `main` (1515-1681).
- **Status:** on the pod; ran in full once (`data_look_20261021T231206Z`, exit 0), after a short run of four sections, and is finished.
- **What it found (M01 part_1 lines 59-114):** training files 5001-7999 do not exist; XGBoost is not installed; the benchmark file has no score column; only artifact version 1 exists.

---

## Step 1b: quick checks

### `runbook/2026-10-19/quick_checks.py`

- **What it does:** read-only checks on the V1 record and two data facts. Writes aggregates only, to `runs/returns/quick_checks_<UTC>/`.
  - a: validation AP per epoch, best and last epoch; also writes the run folders of R05, R15 and R20 (V1's B-H05, B-H15 and B-H20 checkpoints, which V2 reuses) for later steps.
  - b: account overlap between the data folders.
  - c: batch settings.
  - e: B-ALLPOS-H5 AP by position inside the chunk, through `runbook/2026-10-07/paired_report.py`.
  - f: how many rows share the same second.
  - g: whether balance and limit fields are stored before or after the transaction.
  - d: a GPU rescore of `last.ckpt`.
- **Why it exists:** to answer specific questions about the V1 record (best epochs, batch settings, the effect of position inside a chunk) and about the data (same-second rows, balance timing) before any V2 fit.
- **Look at:** docstring (5-33); `MANUAL_RUNS` for the hand-retrained B-H15 and B-H20 (55-58); `DEFAULT_RUN_TABLE` (65), a relative path to a folder that exists off the pod but not on it, which is why check e failed on the pod (M01 part_1 lines 118-121); `find_run_dirs` (132-154), which imports `runbook/2026-10-07/analysis_runs.py` (line 134) and so the ledger reader in `runbook/2026-10-07/collect_returns.py`, and which `main` calls before any check (944); `PIN_CELLS` (172); `check_a` (175-226), pins at 210-220; `check_b` (272); `check_c` (346); `check_e` (398-431); `check_d` (434); `check_f` (651); `check_g` (857); `parse_args` (912-933); `main` (936-981).
- **Status:** runs on the pod today; ran twice on 10-21 (`quick_checks_20261021T232641Z` for a, b, c, f, g, where e failed on its default path; `20261021T235529Z` for the rerun of e). d was not run. The clean-up plan retires it.

### `runbook/2026-10-19/QUICK_CHECKS.md`

- Plain-language explanation of checks a to g and d, with what each reads, writes and costs (lines 5-24). Commands are in `RUNBOOK.md` step 1b. **Status:** docs.

---

## Step 1c: count everything and freeze the populations

### `waqas/v2/storage.py`

- **What it does:** returns Yaqun's S3 file system with a 1 MiB read-ahead block (`THIN_READ_BLOCK_SIZE`, line 10; `thin_read_filesystem`, lines 13-20), so reading a few columns stays cheap. Used by the CPU tools, never by the model path.
- **Status:** runs on the pod today.

### `waqas/v2/scripts/data_inventory.py`

- **What it does:** one pass over both data folders, reading 4 columns per file (id, account, time, label). Per file and month it records rows, frauds, accounts, history-depth bands (count of strictly earlier rows; same-time rows never count), duplicates and empty values. It also counts accounts shared between every pair of files (using a one-time random salt so ids are never stored) and overlap with the benchmark ids. Writes `inventory.json`.
- **Why it exists:** to choose populations that share no accounts and to know their sizes.
- **Look at:** `SCHEMA` (28); `write_frozen`, which refuses to replace a file (37-46); salted digests (97-109); `_depth` with rank method "min" (117-120); depth bands 0, 1-4, 5-9, 10-19, 20+ (123-134); `inspect_frame` with the 0/1 label check (137-176); `inventory` (179-273): salt (195), refusal of absent files (225-230), pair counting (240-245), overlap (260-267), a check of whether training file 8000 and evaluation file 8000 share accounts (268-272); `main` (276-313), exit 2 when incomplete.
- **Status:** runs on the pod today; ran once (L2, `20261022T034405Z`, exit 0).

### `waqas/v2/scripts/select_splits.py`

- **What it does:** from one `inventory.json` it fixes ENC_TRAIN_10 (1-10), ENC_TRAIN_100 (1-100), EPOCH_VAL (4950-4954), DS_TRAIN (the block given on the command line) and DEV_OOT (8000-8010). Then it picks contiguous June blocks after 8010 for SELECT, DS_SELECT and FINAL, with at least 2,000, 2,000 and 3,000 June frauds (least benchmark overlap, then fewest files, then earliest start). It requires zero shared accounts between distinct selected files. Writes `split_v2.yaml`, its `.sha256`, `population_roles_v2.yaml` and `selection_report.json`.
- **Why it exists:** to fix once, before any SELECT reading, which files serve which purpose, with no account shared between them.
- **Look at:** months, minimum frauds and the purpose vocabulary (22-28); `_block` (91-119); `select_splits` (133-252): the DS_TRAIN rule (140-141, **the pod patch site**), fixed roles (146-152), June block loop (156-160), account-collision gate (168-172), June month for SELECT, DS_SELECT, FINAL and DEV_OOT (184; DEV_OOT also keeps its all-month counts, 187-188), label-maturity flag (206-224), allowed-exposure table (229-235); `main` (255-289).
- **The pod patch:** the shipped rule wanted DS_TRAIN inside 5001-7999, but those files do not exist. `patch_select_splits_ds_train.py` replaced lines 140-141 with "inside 1-5000, disjoint from 1-100 and 4950-4954". DS_TRAIN became 4001-4010 (M01 part_1 lines 293-322).
- **Frozen populations:** SELECT 8206-8216, DS_SELECT 8217-8227, FINAL 8260-8277 (M01 part_1 lines 388-412).
- **Watch out:** the allowed-exposure table is written but no code enforces it; `paired_v2.py` only checks that `--purpose` is a known word (line 372), and `score_v2.py` accepts any text. `data_look.py` line 84, `RUNBOOK.md` (steps 1a, 1c, 1f and 4, and the glossary at line 546) and `DECISIONS.md` section 3 still use 5001-5010.
- **Status:** runs on the pod today (patched); ran once.

### `waqas/v2/INVENTORY.md`

- Explains the inventory and split tools: evidence, gates and output layout (lines 9-62). Lines 20 and 46: DS_TRAIN must lie in 5001-7999, which the pod could not satisfy. Its commands are superseded by `RUNBOOK.md` step 1c. **Status:** docs.

---

## Step 1d: check V1 source and checkpoints

### `waqas/v2/scripts/check_v1_source.py`

- **What it does:** compares the hashes of the V1 model-path files (the files Arch B's `train_sequential.py` and `score_sequential.py` import) with what each V1 run manifest recorded after training and after scoring. `MODEL_PATH_FILES` (25-35); `compare`, which fails if the training record is missing (46-61); `main`, exit 1 on a mismatch (64-80).
- **Why it exists:** to prove that the V1 model code on the pod is the code that trained and scored the V1 runs.
- **Status:** parked. No record of a pod run. `make_v2_contracts.py` imports its file list.

### `waqas/v2/scripts/checkpoint_facts.py`

- **What it does:** for each checkpoint reports its hash, epoch and step, settings, input columns with a `month_present` flag, validation policy, and optionally the config hash and a recomputed artifacts hash. `facts` (26-61), month flag (36), artifact hash (45-58); `main` (64-79).
- **Why it exists:** to state, from the checkpoint itself, what a model was trained on, including whether month was an input.
- **Status:** parked.

---

## Step 1e: the no-month artifact (not run)

The plan was to drop month from the inputs. The artifact for that, version 20261019, was never built. Every pod run so far used version 1 with month. See chapter 08 for how the month decision moved.

### `waqas/v2/scripts/build_nomonth_artifact.py`

- **What it does:** a guarded wrapper that runs Yaqun's `fraud/scripts/build_preprocessing_artifacts.py` to build version 20261019. It refuses if `fraud/configs/predictors.csv` has the wrong hash, if the no-month list is not exactly V1 minus month, if month is still a datetime field, or if the version already exists. Expected hash (25); `check` (28-44); `main` (47-62), which calls the V1 builder (58-61).
- **Status:** parked (not run; M01 part_2_and_3 line 555).

### `waqas/v2/scripts/check_nomonth_artifact.py`

- **What it does:** proves the no-month artifact equals version 1 minus month: same entries per feature, same fit files. `compare` (23-34); `main` (37-54).
- **Status:** parked.

### `waqas/v2/configs/preprocessing_nomonth.yaml` and `waqas/v2/configs/predictors_nomonth.csv`

- The build settings for version 20261019 (fit files 1-5, datetime fields day, hour, day_of_week, output in your area; credentials file path at lines 26-27), and the 22-feature list without month (continuous rows 2-7, categorical rows 8-20, derived rows 21-23).
- **Status:** config, not used by any pod run.

---

## Step 1f: measure windows and chunks

### `waqas/v2/scripts/measure_window_rows.py`

- **What it does:** for each row, counts the rows in its target-ending window at each H. Reports the distribution for all windows and for fraud windows, and the cap: the larger of the all-window 99.9th percentile and the fraud-window 99th percentile, rounded up to a multiple of 8, with the share of windows above it. This is the cap rule of `runbook/v2/DECISIONS.md` section 5 (lines 57-67). `chunk_batch_plan` turns widths and the cap into batch, accumulation and scoring-batch settings (about 4,096 targets per update, under 65,535).
- **Why it exists:** to set `max_window_rows` and the batch plan from measured widths instead of guesses.
- **Look at:** `window_sizes` (34-54); `summarise` with the cap rule (62-75, rule at 65-69); `chunk_batch_plan` (78-93); `main` (96-131).
- **Status:** likely ran in L3, not confirmed. The pod has `runs/v2/L3/measure/window_rows_h20.json` and `window_rows_h5.json` (M01 part_2_and_3 lines 471-472). The caps used, 32 at H20 (M01 part_1 line 478) and 8 at H5 (part_2_and_3 line 256), fit this rule, but the records do not name the script.

### `waqas/phase4b/scripts/measure_chunk_widths.py` (on main)

- **What it does:** a CPU tool that reads only the account and time columns and reports strict chunk widths (rows per H+1 distinct seconds), the largest same-account same-second count, and the stage-2 mask size, so `max_chunk_rows` can be set. `strict_chunk_widths` (42-60); `summarize` (63-82, mask size in GiB at 81); file split (85-92); `measure` (95-116).
- **Status:** likely ran in L3, unconfirmed: the pod has `runs/v2/L3/measure/chunk_widths_h20.json` (M01 part_2_and_3 line 473), the output name the runbook gives this tool, but the records do not name the script. The runbook calls it at `RUNBOOK.md` lines 219-222.
- **Watch out:** this tool lives in `waqas/phase4b/scripts/`, not in `waqas/v2/`.

---

## Step 1g: the feature screen (not run)

The feature screen tests new candidate features with XGBoost on files 1-10. It did not run because XGBoost is not installed on the pod. Read `waqas/v2/screen/POD.md` first: it needs about 30 GB of memory.

### `waqas/v2/features/strict_window.py`

- **What it does:** per-account "strictly earlier" time-window building blocks: count, sum, match count, distinct, mid-rank, median, censored. A window that reaches before the declared start of the data returns "missing", never 0. Rule docstring (1-32); `EXTRACT_START` (54); `StrictWindows` (168); `from_frame` (335).
- **Status:** parked. Only the screen uses it.

### `waqas/v2/features/groups.py`

- **What it does:** the candidate feature groups, one function each, with explicit missing-versus-zero rules: velocity (33), coverage (38), acceleration (51), type familiarity (57), amount versus median (81), amount mid-rank (92), spend in 24 hours (99), amount over capacity (118), cash limit observed (131). `GROUPS` (145); `compute_groups` (158).
- **Status:** parked.

### `waqas/v2/features/README.md`

- The strictly-earlier rule (5-11) and the table of groups with formulas (22-32). **Status:** docs.

### `waqas/v2/screen/run_screen.py`

- **What it does:** builds the feature groups and catalogue features on files 1-10, runs the state tests, sets a noise floor (a column of pure noise plus base-model seeds 43 and 44), then for each family runs the account-grouped paired XGBoost screen, a history-lite arm, a time-split test, and a final pass. Writes one JSON of aggregates. Base columns (27-33); `FAMILIES` (34-47); `WAVE1` (49-50); `build` (103-111); `main` (114-218): noise floor (175-184), families (185-204), drift (205-216).
- **Status:** parked (not run).

### `waqas/v2/screen/usefulness.py`

- The paired XGBoost usefulness test: account folds, weighted AP, account-cluster bootstrap, `PASS_RULE` (14), `FINAL_RULE` raised to the noise floor (179), `noise_floor` (184), `final_decision` (192). **Status:** parked.

### `waqas/v2/screen/stability.py`, `probes.py`, `state_test.py`, `features_new.py`

- `stability.py`: history-lite arm (previous 5 rows, line 21), time-split screen (62), PSI drift (95, 121). PSI, the population stability index, measures how far a feature's spread of values moved between the training months and June.
- `probes.py`: future-invariance check (17), single-feature AP (57), label shuffle (73).
- `state_test.py`: consecutive-pair before/after test (27), over-capacity counts (74), verdict (90).
- `features_new.py`: catalogue columns not in `groups.py`, including distance and travel features (57-248).
- **Status:** parked.

### `waqas/v2/screen/power.py` and `run_power.py`

- An offline simulation on fake data of how often `PASS_RULE` would catch a real effect; the source of the power figures in `DECISIONS.md` section 10. **Status:** parked; not a pod step.

### `waqas/v2/screen/synth.py`

- Fake accounts with planted before/after balances, declines and takeovers, for the screen tests. Not shipped. **Status:** test.

### `waqas/v2/screen/README.md`, `POD.md`, `SOURCE.md`

- README: the development note (file table at 5-14). POD.md: pod instructions and memory needs (5-35). SOURCE.md: where the screen code came from (3-10) and its hashes (12-29). **Status:** docs.

---

## Step 2: V1 continuity and the export path

**What ran:** V1 B-H15 and B-H20 were rescored through `score_v2.py` on DEV_OOT and SELECT and reproduced V1 (M01 part_2_and_3 lines 44-52 and 375-376). The export and its check were **not** run; L4 is the next stage (line 703).

### `waqas/v2/export_v2.py`

- **What it does:** exports the model's summary vector per transaction without reading labels. Through `score_v2.load_for_scoring` it hooks the input of `model.head`: the sequence CLS for default B, the target slot for chunk models. Writes `embeddings.parquet` (ids, score, window rows, `e_0` to `e_47`), `manifest.json`, `validation.json` (the head must reproduce the score within 0.000001) and `attempt.json`, and marks the run "exported", which is final.
- **Look at:** docstring (1-21); tolerance (42); slot helpers (46-68); `export`, which records the attempt before reading (71-104); `_export` (107-179): hook (111), reconstruction (122-124), validation (145-152), manifest (157-173); `main` (182-192).
- **Status:** parked (not run).
- **Watch out:** the file is at `waqas/v2/export_v2.py`, not in `scripts/`.

### `waqas/v2/scripts/l4_check.py`

- **What it does:** joins an export's scores to V1 predictions (or to a second export at another batch size) on id plus account, and reports matched and unmatched counts and the largest, 99th-percentile and mean absolute differences.
- **Why it exists:** to show that exported scores reproduce the V1 scores and do not depend on batch size, before anyone builds on the export. `_keyed` (28-34); `_stats` (37-41); `compare_scores` (44-56); `compare_exports` (59-72); `main` (75-93).
- **Status:** parked (not run).

---

## Step 3: the architecture test

**What was planned:** five fits (B05, C05, B05r, B20, C20) without month, compared with Rules A and B in `paired_v2.py`. **What ran:** L3 (chapter 04): ALLPOS-H20-SLIDE, ALLPOS-H20-CHUNK, ALLPOS-H5-SLIDE, with month, then seeds 43 and 44.

### `waqas/v2/configs/b05.yaml`, `b05r.yaml`, `b20.yaml`, `c05.yaml`, `c20.yaml`

- **What they are:** the five step-3 run configs. B configs come from `waqas/phase4b/configs/sequential_hier.yaml`; C configs from `sequential_hier_allposition.yaml`. No month (artifact 20261019, which does not exist), deterministic, validation 4950-4954, and, in the two chunk configs, `???` where step 1 must supply values.
- **Look at `c20.yaml`:** no-month predictor list (3); artifact version 20261019 (7); history 20 (25); causal (28); all-position, non-overlapping chunks, strict (30-33); caps `???` (34-35); batch, accumulation, scoring batch `???` (57, 62, 76); deterministic (75); credentials file path (84); output `runs/v2/C20` (86). Differences: B configs are bidirectional, single target, batch 4096 x 1; `b05r` is seed 43; `b20` is history 20 at 2048 x 2.
- **Status:** config, **not used on the pod**. As written they would fail: the artifact is missing, and the chunk configs hold `???` values.

### `waqas/v2/configs/make_run_configs.py`

- **What it does:** writes the five configs: V1 base config plus declared no-month and per-run changes, with measured values left as `???`. Bases (15); no-month changes (16-24); measured placeholders (25-26); runs (27-33); `build` (41-46); `main` (49-55).
- **Status:** parked (an off-pod generator).

### `waqas/v2/analysis/paired_v2.py`

- **What it does:** account-paired comparisons of V2 prediction files.
  - Recomputes each row's history depth on the full raw files, then keeps June targets (or all targets).
  - Checks each receipt's hash and full coverage.
  - Computes AP and AUROC per depth band, paired AP differences with a 1,000-draw whole-account bootstrap, and the scenario screen.
  - Optionally runs the five-fit Rule A and Rule B decision.
- **Why it exists:** a fair comparison needs the same transactions for both models, June targets that still see their full May history, and an interval that resamples whole accounts.
- **Where it sits:** after `score_v2.py`; its paired reports are what the model choice rests on.
- **Look at:** `SD_RUN_FLOOR` (31); loads `runbook/2026-10-07/paired_report.py` by file path (33-36); `ARCH_SEEDS` (37); June defaults, 2025-06-01 to 2025-07-01 (40-45); `load_raw` (48); `load_models` (121-168); `Comparison` (171-235): AP (195), report (212), contrast with its threshold and the two labels (218); `architecture_decision` (238-260); `analyse` (291-357); `main` (360-441).
- **Status:** runs on the pod today. It made the L3 SELECT and DEV_OOT paired reports, with custom contrasts (the `--comparisons` option) and `--sd-run 0.0137` (M01 part_2_and_3 line 103).
- **Watch out:** `paired_report.py` was not in package 009; the pod uses the copy an earlier package installed (packages 005 and 006 both shipped it). "label" means the interval excludes 0; "scenario_label" uses the screen formula.

### `waqas/v2/analysis/business_metrics.py`

- **What it does:** descriptive fraud metrics: alerts at 0.1% to 5% of traffic, detection and value-detection rates, false positive rate, KS (the largest gap between the score spreads of frauds and non-frauds), reliability, an account bootstrap at 1%, and slices by history depth, amount quintile and source file. `DEPTH_BANDS` (16-17); alert grid (18); amount bins (34-49); `business_report` (204-267); `main` (270).
- **Status:** runs on the pod today in part: `paired_v2.py` imports `DEPTH_BANDS`, `business_report` and `validate_amount_bins` (line 29) and uses `DEPTH_BANDS` every run (line 185). `business_report` runs only for single-run FINAL readings (lines 331-338), which have not run.

### `waqas/v2/analysis/ANALYSIS.md` and `BUSINESS_METRICS.md`

- `ANALYSIS.md`: how `paired_v2.py` works: run table (24-28), rules (30-41), outputs and labels (43-50), custom contrasts (52-64), FINAL metrics (71-77). `BUSINESS_METRICS.md`: definitions (1-40). **Status:** docs.

---

## Step 4: export, contracts and the downstream XGBoost (not run)

The idea: export the chosen model's vector and score per transaction, then test whether adding them to the bank's XGBoost inputs helps. In four "arms": raw features; raw plus score; raw plus vector; raw plus score plus vector.

### `waqas/v2/scripts/make_v2_contracts.py`

- **What it does:** writes every contract file so nothing is typed by hand. Subcommands: encoder, identity, downstream, code-manifest, freeze (`FROZEN_MODEL.json`), bench-targets, amount-bins, benchmark, handover (`handover_manifest.json` with cross-checks and the serving contract).
- **Look at:** subcommand list (7-18); model-path file list (52-54); `encoder_contract`, which refuses an unexpected checkpoint hash (103-123); `freeze` (211-240); `handover` (376-476), which checks the model path is unchanged since the fit; `main` (479 on).
- **Watch out:** line 397 is a handover check that month is absent from the model's inputs. The chosen model uses month, so its handover manifest would record `all_checks_pass: false` (line 474) until that is settled. A review says the same (`bridge/reviews/CL/2026-10-24-results-l3-seeds/README.md` line 32).
- **Status:** parked (not run).

### `waqas/v2/downstream_xgb.py`

- **What it does:** fits XGBoost on DS_TRAIN in the four arms plus PCA 8 and 16 variants (PCA shrinks the 48-number vector to its 8 or 16 strongest directions), reads DS_SELECT once, reports arm 4 minus arm 2 with the paired account bootstrap and the recommended arm, and saves `consumer.joblib`. `--final` loads the frozen bundle and never fits.
- **Why it exists:** to test whether the model's score and vector add value to an XGBoost model built on the raw features.
- **Look at:** XGBoost imported at the top (21); arm table and budget (32-37); encoder pin checks (50-99); `load_population` (131); `raw_features`, which drops month (193-223, line 197); `arm_matrix` (226); `report_predictions` with the decision note (245-278); `run` (281-418): FINAL branch (287-323), fitting (324-396), repeatability check (375-379); `main` (421).
- **Status:** parked. It cannot run until XGBoost is installed on the pod.

### `waqas/v2/analysis/embedding_diagnostics.py`

- **What it does:** summary checks of the exported vectors (spread per dimension, near-constant dimensions, PCA variance, correlation with the score), fitted on DS_TRAIN only, plus input checks for the benchmark. `embedding_diagnostics` (15-58); validation (61-128); `benchmark_embedding_diagnostics` (131).
- **Status:** parked.

### `waqas/v2/USAGE_CONSUMERS.md`

- File layouts and contracts for `downstream_xgb.py` and `benchmark_v2.py`: downstream (11), FINAL (143), benchmark (185), storage and tests (294). **Status:** docs.

---

## Steps 5 to 9: features, scale, freeze, benchmark, handover (not run)

### `waqas/v2/benchmark_v2.py`

- **What it does:** lines up the chosen model's scores and the incumbent's scores with the bank's benchmark set by transaction id; after the freeze, compares AP and AUROC with paired intervals, business metrics and vector diagnostics (`--compare`). It also holds shared helpers others import: `digest`, `read_table`, `canonical_ids`, `paired_interval`, `verify_freeze`.
- **Why it exists:** to compare the frozen model with the incumbent on the same transactions the bank's foundation model was evaluated on (Test 2).
- **Look at:** expected counts (25); `verify_freeze` (95-115); `canonical_ids` (118-127); `paired_interval` (186-209); `depth_report` (212); `run` (254-410), count check (284-286), per-score alignment (287-317), compare branch (from 332); `main` (419).
- **Status:** parked (not run). Its helpers are imported by `checkpoint_facts.py`, `l4_check.py`, `make_v2_contracts.py`, `downstream_xgb.py`, `analysis/embedding_diagnostics.py`, `analysis/business_metrics.py` and `paired_v2.py` (only when given `--amount-col`, line 58).
- **Watch out:** it expects each model's scores as a table keyed by transaction id, with score, label and amount columns (`USAGE_CONSUMERS.md` lines 185-215). The data look found no score column in the benchmark file. The incumbent's scores appear to sit in a separate NumPy logits file (M01 part_1 lines 104-108), so they need converting into such a table first. Benchmark account overlap is unverified.

---

## Side tools shipped in package 009 but outside the runbook

### `waqas/v2/data_size_specs.py`

- Prints data-size settings (training file count and stride) from a chosen V1 resolved config, for corrected REF, A and B runs. Never trains. `build_spec` (40); `main` (124). **Status:** parked.

### `waqas/v2/scale_runs.py`

- Prepares, runs and collects a matched 100-file REF and default-B H15 experiment through the V1 runners. Lanes (34-37); match fields (41-44); secret file names it refuses to touch, including `test.yaml` (50); `prepare` (156), `run` (263), `collect` (325), `main` (364). **Status:** parked. Package 006 deferred these scale runs.

### `waqas/v2/h5_diagnostics.py`

- Reads saved V1 learning evidence (training curves, configs, optional checkpoint inspection) from the ablation folders into a return ZIP, without training. Search roots (28-34); secret names (39-46); `inspect_checkpoint` (190); `analyze_run` (277); `comparisons` (331); `collect` (399); `main` (466). **Status:** parked. Package 006 was built around this reader (`bridge/releases/tf-v2.0.0/package/README.md` lines 33-35), and no record shows it run on the pod. The clean-up plan retires it.

### Package markers: `waqas/v2/__init__.py` and the `__init__.py` in `scripts/`, `analysis/`, `configs/`, `features/`

- `waqas/v2/__init__.py` holds one comment line: V2 code under the governing plan; V1 model files are never edited. `analysis/__init__.py` holds a one-line docstring; the other three are empty. `screen/` has no `__init__.py`. **Status:** runs on the pod today (implicitly, on every `python -m waqas.v2...`).

---

## Check yourself

1. Which training files did the shipped split rule expect for DS_TRAIN, and what did the pod use?
   Answer: the rule wanted 5001-7999, which do not exist. A pod patch script replaced `select_splits.py` lines 140-141, and the pod chose 4001-4010.
2. Why did the feature screen and the downstream XGBoost not run?
   Answer: XGBoost is not installed on the pod, and both need it (`downstream_xgb.py` imports it at line 21).
3. Why would the step-3 configs `b05.yaml` to `c20.yaml` fail as written?
   Answer: they point to artifact version 20261019, which was never built, and the chunk configs still hold `???` values.
4. Where is the chunk-width tool, and where is the window-row tool?
   Answer: `waqas/phase4b/scripts/measure_chunk_widths.py` on main; `waqas/v2/scripts/measure_window_rows.py` at `60232e9`.
5. Is the choice of "Arch B H20 chunk" written in `runbook/v2/DECISIONS.md`?
   Answer: no. Its results log is empty. The choice comes from the update records ("current reading, not a final decision", M01 part_2_and_3 line 284) and your 10-26 request to present a final model (`bridge/OWNER_QA.md` lines 382-388).
