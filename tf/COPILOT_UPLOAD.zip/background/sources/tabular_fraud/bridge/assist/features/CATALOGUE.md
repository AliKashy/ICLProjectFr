# FE-CL-2026-10-19-2: V2 feature catalogue

Author: FE-CL (assist; informs, does not approve). Read at `main` `86be7fe`, PR #11 at `a204078`. The table with every field is `catalogue.csv` (19 rows, F01 to F19). This page gives the reasoning and the order.

Labels: **[V]** verified, **[S]** source claim, **[I]** inference, **[P]** proposal. **Every expected benefit below is an [I]; none has been measured on bank data.**

## Plain-language summary (for Waqas)

- **Shortlist.** Nineteen candidates, cut to the ones with a clear reason to help. Seven make up the first wave (priority 1). Each is an idea that someone already uses or that the data supports, and each can be built from data the bank has at the moment it decides.
- **The first wave**, in order:
  1. Your two ratios: amount ÷ balance and amount ÷ remaining daily limit, with a headroom code.
  2. A new one: how much of the balance the account has spent in the last 24 hours, including this purchase.
  3. Counts of recent transactions over 5 minutes to 30 days.
  4. Whether this merchant type is new for the account.
  5. How unusual this amount is for the account.
- **Why these.** Each one gives the model something it cannot easily work out for itself:
  - a share instead of two raw dollar figures;
  - a look further back than the 15 to 20 transactions the history model sees;
  - an account-specific "is this normal for you" rather than a bank-wide one.
- **What waits.** Device, profile and status fields wait until we know whether the stored value is the value on the day of the transaction or a later snapshot. A later snapshot can leak the answer.

## 1. How I chose

A candidate makes the list only if all four hold:
1. It is computable at authorisation from the current request and strictly earlier rows.
2. It carries information the FT model is unlikely to build itself (section 3).
3. It has a named source: Waqas, the incumbent workbook, the joint list or literature, or a reason stated here.
4. Its production state is bounded.

I dropped or merged several earlier candidates [I]:
- E02 acceleration: only if velocity helps.
- E14 cash-limit observed fraction: likely to encode feed changes.
- E22 authentication tuple: already in the inputs; CL and CH disagreed (`CANDIDATES.csv`).
- E04 and E05: folded into F11.
- E15 to E18: folded into F19 as one blocked "profile" line.

## 2. First wave (priority 1), with the argument

| id | Feature | Built? | Main argument | Gate |
|---|---|---|---|---|
| F01, F02 | amount / balance, amount / remaining merchandise limit | PR #11 E13 [V] | A share of what is left, which is unitless. The model's linear embedding of a z-scored, heavy-tailed balance compresses small balances, where the share matters most (FE-CL-2026-10-19-1 section 6). | T1, T2, CQ-01, CQ-A, CQ-B |
| F04 | headroom code (overdraw, exact drain, ≥90%, 50-90%, <50%, capacity ≤ 0, missing) | FE-CL prototype [V: tests] | Turns two knife-edges into one token. | as F01 |
| F06 | `drain_24h = (S24 + x)/(B + S24)` | FE-CL prototype, on PR #11's sum primitive [V: tests] | "How much of what the account had a day ago has gone, this purchase included". It is a ratio of a sum to a sum, the kind no model in Heaton's study synthesised [S: arXiv 1701.07852, r-diff row]. It uses only earlier amounts and the current balance, never a later row's balance. | T1, CQ-01, CQ-B |
| F08 | velocity counts 5m to 30d + coverage | PR #11 E01, C5 [V] | Windows of 7 and 30 days reach past the 15-20 rows B-H15/H20 see [I]. Best literature support in the joint list [S: joint features.md]. | CQ-02, OQ-20, OQ-13 |
| F11 | MCC new in 30 days; same-MCC count in 24 h | FE-CL prototype, on PR #11's `match_count` [V: tests] | MCC is in the raw files but not among the 23 inputs [S: EDA column table]. The incumbent flags "24hr count of same MCC" as an MIFM feature [V: workbook row 127, `Yes`]. First use of a merchant type is a takeover signal [I]. | MCC present in the pod files |
| F15 | amount mid-rank among the account's earlier 30-day amounts | PR #11 E11 [V] | A unitless "unusual for this account". The FT model's history window is a small sample of the account's normal amounts [I]. | CQ-01 |

On fake data built with a planted drain mechanism, F01+F04, F06 and F11 each passed the screen, and a pure-noise column failed (`screen/tests`) [V]. **This shows only that the screen works.** It says nothing about bank data.

## 3. What the FT model can and cannot learn by itself (the filter used above)

**What the model receives.**
- Numbers enter as `z·w + b`, one z-score per field [V: `fraud/data/preprocessing.py:177-180`; `waqas/phase4a/tokenizer.py:37`].
- The history model sees the last H time-stamps of the account (V1: H up to 20) [S: README facts].

**So a feature adds most when it does one of these** [I]:
- **(a) Rescales across accounts**: ratios, ranks.
- **(b) Combines fields across rows into a ratio of differences or sums**: drain, share of the daily limit already used.
- **(c) Reaches beyond H rows**: 7- and 30-day counts, 30-day novelty.
- **(d) Brings in a field that is not among the 23 inputs**: MCC, merchant, state.

A feature that is a one-field transform of a current input adds little to an MLP-based model; Heaton found log, power and similar easy to synthesise [S]. That is why F05 (`log_bal_after`) and calendar re-encodings sit at priority 3 or are left out.

## 4. Second wave (priority 2) and blocked (priority 3)

**Priority 2** (screen after wave 1, one family at a time):
- **F03** cash ratio. `Lc` is mostly missing.
- **F09, F10** rebuilds of the incumbent's MIFM `Yes` burst features: card-present 5 min count and sum (rows 562-563), card-not-present 24 h count (row 591).
  - Rebuilding them from raw history avoids the profile-snapshot timing risk of the stored versions [I].
  - The flag codes' meanings must be given (the prototype takes them as arguments).
- **F12** merchant novelty: needs a stable merchant key, Q5.
- **F13** merchant-state novelty.
- **F16** card testing: needs a window-max primitive that PR #11 does not have.
- **F17** personal hour atypicality: CQ-02 clock.
- **F18** gap and dormancy: REF-SINGLE has no time channel at all.

**Priority 3:**
- **F05.**
- **F07** share of the daily limit used before this transaction: needs the configured cap, workbook row 564, an as-of question.
- **F14** device and IP: the fields are not in the raw extract as far as we know.
- **F19** profile fields the incumbent flags (`ledger_bal` row 237, deposit EMSD row 255): CQ-09, whether the stored value is as of the transaction.

## 5. Incumbent (15298) features: what can be rebuilt from raw history

Of the 18 MIFM `Yes` rows in the transcribed part (rows 124 to 600) [V: `waqas/feature_related/*/feature_metadata_rows_*.csv`, `MIFM_feature` = Yes]:
- **Seven rows (six features) are counts or sums over short windows of raw transaction fields.** They can be rebuilt with PR #11's primitives:
  - same-MCC 24 h (127);
  - same POS entry mode 24 h, count and sum (135, 136);
  - gas MCC 24 h (541);
  - card-present 5 min count and sum (562, 563);
  - e-commerce 24 h (591).
- **Two need a token or "verified" flag** we do not have: 595, 598.
- **The rest are account-profile values**: ledger balance, deposit counts and EMSDs, early-pay amount, ATM running count. They wait on CQ-09.
- **Caveat on the MIFM column.** What `MIFM_feature` means is not documented. CH reads it as an annotation, not an importance score [S: CH shortlist]. I use it only as "the incumbent team thought this worth flagging".
- **Rows 2-123 are missing.** The incumbent may hold more current-transaction features there.

## 6. Production state per wave [I]

- **Wave 1 needs no state** for F01, F02, F04.
- It needs one 24 h amount sum for F06, the same state as E12.
- It needs five window counts for F08.
- It needs a 30-day MCC set and a 30-day amount list or sketch for F11 and F15.
- All of this is bounded per account. It is larger than the last-17-transactions store the TFM uses [S: readme D5, D6], so it needs a feature-store decision (the readme's section 15.4 direction).

## 7. Tier under plan v4 (added 2026-10-19, from CL's message of 13:48Z; CH has still to confirm)

- **No-state, current-row only (tier 0 for S1):** F01, F02, F03, F04, F05.
  - Kept unless SELECT shows a resolved degradation.
  - Preconditions: `final_pass` (which includes the `null_noise` floor), check g's "before" verdict for each field used, and the input-availability gate.
  - F03 also needs check g's verdict on `available_daily_cash_limit_amt`. That field is mostly missing, so its check g cells may be thin.
- **Per-account state (tier 1: +0.005 and the screen):** F06 to F19.
- F06 `drain_24h` is tier 1 even though it is a capacity idea, because it needs a 24 h amount sum per account.

## 8. Distance and travel: F20-F23 (Waqas, 2026-10-19)

Waqas's words: "maybe we can do distance from previous transaction. And then we can do distance and time from transaction; some type of math for that" [S: `bridge/OWNER_QA.md`, main `6d95b67`]. CL proposed the definitions. Below is what I kept, what I changed, and why. Code: `screen/features_new.py` (`travel`, `dist_usual`, `dist_home`), 8 tests in `screen/tests/test_location.py` [V].

### Plain-language summary (for Waqas)

- **What it is.** We turn each card-present purchase's merchant postal code into a map point. Then we ask:
  - how far it is from the previous in-person purchase;
  - how fast the card would have had to travel to get there;
  - how far it is from where the account usually shops in person.
- **Why it could help.** The model has no location at all today. A card used in New York and then in Los Angeles an hour later is a classic sign of a copied card.
- **What it needs from you.** Two things:
  - confirmation that the postal-code fields are in the files and filled in;
  - permission to put a public postal-code-to-coordinates table on the pod.
- **Home distance waits.** Distance from home uses the cardholder's address on file. It waits until we know that address is the one on file on the transaction's day, not a later one.

### Definitions (changes from CL's proposal marked)

| id | Columns | Formula |
|---|---|---|
| F20 | `dist_prev_km_log1p`, `loc_prev_status` | haversine from the current merchant postal centroid to the **latest strictly earlier card-present located row within 30 days** (change: a 30-day lookback, so the stored state is bounded and censoring follows PR #11). Status values: `ok`, `not_card_present`, `unknown_location`, `no_prior_location`, `censored` |
| F21 | `speed_kmh_log1p`, `impossible_travel` | `v = d / max(gap, 60 s)`; the flag is `v > 900 km/h and d > 50 km` (CL's thresholds kept) |
| F22 | `dist_home_km_log1p` | merchant centroid to the home postal centroid, card-present rows only |
| F23 | `dist_usual_km_log1p`, `loc_rog_30d_km_log1p`, `loc_support_30d`, `postal_seen_30d` | **Change:** the **mean** of the earlier card-present centroids in 30 days, not the medoid, plus the radius of gyration and a "postal code seen before" flag. Means, squares and counts are PR #11 window sums, so the state is five running sums. A medoid needs every point. A two-centre account (home and work) can have a mean between its two centres, which is why `postal_seen_30d` and the radius go with the distance |

**Rules common to all four** [V: tests]:
- Only card-present rows are location evidence, at both ends. A card-not-present row's merchant postal code is a registered address.
- Same-time rows never see each other.
- A postal code that is not a 5-digit US ZIP never gets a centroid, so it is treated as missing. ZIP+4 forms collapse to 5 digits. Foreign codes are unknown until `merchant_state_xcd`'s country values are known.
- Every location column is fed as `log1p(km)` with a status token.

**ATM rows.** I did not exclude them. An ATM is a physical location, so it is good evidence for travel [I]. `transaction_type_xcd` stays in the base, so the model can tell ATM from purchase. If CQ-A shows ATM postal codes are unreliable, add an `atm` exclusion.

### Trust protocol for F20-F23 (on top of TRUST.md)

- **Stage 1, validity.**
  - Merchant postal code: known at authorisation for card-present rows [I; LQ-c].
  - The centroid table must be a fixed external file (for example the public US Census ZCTA Gazetteer) and must not be built from these data.
  - F22's home postal code is a profile field. Hold it at tier 1, and do not read it at all until CQ-09 certifies it point-in-time.
- **Stage 2, leaks.** `future_invariance` now also permutes the postal, presence, MCC and type codes of later rows. F20-F23 pass it [V].
  - Specific trap: building "usual location" from the whole account history instead of strictly earlier rows.
  - The test `test_dist_usual_mean_and_seen` pins strictness.
- **Stage 3 caveat.** Postal-centroid noise is large next to in-town moves: a few km in cities, tens of km in rural areas [I]. So a gain is more likely from the long-distance tail (F21's flag, F23's far-from-usual) than from `dist_prev` in town. Report the screen's by-group split on `loc_prev_status`.
- **Tier (plan v4):**
  - F20, F21 and F23 hold per-account state, so they are tier 1.
  - F22 is tier 1, and stays held, until CQ-09.

### Data facts so far [S: saved EDA, 2 files]

| Field | Missing | Unique values |
|---|---|---|
| `merchant_postal_xcd` | 5.6% | 39,909 |
| `cprsrvc__pisinfo_cardholder_postal_xcd` | 1.7% | 4,202 |
| `merchant_state_xcd` | (described as "state (or country)") | – |

39,909 merchant postal values is more than the roughly 33,000 US ZCTAs [I: approximate public figure]. So foreign codes, ZIP+4 forms or other formats are present. The pod needs a format count first: LQ-a.
