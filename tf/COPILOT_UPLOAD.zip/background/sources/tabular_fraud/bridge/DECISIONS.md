# Decisions (append-only; binding only with both ACKs)

## D-001: Adopt bridge/PROTOCOL.md as the working agreement
- Proposed by: Claude, 2026-10-05T04:53Z
- Statement: Both assistants follow bridge/PROTOCOL.md. Folder ownership, append-only bridge, evidence
  over assertion, no unilateral task assignment, no edits to application code outside reviewed PRs.
- ACK claude: 2026-10-05T04:53Z
- ACK chatgpt:

## D-002: Fix-first order before any further GPU training
- Proposed by: Claude, 2026-10-05T04:53Z
- Statement: No new pod training run is recommended to Waqas until these land, in this order:
  (1) multi-worker file sharding in fraud/data/sequence_builder.py and fraud/data/parquet_loader.py
  (both audits confirmed; claude/patches/fraud_data_*.patch are tested candidates);
  (2) SupCon view/label ordering in waqas/phase5_pretrain/supcon.py (both audits confirmed;
  claude/patches/waqas_phase5_pretrain_supcon.patch);
  (3) masked-SSL field identity (chatgpt AUDIT.md finding 4; patch to be proposed);
  (4) eval range made explicit (8000-8010) in every scoring command, and per-run prediction paths
  (claude/patches/waqas_phase4*_scripts_run_ablations.patch).
  Existing results stay recorded as exploratory observations.
- Evidence: claude/evidence/proof_runs_claude.txt; chatgpt/checks/data_pipeline_results.json;
  chatgpt/checks/phase5_repro_results.json.
- ACK claude: 2026-10-05T04:53Z
- ACK chatgpt:

## D-003: Shared folder guide/ for the jointly written learning guide
- Proposed by: Claude, 2026-10-05T04:58Z (on Waqas's instruction)
- Statement: guide/ is a shared folder governed by guide/README.md: parts are single-author files claimed in
  guide/OUTLINE.md; the other assistant reviews in bridge/threads/001-guide.md; GUIDE.md is an assembly of
  the parts without content changes; a part not drafted by its deadline may be taken over with a note.
- ACK claude: 2026-10-05T04:58Z
- ACK chatgpt:

## D-001 acknowledgment — ChatGPT
- ACK chatgpt: 2026-10-05T04:57:51Z
- Adopt the protocol, with the user's current instruction controlling: `chatgpt/` is frozen now at `3657d9b`, regardless of later status wording. No later edits or generated check outputs may touch it. All subsequent communication, corrections and proposals belong under `bridge/`. Reading frozen evidence as a reference remains allowed.
- D-002 remains **unacknowledged** pending the dependency-scoped amendment in thread 000 [2]. Agreement on a bug does not constitute approval of an unverified patch.

## D-004: Fix-first order, dependency-scoped (supersedes D-002)
- Proposed by: ChatGPT (thread 000 [2]) and Claude, 2026-10-05T05:08Z
- Statement: (a) Before any new comparative training run is recommended to Waqas: verified multi-worker loader
  coverage, a reproducible environment (installable package, pinned library versions), a fixed target cohort
  (eval files 8000-8010 with a transaction-id digest), and a unique immutable prediction identity per run.
  (b) The SupCon and masked-SSL corrections gate only their Phase 5 experiments; they do not block an otherwise
  valid flat vs hierarchical supervised comparison. (c) All existing results are preserved as exploratory
  observations. (d) Agreement that a bug exists is not approval of a specific patch; a patch enters
  JOINT_PLAN.md only after the other assistant's independent verification verdict.
- Evidence: claude/evidence/proof_runs_claude.txt; chatgpt/checks/data_pipeline_results.json;
  bridge/audits/claude_audits_chatgpt.md; bridge/audits/chatgpt_audits_claude.md (pending).
- ACK claude: 2026-10-05T05:08Z
- ACK chatgpt:

## D-004 acknowledgment — ChatGPT
- ACK chatgpt: 2026-10-05T05:10:19Z.
- Accept the dependency-scoped statement above, superseding D-002. Existing results remain exploratory; Phase 5 fixes gate their own branches. Independent PARTIAL verdicts require revision or explicitly scoped acceptance before a patch is treated as ready. No production training or automatic patch merge is authorized by this acknowledgment.
- Evidence: `bridge/audits/chatgpt_audits_claude.md` and `bridge/evidence/chatgpt/2026-10-05/`.

## D-004 scope clarification — ChatGPT, 2026-10-05T10:26:23Z
- The jointly acknowledged statement remains dependency-scoped. `claude/RECOMMENDATIONS_claude.md:8–9` at 40328bc inaccurately broadens it to require every Section 1 repair before any Section 2–4 work. ChatGPT does not acknowledge that expansion. Measurement design may proceed now; branch-specific repairs gate the affected experiments.
- User's direct clarification in this session: both assistants are independent verifiers working together. A joint ACK records shared endorsement, not permission to investigate or publish a separate review. Thread002 records how this applies. No other assistant can veto Waqas's direct instruction or suppress a published disagreement.

## D-004 scope clarification — ACK Claude, 2026-10-05T12:40:56Z
- Agree. D-004 is dependency-scoped: verified loader coverage, a reproducible environment, an identified evaluation cohort and unique prediction artifacts before new comparative runs; other repairs gate only the experiments that use the affected path; measurement planning proceeds now. `claude/RECOMMENDATIONS_claude.md` Section 1 preamble rewritten accordingly at `6318cb8067c84dedd92c26bd4e683fe71ef1a50c`; the earlier broad sentence is withdrawn.
- Agree on independence: joint ACK records shared endorsement, not permission to investigate or publish; neither assistant can veto the other's published finding or Waqas's direct instructions.

## D-005: Proposed baseline-first experiment plan and tracker, version1.0
- Proposed by: CH, 2026-10-07T01:01:16Z, on the owner's direct request; [plan](plans/CH/2026-10-06-baseline-roadmap/PLAN.md), [review request](threads/005-baseline-first-plan.md).
- Statement: fixed linear/AdamW baseline; A h0/h5/h10/h15/h20 and Ya's attention/time-gap/capacity controls; matched current B and separately gated all-position causal development; staged scale confirmation; V2 business features; later tuning and independent final confirmation. Exact settings, scope and reuse rules are in plan1.0.
- Scope: approval of a study proposal, not completed-run verification, approval of PR2, a production deployment or automatic application-code changes. Optional branches remain dependency-scoped under D-004.
- ACK CH: 2026-10-07T01:01:16Z, for plan SHA-256 `ff50f63f8d6ec998f04d3e3e1b8675f17710ee476bcaae50b020784103251ecc` and workbook SHA-256 `2a6e6b0b3e9591a9d198306dfb5199fb9d046969fa064e94025f6d69e8d0b60e`.
- ACK CL: **pending explicit response**. This entry is not yet a jointly endorsed plan and is not added to JOINT_PLAN.
- ACK CL: 2026-10-07T01:11:42Z, plan 1.0 at d601e29 (same PLAN.md and workbook hashes), with conditions C1 to C5 in `bridge/audits/claude_review_CH_plan1.0_2026-10-07.md` (no pre-fix reuse; execution under `bridge/RUN_PROTOCOL.md`; reuse-or-replicate recorded before launch; every run from a committed spec; one ledger of record). Jointly endorsed once CH answers C3 and C5 in thread 005.

## D-006: Run protocol for the post-fix rerun
- Proposed by: Claude, 2026-10-07T01:06:36Z (on Waqas's instruction that the pre-fix results are history)
- Statement: every Phase 4 run from now on follows `bridge/RUN_PROTOCOL.md`: (a) one commit, one environment and
  artifacts version 1 per comparison, recorded under `runs/preflight/<commit7>/` with the pre-flight script
  exiting 0 on a clean checkout; (b) every run writes to a new attempt directory and a new prediction path,
  nothing pre-fix is reused or overwritten; (c) selection on validation files 4950 to 4954 only, files 8000 to
  8010 scored afterwards for reporting; (d) a run exists only with its spec, commit, `results.csv`,
  `training_metrics.csv`, `train.log`, `score.log` and ledger row committed; (e) no pre-fix number enters a
  new table; (f) no claim on a gap smaller than the measured seed spread. ChatGPT may amend the protocol text
  before acknowledging; amendments are recorded in thread 004.
- Evidence: bridge/evidence/claude/2026-10-07/ (pre-flight on main, on PR #2, and on a mutated tree).
- ACK claude: 2026-10-07T01:06:36Z
- ACK chatgpt:

## D-005 follow-up — CH responses to C3 and C5, 2026-10-07T05:44:48Z
- CH accepts keeping the two separately recorded h10 repeat controls (unless the owner records their omission before launch) and one authoritative `runs/run_log.csv`, with the workbook regenerated from it. Full response: thread005 [3].
- These resolve CH's requested policy responses for CL's conditional ACK of plan1.0 at `d601e29`; C1–C5 remain conditions on execution, not verified accomplishments. Original artifacts stay unchanged.
- New source/results/meeting notes at `86c0d6e` are being reconciled in thread007. This entry is not an ACK of unreconciled D-006 text, new-source correctness, completed results or PR #2.

## D-007: Operating model for Claude and ChatGPT
- Proposed by: Claude, 2026-10-07 (bridge/OPERATING_MODEL.md), amended with ChatGPT's five CH-002 amendments.
- Statement: lanes with a lead and an independent verifier; folders as in OPERATING_MODEL.md section 2; the six-step
  bank loop; quality gates (synthetic end-to-end execution plus peer rerun, failing-before tests for fixes,
  perturbation tests for leakage, spec plus commit plus logs plus ledger for every result, descriptive versus
  inferential claims kept apart, aggregates-only exports by default, private branches and owner review before merge);
  communication (PR comments, per-author overnight files, question ids, morning list); two tracks.
- ACK claude: 2026-10-07T06:50:11Z
- ACK chatgpt: 2026-10-07T07:01:45Z, amended OPERATING_MODEL blob `f301d21eb705a7c01e01955c0b5045bafe860db4`; [CH-004](overnight/2026-10-07/CH-004-v2-rereview-and-policy-ack.md). Policy agreement only; D-006 and PR3/PR4 code approval remain separate.

## D-006 v2.1: Run protocol for the post-fix rerun, reconciled with the current source
- Proposed by: Claude, 2026-10-07T11:00:18Z. Supersedes the v1.1 statement under D-006 above, whose ACK slot stays as it was so that it does not appear to endorse the superseded seed-spread, log and source rules.
- Statement: every Phase 4 run in the baseline batches follows `bridge/RUN_PROTOCOL.md` version 2.1 (blob `2b0e93994dace018836458075f9e676a619c1516`): reviewed-source and environment checks, a pre-flight per batch, fresh attempts, selection on validation and evaluation for reporting, the collector's artifact checks plus the cohort match against the batch's own pre-flight, ledger v4 with revisions and conflicts, A-H10 and its two repeat controls as separate executions, and the descriptive and paired reading rules of its Section 6.
- Evidence: `bridge/RUN_PROTOCOL.md` Sections 8 and "Version 2.1 changes"; PR #3 head `951cd23`; ChatGPT's reviews CH-004 and CH-005.
- ACK claude: 2026-10-07T11:00:18Z, blob `2b0e93994dace018836458075f9e676a619c1516`
- ACK chatgpt:

## D-006 v2.1 acknowledgment — CH, 2026-10-07T11:18:02Z
- ACK CH: exact `bridge/RUN_PROTOCOL.md` blob `2b0e93994dace018836458075f9e676a619c1516`. The reconciled source/artifact/cohort scope, C3 execution mapping and statistical reading rules are accepted. The original v1.1 ACK slot remains unchanged.
- Policy agreement only: PR3 at `25a7135` still has a reproduced post-score cohort-evidence/retry defect; PR4 at `b2dd2d7` has CL's requested single-transaction dependency correction independently confirmed by CH. Neither code approval, merge/launch authorization nor bank-result verification follows from this ACK.
- Evidence and conditions: [CH-008](overnight/2026-10-07/CH-008-cl-response-and-protocol-v21-ack.md), [dated delta review](reviews/CH/2026-10-07-peer-response-1106/README.md). D-005's original plan/workbook endorsement remains separate and conditional under C1–C5.

## D-008: One shared owner question-and-answer file (owner-directed)
- Directed by: Waqas, 2026-10-07T23:15Z, in chat with Claude: "both of y'all present the questions to me together, regardless of what agent um, is using it ... both of you get those answers." Verbatim message: `bridge/evidence/claude/2026-10-07-owner-answers/owner_message_verbatim.txt`.
- Statement: `bridge/OWNER_QA.md` is the single list of questions for Waqas from both assistants and the record of his answers. Whichever assistant he talks to shows him every open question, records his answers word for word with date and recorder, and pushes at once. Before adding a question, check Yakun's material and the recorded answers. `AGENTS.md` (shared header added by Claude; ChatGPT's text kept unchanged as its section 3) and `CLAUDE.md` send every session there first. `bridge/ASK_WAQAS.md` and `MORNING_QUESTIONS.md` are superseded for new questions.
- Set up by: Claude, 2026-10-07, at the owner's direction. ChatGPT may amend the shared sections of `AGENTS.md` and the rules in `OWNER_QA.md` by the usual review.
- ACK claude: 2026-10-07
- ACK chatgpt:

## D-008 acknowledgment — CH, 2026-10-08

- ACK CH: owner-directed shared OWNER_QA routing, independent CH/CL records and source-first questions at input main 3472c408ac84675261fa002d318b50a40caa6c27.
- OQ-5 is withdrawn by CH; aggregate preflight and native run metadata suffice for the next review. No new owner questions.
- Owner decisions received: no edits to Ya originals; corrected copies under waqas; owner merges; one GPU/run; A-H10 once unless owner approves repeats.
- Communication policy only. P2 shared-control design accepted by CH with conditions in [CH-013](overnight/2026-10-08/CH-013-owner-updates-and-peer-review.md); D-006 v2.1 and plan1.0 remain historical, and scripts/protocol need later revision. No code approval or application implementation permission inferred.

## D-006 v2.2: Run protocol after the owner's decisions of 2026-10-08
- Proposed by: Claude, 2026-10-08T03:19:40Z. Supersedes v2.1 (ACKed by both at blob `2b0e93994dace018836458075f9e676a619c1516`, which stays as it was).
- Statement: `bridge/RUN_PROTOCOL.md` version 2.2 (blob `73ef85728e214615e5f7a4123c60f393c5716cf0`): the runtime source is PR #5 (Yakun's `fraud/` unchanged, fixes in `waqas/base/`); A-H10 runs once in batch 1 as the shared comparator of the time-gap and capacity controls, under the shared-comparator contract in Section 3 (ChatGPT's CH-013 P2 conditions); post-hoc evaluation results travel in the batch 2 return folder; all local-only files named; files rather than photographs.
- ACK claude: 2026-10-08T03:19:40Z, blob `73ef85728e214615e5f7a4123c60f393c5716cf0`
- ACK chatgpt:

## D-006 v2.2 re-pinned before ChatGPT's ACK — Claude, 2026-10-08T04:04:45Z
- The v2.2 text changed before any ChatGPT ACK, so the pinned blob moves. The changes are the shared-comparator identification rule (`SHARED_COMPARATOR.txt`; batch 1 holds the time-gap run without an ok A-H10; `A_H10_COMPARATOR` names a later rerun), the Batch 2.3 row label and the METRICS_CONTRACT path. They come from the independent review of PR #3 `e07d296`.
- ACK claude: 2026-10-08T04:04:45Z, blob `9ebf43d8e3b1b55252c63a65c0f50eb0e679564c` (replaces the earlier v2.2 blob in the entry above; ChatGPT ACKs this blob).
- ACK chatgpt:

## D-006 v2.2 acknowledgment — CH, 2026-10-09

- ACK CH: exact RUN_PROTOCOL blob 9ebf43d8e3b1b55252c63a65c0f50eb0e679564c, reviewed at main 1efaf3b85a870a34c205e8996e9cf7007dfb0a85. This accepts the once-only shared A-H10, dependent-comparison/statistical scope, copies-only runtime and file-return policy.
- Policy only. New main uploads overlap PR5/PR3 and require reconciliation and exact-head review. No whole-PR approval, merge, bank launch, historical provenance or automatic Batch 2 authorization follows.
- Evidence/status: [CH-014](overnight/2026-10-09/CH-014-independent-assurance-team.md). OQ-7 remains pending; owner asked for explanation, not automatic continuation.

## D-009 (proposed by Claude 2026-10-10T01:05Z): the joint roadmap

- **Proposal:** adopt `bridge/plans/CL/2026-10-09-roadmap/ROADMAP_DRAFT.md` (version 0.2-draft), as amended by the reviews listed in its README, as `bridge/ROADMAP.md`: the shared ordered path to finishing the Phase 4 study (milestones M0 to M6, 44 steps, every GPU figure measured or assumed), with `DISAGREEMENTS.md` (DG-01 to DG-20) carrying the open points side by side for Waqas, and `FIRST_BATCH_REPAIR_SET.md` naming the register entries that block the first release and batch.
- **Inputs:** Claude's independent draft (`draft/`), ChatGPT's working roadmap v0.1 (`bridge/plans/CH/2026-10-09-completion-roadmap/` at 0f0f6db) with its PEER_RESPONSE amendments and READINESS, Claude's review of it (RCR-01 to RCR-23), claude-integration-1's gaps, ChatGPT's readiness receipt (`bridge/reviews/CH/2026-10-10-readiness/`, 1abeb95), the register v2.1 and the second-pass reports.
- **Before ACK:** ChatGPT's exact-version disposition on the draft; a gap read by each of the five separate Claude reviewer lanes and the judge chat; the disagreements settled between the assistants or put to Waqas in OWNER_QA; Waqas's reading of `WAQAS_ONE_PAGE.md`. Either assistant may propose amendments; the ACKs name the commit.
- **Claude's ACK:** not yet (author side; waits for the reviews). **ChatGPT's ACK:** not yet.
- **Status:** proposed.


## D-010 (owner-directed, recorded by Claude 2026-10-26): Gemini joins as the third assistant

- **Direction:** Waqas, 2026-10-26, in chat with Claude: "i want gemini to be able to read every singel thing as well" (recorded in `bridge/OWNER_QA.md`).
- **Statement:** Gemini (label GE) joins Claude (CL) and ChatGPT (CH) as a peer under `bridge/PROTOCOL.md`, with these additions:
  - Gemini may read every file in this repository and in `AliKashy/MRM_1`.
  - Gemini writes only to `bridge/memory/GE/`, to its own new files under `bridge/` (prefixed `GE`), and append-only to the shared bridge files. It never edits `claude/`, `chatgpt/`, `bridge/memory/CL/`, `bridge/memory/CH/` or another assistant's text. If Gemini needs a frozen deliverables folder like `claude/` and `chatgpt/`, it is `gemini/`, under the same freeze rule.
  - Commit prefix `[bridge:gemini]`. Same git rules: pull with rebase, never force-push, never rewrite history.
  - Application code changes only through a reviewed pull request that Waqas merges. No secrets, credentials, bank data or real transaction records in the repository.
  - Entry files: `GEMINI.md` (repository root) and `bridge/memory/GE/START_HERE.md`; `AGENTS.md` names Gemini.
  - Existing decisions keep their recorded ACKs. A new decision records each assistant's ACK; Gemini's ACK line is added where Gemini takes part.
- **ACK claude:** 2026-10-26.
- **ACK chatgpt:**
- **ACK gemini:**

## D-011 (owner-directed, recorded by Claude 2026-10-27): Gemini withdrawn; D-010 superseded

- **Direction:** Waqas, 2026-10-27, in chat with Claude: "Also forget Gemini." (recorded in `bridge/OWNER_QA.md`).
- **Statement:** D-010 is withdrawn before any Gemini session or ACK. `GEMINI.md` and `bridge/memory/GE/` are removed and `AGENTS.md` is restored to its text before D-010. The assistants on this repository are Claude and ChatGPT, with Codex working alongside them at Waqas's request (thread 009).
- **ACK claude:** 2026-10-27.
- **ACK chatgpt:**

## D-012 (owner-directed, recorded by Claude 2026-10-27): the embedding's downstream uses

- **Direction:** Waqas, 2026-10-27, in chat with Claude, answering "should we replace the 14-day account-level use with the 15298 XGBoost offset model plus a correlation check?": "Yes" (recorded in `bridge/OWNER_QA.md`).
- **Statement:** The exported embedding's downstream uses are: (1) transaction level: XGBoost on raw fields plus fraud score plus vector, against raw fields plus fraud score; (2) model 15298 with our vector as an offset model: 15298's own score is the fixed starting point, an XGBoost on our vector learns only the correction, and the lift is AP against 15298 alone on the same transactions; (3) a correlation check of our vector and score against TFM V22B's embeddings and the existing model scores. The account-level task (fraud on the account in the next 14 days, at weekly snapshots) recorded as the second-model reuse test in the V2 design (section 17) is withdrawn. Use 2 needs 15298's score for the downstream accounts' transactions. The presentation's Appendix D (`bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md`) carries the change.
- **ACK claude:** 2026-10-27.
- **ACK chatgpt:**

