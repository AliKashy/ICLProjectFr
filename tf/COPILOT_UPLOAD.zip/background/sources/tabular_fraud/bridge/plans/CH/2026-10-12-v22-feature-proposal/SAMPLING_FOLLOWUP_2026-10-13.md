# Account/customer sampling and the forthcoming 15298 features

CH interpretation, recorded 2026-10-13 UTC. Source snapshot: `e98ef2f`; new evidence is the owner's message quoted in [OWNER_QA](../../../OWNER_QA.md). Documentation only. No new data inspection, model result or CL acceptance is claimed.

## What Jie Chen said

The owner reports that **Jie Chen, director**, replied to Xiaoming's email:

> If we do time series-based feature engineering, I think it is more appropriate to do account/customer level sampling rather than transaction level sampling.

The original reply timestamp/file was not provided. The quote is appended separately to the [email archive](../../../../waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md). The following interpretation is CH's, not additional email text.

## What this means

**Reduce the number of accounts you study while keeping the required history for each selected account.** Randomly removing transactions first can change counts, spending totals, time gaps, novelty and which events appear to be the “last five.” Account/customer sampling is a way to reduce compute without fragmenting each selected entity's available history, provided the source itself retains that history.

Illustration, not bank results: an account had 100 transactions yesterday. Keeping 1% of its transactions leaves one transaction on average, so a count built from that sample describes the sampled feed. Selecting 1% of accounts and retaining all 100 transactions for any selected account preserves that account's count. This does not automatically establish the sample's representativeness or remove upstream missingness.

Xiaoming's preferred order and Jie's advice are compatible:

1. Obtain sufficient eligible history for the entity and feature being measured.
2. If reducing the history population, select whole accounts/customers and preserve their needed histories.
3. For each scored transaction, derive features using only information available at that time. Keep history-source rows separate from the target rows used for model fitting/evaluation.
4. If training targets are subsequently downsampled, do not delete the history needed to construct their features or sequence windows. Compute/store the full features or resolve windows against the preserved source history.

An alternative remains valid: sample target transactions, but retrieve their complete eligible prior histories from a separate full-history source. The problem is computing features from a thinned history, not the mere presence of transaction sampling in a pipeline.

## Choose the entity to match the feature

| Feature scope | History needed | Consequence for sampling |
|---|---|---|
| Account count, spend, time gap, recent sequence | Eligible prior events for that account | Whole-account sampling can preserve these values within the available observation window. |
| Customer behavior across several accounts | Stable customer-to-account mapping and all relevant accounts | Keeping one account alone does not preserve customer-level activity. Select customers and retain the necessary accounts, or obtain the aggregate from a complete source. |
| Card authorization counter | The actual card identity, event definition and reset semantics | An account is not automatically one card; account sampling alone does not settle this feature's definition. |
| Portfolio merchant/device activity | Events across the relevant population | Sampling accounts can still distort these aggregates. Compute them on the appropriate population or explicitly define them as sample-based features. |

The result is still a **per-transaction fraud prediction**. Sampling by account does not change the model into an account-level classifier.

## What our existing files establish

The [data-path email](../../../../waqas/additional_info/data_path_information_email/data_path_information_email.md) says TFM data is partitioned by account into 10,000 buckets, with subsets of at most 5,000 training and 2,000 testing files. It gives October 2024–May 2025 for training and May–June 2025 for evaluation files, with June as that email's intended target month and May as history. That source description does not silently replace the current experiment's scoring contract.

Selecting complete bucket files is compatible with preserving the available histories of included accounts. **Account partitioning does not establish that the underlying extract is unsampled, that every required lookback is complete, that bucket selection is representative, or that all accounts of one customer share a bucket.** Xiaoming's “all fraud plus 1% good” example is not evidence that our TFM extract uses that policy.

The existing coverage return can describe the provided rows and date ranges. It cannot prove the absence of transactions omitted upstream. If a chosen V2 feature needs this fact, use the upstream extraction/sampling definition and history coverage for that feature; do not add another generic pre-flight or halt V1 solely because of this email. If actual evidence later establishes a material history defect, explicitly identify affected V1 claims and decide the correction from that evidence.

## Statistical and encoding implications

- Full-history sampling preserves relevant feature values under the conditions above; it does not guarantee representative fraud prevalence. Uniform versus risk/label-stratified entity selection and any later target downsampling need their inclusion rules recorded. Metrics/weights must match the intended population; equal weight per account is a different question from equal weight per transaction.
- Select a time split appropriate to the study and compute every feature as of each transaction. Entire-account retention is not permission to use later events, later-resolved fraud labels or full-account lifetime totals. Same-timestamp events retain the established strict-prior rule unless stronger availability evidence supports a different contract.
- Repeated accounts in chronological training and evaluation are not automatically leakage when the intended task scores returning accounts with legitimately available history. An unseen-customer study is a separate split/claim. Do not impose an account-disjoint split solely from this sampling recommendation.
- Feature-construction sampling, train/test splitting and account-cluster bootstrap uncertainty are different operations. The existing paired-account analysis does not reconstruct missing historical transactions.
- Frequency/target encoding remains a separate representation choice. Target encoding uses labels: training rows need a chronological out-of-fold/ordered design that excludes their own and unavailable future labels; evaluation labels never fit it. Whole-account sampling does not solve encoding leakage. The existing [encoding proposal](README.md#encoding-choices-and-interpretation) remains conditional, not a claim that target encoding is best.

## How the 15298 upload will change the V2 proposal

The owner will provide **15298 feature importance and the full XGBoost feature list**. This message does not supply those artifacts. Extend the existing V22/engineered-feature catalogs once they arrive, rather than creating a second feature program:

1. Preserve exact model/version, feature names and the importance measure (for example gain, split count or SHAP); keep different measures distinct.
2. Map each feature to its documented meaning, raw inputs, entity key, eligible event population, lookback/formula, units, missing/reset behavior and score-time availability. Separate raw, engineered and post-encoding inputs; do not count encoded dimensions as independent business fields.
3. Record whether current TFM fields/history support it, a new derivation is possible, or an upstream source/definition is missing. For aggregates, distinguish complete elapsed-time history from the model's H-row window.
4. Prioritize a small supported set and compare it against the matched original-feature control, then useful combinations and group removals as already proposed. XGBoost importance helps prioritize investigation; it does not prove incremental FT-Transformer improvement, portability or absence of leakage.

No V1 predictor, cohort, frozen artifact, checkpoint or published005 file changes in this update. V2 remains a separately versioned proposal. CL is to receive this evidence and can record concrete corrections or additional implications; posting the handoff is not agreement.
