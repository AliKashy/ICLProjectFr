# Proposed V2 feature engineering: a small, testable catalog

CH source analysis, 2026-10-12. Reviewed source `bfdfde54973ef19f320fce08d5a13d2a1a2f1888`. This is a design catalog, not implemented features, measured performance, a bank-side execution claim, or an external CL acceptance. Application source was not edited.

`ENGINEERED_FEATURES.csv` contains **24 candidate definitions**, grouped into **six families**. Some definitions emit multiple scalar features; 24 is a count of candidate definitions, not the final input dimension. It is a menu, not a proposal to add every candidate or run every combination.

## What is actually available

- The current `fraud/configs/predictors.csv` has 23 predictors: six continuous, 13 raw categories and four calendar categories.
- The supplied `waqas/features/feature_importance_v22_v17_highlighted/feature_importance.csv` has 120 ranked rows labeled **V22B Model**. Its directory name contains V17, but that does not establish a separate V17 model's feature list or attribution. Ranking is an investigation lead, not proof of usable raw columns, as-of availability, causal importance or incremental FT-Transformer lift.
- `waqas/docs/meeting_notes.md` §§2/7 specifically asks to trace engineered-to-raw mappings using 15298/Table 2.35, adds the chip-card authorization-count idea, and records the lagged-value/counter-reset questions as unresolved. Those notes also propose 90-day elapsed-time windows; the present 30-day candidate cap reuses the later joint V2 design, not a claim that Ya mandated 30 days. A 90-day condition needs enough prior extract history, which the current 61-day evaluation span alone cannot supply. A common time window does not establish equal account tenure or equally complete observation.
- Ya explicitly requests richer raw features/high-cardinality encodings in `docs/phase4_sequential_plan.md` §10.D and feature ablation before increasing model capacity in §10.G. This proposal follows that request.
- Ya's EDA names MCC, merchant ID, merchant postal, cardholder postal, merchant state, ATM network and a 3DS IP field beyond the baseline. Exact raw mapping for most uppercase V22B display names remains unproven. Do not automatically lowercase those display names into a schema.
- Existing CH F01–F22 (`bridge/plans/CH/2026-10-09-feature-engineering/FEATURE_BACKLOG.md`), CH R3 (`bridge/plans/CH/2026-10-12-v2-research/R3_TRANSACTION_TIME_FEATURES.md`) and CL joint feature proposal (`bridge/plans/CL/2026-10-12-v2-research/joint/features.md`) already cover many ideas. This catalog makes definitions and prerequisites more explicit; it does not claim to rediscover those ideas or settle the remaining joint-design disagreements.

## Start small

| Family | Candidate definitions | Suggested use |
|---|---|---|
| P1: activity | E01 declared prior counts; E02 acceleration; E03 recency | Start E01 with5minute and24hour windows only. Other windows are later predeclared variants. E02 is a follow-up transform; E03 has strong overlap with the existing time channel. |
| P2: familiarity | E04 distinct MCC; E05 MCC frequency; E06 merchant unseen; E07 merchant recency; E08 transaction-type frequency; E09 3DS IP unseen | First pilot **raw MCC** as a categorical input, which is not in the engineered-feature count. Then E05; assess other members individually. IP is conditional and later. |
| P3: amount | E10 difference from personal median; E11 empirical rank; E12 prior spend; E13 amount/capacity ratio | Conditional on exact currency/type/sign definitions. E10 and E11 are alternatives initially, not automatically a bundle. |
| P4: business state/change | E14 missingness history; E15 profile/address change recency; E16 token age; E17 card issue age; E18 account age; E19 PIN-set recency; E20 chip-card authorization count | Exact snapshot/entity mappings needed for E15–E20. These are candidates to request from the business, not presumed extract columns. |
| P5: contextual interactions | E21 compatible postal mismatch; E22 authentication/context tuple | Later low-complexity interactions after field dictionaries and simple raw-feature pilots. |
| P6: periodic behavior | E23 existing cyclic hour/day representation; E24 personal hour atypicality | Separate representation comparison; E24 is conditional on a reliable timezone and meaningful history support. |

**First proposed feature wave:** unchanged baseline, raw MCC only, E01 counts only, and E05 MCC familiarity on the MCC control. This is a short experimental sequence, not an immediate launch instruction. Keep optimizer/history/data/artifact fitting policy matched within each contrast. Accept a combination only after its constituent families have evidence; then remove each accepted group to check incremental value. The existing larger-data V2 study remains separate so increased training coverage is not mislabeled a feature benefit.

## Shared definitions and timing contract

Let `t` be the current event timestamp, with an independently defined decision cutoff. For one documented entity, `P_w(t)` contains unique eligible prior **events** whose event times satisfy **`t - w <= e_j < t`**, whose rows and feature values were known by the decision cutoff. Lower edge is included; current time is excluded.

**C1 — strict history.** Compute all features for a timestamp peer group before inserting that group into the history state. Same-time siblings never inform each other, regardless of transaction-ID ordering. Use the established stored timestamp precision; do not silently round to seconds or claim timestamp sorting establishes actual availability order. Later arrivals/corrections cannot rewrite old predictions. Event-time-only replay is conditional until the feed's as-of semantics are established.

**C2 — compute before truncation.** These main candidates use declared elapsed-time history, calculated per event **before** A/B last-H window/chunk truncation. They add information beyond H and must be named **extra-history features**. A count from only H rows is a different, explicitly window-limited condition. An h0 model with these history aggregates is a history-aggregate model, not the no-history reference. Genuine cross-file history requires either confirmed entity partitioning over the chosen file cohort or explicit cross-file state; do not infer it from filenames or the ten-file diagnostic alone.

**C3 — coverage is not tenure.** A lookback reaching before the documented extract start is incomplete. Being after extract start does not by itself prove an account was observed continuously. If complete history is not established, record unavailable/coverage status instead of claiming a full-window count or zero. Never substitute first observed row for account/card creation. Do not automatically drop censored rows or invent a 30-day warm-up cohort: retain the predeclared comparison cohort and report coverage strata. Coverage status is an artifact/interpretation requirement; whether it becomes an additional model input is an explicit feature choice.

**C4 — raw values and missingness.** Compare source categories before unrelated codes collapse to UNK. Calculate numeric summaries from valid observed values before median imputation or standardization. Unknown, not applicable, no observed support and a measured zero are different states. Reuse existing missing flags instead of duplicating them. New continuous features need a frozen transform/missingness contract; do not infer zero-MAD/zero-balance epsilon rules.

**C5 — identities and duplicates.** Account IDs group events; they are not card IDs. Numeric-looking category IDs/postal codes are strings/categories, never arithmetic magnitudes. Same-time distinct events may count as multiple prior events for a later target. Repeated `(account_id, transaction_id)` rows are not silently deleted: determine whether they are duplicate delivery, multiple lifecycle/advice events or distinct requests from the source contract. Reconcile identity once, retain counts, and version any deduplication rule. Current-to-history joins cannot multiply rows silently.

**C6 — fitting and labels.** Vocabulary/scalers/clipping/frequency representations fit on declared training data only. Deterministic as-of counters may update with earlier unlabeled activity during evaluation if that is the declared online history contract. No current or historical fraud labels, future decisions, case dispositions, current decline outcomes or post-decision fields in these candidate definitions. Mature-label target encoding is a different later study, not smuggled into this wave.

**C7 — placement is not settled by a formula.** The catalog defines each event's as-of feature values. Existing joint V2 design proposes **A target-only engineered tokens and B per-transaction encoding**; that is not automatically a matched-information or identical-placement comparison. Preserve this as an explicit unresolved input-placement choice before implementation. Do not silently broadcast a target summary across history or back into earlier all-position-B outputs. Each all-position-B output may receive only its own as-of feature values. No new model head is implied by this proposal.

## Concrete source caveats that affect these definitions

1. `transaction_amt` is in **transaction currency**; `remain_day_merchandise_lmt_amt` is described in **USD**. Current sources do not establish a usable currency/normalized-amount mapping. Amount sums, differences and ratios stay conditional. Unitless ranks still need comparable currency/type semantics.
2. `merchant_state_xcd` is described in Ya's EDA as **state (or country)**. Do not assume it is a clean US-state field or use postal subtraction/distance without a real location definition.
3. `user_data_5_strg_device_ip_address_dbc3ds` is an **IP field for 3DS**, not an established stable device ID. E09 is explicitly IP familiarity within eligible channel coverage.
4. `avs_request_xcd` is an **AVS request**, whereas V22B's `AVS_RESPONSE` is a different display label. Neither missing verification nor not-requested means failure.
5. A/default-B's baseline time channel is **log gap to the scored target for each row**, not a universally identical predecessor-gap feature. E03 is a narrowly defined recency representation and does not rename that baseline.
6. Existing `datetime_features.py` already supports cyclic encoding. Its missing timestamp handling can yield `(0,1)` for cyclic values after fill-to-zero; a proposed new use must distinguish invalid timestamp from midnight/period origin. Do not add a broad new preflight for this; use the existing builder invalid-time policy and affected focused checks.
7. The V22B card/merchant fuzzy counter cannot be reconstructed from its name alone. E06/E07 use an explicit account–merchant contract; they are not claims to reproduce `DC_AUTH_GRPBY_CARD_NUM_MRCH_NAME_FUZZY_COUNT_14_1D`.
8. Counts such as a 224-column return and prior sampled uniqueness/cardinality profiles do not establish a complete present raw dictionary or online availability. That limitation is already recorded; it need not become another repeated questionnaire.

## Deferred proposals are retained, not silently dismissed

Score changes (`external_1_scr`), balance/limit deltas, cumulative business-counter differences, and yesterday's lagged snapshots remain in earlier CH F06/F07/F19 and the meeting notes. They are not new first-wave candidates here because score versions, currency, reset clocks and as-of provenance are unresolved. A counter falling from 2000 to 1000 is neither automatically an error nor automatically fraud; it may reset, expire or represent a rolling count. A lagged value needs the value actually known at that earlier cutoff, not a later recomputation labeled yesterday.

Frequency/capped-vocabulary/hash representations can be separate raw-field pilots. The notes' claim that target encoding is inherently better for neural nets is a hypothesis, not an established project result. Train-only fitting is insufficient to prevent a training row's own label or future-resolved labels entering an encoding. No target encoding is implemented or silently adopted in this label-free shortlist.

## What would count as evidence, not just a plausible story

One small hand-computable fixture can cover the consequential failures: same-time peers, a strictly earlier tied group, both window edges, a missing current category/amount, no prior event, repeated event identity, two accounts, two currencies, a late-arriving prior event and an extract boundary. Check train/scoring definitions agree. Perturbing any future/same-time peer or another account must not change the target's history-derived features. All-position outputs must use their own cutoff. These checks address Ya's strict-before/no-label requirement and documented feature-prototype failures; they are **not** another full diagnostic package or review panel.

Measure feature quality on the pod with existing outputs: coverage, distributions, current/raw mappings, valid support and data-clock/as-of qualifications. Compare candidate groups on validation under a fixed plan; report evaluation AP and agreed temporal/account-level comparisons from the same frozen predictions. An importance ranking on another model is not an acceptance criterion. No guaranteed lift, exact run-count budget or extra-seed policy is adopted by this catalog.

## Compact unresolved dictionary items, only when their family is selected

- **All history families:** event versus decision/availability time and prior-history coverage; duplicate/advice identity semantics. These overlap existing OQ-13/OQ-20 rather than new questions.
- **Amounts:** actual currency or normalized-amount field; compatible transaction types/sign/refund definitions; balance/limit currency and applicability.
- **Business changes:** exact raw aliases, stable card/token/account/customer mapping, datetime units/clock, initial versus subsequent change, and historically preserved as-of snapshots for activation/issue/open/profile/PIN dates.
- **Authentication:** code dictionaries and which results exist by our decision, using existing timing request OQ-14.
- **Chip authorization:** stable card key, chip-capability/entry predicate and request population; source cumulative counters' reset/availability rules if using them rather than recomputing explicit prior events.

A dictionary excerpt and aggregate profiles are enough to settle these design choices; there is no need to ask for raw bank rows or credentials. Existing V1 smoke/training delivery continues independently.
