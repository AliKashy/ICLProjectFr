# Road to a production model from ALLPOS-H20-CHUNK (CL, 2026-10-24)

Owner's order (OWNER_QA, 2026-10-22): stage 1 V1 kept; stage 2 seeds and the best model; stage 3 the no-month test ("do the changes for no month etc to see if there's a lift or not");
stage 4 new features with importance and selection; stage 5 scale to about 100 files. This file adds the embedding
and feature-store work and the production steps from PLAN v6.2 and DECISIONS sections 16 and 17, in the order they
can be done. Every rule that decides a stage is written into DECISIONS before that stage's results are seen.

## Where we are

- Winner: ALLPOS-H20-CHUNK (chunk-trained, target-ending validated and scored, H20, month in). DEV_OOT AP 0.1020 /
  0.0912 / 0.1013 at seeds 42 / 43 / 44, mean 0.0982; ahead of B-H20 on every seed. Three-seed interval pending
  (`bridge/reviews/CL/2026-10-24-results-l3-seeds/cpu_reads.sh`).
- Whether it ships with month is decided by stage 3, not assumed (corrected 2026-10-27; the owner, 2026-10-26: "i dont
  think we're removing month"). The June to September month values never occur in training and read an untrained
  unknown vector. The V2 handover's `month_absent_from_model_inputs` check must follow stage 3's result.
- One model goes forward. B-H20's three seeds stay as a frozen reference. No further stage 2 fits unless the owner
  asks.

## Order of work

| # | Work | Where | Fits / passes | Gate before the next step |
|---|---|---|---|---|
| 0 | Close stage 2: B-H20 recipe check, June SELECT for seeds 43/44, three-seed paired interval, alert-budget capture | pod, CPU | 0 | numbers read; recipe check passes |
| 1 | Code of record and package 010: the three pod patches adopted byte for byte (from the code appendix and the `runs/v2/patches/` receipts), the pod's real `fraud/` and `src/` checked and the V2 tests rerun on them, the store (PR #28), the gate fixes, the DS_TRAIN rule (4001-4010), `xgboost` pinned | CL/CH, no pod | 0 | tests pass on the real files; package gate; installed bytes equal the repository's |
| 2 | Stage 3, no month: build and check the no-month artifact (`build_nomonth_artifact.py`, `check_nomonth_artifact.py`); configs derived from the exact month-in config, changing only the artifact version, the predictor list and the datetime fields (keep `deterministic: false`) | pod, CPU then GPU | 3 (seeds 42-44) | Superseded by the owner, 2026-10-27: no separate no-month test; the feature model (v2) drops month and keeps the time gap, hour, day of week and day of month |
| 3 | Stage 4, features. (a) Candidates: FE-CL's catalogue (F1-F23, distance family F20-F23), items from the data review (declines on earlier rows, advice rows, $0 address checks, same-second order, `transaction_order`), the data owner's list. (b) The CPU screen first (`waqas/v2/screen`), with gain/SHAP importance on the hand features. (c) The winning families' point-in-time input code in `waqas/v2/` with tests. (d) A new artifact version per kept set. (e) Fits: base plus family; selection of the transformer's inputs by retrain ablations (real models), not by masking inputs of a trained model | pod CPU; CL/CH code; pod GPU | 3 per family tested | rule per family written first; a family stays only on its paired reading |
| 4 | Stage 5, scale: chunk widths over files 1-100 first; then one long run of the final recipe on files 1-100 (epoch budget from the first timed epoch) | pod, CPU then GPU | 1 (long) | paired against the 10-file model of the same recipe |
| 5 | Embeddings and the feature store, from the final encoder only: (a) L4 export check (file 8000); (b) exports on DS_TRAIN (train 4001-4010) and DS_SELECT (eval 8217-8227); (c) the store (per-transaction vectors, as-of lookup, frozen scaler and PCA); (d) consumers (D-012, 2026-10-27): transaction-level XGBoost (arm 4 raw + score + vector against arm 2 raw + score, section 16); model 15298 with our vector as an offset model; a correlation check against TFM V22B's embeddings and the existing scores; each read once on DS_SELECT. The account-level next-14-day task is withdrawn | pod GPU then CPU | 3 passes | section 16 and D-012 |
| 6 | Input certification by the data owner: the clock behind hour, day and day of week; `external_1_scr`; PIN, CVV, chip and AVS results; advice rows; label maturity | data owner | 0 | every input certified, or a recorded exception and a retrained model without it |
| 7 | Freeze; FINAL once (eval 8260-8277, encoder and downstream); BENCH against the incumbent once (files 8000-8200 and its `eval_logits.npz`, after one alignment check); report by depth band and with and without declined and advice rows | pod | 2-4 passes | none: these are the final readings |
| 8 | Production handover: contracts, serving cap, same-second rule | CL/CH, pod | 0 | handover checks pass |

## Why this order

- Month goes before features because every later fit would otherwise carry a feature production cannot use, and
  feature lift measured with month in may not hold without it.
- The embeddings come last on the model side because every earlier change (month, features, 100 files) changes the
  vectors, and the plan does not allow one encoder's embeddings to stand in for another's.
- The store and export plumbing can be proven early: the L4 export check on today's winner is one GPU pass and
  catches export faults for chunk models before the final encoder exists.

## Can run now, in parallel

1. Step 0 (CPU, minutes).
2. L4 export check on ALLPOS-H20-CHUNK (1 GPU pass, file 8000, no labels).
3. Install `xgboost` and start the CPU feature screen (CPU only; it is read at step 3).
4. Send the step 6 questions to the data owner.
5. CL/CH: step 1.

## Open for the owner

- Feature importance for the transformer: retrain ablations only (default), or also a permutation diagnostic that is
  reported as a diagnostic and never as a model.
- The code appendix, the patch receipts and the pod's `fraud/` and `src/` files (step 1).
- Elapsed times of the seed-43/44 fits, to size steps 2-4.
