# V2 results through L3: package 009 install, data look, quick checks a-g, L2, L3 H20 sliding test, L3 follow-up (H20-CHUNK, H5-SLIDE)
# and Arch A holdout scoring (2026-10-21 to 22 UTC)

Every result from the pod since package 009 arrived is in this one document. Read-only audit/L2 work ran on the pod
(`/home/jovyan/k194855/tabular_fraud`) without GPU use; L3 deliberately used H200 GPU training/scoring. Reports here
contain counts, types and names only: no row values or identifiers. L3 wrote K194855-owned checkpoints/predictions and
run receipts; no K016730 artifacts or outputs were written.

## Stage names used here

| This document | V2 plan | Reviewer's labels | Pod output folders |
|---|---|---|---|
| 1. Install | before L2 | "section 0" (Response 1) | `runs/install/` |
| 2. Data look | before L2 | "step 0" (Response 1); RUNBOOK step 1 (1b-1d) in the package code | `runs/v2/data_look/` |
| 3-4. Quick checks a-g | V1 record checks, before L2 | RUNBOOK step 1 (1b-1d) in the package code | `runs/returns/quick_checks_*` |
| 5. L2 | **L2** (inventory and populations) | `runs/v2/step1/` in the package code | `runs/v2/L2_inventory/`, `runs/v2/step1/L2_selected/` |

The labels conflict: Response 1 calls the data look "step 0", while the package code files it under RUNBOOK step 1.
This document uses the plan's stage names (L1-L9) and plain names for the rest. The log folder `runs/v2/step0_logs/`
holds the logs of all four.

## Status at a glance

| Stage | Pod run | Result |
|---|---|---|
| Install | `009_20261021_180056_UTC_5ctj616u` | `installed_and_verified` |
| Data look | `data_look_20261021T231206Z` | exit 0; failed sections none |
| Quick checks a, b, c, f, g | `quick_checks_20261021T232641Z` | done (e failed on a missing path: next row) |
| Quick check e | `quick_checks_20261021T235529Z` | all six positions exit 0 |
| Quick check d | not run | not needed (section 3a) |
| L2 | `20261022T034405Z` | `L2_EXIT=0`; all gates pass; populations frozen. One code change (section 5.1) |
| L3 (H20 sliding) | `20261022T054050Z` | `L3_DONE`. ALLPOS-H20 trained, validated and scored on sliding windows: resolved degradation against B-H20 (SELECT -0.0312). Two code changes (section 7) |
| L3 follow-up H20 chunk / H5 slide | `20261022T113848Z` | H20-CHUNK and H5-SLIDE complete; SELECT and DEV_OOT paired analyses complete |
| Arch A holdout scoring (8 models x 3 populations) | `runs/v2/arch_a_scores_retry3` | complete; 24 rows written; final June/capture fields are in the pod CSV (section 8.9) |
| Seed robustness setup | `runs/v2/seed_robustness` | configured, not yet claimed running; seed 43 -> extrasmall-6-0, seed 44 -> extrasmall-1-0 |

## 1. Install

- **Package:** `009_20261021_180056_UTC.zip`, sha256 `e8520703d21769a6e8b2ab6185ce13dc2c0eddd74b79b0d29f6e68ba8e768d09`.
- **Receipt:** `runs/install/009_20261021_180056_UTC_5ctj616u/INSTALLATION.json`.
- **Personalization:** `--package waqas --id K194855 --reference-id K016730 --data-bucket mrmcd-analytics-mrm-mmr-dsai
  --artifact-bucket mrmcd-analytics-mrm-users`. Personalize and install ran on the pod (Linux), so all line endings
  are LF.
- **Files:** 52 added (including the 48 under `waqas/v2/` and `runbook/2026-10-19/quick_checks.py`); 1 replaced,
  `waqas/source_identity.py`. Nothing under `fraud/` or `src/` was written.
- **Existing dependencies:** 68 match your snapshot, 58 differ, 77 observed only, 0 missing on the pod.
  - The 58 that differ are 10 under `fraud/` and 48 under `src/`. These are real content differences, not
    whitespace.
  - The `fraud/` files: `callbacks.py`, `data/parquet_loader.py`, `data/preprocessing.py`,
    `data/sequence_builder.py`, `scripts/check_pid.sh`, `scripts/score_sequential.py`, `scripts/train_baseline.py`,
    `scripts/train_streaming.py`, `sequential_model.py`, `streaming_model.py`.
  - The pod's versions are identical to every copy we hold: our local mirror, Ya's GitHub `main` and `yw_seq`, and
    Ya's pod folder. The difference is therefore between the pod and your snapshot. Please compare on your side.
- **Package name:** `waqas`, as used by all 40 V1 pod run logs and manifests and by package 005.
  - Response 1's two corrections do not match our records:
    - the "hash ending `8de9`" (our records say `...8d09`);
    - "package name misspelled by one letter".

## 2. Data look (`data_look_20261021T231206Z`)

- **Run:**
  - A preflight run (`data_look_20261021T231108Z`, sections pod, environment, package and credentials) came first.
  - Then the full run: all nine sections finished, failed none, peak memory 2.56 GB, `DATA_LOOK_EXIT 0`.
- **Privacy check:** 5 flags. All sit in hashes, schema fingerprints, totals (such as the 158,869,453 total row
  count) or the Python build string; none is in a data value.
  - `SUMMARY.txt`: one 16+ digit run and two 9+ digit runs.
  - `environment.json`: a 7+ digit run in the Python string.
  - `schema.json`: a 16+ digit run in the fingerprint of `eval:8277`, and a schema key with a 7+ digit run.
- **Pod:**
  - 248 CPUs (cgroup quota 7.0), 2,164 GB host memory with a cgroup limit of 206 GB;
  - one H200 (143,771 MiB, 0 MiB in use);
  - 4,496 GB free on the project disk, 443 GB free in `/tmp`.
- **Environment:** pandas 2.3.3, numpy 2.3.5, pyarrow 25.0.1, torch 2.14.1, pytorch-lightning 2.6.6, scikit-learn
  1.9.1. `fraud` is imported from the project root. **`xgboost` is not installed**; it is needed from the feature screen
  and L6.
- **Package:** 74 files hashed, combined `6de53fa2...7d82`, none missing.
- **Credentials:** present and readable, no missing keys.
- **Listings:**
  - training `tfm_raw_data`: part files 1-5000, no gaps, 446.28 GB, plus 1 other object;
  - evaluation `tfm_EVAL_raw_data`: part files 8000-10000, no gaps, 49.14 GB.
  - **Training files 5001-7999 do not exist**, which matches the data owner's email. The planned DS_TRAIN range
    5001-5010 was therefore unavailable (section 5.1).
  - Exports: `TRAIN_HAS_8000=0`, `EVAL_LAST=10000`, `EVAL_END=8300`.
- **Schema:**
  - 406 files were read, footers only: 105 training and 301 evaluation, with 0 errors.
  - Every file has the same 224 columns and types. The 406 fingerprints all differ only because the column order
    differs between files; reading by column name is unaffected.
  - Rows per file range from 206,687 to 924,789, with 158,869,453 in total.
- **Profiles:**

| File | Rows | Frauds | Non-frauds | Time range |
|---|---:|---:|---:|---|
| train 1 | 841,428 | 1,527 | 839,901 | 2024-10-01 00:00:40 to 2025-05-31 23:59:58 |
| train 4950 | 882,259 | 1,332 | 880,927 | 2024-10-01 00:00:23 to 2025-05-31 23:59:34 |
| eval 8000 | 228,043 | 290 | 227,753 | 2025-05-01 00:00:18 to 2025-06-30 23:59:22 |

In all three: 224 columns; transaction ID a string with 0 duplicates; time `timestamp[ns]` with 0 sub-second values;
account ID stored as a double holding whole numbers.
- **Months:** 406 files were read (time, label, account), with 0 errors. Training covers 2024-10 to 2025-05 and
  evaluation covers 2025-05 to 2025-06, both as expected.
- **June frauds in evaluation files after 8010:** 46,547 over 290 files. The cumulative count reaches 2,000 at file
  8022, 4,000 at 8035 and 7,000 at 8054.
- **Benchmark:**
  - `tfm_v22b_dropcpr_falcondecline/eval/cross-file-8000-8200-seed-42_1.parquet` has 952,905 rows and 10 columns.
  - It contains no score column. The identifier-like columns are `account_id`, `token_ids` and `fi_transaction_id`,
    and it also holds `labels_history` and `timestamps`.
  - The incumbent's scores appear to be in `finetune_checkpoint/checkpoint-final-step-10000/eval_logits.npz` (plus
    `eval_metrics.json` and `eval.log`).
  - Nine more eval chunks cover 8201-10000.
- **Artifacts:**
  - Only version `1` exists (fit files parts 1-5, 23 features); version `20261019` does not exist yet.
  - The reference folder `s3://mrmcd-analytics-mrm-users/K016730/tabular_fraud/artifacts` is not readable (Access
    Denied), so no byte comparison was made.
- **Predictions:** 7 folders under `s3://mrmcd-analytics-mrm-users/K194855/tabular_fraud/predictions`.

## 3. Quick checks a, b, c, f, g (`quick_checks_20261021T232641Z`)

- Ledger `runs/run_log.csv`: 15 of 15 V1 run folders found.
- Exit code 1, only because check e failed. Its default run-table path
  (`reviewer_update_v1_20261013/analysis_outputs/run_table.csv`) exists only on our local machine. Check e was rerun
  (section 4).

### 3a. Checkpoints and per-epoch validation AP

In **all 15 V1 runs, `last.ckpt` is the same epoch and step as `best.ckpt`**.

| Run | Best = last (epoch, step) | Peak valid AP | Epochs run |
|---|---:|---:|---:|
| A-GAP05-OFF | 3, 8428 | 0.1303 | 9 |
| A-GAP10-OFF | 5, 12642 | 0.1240 | 10 |
| A-H00 | 3, 8428 | 0.1145 | 9 |
| A-H05 | 2, 6321 | 0.1203 | 8 |
| A-H10 | 4, 10530 | 0.1249 | 10 |
| A-H15 | 6, 14742 | 0.1312 | 10 |
| A-H20 | 2, 6318 | 0.1316 | 8 |
| A-MASK05-C | 2, 6321 | 0.1255 | 8 |
| B-ALLPOS-H5 | 1, 11238 | 0.1122 | 7 |
| B-H00 | 1, 4214 | 0.1148 | 7 |
| B-H05 | 0, 2107 | 0.1031 | 6 |
| B-H10 | 3, 8428 | 0.1103 | 9 |
| B-H15 | 6, 14749 | 0.1285 | 10 |
| B-H20 | 8, 18963 | 0.1154 | 10 |
| REF-SINGLE | 5, 6342 | 0.1240 | 10 |

- **B-H05:** validation AP by epoch was 0.1031, 0.0948, 0.0932, 0.0869, 0.0936 and 0.0988. Its best epoch is the
  first, and no later-epoch checkpoint was kept. **Check d (score B-H05's `last.ckpt`) would rescore the same
  checkpoint, so it was not run.**
- **Pins written to `env_additions.sh`:** `R05` (B-H05), `R15` (B-H15) and `R20` (B-H20) run folders.

### 3b. Folder overlap

- No file number exists in both folders (training 1-5000, evaluation 8000-10000), so a same-number probe is not
  possible.
- The account column is `Nmap_account_reference_xid`, a double in both folders.
- V1 splits (train 1-10, validation 4950-4954, evaluation 8000-8010) have 33,876, 16,792 and 31,474 accounts. Every
  pair of splits shares **0** accounts.

### 3c. Batch settings (as recorded; reported, not compared)

| Run | Batch x accumulation | Effective batch | History | Source |
|---|---:|---:|---|---|
| A-GAP05-OFF, A-H00, A-H05, A-MASK05-C, B-H00, B-H05, B-H10 | 4096 x 1 | 4096 | 5, 0, 5, 5, 0, 5, 10 | ledger (ok) |
| A-GAP10-OFF | 2048 x 2 | 4096 | 10 | ledger (ok) |
| A-H10, A-H15 | 1024 x 4 | 4096 | 10, 15 | ledger (ok) |
| A-H20 | 512 x 8 | 4096 | 20 | ledger (ok) |
| B-ALLPOS-H5 | 256 x 1 | 256 | 5 | ledger (ok) |
| B-H15, B-H20 | 2048 x 2 | 4096 | 15, 20 | manual retrain; the config file may predate the retrain |
| REF-SINGLE | 8192 x 1 | 8192 | none | ledger (ok) |

Every run trained on files 1-10, validated on 4950-4954 and used artifact version 1.

### 3f. Same-second rows

The order used is the original author's: a stable sort by account, time and transaction ID. Each row is paired with
its immediate predecessor in the same second.

| | Training (files 1-10) | Evaluation (files 8000-8010) |
|---|---:|---:|
| Frauds with an earlier same-second row | 451 of 12,757 (3.5%), 225 accounts | 121 of 3,818 (3.2%), 64 accounts |
| Of those, same-amount pairs | 348 | 98 |
| Of those, advice code on either row | 1 | 0 |
| Of those, neither | 102 | 23 |
| Rows with an advice code | 390,959 of 8,622,629 | 117,576 of 2,466,461 |
| Separate purchases ("neither" pairs): balance order consistent / reverse / unchanged | 2,769 / 1,040 / 5,488 | 782 / 330 / 1,525 |

In evaluation, 223 frauds (72 accounts) share their second with any other row, and 186 share it with another fraud.

**Reading:** where two separate purchases fall in the same second and the balance changed, the stored order agrees
with the balance in 70-73% of pairs (2,769 of 3,809 in training, 782 of 1,112 in evaluation). So the stored order
within a second is mostly, but not reliably, the true order (data-owner question 1).

### 3g. Are balance and limit fields stored before or after the transaction?

| Field | "Before" (pairs one second or more apart) | "After" | Unchanged | Ambiguous |
|---|---:|---:|---:|---:|
| `total_available_balance_amt` | 4,836,827 | 1,262 | 713,697 | 267,099 |
| `remain_day_merchandise_lmt_amt` | 3,061,594 | 136 | 712,158 | 154,562 |
| `available_daily_cash_limit_amt` | 13,276 | 16 | 14,914 | 7,556 |

All three are stored **before** the transaction, so they do not leak the transaction's own effect.
`avlble_merch_day_cash_lmt_amt` is marked "unconfirmed": it behaves as a configured limit, not a running value
(data-owner question 7).

## 4. Quick check e: B-ALLPOS-H5 at each chunk position (`quick_checks_20261021T235529Z`)

- **Run table:** `--run-table v1_analysis_outputs/run_table.csv`, sha256
  `9ab29e233a6940c3736c01de6fbc664581e8fd1706f832ad6d1587cbbaa22be9`, identical to our local copy.
- **Exit status:** all six positions exited 0, with no failed checks.
- **Join:** every report joined all 15 runs cleanly on the evaluation cohort: 11 files, 2,466,461 rows, 3,818 frauds,
  31,474 accounts, 0 duplicate IDs.

### 4.1 Whole-evaluation AP of every V1 run, as recomputed on the pod by `paired_report`

| Run | AP | AUROC | | Run | AP | AUROC |
|---|---:|---:|---|---|---:|---:|
| REF-SINGLE | 0.0925 | 0.9487 | | B-H00 | 0.0822 | 0.9322 |
| A-H00 | 0.0816 | 0.9351 | | B-H05 | 0.0674 | 0.9388 |
| A-H05 | 0.0728 | 0.9409 | | B-H10 | 0.0904 | 0.9475 |
| A-H10 | 0.0824 | 0.9408 | | B-H15 | 0.0955 | 0.9473 |
| A-H15 | 0.0928 | 0.9437 | | B-H20 | 0.0955 | 0.9520 |
| A-H20 | 0.0817 | 0.9339 | | A-GAP05-OFF | 0.0767 | 0.9430 |
| A-MASK05-C | 0.0779 | 0.9436 | | A-GAP10-OFF | 0.0808 | 0.9425 |

### 4.2 V1 contrasts (one seed each; 95% account bootstrap with 1,000 draws)

| Contrast | AP difference | Interval | Label |
|---|---:|---|---|
| A-H05 minus A-H00 | -0.0088 | [-0.0169, -0.0013] | not resolved (validation +0.0059 points the other way) |
| A-H10 minus A-H05 | +0.0096 | [+0.0006, +0.0194] | consistent positive |
| A-H05 minus A-GAP05-OFF | -0.0038 | [-0.0093, +0.0012] | not resolved |
| A-H10 minus A-GAP10-OFF | +0.0016 | [-0.0031, +0.0064] | not resolved |
| A-H05 minus REF-SINGLE | -0.0197 | [-0.0276, -0.0127] | consistent negative |
| B-H05 minus A-H05 | -0.0054 | [-0.0122, +0.0013] | not resolved |
| B-H05 minus B-H00 | -0.0148 | [-0.0248, -0.0065] | consistent negative |
| A-H05 minus A-MASK05-C | -0.0051 | [-0.0087, -0.0022] | consistent negative |
| A-H15 minus A-H10 | +0.0104 | [-0.0009, +0.0232] | not resolved |
| A-H20 minus A-H15 | -0.0111 | [-0.0184, -0.0038] | not resolved (validation +0.0005 points the other way) |
| B-H10 minus B-H05 | +0.0230 | [+0.0122, +0.0395] | consistent positive |
| B-H15 minus B-H10 | +0.0051 | [-0.0070, +0.0156] | not resolved |
| B-H20 minus B-H15 | +0.0000 | [-0.0110, +0.0113] | not resolved |
| B-H00 minus A-H00 | +0.0006 | [-0.0075, +0.0094] | not resolved |
| B-H10 minus A-H10 | +0.0080 | [-0.0051, +0.0237] | not resolved |
| B-H15 minus A-H15 | +0.0026 | [-0.0090, +0.0140] | not resolved |
| B-H20 minus A-H20 | +0.0138 | [+0.0008, +0.0287] | not resolved (validation -0.0163 points the other way) |

The seed rule for seeds 45 and 46 was not computed, because each run has one seed.

### 4.3 B-ALLPOS-H5 at each chunk position

For each chunk position k (0-5), B-ALLPOS-H5 is compared with six runs on the rows at that position, where
B-ALLPOS-H5 sees k earlier rows.

- Only position 0 against REF-SINGLE and B-H00 is depth-matched (neither sees history).
- Every other line mixes the history gap with all other differences between the runs.
- The 36 intervals are uncorrected and exploratory.
- Rows differ by position, so do not compare across rows of the table.
- Coverage: 2,448,346 rows and 3,743 frauds over the six positions, of 2,466,461 and 3,818 in the evaluation set.

The table shows AP differences, B-ALLPOS-H5 minus the other run. **Bold** means the interval lies wholly above zero.

| Position | Rows | Frauds | ALLPOS AP | vs REF-SINGLE | vs B-H00 | vs B-H10 | vs B-H15 | vs B-H20 | vs A-H15 |
|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| 5 | 394,669 | 567 | 0.0876 | -0.0043 | +0.0068 | +0.0058 | -0.0029 | +0.0018 | -0.0056 |
| 4 | 399,570 | 619 | 0.0949 | -0.0047 | +0.0090 | -0.0016 | -0.0025 | -0.0100 | -0.0025 |
| 3 | 404,401 | 644 | 0.1021 | +0.0012 | **+0.0143** | +0.0027 | -0.0096 | -0.0052 | +0.0014 |
| 2 | 409,365 | 632 | 0.0968 | -0.0000 | +0.0101 | +0.0016 | +0.0001 | -0.0026 | +0.0063 |
| 1 | 415,109 | 633 | 0.0806 | -0.0007 | **+0.0090** | -0.0004 | -0.0004 | -0.0030 | +0.0009 |
| 0 | 425,232 | 648 | 0.0940 | +0.0064 | **+0.0129** | +0.0109 | +0.0034 | +0.0069 | +0.0105 |

Intervals, in the same order:

| Position | vs REF-SINGLE | vs B-H00 | vs B-H10 | vs B-H15 | vs B-H20 | vs A-H15 |
|---:|---|---|---|---|---|---|
| 5 | [-0.0208, +0.0113] | [-0.0037, +0.0184] | [-0.0055, +0.0158] | [-0.0175, +0.0095] | [-0.0145, +0.0155] | [-0.0260, +0.0119] |
| 4 | [-0.0207, +0.0111] | [-0.0016, +0.0197] | [-0.0195, +0.0112] | [-0.0166, +0.0106] | [-0.0269, +0.0044] | [-0.0218, +0.0145] |
| 3 | [-0.0134, +0.0152] | [+0.0052, +0.0225] | [-0.0099, +0.0144] | [-0.0260, +0.0055] | [-0.0218, +0.0107] | [-0.0148, +0.0191] |
| 2 | [-0.0149, +0.0149] | [-0.0037, +0.0213] | [-0.0116, +0.0139] | [-0.0159, +0.0147] | [-0.0217, +0.0158] | [-0.0102, +0.0236] |
| 1 | [-0.0115, +0.0085] | [+0.0026, +0.0148] | [-0.0095, +0.0075] | [-0.0136, +0.0099] | [-0.0199, +0.0089] | [-0.0156, +0.0138] |
| 0 | [-0.0076, +0.0229] | [+0.0048, +0.0207] | [-0.0030, +0.0257] | [-0.0133, +0.0209] | [-0.0096, +0.0239] | [-0.0060, +0.0299] |

Reading:

- **Against REF-SINGLE, B-H10, B-H15, B-H20 and A-H15:** no interval excludes zero at any position. Even on rows where
  B-ALLPOS-H5 sees 0-1 earlier rows, it cannot be told apart from the history-20 models.
- **Against B-H00 (same architecture, no history):** it is ahead at every position and resolved at positions 0, 1 and
  3. At the depth-matched position 0 the difference is +0.0129 [+0.0048, +0.0207]: all-position training appears to
  help even without history.
- **For the plan:** the chunked scheme does not starve shallow positions of signal. We read this as support for L3
  (all-position H20 against B-H20) as planned.

## 5. L2: inventory and populations (`20261022T034405Z`)

### 5.1 One code change: the DS_TRAIN rule in `select_splits.py`

The shipped selector refused any DS_TRAIN outside 5001-7999, and those files do not exist (section 2):

```python
if not 5001 <= ds_train_start <= ds_train_end <= 7999:
    raise ValueError("DS_TRAIN must be an explicitly sized contiguous block inside 5001-7999")
```

It was replaced on the pod by:

```python
# 5001-7999 were never delivered (Step 0 listing 2026-10-21); DS_TRAIN comes from delivered training files.
ds_files = set(range(ds_train_start, ds_train_end + 1))
reserved = set(range(1, 101)) | set(range(4950, 4955))
if not ds_files or not ds_files <= set(range(1, 5001)) or ds_files & reserved:
    raise ValueError("DS_TRAIN must be an explicitly sized contiguous block inside training files 1-5000, "
                     "disjoint from ENC_TRAIN_100 (1-100) and EPOCH_VAL (4950-4954)")
```

- **Nothing else changed.** The account-overlap gate, the month-coverage gate, the June thresholds and the selection
  policy are as shipped. `data_inventory.py` is unchanged (sha256 `c8bcee4b...62bc`).
- **How it was applied:** a patch script ran on the pod (`runs/v2/patches/select_splits_ds_train_20261022T034405Z/`).
  - It requires LF endings and the shipped rule exactly once, and it keeps before and after copies.
  - sha256 before `1b614316...efd7`, after `9cf76eae...cbf40`.
  - `split_v2.yaml` records the same `selector_sha256`.
- **Tests on a personalized copy of the shipped file:**
  - 4001-4010, 101-110 and 4955-5000 pass;
  - 5001-5010, 95-105, 4945-4955, 1-10 and a reversed block are refused.
- **DS_TRAIN = 4001-4010.** That is ten files like the planned 5001-5010, away from both reserved ranges.

### 5.2 The run

The inventory and the selector ran as one job, which ended with `L2_EXIT=0`. It used CPU only and read S3 only.

- **Inventory:** training 1-100, 4950-4954 and 4001-4010, plus evaluation 8000-8300 (`EVAL_END` from the data look).
  It ran as one invocation with one salt, so account overlap covers every pair of files.
- **Benchmark:** transaction IDs come from the benchmark parquet. The account column was left at its default, so
  benchmark *account* overlap is unverified: `account_id` is not confirmed to be the raw account ID.
- **Selector:** `--ds-train-start 4001 --ds-train-end 4010`, with thresholds 2,000 / 2,000 / 3,000 as shipped. Output
  goes to `runs/v2/step1/L2_selected/`.

| Record | sha256 |
|---|---|
| `inventory.json` | `9c3f54e991cf48c8418b05614a1dc593ce348633396a91e69a92f6f97e84aa3d` |
| `split_v2.yaml` | `c408061501d3e6e04b169474a8360f07fc0e44e53601a92abcd3b1e5db705a4d` |

### 5.3 Gates

| Gate | Result |
|---|---|
| Both listings recorded | PASS (5,001 training objects, 2,001 evaluation) |
| Expected month coverage | PASS |
| File-contained accounts | PASS |
| June fraud thresholds | PASS |
| Benchmark account overlap | UNVERIFIED (see 5.2) |
| Label-immaturity warning | none raised |

### 5.4 Inventory

- **Files:** 416 files, with 0 file errors, 0 duplicate transaction or composite IDs and 0 nulls in the four columns.
- **Types:** timestamps are `datetime64[ns]` with no time zone; account IDs are numeric throughout.
- **No account appears in more than one file.** All 86,320 file pairs were checked, and 0 pairs share an account.
  The history builder's file-contained-account assumption holds.
- **Fraud counts:**

| Files | Frauds |
|---|---:|
| training 1-10 | 12,757 |
| training 11-100 | 130,581 |
| training 1-100 | 143,338 |
| 4950-4954 | 7,285 |
| 4001-4010 | 14,494 |
| June, evaluation 8011-8300 | 46,547 |

- **Benchmark:** all 952,905 benchmark transaction IDs were found in evaluation files 8000-8200, exactly the 201
  files the name says. Every benchmark row maps to a raw file.
- **Fraud rate by month**, frauds per 10,000 rows (rows in the inspected files):

| Source | Month | Rows | Frauds | Rate |
|---|---|---:|---:|---:|
| Training | 2024-10 | 12,939,952 | 23,677 | 18.3 |
| Training | 2024-11 | 12,549,841 | 22,158 | 17.7 |
| Training | 2024-12 | 12,610,504 | 20,598 | 16.3 |
| Training | 2025-01 | 10,971,995 | 18,377 | 16.7 |
| Training | 2025-02 | 11,478,779 | 18,139 | 15.8 |
| Training | 2025-03 | 13,007,918 | 20,361 | 15.7 |
| Training | 2025-04 | 12,782,316 | 20,159 | 15.8 |
| Training | 2025-05 | 13,341,272 | 21,648 | 16.2 |
| Evaluation | 2025-05 | 34,946,434 | 55,440 | 15.9 |
| Evaluation | 2025-06 | 32,947,952 | 48,250 | 14.6 |

June is 92% of May's rate, well above the 50% flag. The data owner should still confirm label maturity
(question 4).

### 5.5 Frozen populations

Evaluation roles count June targets only; May rows serve as history.

| Population | Files | Rows | Frauds | Accounts | Fraud accounts | Benchmark transaction IDs |
|---|---|---:|---:|---:|---:|---:|
| ENC_TRAIN_10 | train 1-10 | 8,622,629 | 12,757 | 33,876 | 2,918 | 0 |
| ENC_TRAIN_100 | train 1-100 | 86,683,008 | 143,338 | 338,204 | 29,853 | 0 |
| EPOCH_VAL | train 4950-4954 | 4,292,059 | 7,285 | 16,792 | 1,463 | 0 |
| DS_TRAIN | train 4001-4010 | 8,707,510 | 14,494 | 33,754 | 3,078 | 0 |
| DEV_OOT (June) | eval 8000-8010 (11 files) | 1,196,737 | 1,703 | 29,537 | 538 | 52,202 |
| SELECT (June) | eval 8206-8216 (11 files) | 1,215,218 | 2,081 | 29,666 | 514 | 0 |
| DS_SELECT (June) | eval 8217-8227 (11 files) | 1,184,642 | 2,034 | 29,097 | 548 | 0 |
| FINAL (June) | eval 8260-8277 (18 files) | 1,979,989 | 3,044 | 48,331 | 877 | 0 |
| BENCH | prepared parquet | 952,905 | - | - | - | - |

- **Distinct files:** 166 selected.
- **Account overlap:** every pair of populations shares 0 accounts. The only exception is ENC_TRAIN_10 inside
  ENC_TRAIN_100 (33,876 accounts), which is intended nesting.
- **Benchmark overlap:** SELECT, DS_SELECT and FINAL all lie after file 8200, so they share no transaction IDs with
  the benchmark. Only DEV_OOT overlaps it, and DEV_OOT is descriptive only.
- **Why FINAL starts at 8260.** The policy is least benchmark overlap, then fewest files, then earliest start. After
  SELECT and DS_SELECT, the shortest block reaching 3,000 June frauds starts at 8260.
- **DEV_OOT, all months:** 2,466,461 rows, 3,818 frauds and 31,474 accounts, the same cohort as the V1 evaluation and
  check e.
- **Exposure table (`population_roles_v2.yaml`):**

| Population | Allowed use |
|---|---|
| ENC_TRAIN_10 | artifact fit |
| ENC_TRAIN_100 | none |
| EPOCH_VAL | epoch selection |
| SELECT | design selection and continuity |
| DS_TRAIN | downstream training and PCA fit |
| DS_SELECT | downstream selection |
| DEV_OOT | none |
| FINAL | final evaluation |
| BENCH | benchmark scoring |

- **History depth:** frauds by the number of earlier rows of the same account in the file.

| Population | 0 | 1-4 | 5-9 | 10-19 | 20+ |
|---|---:|---:|---:|---:|---:|
| ENC_TRAIN_10 | 42 | 175 | 254 | 521 | 11,765 |
| ENC_TRAIN_100 | 543 | 1,991 | 2,549 | 5,005 | 133,250 |
| EPOCH_VAL | 32 | 133 | 172 | 315 | 6,633 |
| DS_TRAIN | 54 | 218 | 265 | 501 | 13,456 |
| DEV_OOT (June) | 2 | 15 | 20 | 60 | 1,606 |
| SELECT (June) | 1 | 4 | 14 | 48 | 2,014 |
| DS_SELECT (June) | 4 | 21 | 15 | 36 | 1,958 |
| FINAL (June) | 5 | 24 | 39 | 96 | 2,880 |

About 91-97% of frauds have at least 20 earlier rows (lowest EPOCH_VAL 91.1%, highest SELECT 96.8%), so H20 models
see a full window for nearly every target.

## 6. Data facts measured during the review (training file 1 and evaluation file 8000, counts only)

- **Fraud tags and declines:**
  - Every fraud tag is on an approved row (`processor_reason_xcd = 00`).
  - `predecline = 1` (5.1% of file 1 and 4.8% of file 8000) never carries the tag. Within it, insufficient funds
    (`51`) is 87% and Falcon real-time declines (`05`, `59`, `89`) about 9%.
  - So `predecline` must not be an input for the current row; declines on *earlier* rows are a legitimate history
    feature.
  - Evaluation should be reported with and without declined rows.
  - Codes `65` and `15` are not in the TMS ISO table.
- **Advice rows** (`transaction_advice_xcd = A`): 4.53% of file 1 and 4.59% of file 8000, never fraud.
- **`transaction_order`:** a per-account sequence starting at 0 that rises with time. It is unique within same-second
  groups. Neither V1 nor package 009 uses it.
- **Type `A` rows:** $0 address-verification-only checks (22,946 rows), never fraud.
- **Which limit applies:** types `C` and `O` carry the cash limit on 100% of rows, type `I` on 39%; all other types
  carry the merchandise remaining limit.
- **Same-second rows:** 2.02% of rows and 7.07% of frauds in file 1; 1.55% and 4.83% in file 8000.

## 7. L3: ALLPOS-H20 trained, validated and scored on sliding windows (`20261022T054050Z`)

### 7.1 What was run

**Question:** does the all-position model, scored on sliding windows (L1: B-ALLPOS-H5, 0.0934 AP on files
8000-8010), beat V1's best H20 model when it uses history 20 and **is trained on sliding windows too**? Training,
validation and scoring all used one target-ending window per transaction, as a production model would.

**Config:** `runs/v2/L3/allpos_h20_slide.yaml` is **B-ALLPOS-H5's resolved training config**. The helper checked that
before writing anything. It changes only:

| Key | B-ALLPOS-H5 | ALLPOS-H20 |
|---|---|---|
| `sequence.history_len` | 5 | 20 |
| `sequence.train_target_ending` | (absent: chunk training) | true |
| `training.batch_size` x `accumulate_grad_batches` | 256 chunks x 1 | 1,024 windows x 4 = 4,096 targets per update (as V1 B-H20's 2,048 x 2) |
| `training.eval_batch_size` | (training batch) | 1,024 |
| `sequence.max_window_rows` = `max_chunk_rows` | null | 32: measured cap, max(all-window p99.9, fraud-window p99) rounded up to 8; mean window 20.5 rows |
| `training.deterministic` | (absent; V1's trainer never enabled it) | false, explicitly, because `train_v2` defaults to true |
| output folder, run name, checkpoint path | V1 folder | `runs/v2/L3/ALLPOS_H20_SLIDE` |

**Unchanged:**

- V1 predictors and artifact version 1 (with month);
- training files 1-10, validation 4950-4954;
- causal strict all-position model;
- model size, AdamW at lr 3e-4, 10 epochs, patience 5, seed 42, bf16-mixed.
