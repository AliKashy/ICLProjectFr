# Changes Made — October 6, 2026, 11:02 AM ET

## Purpose

This document converts the October 6 GitHub Copilot `Project status assessment` conversation from the Dropbox `rundown` folder into a persistent repository overview. It records the work discussed in that chat, including intermediate decisions that were later revised.

## Final current state

The most important final-state point from the conversation is that the optimizer discussion ended with **AdamW-only** in the downstream ablation configs for fidelity to Yaqun's paper-replication baseline, even though a single-seed knob sweep temporarily favored RAdam. The screenshots show the progression from an interim RAdam propagation to a later explicit reversion to AdamW-only.

The original `fraud/` tree was not modified during this work. Changes were made in phase-owned `waqas/phase4a/`, `waqas/phase4b/`, tests, configs, and documentation.

## Model-code bug fixes

### `waqas/phase4a/sequence_builder.py` and `waqas/phase4b/sequence_builder.py`

**Before:** each DataLoader worker independently called `np.random.shuffle(files)` using its own Lightning-reseeded RNG state, then sliced with `files[worker_id::num_workers]`.

**After:** file order is shuffled with a fixed `np.random.RandomState(self.shard_seed)` before worker slicing.

**Reason:** independently shuffled orders do not form a true partition. With four workers, some files could be skipped for an epoch and others read more than once. A shared deterministic shuffle makes the stride-based worker assignment disjoint and complete.

### `waqas/phase4a/sequential.py` and `waqas/phase4b/sequential_hier.py`

Two causal-attention fixes were discussed.

1. **CLS-mask leakage**
   - Before: CLS was represented with a special transaction index and the causal-mask rule allowed real tokens to attend back to CLS while CLS could see the whole sequence.
   - After: causal ordering was corrected so future information cannot leak backward through CLS.

2. **NaN under padding**
   - Before: causal masking and `src_key_padding_mask` were built independently.
   - Failure mode: a fully padded short-history query could end up with no valid key, producing NaNs and corrupting the batch.
   - After: padding was merged into the causal mask per sample and the diagonal was forced open so every query has at least one valid attention position.

Regression tests were added for these padding/causal-mask cases.

### `waqas/phase4a/callbacks.py` and `waqas/phase4b/callbacks.py`

**Before:** EMA weights were restored in `on_validation_end`.

**After:** restoration was moved to `on_train_epoch_start`, with final restoration in `on_fit_end`.

**Reason:** `ModelCheckpoint` also operates around validation-end timing. Restoring raw weights too early could allow a checkpoint to capture raw weights while the monitored validation metric had been computed with EMA weights.

## Ablation and scoring fixes

### `waqas/phase4a/scripts/run_ablations.py` and `waqas/phase4b/scripts/run_ablations.py`

- Before:
  - training used `common + overrides`;
  - scoring used `overrides + common`, creating opposite override precedence;
  - the scoring command did not receive `experiment.run_name`.
- After:
  - training and scoring both use the same override precedence;
  - `experiment.run_name` is forwarded to scoring.

**Reason:** an axis value overlapping a common override could otherwise train one configuration and score another. Passing the run name also enables unique prediction output paths.

### `waqas/phase4a/scripts/score_sequential.py` and `waqas/phase4b/scripts/score_sequential.py`

**Before:** scoring used a fixed output name such as `sequential_preds.parquet`.

**After:** prediction output is namespaced by `run_name` when available.

**Reason:** sweep runs were otherwise overwriting the same S3 object, leaving only the last run's predictions.

## Test updates

### `waqas/tests/test_models.py`

The test conversation records these changes:

- a padded sequence-batch helper was added;
- sequential causal masking with padding received a regression test;
- hierarchical causal masking with padding received a regression test;
- EMA tests were updated for the new restore timing.

The chat reports the test count moving from **22 to 24 tests**.

## Config-value changes

### Eval range

For the sequential flat and hierarchical configs:

- Before: `eval.file_end: 8000` — effectively the one-file smoke range.
- After: `eval.file_end: 8010` — the full 11-file evaluation range.

Reason: the 11-file range matches Yaqun's documented stable reporting standard.

### Checkpoint naming cleanup

A stale `checkpoints/phase6_sequential` path was changed to `checkpoints/sequential` as part of removing old “Phase 6” naming that no longer matched the code organization.

## Ablation-config evolution

### Knob sweep result

The standalone h5 knob sweep produced these marginal `valid_ap` means:

| Knob | Option A | Option B | Result |
|---|---:|---:|---|
| Embedding | linear = 0.1260 | periodic = 0.1202 | linear |
| Attention mask | bidirectional = 0.1234 | causal = 0.1228 | effectively tied |
| Optimizer | AdamW = 0.1189 | RAdam = 0.1273 | RAdam in this sweep |

The chat additionally notes that RAdam beat AdamW in all four matched pairs in that run, including an example periodic+bidirectional comparison of **0.1155 vs 0.1289**.

This caused an **intermediate** decision to propagate `linear + bidirectional + radam` downstream.

### Final optimizer decision

The later rundown explicitly records that the optimizer choice was reconsidered for paper-replication fidelity. Yaqun's referenced baseline uses AdamW uniformly, so the final current state was reverted to **AdamW-only** across the downstream configs.

The conversation describes the sequence as:

`adamw placeholder -> radam propagated after knob sweep -> adamw reverted for fidelity -> temporarily represented as dual-axis -> final adamw-only`

Final state recorded by the chat: downstream configs hardcode `training.optimizer=adamw` and no RAdam axis remains.

### History-axis changes

Architecture A long-history sweep evolved from:

`h10/h16 -> h10/h15/h16/h20 -> h10/h15/h20`

The h16 point was dropped as redundant with the h15/h20 sweep.

Architecture B's primary sweep evolved from:

`h5/h10/h16 -> h5/h10`

The longer-history cases were split out. A file initially called `ft_decisions_hier_h16.yaml` was created for a CUDA-safe long-history run, then renamed in the local Copilot work to `ft_decisions_hier_long.yaml` after its content became h15/h20-only. The associated output root was likewise renamed from `ablations/ft_decisions_hier_h16` to `ablations/ft_decisions_hier_long`.

This document records that chat state; source-file renames should only be applied separately when supported by the actual repository/source evidence requested for modification.

### “Winning knobs” comments

Config comments were revised so old pre-fix ablation winners were no longer stated as settled facts. They were reframed as placeholders requiring reconfirmation after the bug fixes.

## Naming cleanup

The Copilot rundown reports cleanup of stale **“Phase 6”** wording and paths across 13 files in the phase-owned copies. The affected file types included:

- `callbacks.py`
- `numerical_embeddings.py`
- `optim.py`
- `tokenizer.py`
- `sequential.py`
- `train_sequential.py`
- `score_sequential.py`

across the relevant phase4a/phase4b copies, plus sequential-config checkpoint-path cleanup.

The intent was terminology cleanup only: describe the actual Architecture A / Architecture B content and current checkpoint paths instead of leftover “Phase 6 benchmark” naming.

## Documentation mentioned in the Copilot rundown

The chat also lists these newer documentation files:

- `waqas/docs/phase4_progress.md` — top-to-bottom Phase 4 progress, background, ablation results, bugs, and open items.
- `waqas/docs/project_writeup.md` — manager-facing project write-up with expanded next steps.
- `waqas/docs/meeting_notes.md` — consolidated notes on preprocessing, encoding, fine-tuning scope, optimizer schedule, and open technical questions.

## Execution sequence discussed

The conversation's proposed continuation order was:

1. Architecture A long-history sweep.
2. Architecture B h5/h10 comparison.
3. Architecture B longer-history sweep.
4. Time-delta ablation.
5. Capacity ablation.
6. 100-file confirmation.

Those commands in the original chat were operational suggestions from Copilot and are preserved here as project context, not as evidence that the runs were executed.

## Source of this overview

Reconstructed from all 16 screenshots in Dropbox:

`/tabular_fraud/waqas/More_Changed/rundown`

Capture groups:
- October 6, 2026 around 8:34 AM — immediate cleanup / knob-sweep discussion.
- October 6, 2026 around 9:09–9:10 AM — consolidated “everything changed since yesterday” rundown.

The later consolidated rundown is treated as authoritative for final-state decisions when it supersedes an earlier intermediate statement.
