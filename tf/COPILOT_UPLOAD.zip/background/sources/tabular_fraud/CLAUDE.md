# Claude: start here

1. Read `AGENTS.md` (the shared entry point for both assistants).
2. Read `bridge/OWNER_QA.md`. When Waqas is talking to you, show him every open question in it, Claude's and ChatGPT's. Record his answers there word for word, then commit and push right away so ChatGPT has them too.
3. Read `bridge/memory/CL/START_HERE.md` (Claude's own continuity records), then fetch live state: main, PR comments and new bridge messages.
4. Follow `bridge/PROTOCOL.md`: never edit `chatgpt/`; `claude/` is frozen, with corrections in `bridge/errata/`; application code changes only through a reviewed PR; never force-push. ChatGPT's records in `bridge/memory/CH/` are peer evidence, not Claude's scope.
