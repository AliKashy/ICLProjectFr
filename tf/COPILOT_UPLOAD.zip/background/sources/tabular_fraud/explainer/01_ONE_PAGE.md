# The whole project in ten sentences

1. **The goal.** The bank wants a computer program, called a *model*, that looks at each card transaction and gives it a *fraud score*: a number that is high when the transaction is likely to be fraud, so the riskiest ones can be checked first (`docs/fraud_detection_plan_detailed.md`, "Context": the label is `frd_tag`, fraud or not).

2. **Yakun's first model** looked at one transaction at a time, using 23 facts about it (amount, the Visa score, the time of day and so on; `fraud/configs/predictors.csv`), and it hit a limit: about 0.95 AUROC and 0.09 to 0.12 AP, and a bigger model or more data did not move it (`docs/phase4_design_decisions.md:5`). AP and AUROC are the two report-card numbers; see the glossary.

3. **Yakun's next idea** was to also show the model the same account's earlier transactions, its *history*, because how a customer usually behaves, and how fast they are spending, says a lot about whether a new transaction is odd (`docs/phase4_sequential_plan.md`, section 1).

4. **The idea worked a little:** with the 5 previous transactions, the best validation AP went from 0.1247 (one transaction, 100 training files) to 0.1293 (with history, 10 training files), measured on 2026-09-28 (`docs/phase4_sequential_plan.md:295-296`).

5. **There are two ways to build the history model.** Architecture A puts every transaction's facts in one long row and reads it all at once; Architecture B first sums up each transaction separately, then reads the summaries in order (`docs/phase4_sequential_plan.md`, sections 4 and 5).

6. **Version 1 (V1) answers one question:** which architecture, A or B, and which history length (0, 5, 10, 15 or 20 earlier transactions) gives the best fraud score. In your words: "just figuring out, you know, the best architecture, how, what's like the best history length" (`bridge/OWNER_QA.md:511`).

7. **V1 runs Yakun's own code, with corrections, at longer histories:** "this runs only really supposed to be running his code with all corrections at longer histories correctly" (your words, `bridge/OWNER_QA.md:192`). It is 15 training runs, all with Yakun's random seed 42 (`bridge/OWNER_QA.md:214`).

8. **The code on GitHub was rebuilt from photographs** of Yakun's files on 2026-10-02 (commits `64cce77` to `05092b2`); the AI assistants Claude and ChatGPT then checked it, found problems, and put every correction into your copies under `waqas/`, never into Yakun's folder `fraud/`, by your rule (`bridge/OWNER_QA.md:762-763`), with one approved two-character exception (`bridge/OWNER_QA.md:568`).

9. **You run everything inside the bank:** you download a reviewed package, run it on the bank's GPU machines (the *pods*), and send back the folder it produces; the assistants read that folder and prepare the next step. Nothing runs inside the bank without you. Until your fiftieth message only you merged (`bridge/OWNER_QA.md:777-779`); that message, as recorded, lets the assistants merge on GitHub when the work needs it (chapter 8, D59).

10. **After V1 comes V2:** more training data ("100+" files), new optimizers and new features that are known at the moment of the transaction (`bridge/OWNER_QA.md:465-481`).

**Latest (2026-10-14, evening):** a separate auditor chat now checks that every request has a real result. Its first report says the sweep and feature work you asked for is not delivered yet. Claude's final V1 check confirms the labels, but long history against no history was never tested (chapter 11, section 4b). **Earlier (14:49 UTC):** you asked for a full sweep of Yakun's ideas (optimizers, model size, features) on the small data before training on 100 files. Package 006's 100-file runs are postponed; its history-5 evidence reader can still be used (chapter 10). **Earlier (07:25 UTC):** package 006 was released: it reads V1's history-5 evidence, then trains REF-SINGLE and B at history 15 on 100 training files instead of 10 (chapter 7). **Earlier on 2026-10-14:** all 15 V1 runs finished. Compared directly with Yakun's single-transaction model, none of the leading history models is resolved better or worse (differences +0.0003 to +0.0030 AP). **Earlier (2026-10-13):** 14 of 15 runs had finished. It does not yet show that history beats Yakun's single-transaction model: the best runs are only 0.0003 to 0.0030 AP above it, untested. History 5 did poorly; history 10 beat 5; A and B could not be told apart. The numbers are still unchecked against the run files. See [11_V1_RESULTS.md](11_V1_RESULTS.md).

## Three things to understand first

1. **What AP measures, and why it is the number that decides.** Fraud is rare, so a model can look good on many measures while still missing most fraud. AP looks only at how well the model ranks the real fraud cases near the top. Yakun's plan picks models by AP (`docs/fraud_detection_plan_detailed.md`, "Final decisions": "PR-AUC / average precision drives model selection"). See "AP" in the glossary.

2. **The strict history rule.** A transaction's history may only contain transactions from strictly earlier times. If the model could see anything from the same moment or later, it would be "seeing the answer", and its score would look better than it really is. This is Yakun's own rule (`docs/phase4_sequential_plan.md`, section 2: "history is always prior to the target (`time < target_time`)"). Much of the correction work protects this rule.

3. **Why the work is split into stages that you run and send back.** The assistants cannot reach the bank's data or machines. So every step is a package you run on the pod, and its returned folder is the only evidence of what happened. A stage is done only when its return has been read (`runbook/2026-10-07/RELEASE.md:14` on the V1 branches).

## Check yourself

- Why did Yakun add history to the model? (Sentence 3.)
- What is the difference between Architecture A and Architecture B, in one sentence each? (Sentence 5.)
- Why are corrections put into `waqas/` and not `fraud/`? (Sentence 8.)
