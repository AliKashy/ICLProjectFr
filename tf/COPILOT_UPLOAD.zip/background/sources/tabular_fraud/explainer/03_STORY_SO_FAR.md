# The story so far

**In short:** Yakun built a working fraud model and a plan to add transaction history. In October 2026 his code was rebuilt on GitHub from photographs. Two AI assistants audited it, fixed real bugs in your copies, and built a staged package you run on the bank's GPUs. The first stage ran on 2026-10-12. Version 1, 15 training runs, is about to start.

Times are UTC unless marked. Every entry names its source. "Measured" and "assumed" follow the records.
"Reason not recorded" means no file in the repository says why.

---

## Part 1: Yakun's work (September 2026 and before)

These dates come from Yakun's own documents in `docs/`. No commits exist for them, because the repository did not exist yet.

| When | What happened | Why | Source |
|---|---|---|---|
| Before 2026-09-03 | Yakun compared table-data models on a public bank dataset. FT-Transformer won: test AUROC 0.935. | To pick a model. "FT-Transformer outperformed all others with better accuracy, faster training, no overfitting, and minimal configuration." | `docs/tabular_transformer_models.md:28`, `:101` |
| Before 2026-09-03 | Yakun's project plan: history might help, because "A fraudulent transaction may look normal in isolation but suspicious when viewed alongside the account's recent transaction history." He copied the `pytorch_tabular` library into the project so he could change its insides. | The history model "requires modifications to core components that cannot be achieved through configuration or subclassing". | `docs/fraud_detection_plan_overall.md`, "Problem Statement" and "Why Fork" |
| 2026-09-03 | First smoke test on the bank data: 1 epoch on files 1 and 2 (1,676,127 rows). | To check the pipeline works before scaling. | `docs/fraud_detection_plan_detailed.md:135-145` |
| 2026-09-08 | Phase 3: training that reads files piece by piece from storage ("streaming"), with frozen preprocessing artifacts, works end to end. Baseline on evaluation file 8000: AUROC 0.9521, AP 0.0940. | The full data does not fit in memory. | `docs/phase3_streaming_plan.md:5-17` |
| 2026-09-09 | Scaling: 10 files, 2 epochs: valid AP 0.1085; 10 files, 10 epochs: 0.1131; 100 files: 0.1247. Conclusion: the single-transaction model is "feature-limited", meaning more data or a bigger model does not help much. | To find the ceiling. | `docs/phase3_streaming_plan.md:21-45` |
| 2026-09-25 | Phase 4 plan: add each account's earlier transactions. Architecture A (flat) first, "Simplest path to parity"; Architecture B (hierarchical) for the future. Earlier fraud labels excluded ("leakage risk"). History 5, a time-gap input, bidirectional attention. His checks (section 9) and his open items A to G (section 10). | The single-transaction model "is at its signal ceiling". | `docs/phase4_design_decisions.md`; `docs/phase4_sequential_plan.md` |
| 2026-09-28 | First history result: A at history 5, 10 files: best valid AP 0.1293, AUROC 0.9509, against 0.1247 for one transaction on 100 files. Measured. | Proof that history adds signal. | `docs/phase4_sequential_plan.md:287-296` |

## Part 2: your own pod work (early October)

| When | What happened | Source |
|---|---|---|
| 2026-10-03 | You measured fraud rates. Training files 1 to 100: 0.1654% (143,338 of 86,683,008). Evaluation files 8000 to 8010: 0.155% (3,818 of 2,466,461). | `waqas/docs/waqas_roadmap.md`, "Fraud rate" |
| 2026-10-04 | Your "Current Standing": 8-run settings sweep at history 5 (winner "linear + bidirectional + adamw", valid AP 0.1365) and A at h10 and h16. Later both assistants found bugs in that code, so these numbers are history only, not results (rule D-006). | `waqas/docs/waqas_current_standing.md`; `bridge/DECISIONS.md` D-006 |
| 2026-10-06 | After the fixes, you reran on the pod. A h10: valid AP 0.126431, evaluation AP 0.080100, 4.9 hours. A h15: valid AP 0.135650, evaluation AP 0.090500, 9.7 hours. Measured. You believe h20 also ran; its files were never sent (OQ-4). | `ablations/current_run_results_10062026/results.md`; `bridge/OWNER_QA.md:814` |

The phases in your folder: **4a** is your build of Architecture A, **4b** of Architecture B, **5** is pretraining experiments (parked since 2026-10-09) (`waqas/docs/waqas_roadmap.md`).

---

## Part 3: day by day in the repository

### 2026-10-01 to 2026-10-02: the code is rebuilt from photographs
- The source files were photographed on 2026-10-01 and 2026-10-02 and typed back in, file by file, by a transcription helper you authorized (`reconstruction/WORKER.md:3-5`; `bridge/CHANGES_2026-10-06_to_10-08.md:201`). Commits `60f9f89` (first commit) to `eabee6d`. 644 photos were inspected (`reconstruction/HANDOFF.md:146-163`).
- **Why photos:** the only record is Claude's audit guide: "Waqas's laptop is broken. Every file in the repository was reconstructed by photographing the screen" (`claude/PROJECT_GUIDE_claude.md:349-350`). That is Claude's statement; none of your own words confirm it. Separately, the pod has "no GitHub connections" (your words, `bridge/OWNER_QA.md:844`), so code cannot move from the pod to GitHub directly.
- **Why it matters later:** a photo can hide small details. A double underscore (`feature__`) was read as a single one in `fraud/data/preprocessing.py`. That was found on the pod on 2026-10-12 (OQ-22).

### 2026-10-03 to 2026-10-04: your folders are rebuilt
- Phase 4a, 4b and 5 code recovered from photos (for example `66ab2a4`, `33ec42b`, `3a6ecfc`).
- A Claude Code session on your laptop made 8 commits that copied the `pytorch_tabular` library version 1.1.0 into `src/pytorch_tabular/`. Reason not recorded; whether these count as your uploads is open question OQ-12 (`bridge/OWNER_QA.md:54`).

### 2026-10-05: two independent audits; the bridge is created
- Claude (`be28c10`, PR #1, merged the same day) and ChatGPT (`3657d9b`) each audited the code separately. They agreed on eight findings, including a loader bug that skipped about 32% of files each epoch with 4 workers, and an attention mask that leaked (`bridge/threads/000-kickoff.md:5-27`). Chapter 5 explains each.
- Claude created `bridge/` (`3429beb`) so the two could work together without a direct line.
- Both audit folders were frozen, so the original findings could not be quietly changed. Corrections go to `bridge/errata/`.
- You said the sweep's evaluation was on one file, not eleven: "We ran 1 eval on 8000" (`bridge/ASK_WAQAS.md:10`).

### 2026-10-06: fixes reach the pod; your rerun
- The fixes were applied on the pod (with Copilot) and you reran h10 and h15 (Part 2).
- ChatGPT fixed the loader imports and set a smaller step size for h10 so it fits in GPU memory (`24fa955`). Reason: earlier out-of-memory crashes at long history (`bridge/ASK_WAQAS.md`, item 12).
- You chose AdamW as the standard optimizer, following the FT-Transformer paper and Yakun (`bridge/OWNER_QA.md:938`).

### 2026-10-07: the run plan and the shared question file
- ChatGPT's plan 1.0 (`d601e29`); Claude's run protocol (`bridge/RUN_PROTOCOL.md`, decision D-006). Why: your instruction that results from before the fixes are history only (`bridge/DECISIONS.md` D-006).
- PR #3 (Claude: the run package) and PR #4 (ChatGPT: runtime fixes) opened.
- The working model between the assistants was agreed (`bridge/OPERATING_MODEL.md`, D-007). Why: your request "how you and Codex can work together ... finish everything, correctly" (`bridge/OPERATING_MODEL.md:3`).
- Your first big set of answers, and the shared `bridge/OWNER_QA.md` (decisions D1 to D10 in chapter 8). Why: "a system where it's impossible for y'all to hallucinate" (`bridge/OWNER_QA.md:920`).

### 2026-10-08: "never edit his original folders"
- Your rule (`bridge/OWNER_QA.md:762`). PR #4 had edited Yakun's folder, so Claude opened PR #5 with the same fixes as copies under `waqas/base/` (`bridge/CHANGES_2026-10-06_to_10-08.md`).
- You merge; one GPU, one run at a time; Yakun is out of office for a while.
- Your 11 uploads that evening were folded into PR #5 and PR #3 (`bridge/OWNER_QA.md:1070-1080`).

### 2026-10-09: every reviewer, one ranked list
- You approved separate reviewer sessions and asked for every finding to be ranked and walked through (chapter 8, D15 and D16). Five Claude reviewer sessions opened.
- The ranked register: 104 findings (4 blockers, 24 major, 46 minor, 30 small) (`5d23c09`).
- Phase 5 parked; all-position B and B at h0 kept; a baseline of your own uploads published (`baseline/waqas-uploads-2026-10-09`).
- You asked for a roadmap from both assistants (D22). Claude's container hit its usage limit twice that day (`bridge/memory/CL/CURRENT.json`, `session_limit`).

### 2026-10-10: "so I can just run"
- Joint roadmap draft (`2c7289a`; decision D-009, proposed but never acknowledged by both).
- You asked for everything to be filled in so you can just run, and for step-by-step packages (D23, D24).
- Claude did not start writing fixes into your copies on a message relayed through ChatGPT; it asked you directly (OQ-17). Its tool permission layer had refused to start on a second-hand instruction (`bridge/OWNER_QA.md:624`).

### 2026-10-11: yes to the fixes; the pre-flight goes first
- You said yes (OQ-17, `bridge/OWNER_QA.md:614`). Implementation started 20:26 UTC.
- You asked to push the pre-flight alone first, so its findings could shape the rest (`bridge/OWNER_QA.md:590`).
- Issue #7 opened as the coordination log; `bridge/releases/` created to track every package and its returns.

### 2026-10-12: the first pod run, V1 defined, the parallel build
- **Early morning:** "too much reviews for an initial package" (`bridge/OWNER_QA.md:579`). Stage 1 declared done. ChatGPT published the diagnostic package publicly with private names replaced (packages `001`, then `002` without the instruction page).
- **About 05:00 UTC:** you installed package `002` with Copilot. Copilot started `batch1.sh` instead of the pre-flight; it stopped at its own failed pre-flight, so no training ran (`bridge/releases/tf-stage1-v0.1.0/DECISIONS.md`).
- **06:21 and 07:55 UTC, run-001 came back** (Copilot's account plus reconstructions from screenshots, `4708d1f`, `84b16e2`). Measured on the 4 x H200 pod: pre-flight FAIL, tests 746 passed and 2 failed (environment), 18 skipped. Cause: the `feature__` photo misread. Data facts found: same-second transactions are about 2% of rows but hold 6.7% of training frauds; times are whole seconds; training and validation cover 2024-10-01 to 2025-05-31, evaluation 2025-05-01 to 2025-06-30; no account appears in two splits (`bridge/releases/tf-stage1-v0.1.0/DECISIONS.md`).
- **08:25 UTC:** you approved the two-character fix in Yakun's file (D35).
- **09:07 UTC:** V1 defined: "continue doing whatever Yakun was doing and just, like, add the histories as, like, a version one" (`bridge/OWNER_QA.md:524`). **09:28 UTC:** V2 defined: more training data, new optimizers, new features (`:465`).
- **About 09:24 and 18:24 UTC:** Claude's container restarted twice, stopping running work. Cause not recorded (`bridge/reviews/CH/2026-10-12-delivery-blockage/REPORT_AND_HANDOFF.md:67`).
- **11:23 UTC:** joint V1 design, 34 runs, then 32 after review (`6de4340`, `03bef0a`). Your later answers cut it to 15 (seed 42 only at 19:19; no repeat run at 21:05).
- **18:38 UTC on:** the build split into Claude lanes L1 to L4, with reviewers, an integrator and ChatGPT tasks (chapter 9). Lane PRs #8 to #12 opened.
- **20:08 UTC:** ChatGPT published the stage 2 smoke package `003`, pinned to PR #3 at `0d727d8`. Not yet installed; nothing returned (`bridge/releases/tf-stage2-v0.1.0/returns/run-001/README.md`).
- **About 22:07 UTC:** the 4-GPU plus 1-GPU launcher (ChatGPT, `68bcf0a`); the wake channels PR #13 and #14.
- **22:29 UTC:** "All 15 today" (`bridge/OWNER_QA.md:153`).
- **22:44 UTC:** you asked for this guide.
- **22:50 UTC:** you let the assistants push and merge on GitHub (fiftieth message).
- **23:16 UTC:** ChatGPT's hourly task switched off at your request.
- **23:35 UTC:** no pod-loss testing; split the runs across GPUs and combine them (fifty-first message).
- **23:38 UTC:** V1 package 004 released (source `d4205d4`).
- **23:51 UTC:** the V1 code merged into `main` (PR #15, `5166787`); the older pull requests closed or marked merged.

---

## Where things stand at the end of 2026-10-12

- **Merged:** the V1 code is in `main` (PR #15, `5166787`).
- **Run on the bank pods with the new code:** only the stage 1 diagnostic (run-001). **No training on the new code yet.**
- **Ready for you:** V1 package 004, all 15 runs on 4+1 GPUs plus the analysis. Your run is pending.

### 2026-10-13: V1 runs on the pods
- Package 005 (an in-place install without tests) replaced 004 (chapter 7).
- About 03:42 UTC: V1 launched on two 4-GPU pods, with a third as a spare. By the report, 14 of 15 runs were trained and scored; A-H20 was still training. First results, as corrected by Claude's audit: no proof yet that history beats the single-transaction model; history 5 did poorly; history 10 beat 5; A and B not told apart (chapter 11).
- You uploaded the report as a transcription of 93 screenshots, plus feature lists for V2 rebuilt from photos.
- **Planning figure:** V1 about 65.3 GPU hours, assumed; about 2.7 days on one GPU (`DESIGN_V1_AFTER_RUN001.md:30`, under `bridge/`). Measured times exist only for A h10 (4.9 h) and A h15 (9.7 h), on older code.
- **V2:** designs and branches only. **Phase 5:** parked.

## Not recorded

1. Why the code had to be photographed (only Claude's statement that the laptop was broken).
2. Why the 2026-10-03 laptop session copied `pytorch_tabular` 1.1.0 (OQ-12).
3. Who made commit `0df2783` (OQ-12 (d)).
4. Whether Yakun's 0.0940 baseline is on file 8000 alone or files 8000 to 8010: `docs/phase3_streaming_plan.md:15` says file 8000; other records say otherwise.
5. Whether the h20 run happened (OQ-4).
6. What happened at the Monday 2026-10-12 review with Yakun.
7. Why Claude's container restarted twice on 2026-10-12.
8. Whether other photo misreads exist in Yakun's code (the check command in OQ-22 has no recorded result).
9. Why the joint roadmap D-009 was never acknowledged. It was superseded in practice by the V1 design route after run-001 (`bridge/plans/CL/2026-10-12-v1-design/`); no formal close is recorded.

## Check yourself

- Why are your 2026-10-04 numbers "history only"?
- What did run-001 find, and what was its cause?
- What is the one thing that has not yet happened on the bank pod with the new code?
