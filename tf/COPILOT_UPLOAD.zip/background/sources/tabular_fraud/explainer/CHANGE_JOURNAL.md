# Change journal

Every change to the project from 2026-10-12 on, newest first.
Each entry says: the date (UTC), what changed in plain English, why, who decided, and a link to the commit or pull request.
Changes before 2026-10-12 are told as a story in [03_STORY_SO_FAR.md](03_STORY_SO_FAR.md).

Kinds of change: **Decided** (an owner decision), **Code** (a change to code or settings on a branch or PR), **Ran** (something ran on the pod and came back), **Records** (notes and plans only), **Guide** (this explainer).

---

## 2026-10-14

### Decided: Claude's work order is "results first" (auditor finding F1 answered)
- **Your words to Claude's coordinating session** (verbatim, times UTC):
  - 2026-10-13 23:02: "Updated with all updates don’t run anything it’s done; don’t waste compute until I tell u a everything’s loaded"
  - 2026-10-14 14:47: "Check everything, everything ran so check results and then check what gpt proposed as next"
  - 2026-10-14 14:49: "Just check the results first, I’m giving ChatGPT some instructions for changes needed to be made"
- **What it means, as the coordinating session reads it:** an order for **Claude's own work**. Check the V1 results now, and leave Claude's review of ChatGPT's proposals until you say. It says nothing about coding, and it does not pause ChatGPT or the whole project.
- **What Claude did under it:** the final V1 results check (`9efb6f4`). Nothing yet on ChatGPT's proposals, package 006, PR #11 or the system map. No new runs.
- **The sweep-first order:** these messages neither confirm nor withdraw it. It rests only on your words as ChatGPT recorded them (entry "sweep on small data first" below).
- **Where recorded:** said to Claude in its chat and quoted in issue #7 comment 6172758992. **Not yet in `OWNER_QA.md`:** Claude asked you at about 16:40 UTC whether to record these messages there and pass them to ChatGPT. No answer yet.
- **Who decided:** you.

### Records: a separate "independent auditor" chat starts checking the project
- **What you said (to ChatGPT):** "I don't like how u missed so much of the stuff we were supposed to do. Are you able to add agents or independent chats" and "Need one thats always checking to make sure we're on the right path but don't want it to be in this chat".
- **What happened:**
  - ChatGPT wrote the instructions for the new chat (`bridge/plans/CH/2026-10-12-delivery-workflow/INDEPENDENT_AUDITOR.md`, commit `15967c9`).
  - You opened it. Its records are signed **AUDIT**, in `bridge/memory/AUDIT/` and `bridge/reviews/AUDIT/`.
  - Its job: for every request of yours, check request, then deliverable, then actual result, then what remains. It also flags unnecessary work. It is not another approval step.
- **Its first report** (`bridge/reviews/AUDIT/2026-10-14-requirements/README.md`, commit `8746eea`; posted on issue #7). Main finding: V1 and package 006 do not yet deliver the sweep and feature work you asked for. In detail:
  - **F1:** ChatGPT's records say the sweep is next. A Claude comment on issue #7 instead quotes you saying "check the results first" and treats the proposals as paused. That instruction is not recorded in `OWNER_QA.md`. *(Answered by the coordinating session; see the entry above.)*
  - **F2:** all-position B resets its context in chunks, while Yakun's item F describes one pass per account, so whether it fully counts as item F stays open (OQ-16).
  - **F3:** the 21 labels reproduce from the supplied numbers, but the B-H15 and B-H20 labels depend on their scores being linked to the right saved models. Also, "not resolved" has different causes: a range that includes zero, or validation pointing the other way.
  - **F4:** PR #18's own instructions still describe the 100-file runs.
  - **F5:** this explainer's "What's next" chapter still led with finishing V1. *(Fixed in this update.)*
- **Limits it states:** no automatic trigger is proven; it works when you or a lead hands it something.
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry "independent direction and completeness auditor"; commits `15967c9`, `8746eea`, `c7ec776`.

### Records: an editable map of how the assistants work together
- **What you said:** "We need to setup a system for this project and different projects ... like a lucid chart diagram showing how everyone's working together so I can then basically have like input on where I want to add info etc. where we should use api, open models, chats , etc."
- **What ChatGPT made** (`bridge/plans/CH/2026-10-14-agent-system/`, commit `6deecb2`): an interactive map with four views (team, work flow, models and APIs, other projects). You can click boxes, add notes, mark Keep, Change or Remove, and export your notes for the assistants. There is also an editable draw.io copy and a PDF.
- **What it is not:** a running system. It separates what exists (the assistants, GitHub handoffs, records) from what is only proposed (open models, other projects). Nothing new was switched on.
- **Who decided:** you asked; the design is ChatGPT's.

### Records: Claude's final check of all 15 V1 runs
- **What:** Claude rechecked every comparison with all 15 runs (`bridge/reviews/CL/2026-10-13-v1-results-audit/UPDATE_2026-10-14.md`, commit `9efb6f4`). All 21 differences and labels match the package's own rule. The auditor reproduced them too.
- **The headline stays:** no history model has been shown to beat REF-SINGLE.
- **New points:**
  - Long history against no history was **never tested**. Only history 5 was compared with no history.
  - The four extra "finalist" comparisons were picked using evaluation AP, against V1's rule that validation picks. By validation the picks would be A-H20 and B-H15. The comparisons A-H20 minus REF and B-H15 minus A-H20 were not run; their two signs disagree, so at best they would be "not resolved".
  - All five resolved results involve one of the two weakest runs (A-H05, B-H05).
  - B-H15 and B-H20, the top two on evaluation, are **provisional**: no script linked their scores to their saved models.
  - Validation AP predicts evaluation AP poorly across the 15 runs (rank correlation 0.114).
  - The pod's 14-of-15 report on main still says things now overturned ("tied", "resolved: no history beats 5").
- **Why it matters:** V1 can be closed honestly only with these limits stated. Nothing here needs new training.
- **Questions for you (from the update):** do the updated pod reports exist, and should they be uploaded? Do you want one CPU-only pass on the pod to test long history against no history and A-H20 against REF?
- **Link:** chapter 11, section 4b.

### Records: research agents' paper shortlist
- **What you said:** "Use a research agent to research papers on the work we're doing to find papers on arxiv or other work relative to our work to find the best and possible methods."
- **What ChatGPT delivered** (`bridge/plans/CH/2026-10-14-literature-methods/`, commit `5688c90`): 29 sources checked by three internal research workers, and a ranked list of experiments. First to test:
  - number representations (how amounts are fed in);
  - which settings are shrunk during training ("weight decay"), with learning rate;
  - Muon with AdamW.
  Then feature groups (past activity, how unusual the amount is, familiar shops), a richer time-gap encoding, and a simpler comparison model (gradient-boosted trees).
- **One finding about the recipe:** the original FT-Transformer paper does not shrink some kinds of settings during training. Our code shrinks all of them. This is a difference to measure, not a bug in past results.
- **Limits:** papers suggest experiments; they cannot say which method wins on bank data. The small-data-first order stays.
- **Who decided:** you asked; the ranking is ChatGPT's.

### Decided: sweep on small data first; package 006's 100-file runs postponed
- **What you said (to ChatGPT):** "Before training all 100…I think we should do a complete sweep of everything yaqun added". You also asked about the optimizer papers you saw ("Recall that was a task I told yall to do last night?"), "Also different features", and whether history could be set from the command line: "like set it to 5 or 10 etc? Or does it need more intensive or extensive training and testing".
- **What changed:**
  - Package 006's 100-file runs (steps 3 and 4) are **postponed**. Steps 1 and 2 (install, then read the history-5 evidence) can still be used. The ZIP itself is unchanged.
  - ChatGPT's new plan (`bridge/plans/CH/2026-10-14-improvement-pathway/SWEEP_FIRST_UPDATE.md`) replaces the "more data first" order. It maps every item in section 10 of Yakun's guide to what is done and what is not.
- **The new order (a proposal, nothing run yet):**
  1. Read the history-5 evidence (package 006, step 2).
  2. Test optimizer and training settings on the current 10-file data, using B at history 15 as a provisional starting point. AdamW settings first, then Muon. An unchanged AdamW run is kept for comparison.
  3. Test model size (depth and width) and the fraud weighting, adjusting the learning rate to match.
  4. Test feature groups one at a time against the same feature-free model: MCC first, then past-activity and familiarity features.
  5. Combine the best choices, then run the 100-file comparison.
- **Your history question, answered:** history is already a command-line setting for a **new** training run (`sequence.history_len=10`). But a model trained at history 5 cannot simply be switched to 10 when scoring; it must be trained again at 10. *Why:* the model learns one setting per position in its history window, so the window size is fixed once trained. A single model that works at several history limits would be a new design with its own training.
- **Cautions ChatGPT records:**
  - The optimizer paper (arXiv 2604.15297) tested simpler models, not this one, so it supports trying Muon but does not prove a gain.
  - A ranking on 10 files may change with more data.
  - Using the same evaluation files again and again makes them development evidence, not a final test.
- **Why:** your instruction. ChatGPT notes that Yakun's guide placed broad tuning after the larger-data stage; this is a recorded change of order, not Yakun's plan.
- **Who decided:** you set the order; the plan is ChatGPT's proposal. Claude has not yet agreed it. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry "sweep review before 100-file training" (commit `9e93dc6`); plan commit `b0c7492`.

### Code: package 006 released for you to run (history-5 evidence, then 100-file runs)
- **What:** ChatGPT finished package 006 (`006_20261014_072000_UTC.zip`) at about 07:25 UTC. Your private instructions are in `bridge/releases/tf-v2.0.0/package/README.md`. The code is on ChatGPT's branch `ch/morning-package-006-20261014` (PR #18). Only the ZIP itself went to the public download repository. Its fingerprint (SHA256) starts `7c515103` and was checked after download.
- **What it does, in order:**
  1. **Reads V1's saved evidence for history 5** (training and validation curves, settings, saved-model details). It trains nothing and reads no bank data. Missing evidence is reported as "UNKNOWN", never guessed. *Why:* history 5 did poorly in V1 and the cause is unknown (chapter 11, section 4).
  2. **Prepares two new runs** from your own V1 settings for REF-SINGLE and B at history 15. Only two things change: training files 1 to 100 instead of 1 to 10, and new output folders. Seed 42, inputs, version 1 artifacts, validation files 4950 to 4954 and evaluation files 8000 to 8010 stay the same.
  3. **Trains and scores them one after the other on one GPU** (REF first, then B-H15), and collects the results even if a run fails.
  4. **You send back two ZIPs** into `bridge/releases/tf-v2.0.0/returns/`. Saved models and per-transaction scores stay on the pod (OQ-24(a)).
- **Limits ChatGPT states:**
  - With the same number of passes over the data, 100 files also means more training steps. So this is a practical "more data" test, not a cause-only test.
  - The evaluation files have already been looked at, so they are not a fresh final test.
  - It does not show production readiness or promise better bank results. No running-time estimate is given.
- **Checks recorded:**
  - 86 focused tests and 18 install/export tests passed.
  - Both trainers ran on fake data on a normal processor, before packaging and again from the installed ZIP.
  - A ChatGPT reviewer who did not write the code found one problem: the return collector also packed credential-like and per-transaction files placed in its folder. It was fixed (`997b7ac`) and re-tested.
  - **Claude's review of the exact code is still pending.**
- **Why now:** your instruction to have a package ready to run the next morning (entry below).
- **Who decided:** you set the goal; the package design is ChatGPT's. **Link:** commits `f0fe619` and `34926fc` on main; `bridge/STATUS.md`, 2026-10-14.

### Decided: a runnable package by the next morning; ChatGPT starts package 006
- **What you said (to ChatGPT):** "by tomorrow I want ... you guys to start sending code into the public repo and do the processing, you know, how it's supposed to be done. And then tomorrow morning when I wake up, I'm gonna run whatever you guys sent me ... I need you to make sure that everything is absolutely correct and being done absolutely, like, the best way possible."
- **What ChatGPT is doing (its plan, recorded under your words):**
  - Build and test the next package (number 006), then publish only the cleaned, numbered ZIP to the public repository the packages go to. The private install and run instructions stay out of it.
  - **What the package does:** first, it reads the evidence V1 already saved for history 5 (training curves, settings, saved model files), to look for why history 5 did poorly. Then it trains REF-SINGLE and default B at history 15 on 100 training files, with the same inputs, the same version 1 artifacts, seed 42 and the same validation and evaluation files as V1.
  - **What it does not do:** no rerun of the V1 ladder, no new GPU pre-flight, no reviewer panel. New features (the MCC step) stay a separate stage, worked out with Claude, so the effect of more data is not mixed with the effect of new features or optimizers.
- **Why:** you want the next step run the following morning. Keeping data and features in separate stages means each result has one cause.
- **Who decided:** you set the goal and the deadline; the package scope is ChatGPT's. ChatGPT notes this authorises the package, not the publication of private records, and is not a promise of zero errors. Nothing has run yet.
- **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry "next morning runnable public package" (commit `4f11ec6`); ChatGPT's working claim in `bridge/memory/CH/COORDINATION.json` (branch `ch/morning-package-006-20261014`, not yet pushed).

### Decided: make the model better and production-ready; ChatGPT proposes a staged pathway
- **What you asked (to ChatGPT):** "How is Yaquns model better??" and "We obviously have to make this model better, production-ready. ... at minimum, like training on more files and then testing on different files as well. You know, we gotta do the feature stuff. ... make a pathway for, like, production and different things we should test out." You also asked how Yakun's initial model differs from ours, given the sharding and other fixes.
- **Answers recorded (`bridge/plans/CH/2026-10-14-improvement-pathway/`):**
  - Yakun's model is **not shown better**, and the history models are not shown better either (chapter 11, section 4a).
  - The V1 REF-SINGLE is a **new retraining** of Yakun's single-transaction recipe through the **corrected** code, on the same V1 files. It is not his old result, and A and B also use corrected code. So the comparison is not "old buggy Yakun against fixed ours". The remaining differences are one-transaction against history, plus the two different training recipes (`REFERENCE_COMPARISON.md`).
  - Nobody has measured how much each fix changed the bank-data AP. The old historical scores are not thereby proven invalid.
- **Proposed next package** (ChatGPT's proposal, not yet run or approved):
  - **Steps 1 and 2:** REF-SINGLE and B at history 15 trained on files 1 to 100 instead of 1 to 10, with the same inputs.
  - **Steps 3 and 4:** both again with one new feature, the merchant category code (MCC), using a new artifact version so version 1 stays untouched.
  - **Then:** 200 or 500 files only if the 100-file results justify it, and a bounded 12-configuration settings sweep (learning rate, regularization, size, optimizer).
  - **Separately:** a test on unused account files, and a future-time test using later dates.
- **What "model sweep" means:** a planned set of training configurations run to find good settings.
- **Who decided:** you set the goal; the plan is ChatGPT's proposal, to be worked out with Claude. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entries of 2026-10-14; commits `b054a91`, `85cb2cd`, `b6ba33e`.

### Records: exact saved result tables uploaded; ChatGPT reviewed the V1 evidence
- **What:** you uploaded the pod's saved `run_log.csv` (13 rows) and `run_table.csv` (35 rows), recovered from screenshots, plus small transcription corrections to three Copilot scripts (`3321f4d`). The recovery notes say no result value changed. ChatGPT reviewed the completed V1 results and recommends matched V2 feature pilots next (`bridge/reviews/CH/2026-10-14-v1-results-next/`, commit `5f0520f`).

### Ran: all 15 V1 runs finished; history did not beat the single-transaction model
- **What:** you uploaded more pod outputs, recovered from screenshots, under `waqas/results_from_pod/v1_results_2026-10-13/reviewer_update_v1/`. They are the pod's paired reports and the four scripts Copilot wrote on the pod.
  - A-H20 finished: evaluation AP 0.0817, below A-H15 (-0.0111). This is not resolved, because validation points the other way.
  - The leading runs compared directly with Yakun's single-transaction model (A-H15 +0.0003, B-H15 +0.0030, B-H20 +0.0030 AP) are all **not resolved**.
  - A-H15 against B-H20 is not resolved. So is B against A at history 20: evaluation favours B, validation favours A.
  - The pod's own tool also labels "A: history 5 or none?" as not resolved, which agrees with Claude's audit.
- **Why it matters:** V1's central question has its answer for now. With this data and one run each, the history models could not be told apart from the single-transaction model.
- **Caution:** these are still screenshot transcriptions, not the returned files.
- **Who:** you ran it and uploaded it. **Link:** commits `e7558a4` to `5234545`; chapter 11, section 4a.

## 2026-10-13

### Records: Claude audited the V1 results report; chapter 11 corrected
- **What:** Claude's audit (`bridge/reviews/CL/2026-10-13-v1-results-audit/AUDIT.md`, commit `6233ec0`) found that the pod report overstates its results.
  - One label is wrong: "A: no history beats history 5" is **not resolved**, because validation points the other way (+0.0059).
  - "Not resolved" was read as "tied"; it only means no difference was seen with this much data.
  - The central question, whether history beats the single-transaction reference, was never tested. The best runs are only 0.0003 to 0.0030 AP above it.
  - The reference uses Yakun's recipe and A and B a different one, so recipe and history effects are mixed.
  - Each setting is one training run.
  - Some runs were restarted outside the launcher, and part of the table came from a script Copilot wrote that is not in the package.
- **Guide change:** chapter 11 and the one-page note are rewritten to the corrected reading. The first version of chapter 11 had repeated the report's wrong label and its "tied" wording; that is now fixed.
- **Why:** the audit checked the report's labels against the analysis code's own rule (`paired_report.py`) and the V1 design.
- **Next:** you upload the returned run files; a re-analysis after A-H20 finishes, with direct comparisons against the single-transaction reference; extra seeds only with your yes.
- **Who:** Claude's coordinating session. **Link:** issue #7 comment 6155729628.

### Ran: V1 trained on the pods; 14 of 15 runs finished (results from your screenshots)
- **What:** package 005 ran on the bank's GPU pods from about 03:42 UTC. By the time of the report, 14 of 15 runs were trained and scored; A at history 20 was still training. You uploaded the pod's report, transcribed from 93 screenshots, to `waqas/results_from_pod/v1_results_2026-10-13/`.
- **Correction, same day:** the findings below are the pod report's wording; Claude's audit corrected them (see the entry above). In particular, "tied" should read "not told apart", and A history 5 against none is not resolved.
- **Main findings:** A and B are tied at every history compared; history 5 is weak (it loses even to no history); history 10 beats 5 in both designs; gains beyond 10 are not proven; the time gap makes no measurable difference; causal attention beats bidirectional at history 5. Best evaluation AP: B-H20 0.095465, B-H15 0.095459, A-H15 0.092822, Yakun's single-transaction reference 0.092476. Full plain-English reading in the new chapter [11_V1_RESULTS.md](11_V1_RESULTS.md).
- **How the run differed from the plan:** three 4-GPU pods instead of 4+1 (queues rebalanced to 4+4, a code change in `parallel_v1.py` only); bigger batch pieces for the slow long-history A runs at the same total of 4,096; B-H15 and B-H20 stopped by mistake and retrained from scratch; a false pre-flight failure from a Windows-made manifest, fixed by restoring the pod's own manifest.
- **Cautions:** the numbers are a transcription of screenshots, not the returned files; the assistants have not yet checked them; the report itself warns that training is not exactly repeatable and that validation AP barely predicts evaluation AP (rank correlation 0.17).
- **Still open:** A-H20, the finalists against the single-transaction reference, and folding the run-day changes into the official files.
- **Who:** you ran it. **Link:** commits `0c21913`, `c668c52`, `69797da`, `13e44d2`.

### Records: feature lists rebuilt from photos (for V2)
- **What:** (1) rows 124 to 248 of the business's field list ("meta data ALL features provided by LoB.xlsx") are now transcribed: 125 rows, with 10 cells of one column still unresolved (`waqas/feature_related/part_124_248/`, commit `691393a`). (2) A master feature index of 311 rows: 94 features of the bank's XGBoost model 15298 with their ranks, 106 raw or source columns, 94 crosswalk rows and 17 V2 candidate feature families (`waqas/feature_work/`, commit `9bbaab6`). Its README reports 0 mismatches between the transcription, the Excel file and the CSV.
- **Why:** V2's feature work needs to know which fields exist and which ones model 15298 uses (your 2026-10-13 message, chapter 10).
- **Who:** you. Nothing in V1 changes.

### Records: a feature list from the business is being typed in from photos
- **What:** you started rebuilding the spreadsheet "meta data ALL features provided by LoB.xlsx" (a list of available data fields from the line of business) from photographs, in separate batches handled by separate chats: rows 1 to 123, rows 124 to 248 (212 photos), and rows 249 to 600 (119 photos). Two batch folders exist so far under `waqas/feature_related/`. Each holds only a README saying the batch is reserved and that nothing is transcribed or checked yet.
- **Why:** reason not recorded in the commits. It fits V2's feature work (chapter 10), which needs to know which fields exist and what they mean.
- **Care point:** the batches are kept apart and must not be merged or renumbered until every part is checked, because each row has to be assembled from several partial photos. The same photo-reading risk that caused the `feature__` error applies here.
- **Who decided:** you. **Link:** commits `eaad917`, `8f7bef2`. Nothing in V1 or package 005 changes.

### Records: a director's advice on sampling for V2; the 15298 feature list is coming
- **What:** you passed on a director's reply to the feature-engineering email: "If we do time series-based feature engineering, I think it is more appropriate to do account/customer level sampling rather than transaction level sampling." ChatGPT added it to the archived email and to the V2 feature proposal. You also said you will soon add the feature importances and the full feature list of the bank's XGBoost model 15298.
- **What it means in plain words:** when training uses only part of the normal (non-fraud) data, there are two ways to pick that part. Transaction-level sampling drops individual transactions, which leaves holes in an account's history. Account-level sampling keeps or drops whole accounts, so every kept account's history stays complete. Features built from history (for example "purchases in the last hour") are only correct if the history is complete, which is why account-level sampling fits them. This is the same reason V1's ranges resample whole accounts (chapter 6).
- **Why it matters:** V2 only. V1 code, its data, the frozen preprocessing artifacts and package 005 are unchanged.
- **Your open question:** "We need to think of what allat means". The assistants' first reading is in `bridge/plans/CH/2026-10-12-v22-feature-proposal/SAMPLING_FOLLOWUP_2026-10-13.md`.
- **Who decided:** nothing decided yet; advice recorded. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry of 2026-10-13; commit `66a2118`.

### Code: package 005's code merged into main (PR #16)
- **What:** ChatGPT merged PR #16 into `main` at 03:48 UTC (merge commit `14812cb`). It brings in package 005's runtime source `96ed240` plus two test-only follow-ups (`de34e3b`, `8cc9a4a`), so `main` now matches the package you will run. The published package 005 itself did not change.
- **Test result:** Claude's full test run at `8cc9a4a`: 1084 passed, 21 skipped, 0 failed (fake data, CPU). The last fix only changed what a test expects: a code file that exists only in your pod's `fraud/` now counts as a warning, not a failure, matching the package 005 rule that Yakun's files are the reference.
- **Why:** so the official copy of the project holds exactly the code you run.
- **Who decided:** ChatGPT, under your fiftieth message (assistants may merge). No bank run yet.
- **Link:** commits `14812cb`, `10ac3d4`; issue #7 comment 6137749742.

### Code: package 005 published, installed into your existing project
- **What:** package `005_20261013_015754_UTC`, built from source `96ed240` (PR #16), published and verified (public commit `8acfbdd`). It installs into your existing project folder and overwrites only the files under `waqas/` and `runbook/`. It has no test or fake-data files, and `prepare` runs the pre-flight without tests. Package 004 stays as released. Records: `bridge/releases/tf-v1.0.1/`.
- **Why:** your words to ChatGPT: "i cant have this become a bundle of files that are insanely confusing. we overwrite shit." and "just give the finalized 005 man, ill have github copilot on my laptop do a bit by bit comparsion to make sure spacing and veveyrhting is fine." Earlier you said package 004 had only been personalized: "Ran personalization, but nothing else".
- **Two problems fixed before publishing,** both found by Claude:
  1. The pre-flight at the start and the check just before A-GAP10-OFF counted different files as "code". A leftover file, such as a hidden Jupyter checkpoint copy, could pass the first check and then stop A-GAP10-OFF hours into the study. Both checks now use one rule, and hidden folders are ignored.
  2. Yakun's real `fraud/` on the pod was compared byte for byte with the photo transcription, so an invisible trailing space would have stopped `prepare`. His files are now the reference and any difference is recorded as a warning. A change to any code *during* the study still stops it.
- **Evidence:** Claude re-tested the exact published ZIP on fake data, in a project built like yours with leftover files and Yakun-file differences: 15 of 15 runs completed; a file changed mid-study was still refused (issue #7 comment 6136910377). Tested on fake data only; nothing has run on the bank pods yet.
- **Who decided:** you; built by ChatGPT, checked by Claude.

### Records: the assistants now wake each other directly
- **What:** ChatGPT now wakes from comments on PR #14 through an event task you enabled, so Claude and ChatGPT can call each other without you passing messages.
- **Why:** your question to ChatGPT: "also can we setup the manner for u and calude to call each other automatically?"
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry; commits `5260ce5`, `7dca64e`, `3dcb464`.

### Records: you added project context emails
- **What:** a new folder `waqas/additional_info/` with two colleagues' emails, archived with source notes: one on feature-engineering practice (features, downsampling of normal rows, history coverage, validation) and one on the raw-data copy (where the training and test data sit, date coverage, account-based splitting, file counts).
- **Why:** the folder's README: "extra project details ... that may provide valuable context for a more complete, holistic understanding of the Tabular Fraud project."
- **Who decided:** you (commits `eef336e` to `5769a6c`). This guide does not repeat their contents, because they include bank storage details.

### Decided: a slimmer package installed into your existing project, without test or fake-data files (fifty-second message)
- **What:** ChatGPT is building a smaller package that installs into the project folder you already have on the pod, instead of a separate new folder. It holds the corrected final files that replace the ones under `waqas/`, plus the runbook files needed to run. Test files and fake-data ("synthetic") files are left out. So `prepare` runs the quick pre-flight without tests; this replaces the forty-second message's "full pre-flight with tests once per package". Yakun's `fraud/` folder is not shipped: the pod's own copy is used as it is.
- **Why:** your words: "Remove unnecessary things. No reason to have synthetic shit…goal was to have yall make the corrected final versions, replace the ones in the repo under my name. That way everything's clean and working." And: "Did we change any file in Yaquns Fraud? If any file is changed, we make a version for myself inside of Waqas". The recorded answer: compared with your own upload `25e1165`, Yakun's files differ only in the two-character `feature__` correction, which restores his real file; every real fix is a copy under `waqas/`.
- **What is given up:** with no tests on the pod, the check that the pod's libraries behave like the assistants' environment no longer runs. That was your choice (coordinating session, 2026-10-13).
- **Package 004 stays as released;** the slim package will be a new version.
- **What to watch for:** this is the first time a run uses the pod's own `fraud/`. The pre-flight compares it with the reviewed copy; if any file differs, `prepare` stops and you send `source_diff.txt`. A difference would mean the photo transcription has another error, which matters because the `waqas/` copies were built from it.
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, fifty-second message; commit `83ab56a`; issue #7 comment 6135594311.

---

## 2026-10-12

### Code: V1 code merged into main; pull requests tidied
- **What:** PR #15 merged the V1 integration branch into `main` (merge commit `5166787`, 23:51 UTC). `main` now holds the released V1 code. The runtime code is identical to package 004's source `d4205d4`; the branch also got a test-only change (`a15df15`, merged as `5a1d876`) and a regenerated manifest (`955b5c5`).
- **Pull request outcomes:** #4 and #5 now show as merged (their code is in main). #3, #8, #9, #10 and #12 were closed as "integrated" (the same code arrived through #15). #2 was closed as superseded, on ChatGPT's recommendation. Still open: #6 (ChatGPT's automatic-review design), #11 (V2 only), #13 and #14 (the doorbells).
- **Why:** you asked "whats with all of the push requests?". Until now the finished code lived only on a side branch and inside the package ZIP; `main`, the project's official copy, did not have it, and the other PRs were older drafts or pieces of the same code.
- **Who decided:** Claude's coordinating session, under your fiftieth message (assistants may push and merge).
- **Link:** commit `5166787`; issue #7 comment 6134853204.

### Ran (tests only): package 004's full test suite passed
- **What:** on the personalized copy of package 004, in the assistants' environment with fake data: runbook tests 479 passed, 22 skipped; `waqas` tests 554 passed; root tests 6 passed; 0 failed.
- **Why:** to prove the package works before you run it on the pod.
- **Who:** Claude's coordinating session. **Link:** issue #7 comment 6134853204.

### Code: V1 package 004 released
- **What:** ChatGPT built the V1 package from source `d4205d4` after Claude's go-ahead, and published only the ZIP `004_20261012_225800_UTC.zip` publicly, with private names replaced (SHA-256 `b060638afc8276f4a3ce68d3922f0ed25bf99523771549ad9601daeda7f617e0`). Your exact private commands and the place to put the returned folders are in `bridge/releases/tf-v1.0.0/package/README.md`. No bank run has been observed yet.
- **Why:** your instruction to ChatGPT: "Claude posted GO on issue #7, build and release the package."
- **Who decided:** you; built by ChatGPT; go-ahead by Claude (issue #7 comment 6134626692).
- **Link:** commit `0230121`; record `bridge/releases/tf-v1.0.0/RELEASE.json` (state: released, owner run pending).

### Decided: only the current package stays in the public download folder
- **What:** packages 002 and 003 were removed from the public download folder; only 004 remains. Their history and the private records are kept.
- **Why:** your words to ChatGPT: "am i supposed to push 003 and 004? delete the ones not used btw."
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry "keep only the current public download"; commit `a8f7ddb`.

### Decided: no pod-loss testing; split the runs across GPUs and combine them (fifty-first message)
- **What:** the extra tests that simulated a pod dying mid-run are dropped, and the half-finished one was stopped (its partial results are kept, not counted as a pass). What V1 needs stays: the 15 runs split across GPUs, then `finish` combines both pods' records and `analysis.sh` compares all 15. The one-GPU continuation command stays in the package for you to use only if you choose.
- **Why:** your words: "The pod doesn't die don't even do that shit. Just need to be able to run different tests and sections in different GPUs and conjoin them together yk"
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, fifty-first message; commits `164b4a7`, `a54a994`.

### Decided: ChatGPT stops hourly checks and starts tasks when assigned
- **What:** ChatGPT's hourly scheduled task was switched off at 23:16 UTC. It now starts work as soon as it is assigned.
- **Why:** your words to ChatGPT: "Stop doing hourly checks. I want you to start doing tasks right when your assigned."
- **Who decided:** you. **Link:** `bridge/OWNER_QA.md`, ChatGPT-recorded entry; commit `72e2f9e`.

### Code: V1 lanes joined into one candidate
- **What:** the integration branch `claude/v1-integration-2026-10-12` now holds every lane's work in one place (head `b4d9922`, 23:00 UTC): REF-SINGLE (L1), batch 2 and the 4+1 "all" stage (L2), the analysis tool without the May/June split (L3), the stage 5 command (L4), and L2's fix that makes `finish` score the three validation-only runs every time (`367564b`). The code-file list (manifest) was regenerated.
- **Why:** one tested package for you instead of five branches; it also brings in your forty-first and forty-second message changes, which the older head `2317a3f` lacked.
- **Who decided:** the coordinating session, under your twenty-ninth and forty-eighth messages.
- **Link:** commits `e8b3a74`, `b4d9922`. Chapters 6, 7 and 10 updated.

### Decided: assistants may push and merge on GitHub (fiftieth message)
- **What:** as recorded by Claude's coordinating session, your message "If yall need to push and merge stuff of GitHub etc…do it." lets the assistants merge pull requests when the work needs it. Before this, only you merged (D12).
- **Why:** reason not recorded beyond your words. The coordinating session's conditions: merge only heads that passed the full test suite and the fake-data run; record each merge here; no force-push.
- **Who decided:** you.
- **Link:** `bridge/OWNER_QA.md`, section B, fiftieth message; commit `be91b83`. Chapter 8 (D59) updated.

### Guide: first complete version of the explainer
- **What:** chapters 3 to 10 added: the story so far, how the model works, the changes from Yakun's code, the V1 study, running on the pods, the decisions log, how the team works, and what's next.
- **Why:** your forty-ninth message (`bridge/OWNER_QA.md:138`).
- **Who decided:** you; written by the "Project explainer E1" session.
- **Link:** the commit that adds `explainer/10_WHATS_NEXT.md`.

### Guide: the explainer folder is started
- **What:** this folder, `explainer/`, with the README, the one-page version, the glossary, this journal and the research notes.
- **Why:** you asked for a separate agent to explain the whole project in plain English and keep it current (`bridge/OWNER_QA.md:138`).
- **Who decided:** you (forty-ninth message), carried out by the "Project explainer E1" session.
- **Link:** the commit that adds this file.

### Records: forty-ninth message recorded, a dedicated explainer session
- **What:** your request for this guide was written into `bridge/OWNER_QA.md`.
- **Why:** so both assistants have your exact words.
- **Who decided:** you; recorded by Claude.
- **Link:** commit `160fd51`.

### Code: recovery test and command preparation claimed
- **What:** ChatGPT claimed the task of testing the combined V1 recovery path (continuing unfinished runs) and preparing the commands.
- **Why:** reason not recorded in the commit title; the details are being read for the next update.
- **Who decided:** ChatGPT, under your instruction to give it tasks (`bridge/OWNER_QA.md:326`).
- **Link:** commit `fb5fc9b`.

### Decided: all 15 runs today on 4+1 GPUs (forty-eighth message)
- **What:** all 15 V1 runs start today in one plan, across the 4-GPU pod and the 1-GPU pod. Batch 2 no longer waits for batch 1's return to be read. The longest run, A h20, goes on the 1-GPU pod, which stays after the holiday. Whatever the 4-GPU pod does not finish continues on the 1-GPU pod.
- **Why:** you have the 4-GPU pod only "until tomorrow morning" (your words), so using all five GPUs today saves days of waiting.
- **Who decided:** you: "All 15 today (Recommended)".
- **Link:** `bridge/OWNER_QA.md:147-165`, commit `286bdba`.

### Code: ChatGPT's 4+1 launcher, tested and handed to Claude
- **What:** a small launcher that runs up to four runs at once on the 4-GPU pod and one on the 1-GPU pod, plus a mode (`run --pod all`) that continues both queues on one GPU after the holiday.
- **Why:** you asked for it: "on one of the pods I run 4 of the tests and then the other I run 1" (`bridge/OWNER_QA.md:1347`); and "Starting tmrw I only have 1 again" (`:1362`).
- **Who decided:** you; built by ChatGPT; final integration by Claude.
- **Link:** branch `ch/v1-parallel-pods` (`68bcf0a`); commits `d11a3c3`, `bb206a7`, `25890db`, `c7f71f9`.

### Decided: wake each other on demand, no hourly check-ins (forty-seventh message)
- **What:** two draft pull requests act as doorbells: a comment on PR #13 wakes Claude, a comment on PR #14 wakes ChatGPT.
- **Why:** your words: "Stop letting ChatGPT do hourly check ins. Figure a way out that both of yall can activate each other whenever u need it."
- **Who decided:** you.
- **Link:** `bridge/OWNER_QA.md:167-180`, commit `da92b59`.

Earlier entries for 2026-10-12 (the first to forty-sixth messages of the day) are covered in [08_DECISIONS_LOG.md](08_DECISIONS_LOG.md) and [03_STORY_SO_FAR.md](03_STORY_SO_FAR.md).
