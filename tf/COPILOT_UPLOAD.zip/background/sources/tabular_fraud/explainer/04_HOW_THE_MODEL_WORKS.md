# How the model works: from raw files to a fraud score to the AP number

**In short:** each transaction becomes 30 small number-vectors ("tokens"); the account's earlier transactions are added beside it; a transformer reads them all and outputs a fraud probability; all the probabilities for the evaluation files are ranked against the true labels and summed up as AP.
Code is cited as `file:line` in Yakun's original (`fraud/`) unless your copy (`waqas/`) is named. Each step gives its reason; "reason not recorded" means no file says why.

---

## Step 1. The raw data

- **What a row is.** One card transaction: its fraud label `frd_tag` (1 = fraud), a timestamp, an account id, a transaction id, the amount and other fields (`fraud/configs/sequential.yaml:14-21`). The bank data has 224 columns, identical in every split (run-001, `bridge/plans/CL/2026-10-12-v1-design/model.md:36`; reconstructed from screenshots).
- **The files.** The data is cut into numbered Parquet files. Training and validation files come from one store; the evaluation files are a separate extract (`docs/fraud_detection_plan_detailed.md:22`). Each file is read whole, one at a time, so the full data never has to fit in memory. *Why:* the data is far too large for memory; Yakun's Phase 3 was built for "memory-bounded" streaming (`docs/phase4_design_decisions.md:25`).
- **Each account lives in one file.** *Why it matters:* the history can be built inside one file with no cross-file joins (`docs/phase4_design_decisions.md:22`). Measured true on the pod (`model.md:15`).

**The three sets V1 uses**, measured on the pod in run-001 (`bridge/plans/CL/2026-10-12-v1-design/model.md:30-34`; reconstructed from screenshots):

| Set | Files | Rows | Frauds | Fraud share | Accounts | Dates |
|---|---|---|---|---|---|---|
| Training | 1 to 10 | 8,622,629 | 12,757 | 0.148% | 33,876 | 2024-10-01 to 2025-05-31 |
| Validation | 4950 to 4954 | 4,292,059 | 7,285 | 0.170% | 16,792 | same period |
| Evaluation | 8000 to 8010 | 2,466,461 | 3,818 | 0.155% | 31,474 | 2025-05-01 to 2025-06-30 |

No account appears in two sets. So validation tests the model on *other customers* from the same months (`bridge/releases/tf-stage1-v0.1.0/DECISIONS.md:20`). Evaluation uses other customers again, in May and June 2025: May overlaps the last training month, and June is later than all training data (`bridge/OWNER_QA.md:518`).

**Think of it this way:** out of every 1,000 transactions, about 1.5 are fraud. That rarity shapes almost every choice below.

## Step 2. The 23 features

The model may look at 23 facts per transaction, listed in `fraud/configs/predictors.csv:2-24`:

- **6 numbers:** amount, the external Visa fraud score, three daily spending or cash limits, and the balance before the transaction.
- **13 codes:** for example transaction type, PIN check result, CVV result, chip cryptogram result, whether the card was present, whether the terminal was unattended.
- **4 from the timestamp:** month, day of month, hour, day of week. *Why:* the raw timestamp is only used to order transactions, not as an input (`docs/fraud_detection_plan_detailed.md:24`).
- **Plus 6 "is missing" flags,** one per number. *Why:* a missing number is filled with a typical value, and the flag lets the model tell a filled-in value from a real one (`docs/fraud_detection_plan_detailed.md:21`).
- **Never the label of an earlier transaction.** *Why:* labels can change weeks later and may not be known when a transaction is scored (`docs/phase4_design_decisions.md:12`; your words, `bridge/OWNER_QA.md:887`).

Measured input problems (run-001, 3-file samples, `model.md:76-89`): one cash-limit field is missing in 96.5% of sampled training rows. The month is unknown to the model for 48.69% of sampled evaluation rows, because June never appears in training. For V1 this is kept as a stated limit; month handling moves to V2 (`bridge/OWNER_QA.md:536`).

## Step 3. Preprocessing with frozen artifacts

Before the model sees anything, each raw value is converted the same way every time, using **preprocessing artifacts**: a folder of small files made once from training files 1 to 5 (`fraud/configs/preprocessing.yaml:9-12`).

- **Numbers:** fill a gap with the stored middle value (median), then rescale with the stored average and spread, so all numbers sit on a similar scale (`fraud/data/preprocessing.py:177-180`).
- **Codes:** look the value up in a stored list. A value never seen before becomes "unknown" (index 0); a missing value becomes "missing" (index 1) (`fraud/data/preprocessing.py:34-36`).

*Why frozen:* so training, validation and evaluation are encoded identically (`docs/phase4_design_decisions.md:23`). If artifacts were rebuilt mid-study, the inputs would silently change under the experiments, which is why a rebuild must get a new version number (`bridge/OWNER_QA.md:1045-1049`).

## Step 4. Building each transaction's history

For every transaction (the **target**), the code collects the same account's earlier transactions (`fraud/data/sequence_builder.py:146-215`):

1. Read one file and encode every row with the artifacts.
2. Group rows by account and sort by time.
3. For each target, take up to N earlier transactions (N is the **history length**: 0, 5, 10, 15 or 20 in V1).
4. If there are fewer than N, fill the gaps with blanks and mark them "ignore" in an **attention mask**. *Why:* new accounts still need scoring and "can't discard them (fraud is rare)" (`docs/phase4_design_decisions.md:15`).
5. Add the **time gap** to each earlier transaction: how long before the target it happened. *Why:* "Velocity/recency is strong fraud signal" (`docs/phase4_design_decisions.md:14`).
6. Attach only the target's label.

**The strict history rule.** Yakun's plan says history must be strictly earlier (`time < target_time`, `docs/phase4_sequential_plan.md:78`). His code, though, orders same-second transactions by their transaction id and lets the first one count as history for the second (`fraud/data/sequence_builder.py:200`). Nobody knows whether ids follow arrival order; you said "i dont know" (`bridge/OWNER_QA.md:602`). On the bank data, same-second transactions are 1.98% of training rows but hold 6.68% of training frauds (852 of 12,757), a fraud rate 3.37 times the normal one (measured, `model.md:44-48`). So your copies use the strict rule: a same-second transaction is never history for its twin. The cost is tiny: at most 0.0094% of full-depth rows lose a history slot (`model.md:60`). See chapter 5.

**Training only: shuffling.** Windows from about 257 accounts are pooled and shuffled before being cut into batches of 4096 (`fraud/data/sequence_builder.py:223-253`; `model.md:120`). *Why:* one account's windows overlap almost completely, and batches full of one account would teach the model badly (`docs/phase4_design_decisions.md:31`). Evaluation is never shuffled; every transaction is scored exactly once.

## Step 5. Tokens

Each feature of each transaction becomes a **token**, a short list of 48 numbers the model learns:
- a number feature: its value times a learned vector, plus a learned offset;
- a code feature: a learned vector for that code.

That gives 30 tokens per transaction: 6 numbers + 1 time gap + 17 codes + 6 missing flags (`fraud/sequential_model.py:67`). At history 5 the model reads 1 summary token plus 6 x 30 = 181 tokens.
*Why tokens:* this is how an FT-Transformer works; each feature becomes its own token so attention can compare features with each other.

## Step 6. The model reads the tokens

### Architecture A (flat)
All tokens of all transactions go into one long row. Each token gets a tag saying which transaction it belongs to (a "position embedding"). A summary token called CLS is put at the front. One transformer with 4 layers, 8 attention heads and size 48 reads the whole row; the CLS token's final value goes to a small output layer that gives the fraud probability (`fraud/sequential_model.py:23-44,108-132`; `fraud/configs/sequential.yaml:44-50`).
*Why first:* "Simplest path to parity" (`docs/phase4_design_decisions.md:11`). *Cost:* the work grows with the square of the row length, so long histories get expensive.

### Architecture B (hierarchical)
First, a small FT-Transformer (2 layers) sums up each transaction into one vector on its own. Then a second transformer (4 layers) reads those vectors in order, with position tags, and its CLS gives the probability (`waqas/phase4b/sequential_hier.py:1-18,44-93,130-166`).
*Why:* attention over N+1 vectors instead of all tokens is much cheaper, so it "scales to long histories" (`docs/phase4_sequential_plan.md`, section 5). A recorded difference: A and B use the same recipe but not the same size (2+4 layers against 4), so they are "matched on recipe, not on size" (register R-036).

### All-position B
B run so that one pass over a chunk of an account's transactions gives a score for every transaction in the chunk, each seeing only earlier ones. Your copies cut chunks only between seconds, so the strict rule holds (`waqas/phase4b/ALL_POSITION_CONTRACT.md` on PR #5's branch). *Why it was rebuilt:* the older version gave each earlier transaction a time gap to the *final* target, a value from the future, and "A causal attention mask cannot repair a feature that already depends on the future" (`ALL_POSITION_CONTRACT.md:26`).

### The attention direction
By default every transaction may look at every other in its window ("bidirectional"). *Why it is safe:* the window holds only the target and its past, and features are not labels (`docs/phase4_design_decisions.md:17`). The "causal" option lets each transaction look only at earlier ones; V1 compares the two at h5.

### The single-transaction reference (REF-SINGLE)
Yakun's Phase 3 model: one transaction, no history, size 32, 3 layers, batch 8192, learning rate 0.001, 2 epochs, trained on files 1 to 100 (`fraud/configs/streaming.yaml:19-55`). *Why it is in V1:* Yakun's test of success is that the history model beats it (`docs/phase4_sequential_plan.md:209-210`). Note that A at h0 is not the same model as this reference (`bridge/CHANGES_2026-10-06_to_10-08.md:294`).

## Step 7. Training

| Setting | Value | Why |
|---|---|---|
| Epochs | up to 10 | reason not recorded |
| Batch | 4096 windows; at long history smaller batches added up to the same total (for example h10: 1024 x 4) | "start moderate"; longer histories need more GPU memory per window (`fraud/configs/sequential.yaml:53`; `bridge/audits/CH_phase4_fixes_closed_2026-10-06.md:10-12`) |
| Number precision | bf16-mixed | "~halve memory + faster on H200" (`fraud/configs/sequential.yaml:57`) |
| Seed | 42 | Yakun's seed; your choice for V1 (`bridge/OWNER_QA.md:378`) |
| Optimizer | AdamW, learning rate 0.0003, weight decay 0.00001 | "lower for the deeper/richer model" (`docs/phase4_sequential_plan.md:235`); AdamW your decision (`bridge/OWNER_QA.md:938`) |
| Learning-rate cut | halve it after 3 epochs with no improvement in validation loss (`fraud/sequential_model.py:155-156`) | reason not recorded |
| Loss | cross-entropy with no extra weight on fraud (`pos_weight: 1.0`) | default; tuning it is Yakun's future item E (`docs/phase4_sequential_plan.md`, section 10) |
| Early stopping | stop if validation AP has not improved for 5 epochs | AP picks the model (`docs/fraud_detection_plan_detailed.md:23`) |
| Checkpoints | `best.ckpt` (best validation AP) and `last.ckpt` | to score the best epoch, and to resume |

**Validation during training.** After each epoch the model scores the whole validation set, and AP and AUROC are computed once over all of it. *Why not per batch:* "Per-batch ranking metrics are meaningless at low fraud prevalence (most batches have no positives)" (`fraud/callbacks.py:46-51`).

## Step 8. Scoring and the prediction file

The scorer loads `best.ckpt`, reads the evaluation files in order with no shuffling, gives every transaction a fraud probability, and writes one prediction file with the ids, amount, label and score (`fraud/scripts/score_sequential.py:65-134`). Yakun's version always used the same file name, so a second run overwrote the first; your copy names it per run (`waqas/phase4a/scripts/score_sequential.py:97-104`). In V1 these files stay on the pod (D44 in chapter 8).

## Step 9. The AP number

AP and AUROC are computed with the standard scikit-learn functions over the whole set (`fraud/scripts/score_sequential.py:136-140`; `fraud/callbacks.py:78-79`).

**How to read AP, in plain words.** Sort all 2,466,461 evaluation transactions by score, highest first. Walk down the list. Each time you reach a real fraud, note what share of everything above it is fraud. AP is the average of those shares. A model that ranked all 3,818 frauds at the very top would score 1.0. A model guessing at random would score about the fraud share, 0.00155. ChatGPT's caution: "AP around 0.14 is not 14% accuracy or recall. It is a ranking summary" (`chatgpt/AUDIT.md:143`).

**Reference points:**

| Model | Where measured | AP | Source |
|---|---|---|---|
| Single transaction, Phase 3 | evaluation file 8000 | 0.0940 | `docs/phase3_streaming_plan.md:15` |
| Single transaction, 100 files | validation | 0.1247 | `docs/phase4_sequential_plan.md:295` |
| A at h5, 10 files | validation | 0.1293 | `docs/phase4_sequential_plan.md:296` |
| A at h10 (your 2026-10-06 rerun) | evaluation 8000 to 8010 | 0.080100 | `ablations/current_run_results_10062026/results.md` |
| A at h15 (your 2026-10-06 rerun) | evaluation 8000 to 8010 | 0.090500 | same |

These are history. V1's numbers will replace them, because every V1 run is trained fresh on the corrected code (`bridge/OWNER_QA.md:367`).

**V1 reading rules:** pick models by validation AP, never by evaluation AP, so the final test is not used for choosing (`bridge/plans/CL/2026-10-10-first-release/FIRST_RELEASE_SCOPE.md:29`); give each comparison a range by resampling whole accounts, because fraud clusters within accounts (`bridge/OWNER_QA.md:534`).

## Check yourself

- Why are preprocessing artifacts frozen?
- What does the strict history rule change, and why do the numbers say it matters?
- If AP is 0.09, does that mean 9% of frauds are caught? (No; see Step 9.)
