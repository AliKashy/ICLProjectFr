# How a run works on the pods

**In short:** you download a reviewed ZIP, unzip it into a new empty folder on the pod, fill in your private names once, type the commands from the stage's page, and send back the whole folder it writes. Nothing reaches the pod any other way, because the pod has no GitHub connection (`bridge/OWNER_QA.md:844`).
Commands below are copied from the owner pages, with private parts written as `<...>`. The pages themselves are the authority: always type what the current page says.

## The stages

| Stage | What it does | Status at the end of 2026-10-12 |
|---|---|---|
| 1. Pre-flight | Read-only checks; no GPU, no training. | Ran as run-001; result FAIL; read and acted on. |
| 2. Smoke check | A and B, tiny training, to see everything works. | Package `003` published; nothing returned yet. |
| 3 and 4. All 15 V1 runs on 4+1 GPUs | Your chosen plan for today. | Released as package 004 (23:38 UTC); your run pending. |
| 5. Analysis | Compares the runs on the pod; returns totals only. | Included in package 004. |

**Rules for every stage** (`INT:runbook/2026-10-07/RELEASE.md:3-29`):
- Each package goes into a **new, empty folder**. Never unzip over old code. *Why:* so an old file can never mix into a new run, and old results stay untouched.
- **No flags, no variables** beyond what the page says. *Why:* the scripts stop if a test setting is left on, so a test switch cannot leak into a bank run.
- **Send the whole folder**, as files. Not screenshots, not a summary. Everything except model files (`*.ckpt`) and prediction files (`*.parquet`), which stay on the pod (your answer to OQ-24).
- **A FAIL is information.** Send the folder whatever it says. "A stage is done when its return has been read."

## Getting a package onto the pod

The packages are published as ZIPs with private names replaced by placeholders, at your request (`bridge/releases/README.md:7-11`). Each one has its own number and time, like `003_20261012_194404_UTC`, so a new one never overwrites an old one.

```bash
source <pod home>/<environment name>/bin/activate
cd <pod project folder>
python -m zipfile -e <package id>.zip .
cd <package id>
python personalize.py --package <package name> --id <your id> --reference-id <reference id> --data-bucket <data bucket> --artifact-bucket <artifact bucket>
```

- **Line 1** switches on the Python setup you used before, so the checks and the training use the same Python.
- **Line 3** unzips the package.
- **Line 5** puts your private names back into this copy only. It checks file fingerprints first, writes a record called `PERSONALIZATION.json`, and never rebuilds artifacts or reads your credential file (`bridge/releases/tf-stage1-v0.1.0/package/README.md:45`).

The exact values are in the private instructions for each package, under `bridge/releases/<release>/package/README.md`.

## Stage 1: the pre-flight

```bash
python runbook/2026-10-07/preflight_pod.py
```

- **What it does:** reads only. It runs the test suite on the pod, compares every code file with the reviewed list (the manifest), reads a few columns of every data file, and records dates, duplicates, same-second ties, history depth, package versions and the artifact fingerprints (`INT:runbook/2026-10-07/STAGE1_PREFLIGHT.md:29-33`).
- **What comes back:** `runs/preflight/<time>/` with `SUMMARY.txt` and about a dozen files. The last lines say `RESULT PASS` or `RESULT FAIL` and the folder name.
- **Why it exists:** a wrong package or environment shows up here in minutes, not after a day of GPU time; and it answers data questions nobody could answer from outside the bank. You wanted it first: "if there's anything downstream that's impacted by the results from the pre-flight, we're not just wasting token usage" (`bridge/OWNER_QA.md:590`).
- **What happened:** run-001 (2026-10-12). Copilot first started `batch1.sh` by mistake; it stopped at its own failed pre-flight, so nothing trained. The pre-flight itself: FAIL, 3 FAIL lines; tests 746 passed, 2 failed, 18 skipped (Copilot's report). Cause: the `feature__` photo misread (chapter 5).
- **No GPU check.** You removed it: "Don't have a GPU test on the preflight stuff at all" (`bridge/OWNER_QA.md:426`). It only records whether the code sees a GPU.

## Stage 2: the smoke check

```bash
bash runbook/2026-10-07/smoke.sh
```

- **What it does:** runs the pre-flight first; only if it passes, trains A and then B at history 5 on training files 1 and 2 for 2 epochs, checking on validation file 4950 (`INT:runbook/2026-10-07/STAGE2_SMOKE.md`).
- **What it checks:** the validation loss falls from epoch 1 to 2; validation AP and AUROC are sensible (finite, between 0 and 1, AP above the fraud share); the peak memory; and a spot check of 20 histories that each holds only earlier transactions (`INT:runbook/2026-10-07/smoke_checks.py:14-27`).
- **What comes back:** `runs/returns/smoke_<time>/`; the last line says `RESULT: PASS` or `RESULT: FAIL`.
- **Why:** it is Yakun's own first check (`docs/phase4_sequential_plan.md`, section 9 item 1), and it measures how long training takes on the real data.
- **And today's plan?** Your forty-eighth message (all 15 today) has no separate smoke stage; the plan's `prepare` step runs the full pre-flight instead. Whether you already ran smoke package `003` on the pod is not recorded (coordinating session, 2026-10-12).

## Stages 3 and 4 today: all 15 runs on 4+1 GPUs

You have a 4-GPU pod until tomorrow morning and a 1-GPU pod that stays (`bridge/OWNER_QA.md:153-155`, `:1362`). Both see the same shared folder (`:1351`). The page for this is `runbook/2026-10-07/STAGE3_V1_PARALLEL.md`. The joined V1 candidate is branch `claude/v1-integration-2026-10-12` (head `b4d9922` at 23:00 UTC, with the lanes' changes merged); use the version in your package.

Every long command starts with `setsid nohup` and ends with `&`. *Why:* the run keeps going if you close the terminal or the browser. Check progress with `tail -n 5 <log file>`; each log ends with `command ended: exit <number>`.

**Step 1, once, on the 4-GPU pod: prepare.**
```bash
setsid nohup bash -c 'python runbook/2026-10-07/parallel_v1.py prepare --stage all --session v1_001; echo "command ended: exit $?"' > v1_prepare.log 2>&1 < /dev/null &
```
Runs the full pre-flight with tests (once, as you asked, `bridge/OWNER_QA.md:163`), creates a folder for every run and writes the plan file. About 10 minutes, silent while the tests run. Success: the log ends with `PLAN=runs/returns/parallel_v1_001_all/PLAN.json`. If not, nothing trained; send the folder and the log.

**Step 2, at the same time on both pods: run.**
```bash
# on the 4-GPU pod
setsid nohup bash -c 'python runbook/2026-10-07/parallel_v1.py run --plan runs/returns/parallel_v1_001_all/PLAN.json --pod four; echo "command ended: exit $?"' > v1_run_four.log 2>&1 < /dev/null &
# on the 1-GPU pod
setsid nohup bash -c 'python runbook/2026-10-07/parallel_v1.py run --plan runs/returns/parallel_v1_001_all/PLAN.json --pod one; echo "command ended: exit $?"' > v1_run_one.log 2>&1 < /dev/null &
```
Each GPU works through its own queue, one run after another. Each run is Yakun's own runner on a one-run copy of the original spec file. A failed run does not stop the others.

The queues (`claude/v1-lane-batch2-2026-10-12:runbook/2026-10-07/parallel_v1.py:56-59`):

| GPU | Runs, in order | Hours (my sum of the assumed and measured figures; not in the records) |
|---|---|---|
| 4-GPU pod, GPU 0 | A-H15, A-H00, A-H05 | 12.2 |
| 4-GPU pod, GPU 1 | B-H20, B-H15 | 12.5 |
| 4-GPU pod, GPU 2 | A-H10, A-GAP10-OFF, REF-SINGLE, B-H00 | 10.8 |
| 4-GPU pod, GPU 3 | B-ALLPOS-H5, B-H05, B-H10, A-MASK05-C, A-GAP05-OFF | 12.5 |
| 1-GPU pod | A-H20 | 17.0 |

*Why this order:* "The four-GPU pod is temporary: its queues run the longest cells first, so the big runs end while it exists; the longest cell (A-H20) is on the pod that stays" (`parallel_v1.py:53-55`). "Longest first" means the longest single run, by the assumed hours: B-ALLPOS-H5 3.0 h; B-H05 and B-H10 together about 5.5 h in `batch1.sh:18`, so about 2.75 h each; A-MASK05-C and A-GAP05-OFF 2.0 h each (coordinating session, 2026-10-12; all assumed, none measured). The V1 design's own table gives B-H05 2.0 h and B-H10 3.5 h instead (`bridge/plans/CL/2026-10-12-v1-design/matrix.md:244-245`), so the two assumed figures differ. Four runs on one pod share its processors, memory and storage reads, and may slow each other; nobody has measured that (`DESIGN_V1_AFTER_RUN001.md:9`).

**A safety gate:** A-GAP10-OFF starts only after A-H10 finished and passed its checks (`parallel_v1.py:230-243`). *Why:* "time gap off" means nothing without its "time gap on" partner trained on the same code and data.

**If the 4-GPU pod goes away.** Do nothing on it. Wait for the 1-GPU pod's log to end, then on the 1-GPU pod:
```bash
setsid nohup bash -c 'python runbook/2026-10-07/parallel_v1.py run --plan runs/returns/parallel_v1_001_all/PLAN.json --pod all --retry-failed; echo "command ended: exit $?"' > v1_run_all.log 2>&1 < /dev/null &
```
It runs every unfinished run, one after another, on that one GPU. Finished runs are skipped. A run that was cut off starts again from the beginning in a new folder; its old files are kept. "`--pod all`" means all queues on one GPU, not all GPUs.

**Step 3: finish.**
```bash
setsid nohup bash -c 'python runbook/2026-10-07/parallel_v1.py finish --plan runs/returns/parallel_v1_001_all/PLAN.json; echo "command ended: exit $?"' > v1_finish.log 2>&1 < /dev/null &
```
Writes each run's status to `FINISH.txt`, refuses while any run is still going, merges the per-run records into the one ledger `runs/run_log.csv`, and scores the three validation-only runs on the evaluation files (step 2.0). *Why only here:* two pods writing one ledger file at once could corrupt it, so only `finish` writes it.

**Step 4: analysis (stage 5),** in the same folder, after `finish`:
```bash
setsid nohup bash runbook/2026-10-07/analysis.sh > v1_analysis.log 2>&1 < /dev/null &
```
Finds each of the 15 runs' newest successful attempt and its prediction file, and computes every comparison with its range and label. CPU only. Returns totals only, never a transaction or a score. Last line: `Analysis finished: 15 of 15 runs found and compared` or `THE COMPARISON DID NOT FINISH`. *Why on the pod:* the prediction files stay there (OQ-24).

**Where it goes:** the V1 package is **004** (`004_20261012_225800_UTC.zip`, released 2026-10-12 23:38 UTC from source `d4205d4`). Its private guide, `bridge/releases/tf-v1.0.0/package/README.md`, has the exact commands, and its step 7 zips everything into `004_20261012_225800_UTC_return.zip` for you to send back. Returns are kept in the same release folder.

**Current package (2026-10-13): 005.** Package `005_20261013_015754_UTC` (source `96ed240`, records in `bridge/releases/tf-v1.0.1/`) replaces 004 for running. It installs into your existing project folder and overwrites only the files under `waqas/` and `runbook/`; the unzipped numbered folder is temporary and removed after the copy. It has no test or fake-data files, so `prepare` runs the pre-flight without tests (fifty-second message). It ships no `fraud/` files: your pod's own `fraud/` is used, and any difference from the transcribed copy is recorded as a warning, not a stop. A code change during the study still stops it. The commands are the same as above; the exact ones are in the package's private guide. This replaces the "new, empty folder" rule for this package.

**No pod-loss tests.** You said "The pod doesn't die don't even do that shit" (fifty-first message), so the extra tests that simulated a dying pod were dropped. The continuation command above stays available, for you to use only if you choose.

**What to send:** the whole `runs/returns/parallel_v1_001_all/`, the analysis folder, `runs/run_log.csv`, and the logs `v1_prepare.log`, `v1_run_four.log`, `v1_run_one.log`, `v1_run_all.log` (if used), `v1_finish.log`, `v1_analysis.log`.

**What not to do:** edit any file (a changed file makes runs fail the identity check); start the same `run` twice on one pod; start `--pod all` while either pod's `run` is still going; run `batch1.sh` or `batch2.sh`; set any variable.

## The pieces that keep results trustworthy

- **The return folder** exists from the first second and fills as the stage goes, so "send the folder" works even after a crash (`INT:runbook/2026-10-07/batch1.sh:60-67`).
- **Attempt folders:** every launch writes a new folder named by its time; nothing earlier is overwritten.
- **The collector** marks a run "ok" only if everything about it agrees: its results row, its saved settings, the fingerprints of its settings and model file, and finite AP and AUROC between 0 and 1. Otherwise it gets a named status such as `evidence_mismatch`. It never recomputes a number (`INT:runbook/2026-10-07/collect_returns.py:7-37`).
- **The ledger** `runs/run_log.csv` has one row per run attempt. Different evidence for a finished run is a conflict, not silently written over.
- **The manifest** `runbook/2026-10-07/github_source_manifest.csv` lists every code file with its fingerprint. The pre-flight compares the pod's files with it. *Why:* the pod has no Git, so this is the only proof that the code you ran is the code that was reviewed (`bridge/OWNER_QA.md:848`).

## The four failures that are real

You asked "Why would stuff even fail? It's just doing eval training and validation" (`bridge/OWNER_QA.md:245`). The answer recorded (`:248-252`):
1. The pod restarts or the session closes mid-run (A-H20 alone is about 17 hours). Covered by `setsid nohup` and `--retry-failed`.
2. The GPU runs out of memory at h15 and h20. Covered by the smaller batch pieces.
3. A missing package or environment problem. Shown by the pre-flight.
4. A failed pre-flight. Nothing trains; send the folder.

## Package 006 (2026-10-14): history-5 evidence and two 100-file runs

**Update 2026-10-14, 14:49 UTC:** you postponed steps 3 and 4 to sweep on small data first (change journal). Steps 1 and 2 are still usable. Do not start steps 3 and 4 yet (`bridge/releases/tf-v2.0.0/package/README.md`).

Your exact commands are in the private `bridge/releases/tf-v2.0.0/package/README.md`. In plain words, the five steps are:
1. **Install** the ZIP into your existing project, the same way as package 005. It replaces only the files it owns. Yakun's `fraud/`, credentials, frozen artifacts, saved models and earlier results are kept. A backup of changed code goes under `runs/install/`. *Why:* nothing from V1 is lost. Do this while no training job is using the files.
2. **Read the history-5 evidence** with `python -m waqas.v2.h5_diagnostics --inspect-checkpoints`. It writes a return ZIP. *Why:* to look for why history 5 did poorly, without training anything.
3. **Prepare** with `python -m waqas.v2.scale_runs prepare --name scale100_v006`. It copies your V1 settings for REF-SINGLE and B-H15 and changes only the training files (1 to 100) and the output folders. If it finds no matching settings, or two that differ, it stops and lists them. *Why:* it must not guess which earlier attempt to copy.
4. **Run** both models one after the other on one GPU, in the background, then collect the results. Success shows `ref: ok`, `b15: ok` and `SCALE_RETURN=...` in `runs/v2_006_launcher.log`. A return ZIP alone does not prove success.
5. **Send back** both ZIPs from `runs/returns/v2_006/` into `bridge/releases/tf-v2.0.0/returns/`, plus the launcher log if the run failed early. Never upload returns to the public download repository.

## Merging

No stage needs a merge. Whoever merges (you, or since your fiftieth message an assistant; chapter 8, D59): PR #5 first, then PR #3, with "Create a merge commit". Never PR #4 or PR #2 (`INT:runbook/2026-10-07/MORNING.md:126-128`).

## Check yourself

- Why does every package go into a new, empty folder?
- What does `--pod all --retry-failed` do, and when do you use it?
- Why does only `finish` write the ledger?
