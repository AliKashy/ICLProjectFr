# Decisions log: every decision you made

**In short:** this is a list of your decisions, oldest first. Each has your exact words, what it changed, and the reasoning.
All quotes come from `bridge/OWNER_QA.md` (line numbers given), where both assistants record your answers word for word.
Quotes keep your original spelling. Where the record is a paraphrase, it says so.
Old entries are never rewritten; when a later decision changes an earlier one, the later entry says "replaces" and points back.

Messages are numbered the way Claude's records number them ("the twelfth message"). Some decisions were given to ChatGPT; those are marked "to ChatGPT".

---

## 2026-10-07: the first set of answers (22 questions)

**D1. Claude and ChatGPT choose the merge order.**
> "I want you and ChatGPT to decide what's the best." (`:822`)
- Changed: the assistants agreed the order themselves. It is now PR #5 first, then PR #3 (`:978`).
- Reasoning: you had not yet reviewed either PR.

**D2. Run A at history 10 once, unless the reason for three convinces you.**
> "if you can explain why you want to run it three times and I approve the reasoning, then we can run it three times. But if not, save 10 GPU hours." (`:827`)
- Changed: A-H10 runs once and serves as the partner for its controls. Saves about 9.8 GPU hours (2 x 4.9 h, assumed from the measured 2026-10-06 h10 time) (`:999-1003`).
- Reasoning: the noise check the extra runs were for already happens more cheaply elsewhere (`:994-997`).

**D3. No GPU-hour limit.**
> "I don't have like a limit for GPRs." (`:834`)

**D4. Results come back as files, never photos; the pod has no GitHub.**
> "there's no GitHub connections, anything. Um, I will be uploading the files that y'all provide onto that. [...] You do not get the photos." (`:844`)
- Changed: every instruction says "send the file", and the pre-flight checks file fingerprints against a manifest, since the pod has no Git to prove which code is running (`:848`).

**D5. Accounts do not span files.**
> "each account one person's account is only in one file. [...] Yeah no accounts cannot span files. I'm pretty sure." (`:872`)
- Changed: not asked again; the pre-flight re-checks it on every file it reads (`:954`).

**D6. Always check Yakun's documents before asking.**
> "don't don't just put random questions just to have them. Look at his documents as well. Always look at his documents." (`:882`)
- Changed: this became rule 3 of `OWNER_QA.md`.

**D7. No earlier transaction's fraud label may be a model input.**
> "we do not look at the label for previous transactions. [...] Because, of course, of the label maturity issue" (`:887`)
- Changed: confirmed in the code; only the 23 predictors are inputs (`:962`).
- Reasoning (yours): a label can change weeks later when a customer reports fraud, which "dirties the results".

**D8. V22, V17 and the CHP model are for V2 feature work, not now.**
> "V2 is going to be the feature expansion." (`:897`)

**D9. One shared question file for both assistants.**
> "both of y'all present the questions to me together, regardless of what agent um, is using it" (`:923`)
- Changed: `bridge/OWNER_QA.md` was created, and `AGENTS.md` and `CLAUDE.md` send every session to it first (`:925`).
- Reasoning (yours): to set up "a system where it's impossible for y'all to hallucinate" and not "forget information because conversation compaction is a real thing" (`:920`).

**D10. Karpathy's "autoresearch" is a future idea, for feature engineering.**
> "first focus on architecture A, architecture B" (`:912`)

---

## 2026-10-08

**D11. Never edit Yakun's folders; corrections go into your copies.**
> "yeah we never edit his original folders. the solution is we make duplciates and put the version we correct/cahnged into my folder" (`:762-763`)
- Changed: PR #4, which edited 13 files in `fraud/`, was replaced by PR #5, which puts the same fixes into copies under `waqas/base/` (`:765-767`).
- Reasoning: not stated beyond your words. The effect is that Yakun's working code stays as the reference.

**D12. You do the merging.** (Later relaxed by D59.)
> "id rather do the merging; yall just do pr" (`:777`)

**D13. One GPU, one run at a time.**
> "one gpu, one run at a time; we have memory of like 132 gb or so" (`:782`)
- Changed: the batches were ordered by importance to run back to back. (Replaced for the holiday by D56.)

**D14. Yakun is away for a while, but the work must finish.**
> "hes out of office for a while but we need to finish" (`:787`)

---

## 2026-10-09

**D15. Separate reviewer sessions are approved; budget is not a limit.**
> "there is no budget, there is no issue. [...] It is very, very high quality." (`:750`)
- Changed: Claude opened five separate reviewer sessions (OQ-10 answered yes, `:753`).

**D16. Every piece of work through every reviewer, findings ranked, then a walkthrough together.**
> "I want everything to be put through all reviewers; I want alll the reviewers findings ranked. And then we go through them together" (`:737`)
- Changed: one ranked register of findings, `bridge/reviews/REGISTER/` (`:744`).

**D17. Set Phase 5 and the future experiments aside.**
> "Forget the phase 5 and all of the future experiments for now. Honestly remove all of phase 5 from importance." (`:723`)
- Changed: no review, fixes or GPU time for `waqas/future_experiments/`; nothing deleted (`:726-729`).

**D18. Keep predict-every-transaction B and B at history 0; finishing means all of Yakun's open items.**
> "But for the other two, no we need to keep those. Finishing this project is finishing all of the open items, every single thing…" (`:703`)
- Changed: all-position B and B h0 stay in scope. Your question about whether settings interact (does h5 win with the time gap on but h10 with it off?) got a proposed run design (`:707`).

**D19. Track every change against your GitHub uploads; no fingerprint script on the pod.**
> "I just want to track everything since the initial like files being uploaded onto GitHub by me. And no, I won't do that scrip thing" (`:690`)
- Changed: the baseline is your uploads on GitHub, published as branch `baseline/waqas-uploads-2026-10-09` with the file-by-file list `bridge/baseline/CHANGES_BY_FILE.md` (`:694-696`).

**D20. Every file and edit is checked by reviewers.**
> "for all files being made, edits work being done each of the reviewers need to work as well as you right?" (`:678`)
- Changed: a finding closes only when a reviewer who did not write the fix re-checks it (`:680`). How widely to read this is still open (OQ-18, `:73-77`).

**D21. Do not lean on compacted summaries; re-read the GitHub records.**
> "Don't compact so much…recall there are like different files on GitHub too to assist with losses due to compaction" (`:670`)
- Changed: after a compaction, Claude re-reads its continuity records before acting (`:672`).

**D22. A roadmap made by both assistants, checked by all agents.**
> "you and ChatGPT need to create a roadmap. What I need to first second etc. need to finish this project. Have all agents look at everything" (`:657`)

---

## 2026-10-10 (to ChatGPT)

**D23. Everything filled in so you can just run.**
> "I want ever single fine to be completely filled up so I can just run." (`:1131`)
- Changed: packages carry your real settings, with no template filling left (`:1133`).

**D24. Step-by-step packages: you run one, send the results, then the next is built.**
> "You would create a step one package, you would push it on, and then I would handle it." (`:1154`)
- Changed: the work became staged releases (stage 1 pre-flight, stage 2 smoke, and so on).

---

## 2026-10-11

**D25. Yes: Claude may write the first-release fixes into your copies (OQ-17).**
> "Yes, start implementing FIRST_RELEASE_SCOPE v2.2 in draft PRs #5 and #3 [...] Change only my copies and the runbook; leave Ya's originals untouched. [...] Do not merge or start bank-side workloads." (`:614`)

**D26. The credential file is where it was; you do not know how same-second ids are ordered (OQ-19, OQ-13).**
> "yes credential is there. / q 13 i dont know." (`:601-602`)
- Changed: the strict history rule stays the default, and the pre-flight counts same-second ties (`:607`).

**D27. Sequential releases; the first release answers questions for the rest.**
> "firsstrelease could anwser alot if not all questions, those answsers r used for final buildout" (`:603`)

**D28. Push the pre-flight first, on its own.**
> "If the pre-flight is done, let's do let's push the pre-flight. [...] this way, if there's anything downstream that's impacted by the results from the pre-flight, we're not just wasting token usage." (`:590`)
- Changed: stage 1 went out alone; the other lanes paused until its return was read (`:593-594`).

**D29. No local-only files and no extra guardrails (to ChatGPT).**
> "dont mark anything local only. im gonna send yall everything. dont add guardrails i dindt tell u to add." (`:1247`)
- Changed: every generated file is returned (confirmed again in D41). Which pre-flight stops to keep became OQ-21 (`:83`).

**D30. Packages and their returns kept together (to ChatGPT).**
> "the same one that I'm gonna upload is gonna be the same one where I'm gonna upload, like, the answers" (`:1251`)
- Changed: each release folder under `bridge/releases/` has `package/` and `returns/` (`:1255`).

**D31. Both assistants work on everything; no over-engineering; do not deviate from Yakun (to ChatGPT).**
> "both of you are gonna work on each and every single thing. [...] It's not deviating from Yakun. Cause, I mean, Yakun, at the end of the day, he still had running code." (`:1229`)

**D32. A public copy with private names replaced by placeholders, and the smallest possible changes (to ChatGPT).**
> "if it says from Wakas dot import, just remove Wakas, right? But keep the import, and I can just fill it in later." (`:1208`)
- Changed: public ZIPs replace only private identifiers; your private instructions stay private (`:1210`, `:1285-1287`).

**D33. Two project managers and constant communication (to ChatGPT).**
> "I want two project engineers, or project managers, right? One from you, one from Claude." (`:1191`)
- Changed: issue #7 was opened as the coordination log (`:1193`).

---

## 2026-10-12

**D34. Too many reviews for an initial package.** (fourteenth message)
> "Okay doing too much reviews for an initial package. Is it done." (`:579`)
- Changed: no more wording review rounds for stage 1 (`:582-583`).

**D35. Fix the artifact file names, and make the other changes the pre-flight return calls for (OQ-22).** (fifteenth message)
> "Fix the feature amount. U have my approval for that. Make all the other necessary changes from the information you just found as well." (`:565`)
- Changed: two characters in Yakun's `fraud/data/preprocessing.py`, lines 203 and 215, `feature_` became `feature__`. The GitHub copy was rebuilt from photos and a double underscore reads as one; without the fix training cannot load the artifacts (`:85`, `:568`). The one approved exception to D11.

**D36. Design the final A, B and experiments from the data, together, to be perfect.** (sixteenth to twentieth messages)
> "We need this to be absolutely perfect, so don't worry about that." (`:550`)
- Changed: a joint design before any training; the problems to solve were the month input, clustered fraud, imbalance and the run list (`:553-559`).

**D37. V1 is Yakun's design plus the longer histories; other changes in later versions.** (twenty-first message)
> "we just do what he has rather than, like, switching everything up. And in version two or version three, we can do something else. So that way we have, like, some type of results coming in." (`:524`)
- Changed: V1 = Yakun's section 9 checks, his section 10 B longer histories, his Architecture B. Kept from the pre-flight findings: the strict history rule (his own rule) and the artifact name fix (`:526-536`).

**D38. V1's purpose: the best architecture and the best history length.** (twenty-second and twenty-third messages)
> "this is more of like, just figuring out, you know, the best architecture, how, what's like the best history length, etc." (`:511`)
- The May/June split asked for here was later dropped (D46).

**D39. Both A and B, both ways of running B, the time gap test, and everything in Yakun's plan.** (twenty-fourth message)
> "there were two different ways we could run architecture B. [...] we're doing both of those, correct? And then we're also doing like the delta and like every single thing that he had on there." (`:488`)
- Changed: V1 includes default B and all-position B, the time-gap on/off test, the causal-mask test and the leakage check (`:491-505`). All-position B must also respect the strict rule before it runs (`:496`).

**D40. Build V1 now; design V2 with 100+ training files, new optimizers, new features.** (twenty-fifth message)
> "Make the first one I need to run and then make the second version as well. A big thing in the second version is also going to be the addition of 100+ training" (`:465`)
- Changed: V2 design started; three research tasks, each done by both assistants (`:478-481`).

**D41. Return every file, nothing local-only.** (twenty-sixth message)
> "Yes. No local only" (`:452`)

**D42. Do not assume four GPUs; then, no GPU test in the pre-flight at all.** (twenty-seventh and twenty-eighth messages)
> "I might ir might not have 4 gpu" (`:438`); "Don't have a GPU test on the preflight stuff at all. Thats undercut" (`:426`)
- Changed: the pre-flight's GPU check was removed. It only records whether the code can see a GPU (`:429-432`).
- Consequence, stated once: a pod with no visible GPU would train on the slow processor, and the run's log would show it.

**D43. Split the remaining work across ChatGPT, Codex and other Claude chats.** (twenty-ninth message)
> "If you can distribute some of the work to a different chat or to codex do that. Thats why I need yall to work together." (`:410-411`)
- Changed: lanes L1 and L2 opened as separate Claude sessions; ChatGPT took the analysis tool and the smoke package (`:415-419`).

**D44. Keep checkpoints and prediction files on the pod (OQ-24, option a).** (thirtieth message)
> "Choose option a" (`:391`)
- Reasoning: every number the analysis needs is computed on the pod and returned as totals; prediction files are transaction-level bank data (`:98`, `:395`).

**D45. V1 uses only Yakun's seed, 42.** (thirty-first message)
> "For now, use just the seed that yaqun was using. We can use different seeds later, we only had that idea to see why there was a difference in my scoring and Yaquns" (`:378`)
- Changed: batch 1 became 6 runs and batch 2 became 9; seeds 43 to 46 moved to later (`:381-384`).

**D46. Rerun everything; the old results are deleted.** (thirty-second message)
> "Rerun it. I deleted all the older results." (`:364`)
- Changed: every V1 run trains fresh; the old times (A h10 4.9 h, A h15 9.7 h) stay only as planning estimates (`:367-368`).

**D47. Test every part on the same fake data at the same time; review while building.** (thirty-third and thirty-fourth messages)
> "Did u forget a h15..make sure ur testing everything…." / "Distribute it so each part can be tested on the same data together rather then 1 by 1." (`:345-347`)
- Changed: a test fails if any of the 15 runs is missing or duplicated; one shared fake dataset on branch `claude/v1-fake-data-2026-10-12` (`:350-358`).

**D48. Give ChatGPT tasks; spawn as many agents as needed; absolutely correct.** (thirty-fifth and thirty-sixth messages)
> "Spawn as many agents, chats, whatever you need to do." (`:326`); "Whatever keeps up the efficiency while guaranteeing great work." (`:308`)
- Changed: per-lane reviewers, an integrator, lane L4 (stage 5) and more ChatGPT tasks (`:311-320`, `:329-339`).

**D49. Keep giving ChatGPT and its workers tasks.** (thirty-seventh and thirty-eighth messages)
> "Continue giving tasks to ChatGPT and all of its workers too." (`:287`)
- Also answered: Yakun's folders changed in 2 lines of 1 file (`:291`).

**D50. Do not over-engineer: build only what the task needs.** (thirty-ninth and fortieth messages)
> "Make sure ur not over engineering: adding unnecessary components just to add them." (`:265`); "Why would stuff even fail? It's just doing eval training and validation." (`:245`)
- Changed: a standing rule for every session and for ChatGPT: fix a finding only when it has a realistic path to a wrong result, a crash, a lost file or a wrong instruction (`:272-275`). No new failure-handling code; only four real failure modes count (`:248-254`).

**D51. Drop the May/June split; use the files as they are; compare B and A at h5 and at A's best history.** (forty-first message)
> "I really do not care about the May and June thing. Just use the files we have on evaluation as evaluation. Use the ones as validation as validation. Use the ones as training as training. Okay, just don't don't overcomplicate." (`:228`)
> "we could compare A5 and B5, and then also do um, A20 versus B20, because that's like the winning one" (`:228`)
- Changed: replaces the month split of D38 (`:232`). B is compared with A at h5 and at A's best history (`:233`).

**D52. Remove the repeat run; keep stage 5 and the ranges and labels.** (forty-second message)
> "So just remove the repetitive run. I don't care about that. But yeah. keep the stage five analysis script thing and like the ranges and label tools" (`:211`)
- Changed: V1 is 15 runs, 6 in batch 1 and 9 in batch 2, all at seed 42. The separate validation scoring step is removed (validation is already measured each epoch). The full pre-flight with tests runs once per package (`:214-218`).

**D53. Keep Yakun's batch structure and his way of writing prediction files.** (forty-third to forty-sixth messages)
> "Idk just keep whatever he was doing…this runs only really supposed to be running his code with all corrections at longer histories correctly yo" (`:192`)
- Changed: nothing; two proposed changes were not made (`:195-199`).

**D54. Wake each other on demand, no hourly check-ins.** (forty-seventh message)
> "Stop letting ChatGPT do hourly check ins. Figure a way out that both of yall can activate each other whenever u need it." (`:171`)
- Changed: PR #13 wakes Claude, PR #14 wakes ChatGPT (`:174-176`).

**D55. A launcher for 4 runs on one pod and 1 on the other (to ChatGPT); the 4-GPU pod is only for the holiday.**
> "on one of the pods I run 4 of the tests and then the other I run 1" (`:1347`); "Starting tmrw I only have 1 again lol." (`:1362`)

**D56. All 15 runs today, across 4+1 GPUs.** (forty-eighth message)
> "All 15 today (Recommended)" and "Until tomorrow morning" (`:153-155`)
- Changed: one plan; batch 2 no longer waits for batch 1's return to be read; A h20 on the 1-GPU pod; unfinished runs continue on the 1-GPU pod (`:158-165`). Replaces D13 for today.

**D57. Completing still means every part correct (to ChatGPT); do not get stuck on exact folder matching.**
> "we obviously have to do every single aspect of it correct. This is a production at a trillion-dollar company." (`:120`)
> "what I'm more worried about is, like, and more focused on is the overall project, like getting done. I don't want to get stuck in just the beginning." (`:129`)

**D58. A separate agent to explain the project, kept current.** (forty-ninth message)
> "It must use explainable simple English. It must cover everything from beginning to end. Give reasoning for each and every single thing." (`:138`)
- Changed: this guide.

**D59. Pushing and merging on GitHub by the assistants.** (fiftieth message, as recorded by Claude's coordinating session at 2026-10-12T22:50Z)
> "If yall need to push and merge stuff of GitHub etc…do it."
- What the record says it changed: it lifts the earlier rule of D12 that only you merge. The coordinating session's stated conditions: it merges only heads that passed the full test suite and the fake-data run, records each merge in the change journal, and never force-pushes or rewrites history (`bridge/OWNER_QA.md`, section B, fiftieth message; commit `be91b83`).
- Running anything on the bank pods stays yours alone.
- This guide only records the decision; the explainer session itself merges nothing.

**D60. Stop hourly checks; start tasks when assigned (to ChatGPT).**
> "Stop doing hourly checks. I want you to start doing tasks right when your assigned."
- Changed: ChatGPT's hourly task was switched off at 23:16 UTC (`bridge/OWNER_QA.md`, ChatGPT-recorded entry; `72e2f9e`).

**D61. No pod-loss testing; run parts on different GPUs and combine them.** (fifty-first message)
> "The pod doesn't die don't even do that shit. Just need to be able to run different tests and sections in different GPUs and conjoin them together yk"
- Changed: the pod-loss and kill tests were dropped and the one in progress stopped. The split-and-combine path (`finish`, then `analysis.sh`) stays; the one-GPU continuation command stays but is used only if you choose (`bridge/OWNER_QA.md`, fifty-first message; `164b4a7`).

**D62. Build and release the V1 package (to ChatGPT).**
> "Claude posted GO on issue #7, build and release the package."
- Changed: package 004 was built from `d4205d4` and published (`0230121`). See chapter 7.

**D63. Keep only the package in use in the public folder (to ChatGPT).**
> "am i supposed to push 003 and 004? delete the ones not used btw."
- Changed: 002 and 003 removed from the public download folder; history and private records kept (`a8f7ddb`).

**D64. Your question about the pull requests.**
> "whats with all of the push requests?"
- Changed: the coordinating session merged the V1 code into `main` (PR #15, `5166787`) and closed the pull requests that were older drafts or pieces of the same code, under D59 (issue #7 comment 6134853204). The exact wording of this question is as relayed by the coordinating session; it is not yet in `bridge/OWNER_QA.md`.

---

## 2026-10-13

**D65. A slim package installed in place: no test or fake-data files; Yakun's `fraud/` stays his.** (fifty-second message)
> "Remove unnecessary things. No reason to have synthetic shit…goal was to have yall make the corrected final versions, replace the ones in the repo under my name. That way everything's clean and working."
> "Did we change any file in Yaquns Fraud? If any file is changed, we make a version for myself inside of Waqas and whatever phase we are running.."
- Changed: the pod package drops test and fake-data files and replaces your `waqas/` files in your existing project; `prepare` runs the pre-flight without tests (replaces part of D52). No `fraud/` files are shipped; the pod's own `fraud/` is used, and the pre-flight checks it against the reviewed copy (`bridge/OWNER_QA.md`, fifty-second message; `83ab56a`).
- Reasoning recorded: Yakun's files differ from your upload only by the two-character photo correction (D35); every real fix already lives under `waqas/`.

**D66. Overwrite in place; no confusing bundles (to ChatGPT).**
> "no. im saying it should be clean. the files should be under waqas....replace the old files right...like we dont need to have so many files like tf_packages etc...."
> "do u get what im saying. i cant have this become a bundle of files that are insanely confusing. we overwrite shit."
- Changed: packages install into your existing project and overwrite matching files; the unzipped folder is temporary. You also said package 004 was only personalized: "Ran personalization, but nothing else".

**D67. Deliver the finalized 005; Copilot compares the source on your side (to ChatGPT).**
> "...just give the finalized 005 man, ill have github copilot on my laptop do a bit by bit comparsion to make sure spacing and veveyrhting is fine."
- Changed: package 005 published (source `96ed240`); differences between the pod's `fraud/` and the transcription become warnings, not stops.

**D68. The assistants call each other automatically (to ChatGPT).**
> "ok lmk when done. also can we setup the manner for u and calude to call each other automatically?"
- Changed: you enabled a ChatGPT event task on PR #14, so ChatGPT wakes on its comments.

---

## 2026-10-14

**D69. Make the model better and production-ready (to ChatGPT).**
> "We obviously have to make this model better, production-ready. You know, I was thinking, like, at minimum, like training on more files and then testing on different files as well. You know, we gotta do the feature stuff."
- Changed: ChatGPT drafted a staged pathway, to be agreed with Claude. It starts with 100 training files, then the first new feature (MCC), then a bounded settings sweep, plus new account and future-time tests (chapter 10, section 2a). Nothing is approved to run yet.

---

## Questions still open for you

These are in section A of `bridge/OWNER_QA.md`. Short version:

| Question | What it asks | Why it matters |
|---|---|---|
| OQ-7 | (head from before D56) start batch 2 yourself after batch 1's return is read, or back to back? | Largely settled for today by D56. |
| OQ-9 | Rerun the mask comparison or reuse old results? | Settled in practice by D46 (everything reruns). |
| OQ-11 | Delete five old docs in `waqas/docs/` on GitHub too? | Low priority. |
| OQ-12 | Which early uploads count as yours? | Decides the baseline's "your files". |
| OQ-14 | Can the Visa score and four check fields be filled in after the transaction? | If yes, the model may be partly "seeing the answer". |
| OQ-15 | Which evaluation files has nobody looked at, and how long do labels take to settle? | Needed for a final, untouched test number. |
| OQ-16 | Does block-wise all-position B count as Yakun's item F? | Decides how its result is described. |
| OQ-18 | How widely to read "each of the reviewers need to work as well". | Decides review effort. |
| OQ-20 | Are rows with `transaction_advice_xcd` decisions at the time, or later notices? | Decides which rows are scored. |
| OQ-21 | Which pre-flight stops to keep? | Partly settled by D42 (GPU check removed). |
| OQ-23 | Was May meant as history for June? | Lower priority since D51. |

## Check yourself

- Which decision made V1 "Yakun's design plus the longer histories"? (D37.)
- Why is there one exception to "never edit Yakun's folders"? (D35.)
- What changed because you have the 4-GPU pod only until tomorrow morning? (D56.)
