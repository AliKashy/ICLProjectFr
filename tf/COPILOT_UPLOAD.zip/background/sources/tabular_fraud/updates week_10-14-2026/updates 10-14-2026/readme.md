# Updates: 14 October 2026

Record of everything added, changed, used, decided and proposed on 2026-10-14 in
`C:\Users\K194855\Downloads\tabular_fraud_local`. Every item states **what** it is, **where** it is, and **why**
it exists. All updates are proposals made from github copilot. Thorough inspection, audit, approval, and sign off is needed.

The folder is named `updates 10-14-2026` because Windows does not allow `/` in folder names. The companion file
`FILE_INVENTORY.csv` lists every touched file with its size, timestamp and SHA-256.

**Scope rules followed all day**
- Nothing was run on, uploaded to, or changed on the GPU pods. All work is local.
- No V1 code, config, checkpoint, prediction or analysis output was modified. The one exception is a correction
  inside the V1 report (section 2.2).
- Credential files were never opened, copied into documents, or packaged.

---

## 1. Day at a glance

| # | Work | Result |
|---|---|---|
| 1 | Audited Yaqun's implementation against V1 | `yaqun_implementation/findings/YAQUN_AUDIT.md`; one V1 report correction |
| 2 | Read the Confluence project page | Learned the TFM vs LOB XGBoost vs offset results (section 4.2) |
| 3 | Answered "can features serve models other than 15298?" and revised the Nengfeng email | Analysis is in this record; source emails are archived in the reviewer handoff |
| 4 | Checked the browser-LLM research candidates against the papers | Findings in chat, then written into `research_context/` |
| 5 | Wrote a project brief for browser research chats | `research_context/PROJECT_CONTEXT_FOR_RESEARCH.md` |
| 6 | Reviewed five browser-LLM answers claim by claim | `research_context/LLM_RESPONSES_REVIEW_AND_PLAN.md` |
| 7 | Read-only evidence audit of the code, artifacts and benchmark | Answered in chat; drove the experiment design |
| 8 | Built the ALLPOS-H5 sliding-scoring experiment | Three new files plus an upload ZIP |
| 9 | Planned the next steps (sweep, splits, features, embeddings, production) | Section 7 |

---

## 2. Files added or changed

### 2.1 `yaqun_implementation/` (new folder, created 12:36–13:06)

| Path | What | Why |
|---|---|---|
| `yaqun_implementation/all_files/` (599 files) | Yaqun's **untouched, unfixed** work, downloaded locally as-is (no bug fixes applied): his GitHub repository's two branches (`github_tabular_fraud/main/tabular_fraud-main`, `github_tabular_fraud/yw_seq/tabular_fraud-yw_seq`) and his pod directory (`pod_dir/k016730/`: projects, scripts, small_data, test) | The audit needed his original code, configs, logs and metrics side by side with V1, without touching his live repository or pod. It is kept unfixed on purpose, as evidence of what his reported numbers were produced with. |
| `yaqun_implementation/all_files/README.md` | Describes each copied source | So anyone opening the folder knows what each subfolder is and where it came from |
| `yaqun_implementation/git_backup/{saint,tabular_fraud}/git_metadata/` (369 files) | His `.git` folders, renamed to `git_metadata` | Kept as evidence (history, refs), but renamed so the copies are not live git repositories. This prevents accidental commits or pushes to his remotes, and stops VS Code treating them as repositories. |
| `yaqun_implementation/findings/YAQUN_AUDIT.md` | **Our analysis** of that untouched copy (not part of his code): inventory, 12-area checklist, evidence trace of his reported numbers, side-by-side results, gaps, verdicts, V2 recommendations | Needed to know whether his "history beats single-transaction" claim holds, why his 10-file history-5 model scored above ours, and what V1 should adopt or fix |

The files named `aws_key_prod.sh` and `S3_credentials.yml` in his pod copy are placeholders (confirmed by Waqas), so
no action is needed. The audit's own security note about them is now superseded by this confirmation.

### 2.2 `tabular_fraud/reviewer_update_v1_20261013/V1_COMPLETE_REPORT.md` (modified, 14:27)

- **What changed:** section 8.3 ("Why Yaqun's history-5 result showed a lift and V1 shows a drop").
  - It now states that Yaqun **did** score history 5 on evaluation files 8000–8010.
  - It adds his evaluation table: 100 files AP 0.0965 / AUROC 0.9544; 10 files 0.0871 / 0.9475;
    single-transaction 100 files 0.0940 / 0.9514.
  - It adds the explanation of the differences (different comparisons, in-period vs out-of-time holdouts,
    training size, the loader bug, the same-second rule, single-run noise).
- **Why:** the earlier text said he never scored evaluation. The audit found his scoring logs (`seq_score_*.log`),
  so the statement was wrong. A report sent to reviewers must not contain a known error.

### 2.3 `project_info/` (files added 14:51–14:54)

| Path | What | Why it is used |
|---|---|---|
| `project_info/Confluence_Foundation_Model_for_Fraud.pdf` | Waqas's PDF export of the Confluence page "Foundation Model for Fraud" (SHA-256 `4582a79b…0787`) | Official project record: goals, people, dated updates, TFM and offset results |
| `project_info/Foundation_Model_for_Fraud_MD.md` | That PDF converted to Markdown | Searchable and quotable. It is the source for every TFM, LOB and offset number used today. |

Both files were used as inputs and were not edited today.

### 2.4 `research_context/` (new folder)

| Path | What | Why |
|---|---|---|
| `research_context/PROJECT_CONTEXT_FOR_RESEARCH.md` | A complete project brief, built to paste into browser Copilot or other chats. It covers framing, data splits, features, model families, all V1 results and statistics, related internal results (Yaqun, TFM, offset), V2 feature plans, the code map, documents, verified literature, candidate next steps and open research questions. | Browser assistants have no access to the repository. Without this brief they give generic advice; with it they can give project-specific, checkable recommendations. |
| `research_context/LLM_RESPONSES_REVIEW_AND_PLAN.md` | Claim-by-claim verdicts (correct / partly correct / incorrect / unverified / omission) on five browser-LLM answers, with evidence from code and papers. It also holds a consolidated error list, the phased plan, section 6A (all-position history, train-before-benchmark, XTab) and section 6B (tabular foundation models). | Those answers contained good ideas and some errors (for example, that Muon has only large-model evidence, overstated TabFM claims, and an unsupported 127K fraud count). Decisions needed one checked source of truth. |
| `research_context/ALLPOS_H5_SLIDING_PACKAGE.zip` | Historical upload package created for the original pod-transfer procedure; SHA-256 `78edb17d…60b6` | Preserved as historical provenance only. The current reviewer handoff stores the three experiment files separately as raw files and contains no ZIP. |

**Edits made to the brief during the day, and why:**
1. **Optimizer, scheduler, determinism and classifier-head facts added (§5.4).** They were verified in
   `sequential_hier.py`, and the brief had omitted them.
2. **The §9 code map was corrected:**
   - the periodic embedding is a shared-linear variant with no ReLU and sigma = 1;
   - the Muon option has no parameter split;
   - EMA exists but is unused;
   - the pretraining code is single-transaction, and its contrastive part is label-supervised SupCon, not CoLES.

   The brief had overstated what already exists.
3. **Notes added to §7.2:** the offset model used in-sample TFM embeddings, and the TFM embedding came from the
   fraud-fine-tuned model. Both affect how our embedding test must be designed.
4. **Literature rows added (§11):** the Muon tabular benchmark (2604.15297), the Muon reference, the NVIDIA
   example, XTab, TabPFN-2.5, TabICL / TabICLv2 and TabDPT. These were each verified against the paper or
   repository.
5. **Facts added:**
   - our data is MMR's TFM raw data (`tfm_raw_data` / `tfm_EVAL_raw_data`);
   - all-position chunk mechanics (H = 5 only; chunk positions);
   - "TabFM" vs "TFM" naming;
   - "we are building an FT-based transaction representation model".

   Each fact was verified from configs or code, or needed to avoid confusion.

### 2.5 The ALLPOS-H5 sliding-scoring experiment (three new files, 19:26–19:30)

| Path | What | Why |
|---|---|---|
| `tabular_fraud/waqas/phase4b/scripts/allpos_sliding_experiment.py` | Gated entrypoint with subcommands `inspect`, `verify`, `score` and `report` | Tests whether the existing ALLPOS-H5 checkpoint scores differently when each transaction gets its full recent context, without retraining |
| `tabular_fraud/tests/test_allpos_sliding_experiment.py` | 18 tests (listed below); runs under pytest, or standalone if pytest is missing | Proves the window rules, masking, contract protection and output safety before any real scoring |
| `tabular_fraud/runbook/2026-10-14/ALLPOS_H5_SLIDING_RUNBOOK.md` | The trained semantics resolved from code, with line references, plus literal pod commands, pass/fail criteria and failure actions | The pod run must need no guessing, no placeholders and no manual code edits |

**Why this experiment comes first.**
- V1 scored the all-position model in non-overlapping 6-second chunks per account. A transaction near the start of
  a chunk sees little or no history, even when its account has plenty.
- Only 394,669 of 2,466,461 evaluation rows (16.0%) had exactly 5 earlier rows inside their chunk. By contrast,
  2,324,084 rows (94.2%) have at least 5 earlier rows in their file.
- So V1 under-tested this architecture. Re-scoring the existing checkpoint is the cheapest way to find out whether
  context availability matters, and it decides how every later all-position run should be scored.

**How it preserves the trained model.**
- **Unchanged contract check.** The checkpoint is loaded with its own V1 config into the original model class. The
  model's own `on_load_checkpoint` contract check runs, then a strict state-dict load. The contract must equal V1
  `score_metrics.json`. The checkpoint is never edited.
- **Same model semantics.** Each window holds the target's whole second plus up to 5 earlier distinct seconds. It
  is encoded with the builder's own ordering and gap code, then scored with the unchanged strict mask and position
  rule.
- **Every row once.** Only target-second rows are emitted, so each source row gets exactly one score.
- **Policy recorded separately** (`allpos_sliding_strict_v1`) in the verify and score records and in an output
  column.

**Safety gates.**
- **`inspect`:**
  - hashes the checkpoint and config against the V1 manifest;
  - checks that the model-path source files still hash-match the V1 manifest;
  - confirms the S3 sources, preprocessing and V1 predictions exist.
- **`verify`:**
  - synthetic checks;
  - the adapter must equal the builder's chunks tensor-for-tensor;
  - repeat, padding and batch-size variability are measured to set the tolerance;
  - V1 chunk scores must be reproduced;
  - on rows whose inputs are genuinely identical, tensors are compared before any score;
  - a CPU deterministic cross-check.
- **`score`:**
  - refuses to run without a matching verify pass;
  - writes to temporary files, reads them back, checks IDs against the source, then promotes them;
  - records hashes per partition, supports a hash-checked resume, and checks totals against V1.
- **`report`:**
  - reuses V1 `paired_report.py` (whole-account bootstrap, 1,000 draws, seed 0);
  - requires label, amount, history-count and chunk-position agreement before computing any slice.
- **Output:** new folders only, at `/home/jovyan/k194855/tabular_fraud/waqas/scoring/allpos_sliding_h5/<run id>/`.

**The 18 tests.** All live in `tabular_fraud/tests/test_allpos_sliding_experiment.py`.

**Where they run:** on the pod, from `/home/jovyan/k194855/tabular_fraud`, with
`/home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI/bin/python -m pytest -q tests/test_allpos_sliding_experiment.py`.
If pytest is missing, use `/home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI/bin/python tests/test_allpos_sliding_experiment.py`
(runbook §2.5). Run them **before** `inspect`; any failure means stop.

**What was run locally on 2026-10-14:**
- `py_compile` on both files: passed.
- The CLI help for every subcommand: works.
- The built-in runner: 2 passed, 0 failed, 16 skipped, because this PC has no numpy, pandas or torch.

| # | Test | Why it was added | Local result | Must run on the pod |
|---|---|---|---|---|
| 1 | `test_one_row_account` | An account with a single row must get one window with no history and position 0, not an error or an empty window | skipped | yes |
| 2 | `test_fewer_than_h_prior_groups` | Short histories must use all available earlier seconds without padding errors | skipped | yes |
| 3 | `test_exactly_h_prior_groups` | At exactly 5 earlier seconds the window must equal the full 6-second context and match the chunk | skipped | yes |
| 4 | `test_more_than_h_prior_groups` | Long histories must keep only the 5 most recent earlier seconds; also checks the chunk-equivalence flag | skipped | yes |
| 5 | `test_same_second_target_rows_share_one_window` | Tied rows in the target second must share one window and all be emitted from it | skipped | yes |
| 6 | `test_same_second_history_rows_all_included` | A tied earlier second must be included whole, never split | skipped | yes |
| 7 | `test_wide_tied_group_not_capped` | Windows wider than 6 rows must not be silently cut; no row may be dropped | skipped | yes |
| 8 | `test_account_boundaries` | A window must never mix two accounts | skipped | yes |
| 9 | `test_stable_ordering_independent_of_input_order` | Row order must follow the builder's (time, transaction ID) rule regardless of file order | skipped | yes |
| 10 | `test_previous_strictly_earlier_gaps` | Time gaps must use the trained rule: seconds since the latest strictly-earlier row, 0 for the oldest included second | skipped | yes |
| 11 | `test_padding_and_masks` | Padding must be zeros with mask False, matching training | skipped | yes |
| 12 | `test_exactly_once_emission` | Every row must be scored exactly once (no gaps, no duplicates) | skipped | yes |
| 13 | `test_no_future_or_same_second_neighbor_attention` | Model level: changing future or same-second rows must not change the target's score, and the mask must hide them | skipped | yes |
| 14 | `test_original_contract_preserved` | Loading must keep the trained contract unchanged and must reject a changed contract | skipped | yes |
| 15 | `test_incompatible_verify_metadata_refused` | `score` must refuse a failed, missing or mismatched verify result | **passed** | yes (rerun) |
| 16 | `test_output_overwrite_refusal` | Existing results must never be overwritten; run folders must stay inside the experiment root | **passed** | yes (rerun) |
| 17 | `test_identifier_and_label_alignment` | Joins must refuse missing, duplicate or extra IDs, and labels must line up after the join | skipped | yes |
| 18 | `test_input_equivalence_subset_selection` | The rows used to prove sliding = chunk must have truly identical inputs | skipped | yes |

Expected on the pod: 18 passed, 0 failed, 0 skipped. Expected, not yet observed.

**Status:** built and packaged, **not yet uploaded or run**. The venv stays at
`/home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI` (Waqas decided against moving it into a new `venv` folder), so
the runbook paths stay valid.

### 2.6 This folder

| Path | What | Why |
|---|---|---|
| `updates 10-14-2026/README.md` | This record | Requested: complete, reasoned documentation of the day |
| `updates 10-14-2026/FILE_INVENTORY.csv` | Every file touched, with size, timestamp, SHA-256, author and purpose | Machine-checkable list, so anything changed later can be detected |

### 2.7 Produced in chat only (no file)
- **Nengfeng email:** the "feature store" / two-step framing. Revised to remove the "demanding" paragraph, refer
  to the internal PFM/TFM work and Xinyu's offset model, and offer the CoLES paper rather than cite it. The later
  manager response is archived and analysed in section 15.4.
- **"Can features be built for models other than 15298?"** Yes. Embeddings from the raw-field encoder are
  model-agnostic and can be joined by transaction ID. Xinyu's offset model is the internal precedent.
- **Answers about tabular foundation models (TabFMs):**
  - TabFMs are not FT-Transformers.
  - We are not building a TabFM; we are building an FT-based transaction representation model.
  - How TabFMs differ from payment/transaction foundation models.

### 2.8 Not changed
- **V1, local:** V1 code (`waqas/phase4a`, `phase4b`, `base`, `scoring`, `runbook/2026-10-07`), configs, the review
  bundle in `pod_review/`, and `reviewer_update_v1_20261013/` apart from §2.2.
- **Pods:** checkpoints, S3 predictions, and anything on the pods.

---

## 3. Existing material used, and why

| Source | Used for |
|---|---|
| `pod_review/v1_full_review_20261013T155312Z/` (the byte-exact pod export) | As-run code, manifests, the data contract and paired-report outputs, i.e. evidence rather than recollection |
| `.../allposition_strict_h5/.../history-h5/score_metrics.json`, `run_manifest.json`, `resolved_score.yaml` | Checkpoint path and SHA (`39d9709e…a554`), trained contract, V1 prediction path, interpreter path, code hashes, S3 paths |
| `.../preflight/20261013T033615Z/data_contract.json` | Split periods, counts, account disjointness, history-depth counts, same-second tie counts |
| `runs/paired_report/` (`paired_lines.csv`, `paired_runs.csv`, `paired_report.txt`) | Where the 394,669-row position-5 subset and the +0.0207 reading came from |
| `waqas/phase4b/{sequential_hier,sequence_builder,factory,tokenizer,numerical_embeddings,optim,callbacks}.py` | Every mechanism claim (mask, positions, gaps, loss, contract, optimizer, embeddings) |
| `runbook/2026-10-07/paired_report.py`, `waqas/scoring/temporal_eval.py` | Reused by the experiment's report step (bootstrap, history counts, chunk positions) |
| Papers and repositories (each verified by fetching) | SOHET, FraudTransformer, TabReD, XTab, the Muon tabular benchmark (2604.15297), TabPFN-2.5, TabICL / TabICLv2, TabDPT, nuFormer, NVIDIA transaction-foundation-model; plus Stripe, CoLES, TabBERT, FT-Transformer and numerical embeddings, verified earlier |

Local and as-run code were compared by hash. They are identical except for garbled docstring characters in three
local files (`sequential_hier.py`, `numerical_embeddings.py`, `optim.py`); the code itself is the same.

---

## 4. Key findings, with evidence

### 4.1 Yaqun audit
- **His evaluation results, verified from logs:**
  - history 5, 100 files: AP 0.0965 / AUROC 0.9544;
  - history 5, 10 files: AP 0.0871 / AUROC 0.9475;
  - single-transaction, 100 files: AP 0.0940 / AUROC 0.9514.
- **His "history beats single" claim** is +0.0025 AP from one run each, untested. V1's intervals for gaps of this
  size span about ±0.01–0.02.
- **Training data size is V1's biggest gap:** 10 files vs his 100.
- **His 10-file history-5 model beat V1's A-H05 (0.0871 vs 0.0728).** Candidate causes: a file-sharding bug (about
  32% of files skipped per epoch), allowing same-second rows into history, a 1-file validation set, and about 2x
  more batches per epoch. The cause is still unexplained.
- **V1 is methodologically stronger on every audited area except training scale.**

### 4.2 Confluence: TFM vs LOB vs offset (952,905-row out-of-time set, June 2025)

| Model | KS | AUC | DR@0.006 | VDR@0.006 | FPR@0.006 |
|---|---:|---:|---:|---:|---:|
| FL original (LOB XGBoost) | 0.8410 | 0.9727 | 0.5486 | 0.5631 | 6.3402 |
| TFM score alone | 0.8215 | 0.9685 | 0.5664 | 0.6877 | 6.1629 |
| Offset (FL + 20 TFM embedding columns) | 0.8390 | 0.9730 | 0.5678 | 0.6207 | 6.0925 |

- A sequence transformer alone already beats the LOB model on DR, VDR and FPR at the operating point.
- The offset's embeddings were extracted on the TFM's own training rows (in-sample). Its larger train-to-OOT drop
  (DR 0.6095 → 0.5678) fits that.

### 4.3 Code and artifact audit
- **Data source:** our data is MMR's TFM raw data (`tfm_raw_data`; evaluation `tfm_EVAL_raw_data`).
- **Per-file history:** history is built within one file, and no account spans files (`accounts_in_more_than_one_file: 0`).
- **Periods:**
  - train and validation: 2024-10-01 to 2025-05-31;
  - evaluation: 2025-05-01 to 2025-06-30;
  - nothing later is verified.
- **All-position chunks:**
  - a chunk holds up to H+1 distinct **seconds**, not rows;
  - the model's position = strictly-earlier **rows**, capped at H;
  - the time gap is measured to the latest strictly-earlier row in the chunk, and is 0 at the chunk start;
  - loss = sum over real rows / number of real rows;
  - `max_chunk_rows` raises, never truncates.
- **No sliding path existed** for all-position checkpoints, and the existing code blocks one (builder L258–259,
  `factory.py` L23–32, contract check L206–224).
- **Embeddings:** all-position predictions use each row's own output vector, `out[:, 1:]`. `embed()` returns the
  sequence summary (seq_CLS), which is not directly supervised in all-position mode and is not the head's input. A
  per-row export function is therefore needed.
- **Optimizer:** one optimizer; every parameter is weight-decayed; `ReduceLROnPlateau` on in-period validation
  loss; no determinism flag. The Muon option would send embeddings and the head to an AdamW learning rate.
  `pytorch_optimizer` is not pinned.
- **Periodic embedding:** shared linear layer, no ReLU, sigma fixed at 1; it is also applied to the time gap.
  Missingness flags are categorical.
- **Not found locally:**
  - the prepared benchmark artifact and TFM-score paths are known (sections 13–14), but the files are not copied
    locally; `cross-file-8000-8200` is a prepared TFM evaluation artifact name, **not evidence that it maps to raw
    files 8000–8200**, so no V1 overlap should be inferred from that name;
  - no fraud count for files 11–100;
  - no XGBoost offset consumer code.

---

## 5. Corrections made to earlier statements

| Earlier statement | Correction | Basis |
|---|---|---|
| "Yaqun never scored evaluation" (V1 report 8.3) | He did (section 4.1) | His pod logs |
| Muon evidence is only large-model pretraining | A tabular benchmark (2604.15297) shows Muon beats AdamW for MLPs on 17 datasets, and TabICLv2 uses Muon | Paper abstracts |
| "Periodic embeddings are implemented" | A weaker variant (shared linear, no ReLU, fixed sigma; also applied to the time gap) | `numerical_embeddings.py`, `tokenizer.py` |
| "Pretraining code partly exists" | Single-transaction only; contrastive is label-supervised SupCon, not CoLES | `future_experiments/pretrain/` |
| All-position is "the only past-only / cacheable design" | Wrong. Sliding-target B is also past-only, and causal outputs are not reusable account states. | Mask and builder code |
| "At H5 each row sees about 2.5 rows" | Conditional; measured: 16.0% of rows sat at position 5 | `paired_lines.csv` |
| "21x21 attention means low cost" | Covers one matrix only. Measure throughput, memory and end-to-end latency. | Architecture |
| "About 127K frauds in 100 files" | Unsupported extrapolation; retracted | No count exists |
| "July 2025+ holdout" | Does not exist (MMR emails, section 13) | Data ends June 2025 |
| "seq_CLS is untrained" | Not directly supervised in all-position mode and not the head input; its layers are trained | Mask and loss code |
| "Sliding scoring has no train/score mismatch" | It keeps the semantics but changes context availability and boundary frequency, which is what it measures | Design |
| TabFM absolutes ("don't train on your data", "only XTab", "0.15% breaks it", "only via distillation") | Qualified: context labels drive predictions; XTab is one example; sparse fraud is a risk; distillation is one option; capabilities and licences are version-specific | Papers |
| XTab "millions of rows → little gain" | Unsupported; removed | XTab text |

---

## 6. Decisions and reasons

| Decision | Reason |
|---|---|
| Re-score the existing ALLPOS-H5 checkpoint before any new training | Costs no training; isolates context availability; decides how the whole sweep is scored |
| Keep the trained contract; record the policy separately | Bypassing the contract could silently attribute results to a model that was never trained that way |
| Fail closed on unexplained score differences | Results must not look valid when they are not; GPU nondeterminism is not accepted as an excuse |
| Put outputs in new per-run folders | Protects V1 artifacts and makes every result traceable |
| Use "TabFM" for tabular foundation models and "TFM" for MMR's model | Avoids the naming collision |
| Describe our work as an "FT-based transaction representation model" | The higher claims (foundation model, TabFM) need transfer evidence we do not have yet |
| Keep the venv where it is | Moving a venv breaks its absolute paths; the V1 manifest records the current path |
| Keep external TabFM benchmarking as an optional side study | It is a different paradigm (flat rows, no history); not a prerequisite for FT work |

---

## 7. Proposed next steps (ordered, each with its reason)

The executable version of these steps is `V2_EXECUTION_PLAN.md` in this folder (v3, 2026-10-16: lean stages L1–L9,
about 5 initial training runs, conditional expansion only). Where this section and the plan differ, the plan is
current.

1. **Run the sliding experiment on the pod** (runbook §2.1–2.11).
   - *Why:* it measures whether full context helps ALLPOS-H5, and the result sets the scoring mode for the sweep.
   - *Gate:* `verify` must pass every check.
2. **Redesign the data splits before the sweep** (now concrete; see section 13 for the email facts behind it).
   - **Proposed design** (still to verify on the pod by listing both buckets and reading row dates):

   | Split | Files | Target rows | History rows |
   |---|---|---|---|
   | Train | a set of `tfm_raw_data` files (accounts never used elsewhere) | 2024-10-01 to 2025-04-30 | earlier rows of the same account in the same file |
   | Validation | different `tfm_raw_data` files (disjoint accounts) | 2025-05 only | Oct 2024 to Apr 2025 rows of the same file |
   | Test | `tfm_EVAL_raw_data` files **not used in V1** (so not 8000–8010) | 2025-06 only | May 2025 rows of the same file (exactly the TFM protocol) |

   - Validation is then out-of-time (May), between training (Oct–Apr) and test (June). Accounts stay disjoint
     across all three by construction (buckets are split by account).
   - Refit the preprocessing artifacts (a new version) on training files and training-period rows only.
   - `month`: training sees Oct–Apr only, so May and June are unseen by design. Test dropping it or using the
     cyclical encoding (Y15).
   - Also report V1's files 8000–8010 on **June targets only**, to compare with V1 and with the TFM protocol.
   - **Code needed:** a "target period" rule, so rows outside the target dates serve only as history. In
     all-position mode their labels must be -100 so they add no loss. In single-target mode they are skipped as
     targets. The current builders make every row a target.
   - *Why:* V1's validation was in-period (rank correlation 0.11 with evaluation). V1's "evaluation" was about
     51% May rows, inside the training period. Files 8000–8010 were used to pick finalists. MMR confirmed there is
     no data after June 2025 (no July holdout is possible).
3. **All-position B at history 0 and history 20 only** (Waqas's decision, replacing a full 0–20 sweep).
   - **History 0** is the within-pipeline no-history control: each chunk is one second, and same-second rows are
     hidden from each other, so every transaction is scored on its own features with the same recipe. It
     separates "history helps" from "this recipe is better".
   - **History 20** is the longest V1 length, where regular B held its level (B-H20, AP 0.0955) and A dropped.
   - Change only the history length. Report real transactions per update, chunks per update and update counts,
     because longer chunks change the effective batch.
   - Score H20 both chunked and sliding. Compare with V1's B-H20 and B-H00. Use 2–3 seeds if the two are close.
   - Monitor the train-to-validation gap.
   - Run `measure_chunk_widths.py` at H20 before setting `max_chunk_rows`.
   - *Why:* all-position was only tested at H5, the weakest setting elsewhere, yet it still neared the leaders. Two
     endpoints answer "does long history help this design" at a fraction of the cost of five lengths. Intermediate
     lengths can be added later only if 0 vs 20 is ambiguous.
4. **Scale the training data** (10 → 100 files) at the best configuration.
   - Count the frauds first; do not assume the number.
   - *Why:* Yaqun's runs show a large gain from more data (0.0871 → 0.0965).
5. **Add features** (V2 list: MCC, merchant, velocity, 15298 features), computed only from earlier transactions,
   as one controlled comparison.
   - Compute every cross-row aggregate from the unsampled raw account stream first; only then select or
     downsample target rows. Keep history rows even when they are not training targets.
   - Require an event-time definition, lookback, cold-start indicator and production source for every candidate.
     Reject full-window values such as account-level `max(date) - min(date)` broadcast to earlier transactions.
   - For count, spend, diversity, recency and velocity features, test the offline implementation against an
     incremental replay that exposes only rows strictly earlier than each target.
   - *Why:* V1 uses 23 raw fields. Engineered history features are what the incumbent relies on.
6. **Export the embedding and test it in XGBoost.**
   - Write a per-row export function for all-position, using the head input `out[:, 1:]`.
   - Compare raw features only / + FT score / + FT embedding, with the consumer trained on rows the encoder never
     saw. Then repeat with FL's features in Xinyu's offset framework.
   - *Why:* the target product includes reusable features for several XGBoost models.
7. **Production readiness** before anyone builds on the embedding.
   - A history store giving the last H seconds per account at decision time.
   - Confirm same-second availability (still open with the data owner).
   - End-to-end latency, a fallback for accounts with no history, versioned encoder releases (each retrain = new
     feature version), then shadow scoring with mature labels.
   - *Why:* an embedding that cannot be produced live, point-in-time and fast enough cannot be used in production.
8. **Benchmark the best model against FL and TFM** on the 952,905-row set. Check overlap with our files first.
   - The XGBoost and fraud-fine-tuned developer-model results are already available; use them as external
     baselines after our model and evaluation design are fixed.
   - *Why:* this is the system-level challenger question, not the driver of our architecture search.
9. **Later, separately:** recipe changes one at a time (EMA, weight-decay groups, PLR / PLE embeddings, a proper
   Muon/AdamW split); time encoding; reconstruction-first pretraining; an optional TabFM side study on engineered
   features.

**On "no account-level relationships":**
- Account history **is** the model's input; that is where the signal comes from.
- What must be avoided is account **identity**: no account IDs as features, no memorization (splits are
  account-disjoint), no cross-account links, no future data, no historical labels as inputs.
- The resulting per-transaction embedding works for unseen accounts and can be reused by any model that joins on
  transaction ID.

---

## 8. Open questions and blockers

| Item | Owner | Blocks |
|---|---|---|
| Exact DR / VDR / FPR@0.006 definitions; row-level LoB scores only if paired analysis is required | Xinyu / LoB | Steps 6 and 8 |
| Optional overlap check between `tfm_EVAL_raw_data` 8000–8010 and the prepared benchmark | Us: join `fi_transaction_id` if needed; do not infer a mapping from the artifact name | Step 8 interpretation only |
| ~~Files and periods available beyond June 2025~~ | Resolved by MMR's emails: training data Oct 2024–May 2025; test data June 2025 with May histories; nothing later (section 13). Still to verify on the pod: the exact file numbers present in each bucket. | Step 2 |
| Fraud counts beyond file 10 | Us (`count_train_fraud.py` on the pod) | Step 4 |
| Are same-second transactions available at decision time? | Data owner | Steps 3 and 7 |
| Is `external_1_scr` an upstream fraud score? | Data owner | Step 5 / ablation |
| Does the TFM use Muon + AdamW? | MMR | Step 9 context only |
| ~~What exactly the "complete sweep" covers~~ | Resolved: history 0 and 20 only (Waqas) | |
| Is `pytorch_optimizer` installed on the pod? | Us | Step 9 (Muon) |
| Where FL's features live and how to access them | Xinyu | Step 6 |

---

## 9. Proposed fixes to the research documents (not yet applied)
These came from the read-only audit. They are **proposed only**; they will be applied to `research_context/` when
Waqas approves. Until then, those two documents contain the statements below and must be read with this list.

| # | Where | Proposed fix | Why |
|---|---|---|---|
| P1 | Brief §5.3; review E13 and 6A | Remove "all-position is the only past-only / cacheable design" | Wrong. Regular sliding-target B also uses only the current and earlier transactions. Causal outputs depend on where the chunk starts, so they are not reusable account states. |
| P2 | Brief §5.3; review 6A | Define H as "up to H+1 distinct seconds per chunk"; add that only 16.0% of evaluation rows sat at chunk position 5 | The code cuts chunks by distinct seconds, not rows (`_chunk_spans`). "About 2.5 earlier rows on average" was an estimate; 16.0% is measured (`paired_lines.csv`). |
| P3 | Brief §5.3 | State that seq_CLS is not directly supervised in all-position mode and is not the head input; per-row embedding export must use `out[:, 1:]` | In all-position mode the head reads `out[:, 1:]` (`sequential_hier.py` L324). Exporting `embed()` would give a representation the predictions never used. |
| P4 | Review 6A.3 | Remove "about 127K frauds in 100 files" | Extrapolated from 10 files, not counted. No count exists for files 11–100. |
| P5 | Review 6A.3 | Remove the "July 2025+ holdout" | MMR's emails (section 13) confirm the shared data ends in June 2025. |
| P6 | Review 6A.3 | Make fraud-enriched sampling an optional experiment, not the V2 design | It changes the training distribution and calibration. It must be compared against natural prevalence, not assumed better. |
| P7 | Review 6A.4 | XTab fine-tunes the pretrained backbone with newly initialized featurizers and heads; remove "millions of rows → little gain" | The first is what the paper describes. The second is not supported by XTab. |
| P8 | Review 6B | Apply the TabFM qualifications from section 5 of this record (context labels drive predictions; XTab is one example, not the only one; sparse fraud is a risk, not a proven failure; distillation is one option; capabilities and licences are version-specific; report both the million-scale claim and its stated limitation) | The earlier wording was absolute where the papers are not. |
| P9 | Brief §3.1 | Add: history is built per file and no account spans files; evaluation history starts 2025-05-01; evaluation history-depth counts (≥5: 2,324,084; ≥10: 2,202,030; ≥15: 2,089,467; ≥20: 1,983,461) | Verified in `data_contract.json`. Needed to plan history length and the benchmark history source. |
| P10 | Brief §9 | Add: periodic sigma is not configurable; the time gap goes through the periodic embedding too; there is no local XGBoost/offset consumer; `export_embeddings.py` cannot load phase4b checkpoints | Verified in `tokenizer.py`, `sequence_builder.py`, `numerical_embeddings.py` and a code search. These facts change the effort of three planned steps. |
| P11 | Everywhere | Do not infer raw-file overlap from `cross-file-8000-8200-seed-42_1.parquet`; treat any overlap check as an optional ID join | Waqas clarified that `8000` in the prepared TFM artifact name is not the raw `tfm_EVAL_raw_data` file number. |
| P12 | `yaqun_implementation/findings/YAQUN_AUDIT.md` §1.4 | Replace the credential warning with "placeholder files, confirmed by Waqas" | Waqas confirmed they are placeholders, not his credentials. |

---

## 10. Security and hygiene
- `tabular_fraud/test.yaml` is the S3 credential file referenced by V1 configs. It was never opened and is not in
  the ZIP.
- The experiment never logs or stores credential contents; S3 access goes through the existing
  `make_s3_filesystem`.
- Do not commit `.gradle`, `.npmrc`, `pip.conf`, `NuGet.Config` or credential files. Add them to `.gitignore` if
  this repository is ever pushed.

---

## 11. Review of the browser-LLM chat on FT-Transformer embeddings and CoLES (exported 2026-10-14)

**Did it find anything wrong with our work, code or methodology? No.** It states that it did not inspect our
repository ("Evidence gap: I have not inspected your current repository or sequence builder"), so it made no
finding about our code or results. Below is how each of its points relates to our verified implementation.

| Its point | Relation to our work | Action |
|---|---|---|
| The FT-Transformer paper never exports embeddings to other models; it only uses `[CLS]` for its own head | Consistent with our reading | None |
| Export the final `[CLS]` vector, not flattened feature tokens | Right for **sliding-target B**: `embed()` returns the sequence summary (seq_CLS), which is that model's head input. **Not right for all-position B**: its head reads each row's own output `out[:, 1:]`, so that is what must be exported (proposed fix P3). | Keep the export plan as written in step 6 |
| The paper's head is `Linear(ReLU(LayerNorm([CLS])))` | **Observation, not an error:** our B head is `Linear(48, 2)` applied directly to the un-normalized output of a pre-norm encoder (`sequential_hier.py` L163; `_encoder` creates no final norm). It is a deviation from the paper, so it is a candidate recipe check (adding a final LayerNorm) and something to know when exporting embeddings (their scale is unnormalized). | Add as an optional recipe test in step 9; not a fix |
| Train consumer models on **out-of-fold** embeddings to avoid leakage, or freeze an encoder and extract on an untouched population | Our plan uses the second option: the consumer is trained on rows the encoder never trained on. Out-of-fold needs K encoder retrains, and embeddings from different fold encoders do not share a coordinate system, so they cannot be pooled into one training table without checks. | Keep our option; note out-of-fold as an alternative |
| Combine FT event encoding + temporal encoder + CoLES-style pretraining; SOHET is the closest precedent | This is our Architecture B plus a pretraining stage. SOHET was already verified by us. | No change; pretraining stays a later, isolated experiment |
| CoLES rewards account stability, which may suppress sudden fraud signals | Same risk already recorded in our review | None |
| Change one variable at a time (do not switch flat to hierarchical while testing pretraining) | Consistent with our plan | None |
| "If strictly single-row FT, use SCARF-style pretraining" | Our existing `future_experiments/pretrain/` code is single-row (masked autoencoder; SupCon with SCARF-style corruption), so that route is partly built | None now |
| A lower contrastive loss is not success; judge by downstream fraud metrics | Consistent | None |
| Its example uses d = 192 | Ours is 48 | None |

**New sources it cited that we have not verified** (treat as leads, not evidence):
- Plaid engineering article (2 Apr 2026);
- Visa TransactionGPT technical report;
- Revolut PRAGMA;
- a July 2026 Sber multimodal event-transformer paper;
- Featurespace's purchasing foundation model (arXiv 2401.01641);
- T-JEPA (arXiv 2410.05016);
- SCARF (arXiv 2106.15147).

---

## 12. Every test or lever Yaqun proposed, and its status

Sources (his untouched copy, branch `yw_seq`, folder `docs/`):
- `phase4_design_decisions.md`: decisions 3, 6, 7, 9, 10, 11 and the "Deferred" list;
- `phase4_sequential_plan.md`: §2, §9 ablations, §9.2 "Next levers", §10;
- `fraud_detection_plan_overall.md`: "Phase 3: Optimization" and "Open Questions";
- `fraud_detection_plan_detailed.md`;
- `phase3_streaming_plan.md`;
- `tabular_transformer_models.md`.

### 12.1 Tested in V1 or covered by today's work

| # | His item | Status | Plan |
|---|---|---|---|
| Y1 | History length 0 vs 5 | Done in V1 (A and B) | History 0 for all-position B |
| Y2 | Longer history (10–20), his "main lever" | Done in V1 for A and B (5–20) | All-position B at 20 |
| Y3 | Time-delta on vs off | Done in V1 at history 5 and 10: no measurable effect | Retest once with a better time encoding (Y18) |
| Y4 | Bidirectional vs causal | Done in V1 at history 5: causal better | All-position is causal by design |
| Y5 | Hierarchical architecture (b) | Done (Architecture B) | Carried forward |
| Y6 | "Predict every transaction at once" | Done (B-ALLPOS-H5) | Sliding scoring, then history 0 vs 20 |
| Y7 | Multi-file validation | Done (5 files) | Must also become out-of-time (step 2) |
| Y8 | More data (10 → 100 files) | Not done | Step 4 |

### 12.2 Not yet tested (all go into the plan)

| # | His item | Notes | Plan |
|---|---|---|---|
| Y9 | `train_stride > 1` to reduce overlap between training windows (fraud targets never skipped; `eval_stride` stays 1) | **Applies only to sliding-target A and B.** All-position B forces stride 1 and already has no overlap (each row is a target exactly once), so stride cannot be tested there. | Test only if regular B is still a contender after step 3: stride 1 vs 2 vs 4 at the chosen history length |
| Y10 | Capacity sweep (`input_embed_dim` 48–64+, more blocks), with a lower learning rate for deeper models | Never run. REF-SINGLE beat A-H00 by 0.011 AP with identical inputs, so the recipe is a real bottleneck. | Stage 2 screen |
| Y11 | Hyperparameter tuning: learning rate, dropout, batch size, epochs and early stopping | Never run (`tune.py` exists) | Stage 2 screen |
| Y12 | Class imbalance: `pos_weight` or a weighted sampler | Never run (`pos_weight` = 1) | Stage 2 screen; check calibration if scores feed downstream models |
| Y13 | Shuffle buffer and batch size (batch 512 collapsed single-transaction training without row shuffle) | Not tested for sequences | Stage 2 screen (buffer size, effective batch) |
| Y14 | Checkpoint-selection metric (`yw_seq` switched it to `valid_auroc`) | Not tested | Keep AP, but report both; the out-of-time validation fix matters more |
| Y15 | Datetime encoding: categorical vs cyclical sin/cos (option already in code); `is_weekend` | Not tested. Relevant because 48.7% of evaluation rows have an unseen `month`. | Stage 2 screen: categorical vs cyclical vs dropping `month` |
| Y16 | Missing-flag on vs off | Not tested | Low priority |
| Y17 | Historical `frd_tag` as a feature | Deliberately excluded: labels may not be known at decision time | Only if the data owner confirms label availability at scoring time; otherwise never |
| Y18 | Open question: how to encode time gaps | Partly tested (on/off only) | Stage 2: piecewise-linear / sinusoidal time embedding |
| Y19 | Open question: same features for history rows as for the target, or a reduced set? | Not tested | Stage 5, with V2 features |
| Y20 | High-cardinality encoders for future features (hashing, frequency, target encoding fitted on train only, capped vocab + OOV) | Not built | Stage 5, needed for merchant and MCC |
| Y21 | Inference latency | Not measured | Step 7 (production readiness) |
| Y22 | Memory levers (SDPA / memory-efficient attention) | Not needed so far | Only if history 20+ runs out of memory |

### 12.3 Our additions (not his), already in the plan
- Sliding scoring.
- Multiple seeds.
- EMA.
- Weight-decay parameter groups.
- PLR / PLE numerical embeddings.
- A proper Muon/AdamW split.
- A final LayerNorm before the head (section 11).
- `external_1_scr` ablation.
- Out-of-time splits.
- Pretraining.

### 12.4 How to search for the best model without overfitting to validation
Testing every item above against every other is a combinatorial explosion, and selecting among many runs on one
validation set overfits that set. Run it in stages instead:

| Stage | What | Rule |
|---|---|---|
| 0 | Fix the data (out-of-time validation, untouched test, files verified) | Nothing is compared before this |
| 1 | Architecture: all-position B at history 0 and 20 (chunked and sliding), with V1 B-H20 as reference | Choose the architecture |
| 2 | Recipe screen on the chosen architecture, **one factor at a time** vs one reference, 10 files, 1 seed: Y10–Y15, Y18, EMA, weight-decay groups, final LayerNorm, PLR, Muon split; Y9 stride only if regular B is still in play | Keep a factor only if it beats the reference on validation by more than the measured seed-to-seed spread |
| 3 | Combine the kept factors; confirm with 3 seeds | The combination must beat the reference across seeds |
| 4 | Scale to 100 files (Y8) | Same recipe; only the data size changes |
| 5 | V2 features with point-in-time history and Y19 / Y20 | One controlled comparison |
| 6 | Optional: self-supervised pretraining | Fine-tune on top of the stage 5 winner |
| Final | Score once on the untouched test set and the 952,905 benchmark; export the embedding for the XGBoost tests | The test set is used **once**, after all selection |

---

## 13. Data facts from MMR's emails (received 2026-10-15) and what they change

Source: the "TFM Debit Card raw data copy" thread (Sumegha, 17 Aug – 31 Aug 2026; Xiaoming; Xinyu). The TFM is
MMR's payment/transaction foundation model, but our FT work uses the **same raw data**, so these facts apply
directly.

### 13.1 Facts stated by MMR

| # | Fact | Who / when |
|---|---|---|
| D1 | Training data `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/` covers **Oct 2024 to May 2025** | Sumegha, 17 Aug |
| D2 | Test data `tfm_EVAL_raw_data/` is **June 2025 targets with May 2025 histories**, so the files hold May–June 2025 | Sumegha, 17 Aug |
| D3 | Data is partitioned **by account** into 10,000 buckets (`part_1` … `part_10000`); an account appears in exactly one file | Sumegha, 17 Aug; confirmed 31 Aug |
| D4 | At most 5,000 files are used for training and 2,000 for testing. The training folder holds 5,000 files; files 5001–7999 were not used for pretraining or fine-tuning. | Sumegha / Xinyu, 17 and 31 Aug |
| D5 | The best TFM (v22b) uses the **last 17 transactions**, with **no time lookback limit**; the sequence is padded to 2,048 tokens | Sumegha, 18 Aug |
| D6 | For production, storing the last 17 transactions per account is a fixed memory cost; **fewer transactions = better operational efficiency**. Xiaoming suggested a maximum lookback (e.g. 18 months); Sumegha said the count limit is what matters. | Sumegha / Xiaoming, 18–19 Aug |
| D7 | The TFM "often converges much earlier and does not require the full training data" | Sumegha, 31 Aug |

### 13.2 What these facts change for us

| Topic | Before | Now |
|---|---|---|
| **V1 "evaluation" was not fully out-of-time** | Treated 8000–8010 (May–June) as out-of-time | By D1 and D2, May rows (about 51% of the 2,466,461 rows; June = 48.7%) fall **inside** the training period. They are accounts never seen in training, but not a later period. The TFM protocol scores **June targets only**, using May as history. V1's numbers stay valid as recorded, but a June-only view is needed for any out-of-time claim or TFM comparison. |
| **The unseen-`month` problem** | Looked like a quirk of the evaluation files | Built into the TFM protocol: June is always unseen when training ends in May. Handle it by dropping `month` or using the cyclical encoding (Y15), not by changing the test set. |
| **Later holdout** | "July 2025+ if it exists" | Does not exist in these buckets. The test is June 2025, and the validation must be May (step 2). |
| **Benchmark overlap** | Unverified and not implied by the artifact name | The prepared benchmark is `.../eval/cross-file-8000-8200-seed-42_1.parquet`, but Waqas clarified that its `8000-8200` naming does **not** identify raw `tfm_EVAL_raw_data` files. Only an explicit `fi_transaction_id` join could establish overlap, and that check is optional unless we use the prepared benchmark for a formal comparison. |
| **Benchmark history source** | Open question | Answered by D2 and D3: each eval file holds the account's May rows, so June targets get their history from the same file, the same way our builders already work. History cannot reach earlier than May 1, 2025, exactly as for the TFM. |
| **Account disjointness** | Verified for V1's three splits | Guaranteed by design (D3) across train-folder and eval-folder files. Validation must still use different train-folder files from training. |
| **History length for production** | "Last H seconds per account" | The TFM serves the last 17 transactions, counted in transactions, not time (D5). Our all-position H counts **distinct seconds**, so tied seconds can hold more rows. A production version needs a row cap or a rows-based definition. History 20 is close to the TFM's 17; if history 0 vs 20 shows a shorter history is nearly as good, prefer it (D6). |
| **How much data to use** | 10 → 100 files | Up to about 5,000 training files exist. D7 suggests diminishing returns, so keep the plan at 10 → 100 and add more only if 100 clearly beats 10. Count frauds first. |
| **TFM training overlap** | Not considered | V1's train (1–10) and validation (4950–4954) files are inside the TFM's 5,000 training files. That doesn't matter for our own model. It does matter for the TFM-embedding comparison (step 6): TFM embeddings on those files may be in-sample (pretraining pool and/or the sampled 10.24M-row fine-tune), so consumer tests must use files the TFM did not train on, i.e. eval-folder files. |

### 13.3 Still to verify on the pod (read-only, cheap)
1. Exact file numbers present in `tfm_raw_data/` and `tfm_EVAL_raw_data/` (list the S3 keys; do not assume 1–5000 or 8000–9999).
2. Per-file min and max dates, rows and frauds for the files chosen for the new splits. Same method as V1's
   preflight `data_contract.json`.
3. In V1's files 8000–8010: June-only row and fraud counts, and how many June targets have at least 5 / 20 earlier
   rows. This tells us how much history June targets actually have.

---

## 14. Lessons from PFM / TFM work for our FT model (received 2026-10-15)

Sources reviewed:
- Sumegha / Xinyu email thread "Model Replication Data" (4–22 Sep 2026).
- Xiaoming / Waqas Teams thread correcting the account structure.
- Sumegha / Xinyu / Waqas Teams replication thread (21 Sep 2026).

This section is **supporting evidence for how we should build, train, validate, evaluate and add features to our
FT model**. It is not a proposal to redirect the project toward reproducing or extending the PFM / TFM. The account
correction is still useful: the early statement that the OOT data had one target per account was wrong; Waqas
checked the file directly.

### 14.1 Newly established facts

| ID | Fact | Evidence / consequence |
|---|---|---|
| R1 | The v22b benchmark artifact is `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/eval/cross-file-8000-8200-seed-42_1.parquet`. | This is a prepared TFM evaluation artifact. Its `8000-8200` naming does **not** refer to raw TFM bucket files and creates no implied overlap with V1 files 8000–8010. We have its logits and aggregate developer-model results. |
| R2 | It has 952,905 unique targets from 317,672 accounts: 104,028 accounts have one target; 213,644 have multiple; mean 3, median 2, range 1–60. | Evaluation observations are clustered by account. Confidence intervals and paired tests must resample accounts, not transactions. Report transaction-weighted metrics, plus an account-balanced sensitivity view. |
| R3 | Accounts were unseen in TFM training. About 1M target transactions were sampled **completely at random**, not stratified; pre-Falcon declines and other LoB-excluded segments were then removed to reach about 950K. From v30 onward, filtering occurs before the 1M sample. | Results apply to the eligible post-filter population, not all June authorizations. Record the exact exclusion rules and order; v22b and v30 samples are not constructed identically. |
| R4 | The payment foundation model received a distributed fraud fine-tune that added the fraud head and trained for 10,000 steps across the available files, presenting 10,243,344 target rows. Those fine-tuning targets and the 952,905 OOT targets have zero transaction-ID overlap. | This is useful evidence for scale, distributed training and head fine-tuning choices. It is not our proposed training recipe by default. MMR states OOT accounts were unseen, and account binning guarantees an account occurs in only one raw file. |
| R5 | Supplied v22b output had 952,908 physical rows but 952,905 IDs: three non-fraud IDs were duplicated with identical metadata and scores, consistent with distributed sampler padding. | Deduplicate by `fi_transaction_id` before metrics. Permit identical duplicates only with an audit count; fail on conflicting labels, metadata or scores. Never let sampler padding weight metrics. |
| R6 | Supplied 4-GPU metrics after deduplication: AUC 0.9684954520, KS 0.8214186849, AP 0.2736735580, PR-AUC 0.2768044252, log loss 0.2770427428. Waqas's rerun: AUC 0.9684926181, KS 0.8212473741, AP 0.2736101443, PR-AUC 0.2767267330, log loss 0.2770424619. | Aggregate ranking metrics reproduce very closely, but scores do not reproduce exactly. Preserve both AP and trapezoidal PR-AUC labels; they are different statistics. |
| R7 | Waqas's two reruns were exactly equal on all 952,905 rows. Against the supplied output, 15.71% of logits differed; all-row mean absolute probability difference was 0.00013460 and maximum 0.01409278. Sumegha's separate one-GPU rerun differed from both (20.42% of logits vs Waqas; max probability difference 0.02191817). | Fixed code and environment can be repeatable, but checkpoint + data alone are insufficient for exact cross-environment reproduction. Code revision, package/CUDA stack, precision, device count and evaluation order all belong in the model contract. |
| R8 | The tokenizer config supplied to Waqas lacked required `mask_token` and `fill_missing`; adding `mask_token="<MASK>"`, `add_mask_token=False`, `fill_missing=False` loaded the unchanged 5,378-token vocabulary without changing token IDs. | Probably not the score-difference cause for pre-tokenized evaluation, as Sumegha said, but it proves the artifact bundle was not self-loading under the supplied code. Add an artifact-load smoke test and hash the repaired config. |
| R9 | MMR and Waqas were operating with different repository versions. Sumegha recommended repeating exact replication against Shubham's cleaned shared repository. | Do not attribute cross-stack differences solely to GPU nondeterminism. The clean-repo rerun is the discriminating test. Archive commit SHA and a lockfile with every official score. |
| R10 | v22b is legacy BMG and contains non-production fraud proxies, specifically status/card-inactive date, which MMR says has potential leakage and should not be used in its current form. v30 is newer CSCA, contains LoB engineered features and drops features unavailable in production. | v22b is a useful historical system benchmark, but not a clean architecture-only or production-feasible comparator. Ask for v30 results/artifacts and run feature ablations before drawing representation conclusions. |

### 14.2 Direct changes to our modeling and evaluation

The reusable lessons below are the point of this section. PFM / TFM replication work is context and a source of
tested practices; our objective remains the strongest defensible FT-based fraud model and reusable embedding.

1. **Use two June evaluations with different jobs.**
   - **Untouched benchmark:** the exact 952,905 prepared targets, used once for final FL / TFM comparability.
   - **Broader raw-June test:** all eligible June targets in held-out eval files, used to measure generalization
     beyond the random 950K sample. Freeze eligibility rules before scoring.
2. **Never build history from the sampled benchmark rows.** Retrieve each target's full eligible May-to-target raw
   account stream from its source file. A prior benchmark target from the same account may validly appear as
   history for a later target only through the raw chronological stream and without its label.
3. **Keep validation account-disjoint and temporal.** Train targets Oct–Apr; validation targets May in different
   train-folder files; test targets June in eval-folder files. The benchmark confirms the final test population is
   unseen-account as well as out-of-time.
4. **Use account-clustered uncertainty.** Bootstrap accounts and carry all their targets together. Transaction-row
   bootstrap would make intervals too narrow because 67.3% of accounts contribute multiple targets.
5. **Make benchmark ingestion strict.** Assert 952,905 unique IDs, 317,672 accounts, known label count, no metadata
   conflicts, and report physical rows separately from unique targets. Deduplicate the three known padding rows.
6. **Version the complete inference stack.** Save repository commit, dirty-state patch, checkpoint and tokenizer
   hashes, Python / torch / CUDA / cuDNN versions, GPU model and count, precision, batch size, sampler, seed and
   deterministic settings. Run same-stack repeat scoring before cross-stack comparison.
7. **Set numerical gates by purpose.** Exact equality is required for repeated scoring in one frozen stack. For a
   certified cross-stack port, require population identity plus predeclared per-row and aggregate tolerances; do
   not waive a failure merely because AUC is close.
8. **Separate discrimination from calibration.** The TFM's ranking is strong, but log loss 0.277 is poor relative
   to the 0.1488% prevalence baseline, consistent with fraud-enriched fine-tuning and/or uncalibrated scores.
   Evaluate Brier score, calibration curves and post-hoc calibration on validation before production comparisons.
9. **Do not call v22b superiority an architecture result.** Its leakage-risk status date, engineered features,
   training scale and sampling differ from ours. Compare systems as delivered, then add matched-feature and
   production-available-feature comparisons. Prefer v30 as the production-relevance comparator when available.
10. **Preserve segment scope.** Apply the same pre-Falcon and other LoB exclusions to FL, TFM and FT for the main
    comparison; separately report excluded populations if labels and deployment requirements permit.

### 14.3 Questions and checks, prioritized

| Priority | Question / check | Why it matters | Owner |
|---|---|---|---|
| P0 | What are the exact pre-Falcon and "other segment" filter predicates, and are they applied using only information available at decision time? | Defines the benchmark population and may itself leak outcome information. | MMR / LoB |
| P0 | Which exact v22b input columns are fraud proxies or unavailable at authorization time, especially status/card-inactive date? Supply feature definitions and event-time availability. | Determines whether v22b metrics are deployable and whether comparison with our 23 fields is fair. | MMR |
| P2 | If we use the prepared benchmark for a formal final claim, join its IDs to our scored population and report exact row/account overlap. Do not use `8000-8200` as raw file numbers. | Makes the comparison population explicit without inventing a file mapping. | Us |
| P0 | Obtain the cleaned shared repository commit and rerun the supplied checkpoint under its pinned environment on one and four GPUs. | Separates code drift from device-count / numerical effects. | MMR + us |
| P0 | Confirm the label definition, maturation window, as-of date and whether labels or status fields were revised after June 2025. | Old labels are likely mature, but maturity alone does not prove point-in-time construction. | Data owner / LoB |
| P0 | Confirm DR, VDR and FPR@0.006 definitions, denominator, threshold construction and units. The aggregate XGBoost and developer-model results already exist; request LoB row-level scores only if we run paired analysis. | Prevents metric-definition mismatch without making baseline acquisition a new workstream. | Xinyu / LoB |
| P1 | Supply the full benchmark manifest: 1,418 fraud count, 317,672 account count, duplicate-ID policy, schema, creation code, seed and source-file list. | Turns Teams findings into an executable data contract. | MMR + us |
| P1 | Was simple random sampling performed across all eligible transactions, per file, or after any per-account cap? Were all frauds retained or sampled at the same rate? | "Simple random" is not enough to reconstruct inclusion probabilities or explain AP. | MMR |
| P1 | Why do the supplied and rerun logits differ in bf16-sized increments? Compare fp32, bf16, batch sizes, sampler order, `eval()` state, attention kernels and one-vs-four-GPU gathering under the same commit. | Finds the numerical source without guessing. | MMR + us |
| P1 | Are dropout and all stochastic augmentations disabled at evaluation, and are logits saved before or after any calibration / temperature transform? | A hidden stochastic or calibration step could explain score differences. | MMR |
| P1 | What precise tokenizer/code versions produced the checkpoint and token parquet? Can the official artifact load from a clean environment without patching? | Token-ID compatibility is necessary but not sufficient for exact model compatibility. | MMR |
| P1 | Provide v30's checkpoint, tokenizer, benchmark construction, production-available feature list and matched metrics. | v30 is the relevant production comparator; v22b is explicitly leakage-risk legacy data. | MMR |
| P1 | Do TFM histories include prior transactions that fail the target eligibility filters, declines, or transactions later excluded from scoring? | History eligibility can materially change sequence signal and fairness of reconstruction. | MMR |
| P1 | For multiple June targets on one account, can an earlier target transaction become history for a later target? Are labels ever encoded in history tokens? | Earlier transactions are causally valid; earlier labels are not available online. | MMR |
| P1 | Confirm all OOT accounts, not merely target IDs, have zero overlap with pretraining and fine-tuning. Provide salted account-set intersection counts. | MMR stated unseen accounts; an executable check closes the contract without sharing identifiers. | MMR |
| P2 | Report metrics by targets-per-account, history depth, cold start, source file, day/week, amount, segment and fraud type. | Reveals whether gains come from repeated-account history or a narrow segment. | Us |
| P2 | Compare transaction-weighted and account-balanced metrics, plus account-clustered confidence intervals. | Prevents accounts with up to 60 targets dominating conclusions. | Us |
| P2 | Explain AP 0.2737 versus PR-AUC 0.2768 and standardize the library/interpolation used. | Avoids decimal disputes caused by comparing distinct PR summaries. | Us / MMR |
| P2 | Assess calibration at natural prevalence and after validation-only Platt / isotonic calibration. | Ranking gains do not imply usable probabilities; current log loss is a warning. | Us |
| P2 | Confirm same-second ordering/availability, transaction timestamp precision and tie-breaking in TFM sequences. | Needed to align our strict same-second exclusion with TFM and production reality. | Data owner / MMR |
| P2 | Quantify v22b performance after removing status-date and every non-production proxy. | Estimates how much of the published result survives a production-feasible feature set. | MMR |
| P3 | What does `8000-8200` denote in the prepared artifact naming, and was model/recipe selection ever performed on this same benchmark? | The name is not a raw-file mapping; only prior use matters for whether the benchmark remained untouched. | MMR |
| P3 | Are the three duplicate IDs always the expected distributed-sampler padding positions for the world size and sampler version? | Useful reproducibility check, but lower modeling risk once deduplicated. | MMR |

### 14.4 Interpretation boundary

These threads strengthen the benchmark contract but do **not** yet prove that our FT model should copy the TFM's
feature set, tokenizer, 17-transaction policy or sampling. The defensible comparison ladder is:
1. reproduce v22b as a frozen legacy system;
2. compare all models on identical IDs, labels, exclusions and history availability;
3. compare production-available features only (preferably against v30);
4. ablate scale, proxy features and history before attributing gains to architecture or embeddings.

For our immediate plan, the practical takeaways are narrower: preserve account-disjoint files, use target-period
masking so earlier rows serve as history, test scale deliberately, log complete distributed-training contracts,
deduplicate evaluation IDs, cluster uncertainty by account, compare feature additions one at a time, and keep the
available XGBoost and fraud-fine-tuned developer-model results as external baselines rather than design targets.

---

## 15. Two Xiaoming / cross-team emails: relevance to our work (received 2026-10-15)

The substantive contents of these emails, together with the earlier raw-data and PFM/TFM replication threads, are
archived separately in
`updates 10-14-2026/reviewer_update_20261015/SOURCE_THREADS_20261015.md`. This section contains our analysis; the source
archive keeps the statements and metrics separate so a reviewer can challenge our interpretation.

### 15.1 Email 1: decision models and a Tabular FM backbone

**What the email proposes.** A reusable decision model is envisioned as a relatively cheap, fast classifier for
tasks such as routing, risk categorization, policy gating, confidence, escalation and model challenge. Xiaoming
argues that tabular applications should prefer a tabular-native backbone because conversion into a generic LLM
token space can lose information, and that task fine-tuning should outperform direct use of a pretrained model.

**Technical reading.** The first argument is relevant and supports our representation choice: our FT tokenizer
embeds typed numerical and categorical fields directly; it does not stringify a row into generic language tokens.
That reduces one important source of avoidable information loss. It does not prove FT-Transformer is the best
backbone; GBDTs, MLP-PLR and modern TabFMs remain empirical comparators. The second argument is directionally
reasonable—task fine-tuning adapts representations and attention—but the specific claim that it works because
"Q-representation and K-representation become more aligned" is an unverified mechanism, not a model-selection
rule. Fine-tuning changes Q, K, V, feed-forward blocks, embeddings and the head; performance must be demonstrated
on held-out data.

**Impact on our experiments.** No immediate architecture pivot. Our existing plan already tests the useful parts:
- a tabular-native FT encoder rather than generic text tokenization;
- fraud-supervised fine-tuning;
- a per-transaction score and representation exported into XGBoost;
- latency, point-in-time availability and strong XGBoost / developer-model comparisons.

Add one representation test after the predictive model is stable: **frozen embedding + new head** versus
**end-to-end fine-tuning** on an encoder-unseen split. This measures whether the backbone carries transferable
signal and whether adaptation is necessary. It is more informative than inspecting Q/K similarity alone.

**Are we contributing to this broader idea? Partly, as a concrete fraud-domain case study.** We can contribute:
- evidence for a typed tabular-sequence backbone on a large, sparse, time-shifted classification problem;
- a reusable transaction embedding tested in a second consumer (XGBoost);
- practical evidence on history, feature-store inputs, calibration, latency and production replay.

We are **not yet building the proposed off-the-shelf decision model or a Tabular FM**. Our current encoder has one
schema, one portfolio and one supervised fraud task. A broader claim requires transfer to new models/tasks or
portfolios, frozen-backbone tests, standardized input adapters, multiple heads, and cost/latency comparisons. The
external Jev/Laya-style work is adjacent R&D, not a dependency of the present FT plan.

### 15.2 Email 2: full-history, point-in-time feature engineering

**What the email establishes.** Serial correlation lives within an account/customer, so account history must be
preserved. Historical aggregates must be computed from the full, point-in-time transaction stream **before** any
class-specific target downsampling. Otherwise count, spend, merchant diversity, velocity, recency and similar
features encode the sampling policy instead of production behavior. Full-window aggregates also leak future
information and post-fraud account closure into earlier rows. Sampling bias and look-ahead/survivor leakage are
different defects and need different fixes.

**Important nuance.** Sidney's narrower argument about `activity_interval` is plausible but should not become a
waiver: class-based thinning may distort an extreme-statistic span less for high-activity, single-fraud accounts,
but it can be severe when few legitimate rows survive and for high-fraud/high-velocity typologies. More
importantly, a full-window `max(date)` remains future leakage regardless of sample size. We do not need to decide
how often the distortion is material because the clean construction is available: full unsampled, strictly-prior
history.

**Current-state impact.** V1 is aligned with the main policy:
- raw FT training is at natural prevalence; it does not use the cited 1%-good class sample;
- accounts are assigned to one raw file, preserving their available stream and preventing cross-file splitting;
- sequence windows are built from raw rows and use strictly earlier timestamps; labels are not history inputs;
- train, validation and evaluation accounts are disjoint.

V1 still uses a deliberately capped history (H seconds). That is not sampling corruption if the identical
strictly-prior cap can be reproduced online; it is a model/context choice to test. Same-second availability and
the limited May history in evaluation remain explicit boundary conditions.

**Binding requirements for V2 and feature addition.** Every historical feature must satisfy this order:

`full raw account stream -> chronological point-in-time feature replay -> split/target selection -> optional training-target downsampling -> model`

Consequently:
1. Never construct V2 aggregates from a fraud-enriched or target-sampled table.
2. Downsample targets only; do not remove their prior history from the feature/sequence source.
3. Fit learned encoders, imputers and normalizers on training targets only, while computing causal histories from
   the allowed pre-target raw stream. This separates feature availability from parameter fitting.
4. Validation and test retain natural prevalence and use the same online-reproducible feature definitions.
5. Replace ambiguous zero fills with explicit cold-start / no-history indicators.
6. Validate aggregate code by chronological replay and perturbation tests: adding a future row must not change an
   earlier target; deleting an unsampled target must not delete that transaction from later history when it would
   exist in production.
7. Treat closure-sensitive features (activity span, recency, tenure, inactivity) as high risk; define them as of
   the target timestamp and test fraud-account closure effects by cohort.
8. If class-based target downsampling is later introduced, record inclusion probabilities, use population-based
   calibration, and rerun ranking/threshold checks because neural models and trees are not protected by the simple
   unregularized case-control logistic-regression result.

**Are we contributing to this broader idea? Yes, directly.** Our history-aware FT model is the transformer-based
approach Xiaoming describes for within-account serial correlation. The planned point-in-time V2 aggregates and
per-row embeddings are also candidate inputs to the portfolio feature-store vision. Today, however, our artifacts
are an experiment pipeline, not a production feature store. Contribution to that larger program requires a
canonical feature contract, historical backfill plus incremental online computation, freshness/lineage/versioning,
and demonstrated reuse by another model or validation.

### 15.3 Decisions caused by the emails

| Decision | Status |
|---|---|
| Keep the current FT/tabular-sequence direction; do not pivot to a generic LLM decision model | Confirmed |
| Treat broader TabFM/decision-model work as a later transfer benchmark, not a prerequisite | Confirmed |
| Add frozen-backbone versus end-to-end fine-tuning as the representation-transfer test | New, after the core model is stable |
| Compute V2 historical features by full-stream chronological replay before any target sampling | Binding |
| Preserve non-target rows as history if they would have existed at production scoring time | Binding |
| Add future-invariance, history-deletion and cold-start tests to the V2 feature gate | New |
| Describe our broader contribution as a fraud-domain case study plus reusable representation—not yet a Tabular FM or production feature store | Confirmed |

### 15.4 Manager response: Nengfeng's feature-store direction (received 2026-10-16)

Nengfeng agreed that the all-position results are promising if they hold as history and training size increase. He
confirmed that the feature-store objective is **not merely a better FT-Transformer**: the key question is whether the
embeddings contain reusable signal that improves downstream fraud models. He endorsed comparing against the frontline
XGBoost model and the transaction foundation model, then evaluating embeddings through offset models or other
downstream consumers.

He asked us to examine:

1. Correlation between FT embeddings, foundation-model embeddings and existing model scores.
2. PCA or other dimensionality-reduction methods for embedding export.
3. Whether embeddings can be standardized as reusable feature-store assets rather than remaining model-specific
   features.

**Interpretation.** This confirms the intended product of our work: a validated reusable representation and its
downstream lift, not just an isolated AP result. Correlation is diagnostic, not a success criterion; high correlation
can mean redundancy, while low correlation can reveal complementary signal. PCA must be fit on training data only and
evaluated against the uncompressed embedding, because compression can discard the useful fraud signal. Standardization
requires a versioned schema, dimensions, dtypes, normalization parameters, transaction-ID contract, point-in-time
history contract, freshness/latency expectations and backward-compatibility policy.

**Manager-aligned representation workstream.** After the data split and encoder are frozen:

1. Export per-row FT embeddings from the actual prediction representation (`out[:, 1:]` for all-position B), plus
   the FT score and transaction ID. Do not export `seq_CLS` unless it is separately justified and named.
2. Align FT embeddings, available PFM/TFM embeddings, frontline XGBoost score and FT score by transaction ID on
   the same untouched evaluation population.
3. Report pairwise score/embedding correlations, PCA explained variance, and redundancy diagnostics without treating
   correlation as performance.
4. Train downstream XGBoost consumers on encoder-unseen rows. Compare raw features only, raw + FT score, raw + FT
   embedding, compressed FT embedding, and where available raw + TFM embedding / offset variants.
5. Fit PCA, scalers and any feature selection on the downstream training split only; never fit them on the final
   evaluation population.
6. Measure incremental AP/AUC/KS and operating-point DR/VDR/FPR, calibration, account-clustered uncertainty,
   latency, storage width and missing-embedding fallback.
7. Define a feature-store contract: embedding version, model/checkpoint hash, input schema, history policy, output
   dimensions, dtype, scaler/PCA artifact hashes, valid-from time, ID key, freshness SLA and rollback behavior.
8. Test reuse in at least one second consumer or model family before calling the embedding reusable.

This manager direction strengthens the existing embedding/XGBoost plan; it does not change the immediate order:
fix the data and temporal validation first, establish the best encoder, then run the representation workstream.
