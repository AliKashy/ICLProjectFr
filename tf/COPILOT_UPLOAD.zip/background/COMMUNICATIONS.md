# Work communications log: tabular fraud project

## 1. About this file

This file lists the work communications behind the tabular fraud project (the FT-Transformer card-fraud model). It says what managers, colleagues and other teams said, when and where, and what it changed in the work.

It covers: Confluence weekly updates and meetings, emails, Teams chats, team meetings, presentations to managers, Yaqun's plan documents, requests to the data owner, the line of business (LoB) and Xinyu, and managers' or colleagues' words as relayed by Waqas.

It does not cover Waqas's conversations with AI assistants, or the assistants' own work notes.

Two projects appear:

- **tabular fraud** (repo AliKashy/tabular_fraud): Waqas's FT-Transformer fraud model. Waqas's main work from late September 2026.
- **MRM_1** (repo AliKashy/MRM_1): the sibling project, validation of MMR's Transaction Foundation Model (TFM), July to September 2026. It holds the Confluence export.

Many early communications are about the TFM. They matter here because the tabular fraud model uses the same raw data, the same benchmark population (Test 2) and many of the same candidate features.

### People

| Name (spelling variants) | Role, as the sources give it |
|---|---|
| Waqas (K194855) | Owner of the tabular fraud project; reviewed and replicated the TFM with Xinyu. |
| Yaqun (older files: Yakun) | Original author of the tabular fraud plan, design log and handoff guide; colleague; out of office for a while from about 9 Oct 2026. |
| Xiaoming (meeting notes: Xiaming) | Manager ("From: Xiaoming, manager"); receives the weekly updates; wrote the feature-engineering emails. |
| Nengfeng | Manager; attended the 28 Jul TFM meeting; replied on the feature-store direction (16 Oct). |
| Jie Chen | Director; replied to Xiaoming's 12 Oct email. |
| Waqas's manager (not named) | Named the two embedding uses relayed on 26 Oct. The sources do not say which manager. |
| Xinyu (Xinyu Zhou) | Colleague on the foundation-model work; ran the TFT and ICL trials; reviewed the TFM with Waqas; built the offset model (frontline XGBoost plus TFM embeddings); named contact for frontline features, scores and metric definitions. |
| Sumegha (also Sumagh, Sumagha) | TFM developer in the MMR team; sent the raw-data email; gave Yaqun the first predictor list; supplied the v22b checkpoint package. The TFM V22B package calls the developer side "Developer". |
| Shubham | MMR side; owner of the cleaned shared TFM repository. |
| Joel | Credited with the raw-data copy; held the GPU coordination meeting. |
| Sandhya | Attended the 31 Jul GPU coordination meeting. |
| Hanyu | Recipient of the 27 Aug update. |
| Sidney | Cross-team colleague on Xiaoming's 15 Oct feature-engineering thread. |
| Shaunak | Previous QAP; did earlier feature-engineering work (not received). |
| MMR | Team that built the TFM. Some records call it the payment foundation model (PFM); whether PFM and TFM always mean the same model is not stated. |
| LoB / front-line (FL) | Line of business; owns the debit-card XGBoost model 15298 and the field metadata spreadsheet. |
| Data owner (not named) | The data-feed owner who can confirm field meanings and timing. |
| Senior quants | Executive-director and senior quants met on 6 Oct and 26 Oct. |
| Internal participant / internal reviewer (not named) | People on the TFM threads, as the TFM V22B package labels them. |

### Kind of text

Each block says what kind of text its source is:

- **Original text**: written at the time (email body, Confluence row, slides, meeting notes, plan document, report).
- **Relayed by Waqas**: Waqas's own account of what someone said or wants. The original message is not in the repositories.
- **Summary**: a later project record that paraphrases the communication, for example the TFM V22B package's communication log (COM-001 to COM-015) or Waqas's 14 Oct update readme. The original is not supplied unless the block says so.

Where the original is missing, the block says so. No dialogue has been added.

### Source references

References are `path:lines`. A path starting `MRM_1/` is in the MRM_1 repo. Any other path is in tabular_fraud. Both repos are copied into `background/sources/tabular_fraud/` and `background/sources/MRM_1/` at the same paths. So `MRM_1/confluence/Foundation Model for Fraud:9` is at `background/sources/MRM_1/confluence/Foundation Model for Fraud`, line 9, and `waqas/docs/meeting_notes.md:104-202` is at `background/sources/tabular_fraud/waqas/docs/meeting_notes.md`, lines 104 to 202.

Some paths contain spaces, for example `updates week_10-14-2026/updates 10-14-2026/readme.md` (the 14 Oct update readme) and `updates_week_10-14-2026/Updates 10-15-2026/complete_reviewer_context.md`. Each Confluence row is one line of `MRM_1/confluence/Foundation Model for Fraud`. The deck is cited by slide number.

---

## 2. Chronological log

### C01. 15 May 2026: TFM fraud use-case presentation by the developing team

- **Date:** 15 May 2026 (the presentation name in COM-001 is "2026-05-15 FrontierAI Transaction Foundation Model presentation"). The deck file was added to MRM_1 on 20 Sep 2026.
- **People:** the TFM developing team (MMR / FrontierAI); audience included Waqas.
- **Channel:** presentation deck `MRM_1/Transaction_Foundation_Model_Exact_Match_v4(1).pptx` (34 slides, title "Transaction Foundation Model - Fraud Detection Use Case").
- **Kind of text:** original text (slides). That this deck is the 15 May presentation is likely, but no source says so directly. Waqas later said the deck describes TFM version 17 (relayed by Waqas).
- **What was said:**
  - Slide 28: "Keep all fraudulent transactions and down-sample to 1% of non-fraud." "Training data July 2024 to December 2024, ~52M sequences. Validation data April 2024."
  - Slide 30: "Generally last token pooling leads to best results." "A shallow classifier head is sufficient." "Separate learning rates." Weight decay 0.2 to 0.3 reasonable.
  - Slide 31 (UDR, VDR, FPR at 0.6% outsort): XGBoost LoB v1.2 with engineered features (Jun25) 0.548, 0.580, 5.79; XGBoost without engineered features (Apr24) 0.225, 0.173, 14.995; FT-TFM H=5 first pooling 0.024, 0.014, 151.54; last pooling 0.703, 0.604, 4.297; average pooling 0.689, 0.597, 4.402; fraud weight 14.6: 0.666, 0.589, 4.590; best H=12 last pooling Apr24 0.731, 0.638, 4.093 and Jun25 0.684, 0.637, 4.980. "FPR = non-fraud/fraud in 0.6% outsort." "LoB model uses 94 features with vendor model VAA score; we use 98 tokenized features excluding VAA score."
  - Slide 33: "Last pooling consistently outperforms." "Complex classifier head yields little to no boost." "Checkpoints peak mid-training, then degrade. Select by validation metrics, not step count."
  - Slide 34 (next steps): "Foundation model as feature extractor for downstream models." "Consider XGBoost + GNN features, XGBoost + Transformer embeddings." "Feature Importance Analysis."
- **What it changed:** last pooling accepted as the delivered TFM's setting. The developers' own next step (XGBoost plus transformer embeddings) is the same idea as the later embedding tests (C33 next step 5, C48, C55). The validation month (Apr 2024) coming before the training period became a question for the developer (C32). The 1% non-fraud downsampling is the TFM recipe; the tabular fraud model trains at the natural fraud rate, and downsampling stays a proposal.
- **Status now:** context only. TFM v22b numbers come from the rerun report (C33), not this deck.
- **Sources:** `MRM_1/Transaction_Foundation_Model_Exact_Match_v4(1).pptx` slides 1, 28, 30, 31, 33, 34; `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:63`; `guide/parts/01_foundations.md:232-245`

### C02. 28 Jul 2026: meeting with Sumegha about MMR's TFM

- **Date:** 28 Jul 2026
- **People:** Sumegha, Nengfeng, Xiaoming, Xinyu, Waqas
- **Channel:** meeting, recorded as a Confluence weekly update row; also logged as COM-001 "Internal TFM introduction".
- **Kind of text:** original text (Confluence row) plus summary (COM-001). No meeting transcript exists ("Meeting transcript unavailable").
- **What was said:** "Meeting with Sumegha to discuss the TFM developed by MMR." "MMR is organizing the repo, and we will be ready to get access soon." "It will take time for TSFM installation as security and other checks are going." ("TSFM" is the source spelling; the source does not define it.) COM-001: "Internal introduction to the Transaction Foundation Model"; presentation materials were referenced (C01).
- **What it changed:** added the in-house TFM review. COM-001: "Established the review scope: data, representation, architecture, pretraining, fine-tuning, evaluation, and reuse."
- **Status now:** done. Repository access came later (C18).
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:9`; `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:54-67`

### C03. 30 Jul 2026: Xinyu's first TFT trial and the fraud-label leak

- **Date:** 30 Jul 2026
- **People:** Xinyu
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Xinyu completed one testing trial of TFT model with old Visa credit card data (training: 2022-07 - 2022-08, valid: 2022-09, OOT: 2022-10)." "Train model by taking all accounts with fraud transaction and downsampling accounts without fraud to 2%." "Treat fraud label as a feature 'unknown variable in prediction'." "Obtain 99% AUC in OOT data." "Data leakage issue exists since a target transaction cannot see a finalized fraud label at the un-maturated time point. We need a better design of how to input the fraud label." ("TFT" is not defined in the source.)
- **What it changed:** added the fraud-label maturity and leakage concern that runs through all later work. It supports Yaqun's decision 2 (C34): no past fraud labels as inputs in any tabular fraud model. Later project guides cite this "meaningless 99% AUC" as "another team" hitting the leak; the Confluence row shows it was Xinyu's trial.
- **Status now:** the 99% AUC result was not carried forward. "No past labels as inputs" is in force. How long labels take to settle is still an open question for the data owner (C49).
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:10`; `guide/parts/01_foundations.md:247-254`; `docs/phase4_design_decisions.md:1-25`

### C04. 31 Jul 2026: GPU resource coordination meeting with Joel

- **Date:** 31 Jul 2026
- **People:** Joel, Sandhya, Xiaoming, Xinyu, Waqas
- **Channel:** meeting (Confluence weekly update row)
- **Kind of text:** original text
- **What was said:** "Meeting with Joel about GPU resource coordination (participant: Joel, Sandhya, Xiaoming, Xinyu, Waqas)." "Xinyu and Waqas have GPU access now."
- **What it changed:** added GPU access for Waqas and Xinyu for the ICL and TFM work.
- **Status now:** done
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:11`

### C05. 4 Aug 2026: Xinyu and Waqas catch-up on Chronos-2 and fraud-label input

- **Date:** 4 Aug 2026
- **People:** Xinyu, Waqas
- **Channel:** catch-up meeting (Confluence weekly update row)
- **Kind of text:** original text
- **What was said:** "Xinyu and Waqas have a catch-up meeting." "Xinyu goes through the Chronos-2 model with Waqas." "Xinyu discussed fraud label issue with Waqas for an input design to transformer model." The same Confluence page recommends Chronos ("Chronos: best overall (multi-series + covariates)"; next step "Select initial model (Chronos recommended)").
- **What it changed:** nothing lasting. No later entry records a Chronos fine-tune. Work moved to in-context learning (17 to 31 Aug), then to the TFM review. Whether Chronos was formally dropped is not stated.
- **Status now:** not continued
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:12,49,120`

### C06. 5 Aug 2026: TFM code walkthrough in Teams

- **Date:** 5 Aug 2026, 09:00 to 11:00
- **People:** developer team (invite list); attendance not proven
- **Channel:** Microsoft Teams meeting (COM-002); related email "RE: Internal foundation model introduction"
- **Kind of text:** summary (COM-002). No transcript. The content of the walkthrough is missing.
- **What was said:** "A two-hour code walkthrough was scheduled in Microsoft Teams."
- **What it changed:** decision recorded: use source files and related messages as the implementation evidence.
- **Status now:** scheduled (an invite exists); whether it took place and what was covered are not recorded
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:69-82`

### C07. 17 Aug 2026: Xinyu's first in-context learning (ICL) results, shared with Xiaoming

- **Date:** 17 Aug 2026
- **People:** Xinyu, Xiaoming
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Xinyu shared initial results with Xiaoming by convert vectorized transaction data into text and use LLM for in-context learning using transaction-level downsampled Debit Card data (202410 - 202507)." Each row turned into text with engineered features; balanced few-shot examples; "No account history information." Downsampled OOT: "KS: 0.5889, AUC: 0.8718, DR@15%: 0.7195". Next plan: "Redesign text transformation by only incorporating meta data of each transaction." "Introduce account history in the text, but do not include the label of history transactions due to label maturity issue."
- **What it changed:** led to the 21 Aug iteration (C11). Repeats the rule: no history labels.
- **Status now:** superseded; ICL paused on 31 Aug (C16)
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:13`

### C08. 17 Aug 2026: Sumegha's email "TFM Debit Card raw data copy" (thread to 31 Aug)

- **Date:** 17 Aug 2026, 9:13 AM; Xinyu's reply 31 Aug 2026, 3:52 PM
- **People:** Sumegha (sender) to all; Joel credited for the copy; Xinyu Zhou replied
- **Channel:** email "TFM Debit Card raw data copy" and "RE: TFM Debit Card raw data copy" (COM-003)
- **Kind of text:** original text (the email body is kept in tabular_fraud) plus summary (COM-003)
- **What was said:**
  - "The raw data used to pretrain and fine-tune the TFM model has been copied to this shared bucket s3://mrmcd-analytics-mrm-mmr-dsai/."
  - "Training data ranges from 102024 to 052025: s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/"
  - "Testing data for TFM is 062025 but has 052025 histories. Therefore, the testing data here covers 052025 to 062025: s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/"
  - "The data is partitioned by account into 10000 buckets totally (part_1, part_2, ... part_10000) and you will see a subset of these files (we use at most 5000 files for training and 2000 files for testing)."
  - Xinyu's reply: "Thank you, Sumegha and Joel, for the efforts. This is very helpful."
- **What it changed:**
  - These are the exact folders the tabular fraud code reads (training from tfm_raw_data, evaluation from tfm_EVAL_raw_data).
  - Recorded as data facts D1 to D4 on 15 Oct. Changed: V1's evaluation files 8000-8010 are only half out-of-time (about 51% May rows, inside the training period; 48.7% June), so a June-only view is needed for any out-of-time claim.
  - Removed: the planned "July 2025+" holdout (it does not exist).
  - Added: benchmark targets take history from the same evaluation file; account disjointness holds by design; a proposed split redesign (train Oct to Apr, validate May, test June), which was never adopted (the 26 October records still use October to May for training and validation and May to June for Test 1 [bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:88-101]); TFM-embedding consumer tests must use evaluation-folder files, because V1's training and validation files sit inside the TFM's 5,000 training files.
  - The 23 Oct data inventory found "Training files 5001-7999 do not exist, which matches the data owner's email", so the planned DS_TRAIN files 5001-5010 became train files 4001-4010.
- **Status now:** facts in force. Split roles later frozen as EPOCH_VAL, DEV_OOT, SELECT, DS_TRAIN/DS_SELECT and FINAL. Open: whether May in the evaluation files was meant only as history for scoring June (OQ-23).
- **Sources:** `waqas/additional_info/data_path_information_email/data_path_information_email.md:1-29`; `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:84-97`; `updates week_10-14-2026/updates 10-14-2026/readme.md:554-591`; `updates_10_23_2026/M01_V2_results__through_l3.part_1.md:79-82`; `fraud/configs/preprocessing.yaml:10`; `fraud/configs/eval.yaml:16`; `bridge/OWNER_QA.md:98`

### C09. 17 Aug 2026: Teams chat on the time column and feature descriptions

- **Date:** 17 Aug 2026, 11:25 to 11:36
- **People:** Developer (MMR)
- **Channel:** Teams meeting chat "Internal foundation model introduction" (COM-004)
- **Kind of text:** summary (COM-004)
- **What was said:** "Developer identified transaction_dttm as the transaction-time column. Developer said the data has more features than the data sheet; tokenizer configuration contains concise feature summary statistics, while feature descriptions should be obtained from metadata tables."
- **What it changed:** the four calendar inputs of the tabular fraud model (month, day, hour, day_of_week) are taken from transaction_dttm. Field descriptions come from the business metadata list (C42).
- **Status now:** in force. Which clock transaction_dttm records (UTC or local) is still a data-owner question (C49). Evidence gap in COM-004: "Exact metadata files still need to be retained."
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:99-112`; `fraud/configs/predictors.csv:21-24`; `explainer/CHANGE_JOURNAL.md:170`

### C10. 18 to 19 Aug 2026: raw-data thread on TFM history length and production memory

- **Date:** 18 Aug 2026 21:42 and 19 Aug 2026 21:35
- **People:** Sumegha (Developer), Xiaoming
- **Channel:** email thread "TFM Debit Card raw data copy" (COM-005, COM-006)
- **Kind of text:** summary (COM-005, COM-006, and facts D5 and D6 in the 14 Oct update readme). The original thread text is not in either repository.
- **What was said:**
  - COM-005: the best-performing v22b version "used the last 17 transactions, had no maximum time-based lookback, was limited by fixed sequence length, and could pad sequences shorter than max sequence length 2048."
  - COM-006: operational use "would require retaining the last 17 transaction token IDs per account regardless of a time-period lookback, and that reducing the number of retained transactions would improve operational efficiency more directly."
  - D6: "Xiaoming suggested a maximum lookback (e.g. 18 months); Sumegha said the count limit is what matters."
- **What it changed:** tabular fraud keeps history 20 as close to the TFM's 17, with the rule "if history 0 vs 20 shows a shorter history is nearly as good, prefer it". A production version needs a row cap (the final model caps windows at 32 rows). The TFM history policy is listed as the history-store requirement for production. Architecture B borrows the TFM's 17-transaction window as a target. In the TFM validation, "Last-17 vs current window=None" became an open item.
- **Status now:** applied in design. TFM side: "Needs reconciliation" (open); window-size experiment not run.
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:114-142,324`; `updates week_10-14-2026/updates 10-14-2026/readme.md:564-570,582-584`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:76`; `guide/GUIDE.md:958-961`

### C11. 21 Aug 2026: Xinyu's ICL update with meta features and account history

- **Date:** 21 Aug 2026
- **People:** Xinyu
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Only consider 10 meta features by converting transactions to sentences." "Incorporate historical information to the sentence by summarizing previous 5-10 consecutive transactions from the same account." 20 few-shot examples in four groups of 5 (fraud or not in history, fraud or not for current). Downsampled OOT: "KS: 0.3649, AUC: 0.7272, DR@11% (fraud rate): 0.3364, VDR@11% (fraud rate): 0.4293". Next plan: more examples up to the token limit; more meta features.
- **What it changed:** led to the 27 Aug test (C14).
- **Status now:** superseded; ICL paused 31 Aug
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:14`

### C12. 24 Aug 2026: Waqas's ICL fraud-scoring framework (Confluence update)

- **Date:** 24 Aug 2026
- **People:** Waqas, to the team
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Four prompt variants: P0, P1, P2, and P3"; feature families "F0: 94 engineered features" and "F1: five available natural transaction features"; demonstration selection "D0: deterministic pseudo-random retrieval", "D1: cosine-similarity retrieval", "D2: Euclidean-distance retrieval"; policies Low (1 fraud, 1 non-fraud) and High (10 and 10); representations "R0: natural-language transaction write-out" and "R2: deterministic JSON transaction representation"; "over 96 different possible configurations". Best: "P3 and the engineered feature set: ROC AUC 0.8867, KS 0.6394, and PR-AUC 0.5804". Next plan: "Use TFM data for future experiments." "Preserve the current prompt and experiment framework for the next phase." "Explore different methods to vectorize tabular data." "Include 10x more examples." "Include account history." "Run experimental grid." "Research on updated list of Tabular Foundation Models."
- **What it changed:** the framework was kept, but the ICL line was paused on 31 Aug. Tabular foundation models appear later only as literature or challenger ideas. The "94 engineered features" likely match the 94 features of model 15298, but this is not confirmed.
- **Status now:** paused
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:15`

### C13. 24 Aug 2026: Teams chat handing over the shared GPU pod

- **Date:** 24 Aug 2026, 08:56 to 09:14
- **People:** Developer (MMR), Waqas
- **Channel:** Teams chat (COM-007)
- **Kind of text:** summary (COM-007)
- **What was said:** "Developer authorized use of LEW-extrasmall-6, asked that the usage list be updated, described the pod as a shared computer, instructed use of a personal subfolder, warned against overwriting others' work, and required usage-note updates."
- **What it changed:** all work kept in Waqas's own k194855 folders; other users' processes and files are never touched. TFM validation outputs sit under `/home/jovyan/k194855/TFM/Validation/V22B/Reproduction`.
- **Status now:** in force
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:18-21,144-157`

### C14. 27 Aug 2026: Xinyu's ICL update (100 and 200 examples, VAA) and the TFM review assignment

- **Date:** 27 Aug 2026
- **People:** Xinyu, updating Xiaoming, Yaqun and Hanyu; Waqas assigned
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "In prompt, use 100 or 200 examples from training dataset." "Consider more meta features as well as VAA score." On 6,102 transactions: 100 examples "5668 valid outputs, KS: 0.5831, AUC: 0.8524, DR@11% (fraud rate): 0.4325"; 200 examples "5093 valid outputs, KS: 0.5983, AUC: 0.8561, DR@11% (fraud rate): 0.4306". "The current model gemini-2.5-pro may not be well configurable with long prompt." "100 can be a bottleneck." VAA alone: "KS: 0.6952, AUC: 0.8946, DR@11%: 0.6815. The result is reasonable given VAA was trained on much more data size." Next: batch mode; "Xinyu and Waqas will review the in-house fine-tuned TFM, with special attention to feature leakage issues."
- **What it changed:** added Waqas's TFM validation work and its focus on leakage (C16, C25). The VAA vendor score is also what separates the LoB XGBoost benchmark from the TFM in the deck (C01).
- **Status now:** done; led to the 31 Aug review scope
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:16`; `MRM_1/Transaction_Foundation_Model_Exact_Match_v4(1).pptx` slide 31

### C15. 27 Aug 2026: Yaqun's update on SAINT and pytorch-tabular

- **Date:** 27 Aug 2026
- **People:** Yaqun
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Migrated the SAINT code to run on OCP using CPU. Successfully ran the model training for 1 epoch on its example bank data (Only 1 epoch because it is slow with CPU)." "Found a package pytorch-tabular which is well-maintained and implements several deep NN models for tabular data including FT-Transformer. Confirmed it can be installed on OCP." Next plan: "Explore more one these models using MMR's model 15298 data when GPU is available."
- **What it changed:** this is the start of the tabular fraud project, which is "Forked from pytorch_tabular v1.1.0" with an FT-Transformer. First mention of 15298, the bank's debit-card XGBoost model (model document 15298).
- **Status now:** done; became the tabular fraud repo
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:17`; `README.md:3,9`

### C16. 31 Aug 2026: batch-mode ICL; focus moves to the TFM, with a review scope

- **Date:** 31 Aug 2026
- **People:** Xinyu, Waqas
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:**
  - Batch mode: "Out of 6102 transactions, there are 4400 transactions with valid output score, worse than individual prediction"; "if there exists invalid output, then all transactions in this prompt do not have valid output score"; "overall performance is similar".
  - "Xinyu and Waqas will focus more on transaction foundation model": "Review the codes and architecture of the in-house transaction foundation model."
  - Fine-tuning: "Review the fine-tuning approach (full tuning, LORA) and replicate the results."
  - Data: "If there is any transaction-level downsampling applied, analyze its impact on score and embedding results."
  - Features: "Examine potential data leakage issues." "Investigate in detail how the model adapts to new features not in pretraining, like how the token is created."
  - Config: "Review the hyper-parameters, random seed settings." "Check if there is special technique adopted for neural network, analyze its impact on model score and embedding results. Quantify it by how much uncertainty it introduced to model output."
  - Architecture: "Review the NN architecture for potential data leakage issues."
  - Explainability: "Explore possible ways to explain the contribution of each feature on the score or embedding results."
- **What it changed:** ICL stopped. This list became the TFM validation scope: replication (done: model rerun and an independent fine-tune, C33), downsampling (v22b train rate resolved as about 12% fraud), leakage (ablations and architecture review planned), seeds and hyperparameters, uncertainty (rerun found 84.2891% exact matches), explainability.
- **Status now:** partly done. Replication and rerun complete; ablations, chronology checks and explainability open.
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:18`; `MRM_1/my_notebooks/FineTune_Rerun/TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md:529-537`

### C17. 31 Aug 2026: email on omitted files 5001-7999 and account partitioning

- **Date:** 31 Aug 2026, 15:46 to 15:51
- **People:** internal reviewer (not named), Developer (Sumegha)
- **Channel:** email "TFM Debit Card raw data copy" (COM-008)
- **Kind of text:** summary (COM-008 and fact D7 in the 14 Oct update readme). The original text is not in either repository.
- **What was said:** "Internal reviewer asked whether files 5001-7999 were omitted and whether an account appears in only one Parquet. Developer answered 'Yes' to both and added that TFM often converges earlier and does not require the full training data." D7: the TFM "often converges much earlier and does not require the full training data."
- **What it changed:** TFM replication follows the 5,000-file training scope. Tabular fraud relies on the same property ("Every file holds whole accounts"); its pre-flight counts accounts found in more than one file. D7 is why the plan stays at 10 then 100 files and adds more only if 100 clearly beats 10.
- **Status now:** in force; an artifact-level check is still advised. The 100-file run has not been done.
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:159-172`; `updates week_10-14-2026/updates 10-14-2026/readme.md:566-570,582-584`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:88`

### C18. 31 Aug 2026: Teams chat on file scope, repository and implementation files

- **Date:** 31 Aug 2026, 15:47 to 16:53
- **People:** internal participant (not named), relaying the Developer
- **Channel:** Teams chat (COM-009)
- **Kind of text:** summary (COM-009)
- **What was said:** "Internal participant reported Developer confirmation that Parquets 5001-7999 were not used and recommended following that scope. Discussion identified the develop-branch repository plus a separate Implementation_Files_TFM folder containing checkpoints, PKL files, epoch data, and possibly version-misaligned code." Repository: k102157/txn-foundation-model, develop branch.
- **What it changed:** GitHub source, shared implementation files and controlled outputs kept separate; provenance checked before copied files are used as proof.
- **Status now:** in force. "Exact version mapping of Implementation_Files_TFM remains uncertain."
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:174-187`

### C19. 1 Sep 2026: Teams chat: no training notebook

- **Date:** 1 Sep 2026, 09:30
- **People:** internal participant relaying the Developer
- **Channel:** Teams chat (COM-010)
- **Kind of text:** summary (COM-010). "Direct Developer message not recovered."
- **What was said:** "Developer said there was no training notebook; training and evaluation were run directly as scripts, with README files and specific documentation guiding which scripts matter and how to run them."
- **What it changed:** distributed_finetune.py, fraud_eval.py, configs and READMEs treated as the implementation path. The rerun and fine-tune used these scripts.
- **Status now:** done
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:189-202`

### C20. 2 to 3 Sep 2026: Teams channel on shared-storage cleanup

- **Date:** 2 Sep 2026 11:23 to 3 Sep 2026 12:11
- **People:** Developer and the PFM Training group
- **Channel:** Teams channel (COM-011)
- **Kind of text:** summary (COM-011). The rest of the discussion is not in the package.
- **What was said:** "Developer relayed a request to reduce MAN41 PVC usage, recommended moving large checkpoints to S3, and the group discussed deleting or moving old checkpoints and data folders."
- **What it changed:** storage housekeeping only; no recorded effect on the work.
- **Status now:** outcome not recorded
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:204-213`

### C21. 3 Sep 2026: Yaqun's benchmark, FT-Transformer chosen, first 23 predictors (from Sumegha)

- **Date:** 3 Sep 2026
- **People:** Yaqun; predictor list from Sumegha
- **Channel:** Confluence weekly update
- **Kind of text:** original text. The next-plan items of this entry are not in the export.
- **What was said:** GPU environments set up for "SAINT and Pytorch-Tabluar packages" (source spelling). 10-epoch results on SAINT's public bank data: SAINT (intersample) AUROC 0.822, loss 0.491, 66.9K params, 33 it/s; SAINT_S 0.851, 0.468, 40.8K, 55; CategoryEmbedding (MLP) 0.921, 0.212, 15.5K, 112; FT-Transformer 0.935, 0.199, 138K, 68. "FT-Transformer has the best performance. The intersample attention of SAINT doesn't help much but makes the model slow." "Pytorch-Tabular's code is better structured and implemented." "We may want to focus more on FT-Transformer model and fork the Pytorch-Tabular code for our internal fraud model development." "Identified an initial predictor list for our internal data (from Sumegha) with 19 transaction-level raw variables that are either continuous or low-cardinality categorical variables. Also, derived four variables from transaction time: month, day, hour, and day-of-week. So totally there are 23 predictors." "Numerical: median-impute + _isna flags; Categorical: adding two categories, 'UNKNOWN/UNSEEN' and 'MISSING'."
- **What it changed:** set the starting point of tabular fraud: FT-Transformer on a pytorch_tabular fork. `fraud/configs/predictors.csv` holds exactly these 23 inputs. `fraud/data/preprocessing.py` does median imputation with `<col>_isna` flags and reserved UNK/OOV (index 0) and MISSING (index 1) categories.
- **Status now:** in use. The 23 are still "Today's inputs" in the 26 Oct presentation (C53).
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:19`; `fraud/configs/predictors.csv:1-24`; `fraud/data/preprocessing.py:6,14,35,76`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:119`

### C22. 3 Sep 2026: Xinyu's TFM workflow summary document

- **Date:** 3 Sep 2026
- **People:** Xinyu
- **Channel:** Confluence weekly update
- **Kind of text:** original text
- **What was said:** "Xinyu summarized TFM workflow, see the document." "The document is on the share folder and can be continuously modified."
- **What it changed:** probably the Fraud_Finetuning_Workflow_Summary.docx resent to Waqas on 9 Sep (C27); the sources do not say they are the same file. Treated as secondary evidence.
- **Status now:** available to Waqas from 9 Sep
- **Sources:** `MRM_1/confluence/Foundation Model for Fraud:20`

### C23. Undated: Yaqun's written project plan, benchmark report and open questions

- **Date:** undated. The sources place it before 3 Sep 2026; it reports the same benchmark as C21.
- **People:** Yaqun (author), to the team
- **Channel:** plan and benchmark documents in `docs/`
- **Kind of text:** original text
- **What was said:** "FT-Transformer outperformed all others with better accuracy, faster training, no overfitting, and minimal configuration." "We are adopting PyTorch Tabular with FT-Transformer as the foundation for our fraud detection work." "Use PyTorch Tabular with FT-Transformer for production." Caveat: "No hyperparameter tuning was performed... Results are directional." The sequential model "requires modifications to core components that cannot be achieved through configuration or subclassing", so the library was forked. Open questions: (1) "Max history length: How many past transactions to include? (5? 10? 20?)"; (2) same or reduced feature set for history rows; (3) how to represent time gaps; (4) "Data partitioning: How are parquet files organized in S3? (By date? By account? Random?)"; (5) "Inference latency: For real-time fraud detection, how fast does the sequential model need to be?"
- **What it changed:** set the whole project on the FT-Transformer (src/pytorch_tabular fork, v1.1.0). Later the history models were written outside the fork, and ft_transformer_seq stayed an empty placeholder. Questions answered: (1) N = 5 first, then 0 to 20 in V1; (2) same 23 features per transaction; (3) time-delta feature plus position embedding; (4) each account sits in one file (C08, C17).
- **Status now:** foundation in force. Question 5 (latency) open: no latency test; serving out of scope.
- **Sources:** `docs/fraud_detection_plan_overall.md:3-14,30-43,145-151`; `docs/tabular_transformer_models.md:95-116`

### C24. 4 Sep 2026: email "Model Replication Data"

- **Date:** 4 Sep 2026, 11:08 to 11:11
- **People:** Developer (Sumegha); internal participant (not named) who added Waqas
- **Channel:** email "Model Replication Data" (COM-012)
- **Kind of text:** summary (COM-012)
- **What was said:** "Developer stated that datasets and pretrained-model paths would be shared. Internal participant added Waqas to the thread because he was working on the foundation model."
- **What it changed:** "Formally connects Waqas to the replication handoff."
- **Status now:** done
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:215-228`

### C25. 8 Sep 2026: email "RE: Model Replication Data": v30 and v22b, with the v22b leakage warning

- **Date:** 8 Sep 2026, 09:36
- **People:** Developer (Sumegha / MMR)
- **Channel:** email "RE: Model Replication Data" (COM-013)
- **Kind of text:** summary (COM-013; also item R10 in the 14 Oct update readme). The original email text is not in either repository.
- **What was said:** "Developer supplied v30 and v22b S3 package roots. Developer described v30 as newer, production-oriented CSCA data with LoB engineered features and features unavailable in production removed. Developer described v22b as older BMG data containing fraud proxies including status date, which should not be used in current form because of potential leakage from card inactive date." Paths: `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v30/` and `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/`. R10: "v22b is legacy BMG and contains non-production fraud proxies, specifically status/card-inactive date, which MMR says has potential leakage and should not be used in its current form."
- **What it changed:** TFM: v22b run as a separate controlled run, with the leakage warning kept as an open model-risk issue. Tabular fraud: the feature plan leaves out 7 status fields (INACTV_DT, account status-change date, two online-banking login-block dates, three status codes) because "The TFM developer flagged V22B's status date as a fraud proxy". This cut the TFM V22B fields added to the model from 95 to 90 in the 26 Oct presentation. Waqas's later belief (21 Oct, C51) that the payment foundation model "removed ... features that aren't available at time of transaction" matches this description of v30, not v22b.
- **Status now:** v22b status-date leakage: open model-risk issue. Status-field exclusion adopted in the feature plan (not trained yet). v30 not started.
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:230-243,325`; `updates week_10-14-2026/updates 10-14-2026/readme.md:595-696`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:145-146`; `bridge/OWNER_QA.md:415,423`

### C26. 8 Sep 2026: Teams chat: start replication, v22b first

- **Date:** 8 Sep 2026, 09:41 to 09:48
- **People:** internal participant (not named), Waqas
- **Channel:** Teams chat (COM-014)
- **Kind of text:** summary (COM-014)
- **What was said:** "Internal participant asked Waqas to start replication from the Developer-supplied paths. Waqas stated that v30 and v22b would remain separate workstreams; internal participant requested v22b first."
- **What it changed:** "Active workstream is v22b only. Do not mix v30 artifacts or conclusions." All later TFM work is v22b.
- **Status now:** v22b done through the model rerun and an independent fine-tune; v30 not started
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:245-258`

### C27. 9 Sep 2026: Teams chat: workflow summary access

- **Date:** 9 Sep 2026, 11:08 to 11:11
- **People:** Waqas, internal participant (not named)
- **Channel:** Teams chat (COM-015)
- **Kind of text:** summary (COM-015)
- **What was said:** "Waqas reported access denied to Fraud_Finetuning_Workflow_Summary.docx from Confluence and Teams links. Internal participant resent the file directly; Waqas confirmed access worked."
- **What it changed:** workflow summary available; "it remains secondary evidence unless linked to primary code or Developer communication."
- **Status now:** done
- **Sources:** `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:260-273`

### C28. 4 to 22 Sep 2026: rest of the "Model Replication Data" thread and the replication Teams threads

- **Date:** email 4 to 22 Sep 2026; Teams replication thread 21 Sep 2026; Xiaoming and Waqas Teams thread (date not given). Supplied for analysis on 15 Oct.
- **People:** Sumegha and Xinyu (email); Sumegha, Xinyu and Waqas (Teams replication thread); Xiaoming and Waqas (Teams thread correcting the account structure); Shubham named; MMR; LoB
- **Channel:** email thread plus two Teams threads
- **Kind of text:** summary (items R1 to R10 in the 14 Oct update readme). The original thread text is not in either repository.
- **What was said:**
  - R1: the benchmark file is `s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/eval/cross-file-8000-8200-seed-42_1.parquet`.
  - R2: 952,905 unique targets from 317,672 accounts (104,028 with one target, 213,644 with several, max 60). The early statement that the OOT data had one target per account was wrong; Waqas checked the file.
  - R3: accounts unseen in TFM training; about 1M targets "sampled completely at random", then pre-Falcon declines and other LoB-excluded segments removed to about 950K; from v30, filtering happens before sampling.
  - R4: fraud fine-tune of 10,000 steps on 10,243,344 target rows, zero ID overlap with OOT.
  - R5: three duplicated non-fraud IDs (sampler padding).
  - R6: supplied AUC 0.9685, KS 0.8214, AP 0.2737; Waqas's rerun very close.
  - R7: Waqas's two reruns identical; supplied and rerun logits differ; Sumegha's own one-GPU rerun differed from both.
  - R8: tokenizer config lacked mask_token and fill_missing; Sumegha said this is probably not the cause of the score differences.
  - R9: different repository versions; "Sumegha recommended repeating exact replication against Shubham's cleaned shared repository".
- **What it changed:** account-clustered bootstrap made the rule for intervals; benchmark loading removes the three padding rows; full inference-stack versioning; "do not call v22b superiority an architecture result"; ask for v30 artifacts. Test 2 in tabular fraud became exactly these 952,905 transactions (TFM V22B AP 0.2737, AUROC 0.9685). A prioritised P0/P1 question list for MMR and LoB was written (filter predicates, proxy columns, clean-repo rerun, label definition, DR/VDR/FPR definitions, v30 package).
- **Status now:** lessons adopted. Clean-repo rerun on Shubham's repository: not done. MMR/LoB question list: no answer recorded. Test 2 comparison not yet run (planned after the feature and 100-file stages).
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:595-696`; `updates_week_10-14-2026/Updates 10-15-2026/complete_reviewer_context.md:18,222-249`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:96,101`

### C29. Before 21 Sep 2026: Sumegha hands over the v22b model package

- **Date:** before 21 Sep 2026 (exact date not stated)
- **People:** Sumegha (Developer) to Waqas
- **Channel:** artifact handoff
- **Kind of text:** summary (as described in Waqas's rerun report)
- **What was said:** "Sumegha provided the Developer-delivered repository snapshot, final checkpoint, tokenizer package, evaluation Parquet, and supplied scoring outputs used in this validation." Evaluation file cross-file-8000-8200-seed-42_1.parquet (952,905 rows); supplied eval_logits.npz (952,908 rows) and eval_metrics.json; checkpoint files model.bin, config.json, finetune_config.json, tokenizer/config.json, tokenizer/vocab.json (5,378 entries).
- **What it changed:** enabled the model rerun and the three-way comparison (C33). The same 952,905 transactions became Test 2 in tabular fraud.
- **Status now:** done
- **Sources:** `MRM_1/my_notebooks/FineTune_Rerun/TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md:44-73,89-93`

### C30. About 20 Sep 2026: the team's view on the rerun not matching exactly

- **Date:** about 20 Sep 2026
- **People:** the team (not named), relayed by Waqas
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas. The team's own message is not in the repositories.
- **What was said:** Waqas's first reported result: "~84.7% of probabilities identical, ~15% differing, mean difference about 0.0, max difference about 0.007." Waqas's view: "a little difference is expected." The team's position: "it should be exactly the same."
- **What it changed:** the rerun was checked for exact matches and the cause of differences. The final report (C33) gives 803,195 exact matches (84.2891%), mean absolute difference 0.00013460, maximum 0.01409278, and says the differences come from the model forward output, not the sigmoid. The earlier 84.7% and 0.007 figures are superseded. Determinism controls and recording precision and hardware with every metric were recommended.
- **Status now:** finding documented in the rerun report
- **Sources:** `MRM_1/claude/REPRODUCIBILITY_NOTE_claude.md:1-16`; `MRM_1/my_notebooks/FineTune_Rerun/TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md:15-17,389-396`

### C31. About 20 Sep 2026: TFM validation timeline to January

- **Date:** about 20 Sep 2026
- **People:** Waqas, relaying the work timeline
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas (as recorded in a planning note)
- **What was said:** "Timeline is to January, roughly 15 weeks, about 13 effective after holidays. The mid-performance review at week 4 is a checkpoint, not the deadline." About 15 weeks from 21 September.
- **What it changed:** the TFM validation work was laid out in four phases to January, with a 30-day plan and one memo per Monday (plan only).
- **Status now:** plan only; whether it was followed is not recorded. From early October Waqas's main work is the tabular fraud model.
- **Sources:** `MRM_1/claude/WORK_INVENTORY_claude.md:6-8`; `MRM_1/claude/PLAN_30_DAY_claude.md:13-28`

### C32. About 20 Sep 2026: draft email to the developer, "TFM v22b replication: a few questions"

- **Date:** about 20 Sep 2026
- **People:** Waqas to the Developer (Sumegha)
- **Channel:** draft email
- **Kind of text:** original text of a draft. No record that it was sent.
- **What was said:** five questions: (1) the exact run configuration (pool_strategy, window_size, gradient_accumulation_steps, number of GPUs, use_hybrid_attention); (2) a single-GPU reference run; (3) whether re-scoring gives bitwise identical scores; (4) read access to the source repo; (5) the original values of the tokenizer keys mask_token, fill_missing, add_mask_token. Related questions on the deck: which version it describes; why its validation month (Apr 2024) comes before its training period (Jul to Dec 2024); which checkpoint was selected and how; whether VAA was left out of the TFM but used in XGBoost; whether FSDP is used; downsample 1 or 100.
- **What it changed:** some were answered later from evidence: pool_strategy "last"; downsample about 85 to 100 (train about 12% fraud); the deck is v17 (relayed by Waqas).
- **Status now:** drafted; sending not recorded. The rerun report still lists the historical runtime configuration and the tokenizer adjustment as items to review with Sumegha (C33).
- **Sources:** `MRM_1/claude/PRE_2PM_BLOCK_claude.md:36-75`; `MRM_1/claude/DECK_INTAKE_claude.md:321-336`

### C33. 21 Sep 2026: Waqas's report "TFM v22b Model-Object Rerun and Fine-Tuning Comparison"

- **Date:** 21 Sep 2026 (commit date of the report)
- **People:** Waqas (author); Sumegha named for follow-up
- **Channel:** validation report (Word document, also in Markdown)
- **Kind of text:** original text
- **What was said:** supplied vs model rerun vs fine-tuned model on 952,905 unique transactions (1,418 fraud, 951,487 non-fraud): ROC AUC 0.9684955047 / 0.96849262 / 0.96619768; KS 0.8214189678 / 0.82124737 / 0.80633894; average precision 0.2736735573 / 0.27361014 / 0.24806854; PR-AUC 0.2768044244 / 0.27672673 / 0.25114480; log loss 0.2770421477 / 0.27704246 / 0.14536295. Exact matches 803,195 (84.2891%). Three duplicate non-fraud rows in the supplied output. Next steps:
  1. "Repeat the Model Rerun after the LEW41 change window ends on September 20, 2026."
  2. "Review the completed findings with Sumegha next week, including the historical runtime configuration, tokenizer adjustment, duplicate supplied rows, and remaining same-checkpoint score differences."
  3. "Update the final validation conclusion."
  4. "Benchmark TFM against established fraud-model baselines using consistent populations."
  5. "Test whether frozen TFM embeddings improve an established fraud-model baseline."
  6. "Quantify key fine-tuning choices through controlled ablations, including history length, pooling, downsampling, and auxiliary signals."
  7. "Validate prediction-time availability and leakage controls."
- **What it changed:** closed the v22b replication (the fine-tune is an independent model that does not match the delivered one). Its population and TFM AP 0.2737 / AUROC 0.9685 became Test 2 in tabular fraud. Steps 4 and 5 match the tabular fraud Test 2 head-to-head and the TFM-embedding correlation check (C55).
- **Status now:** report done. Repeat rerun, review with Sumegha and steps 3 to 7: not recorded as done.
- **Sources:** `MRM_1/my_notebooks/FineTune_Rerun/TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md:5-37,374-396,418-428,513-537`

### C34. 25 Sep 2026: Phase 4 design discussion (decisions 1 to 11)

- **Date:** 25 Sep 2026
- **People:** Yaqun (participants not named in the record)
- **Channel:** design discussion, recorded as "Record of the design discussion" (decisions log)
- **Kind of text:** original text
- **What was said:** context: the single-transaction FT-Transformer "is at its signal ceiling" and "feature-limited". Decisions: flat SEP-token architecture, "Simplest path to parity"; historical frd_tag "Excluded in v1" because "Prior-transaction fraud labels may not be available at inference time"; N = 5, stride 1, "Never skip a fraud transaction as a target"; time-delta features ("Velocity/recency is strong fraud signal"); left-pad short histories ("can't discard them (fraud is rare)"); configurable capacity, start moderate and "re-run a capacity sweep"; attention configurable, default bidirectional; transaction-level position embedding only. Follow-up notes (9 to 11): "stride=1 windows overlap by construction"; use "a window-level shuffle buffer spanning many accounts"; "eval_stride = 1 always (score every transaction, mirrors production)"; "Default precision: bf16-mixed, start batch ~4096, watch nvidia-smi; use accumulate_grad_batches".
- **What it changed:** defined Yaqun's sequence_builder.py and sequential_model.py, which Waqas reused and V1 runs. No past labels anywhere. The causal option of decision 7 was found leaking through CLS (5 Oct) and fixed in Waqas's copies (6 Oct); V1 tests it. A 65,536-window shuffle buffer and eval_stride 1 are used in every run. Batch 4096 ran out of GPU memory at history 10 and 16, so smaller batch pieces with gradient accumulation adding to 4096 are used.
- **Status now:** decisions in force. The capacity sweep of decision 6 has not been run.
- **Sources:** `docs/phase4_design_decisions.md:1-33`; `docs/phase4_sequential_plan.md:215-234`

### C35. 28 Sep 2026: Yaqun's Phase 4 plan: first history result and open items A to G

- **Date:** results 28 Sep 2026; section 10 written after the result
- **People:** Yaqun (author)
- **Channel:** Phase 4 plan document (Yaqun's handoff guide; older files call it "Yakun's guide")
- **Kind of text:** original text
- **What was said:**
  - Section 5: Architecture B, the hierarchical per-transaction model (future).
  - Section 9 verification: a small smoke test, parity against the single-transaction reference, three ablations (history 0 against 5, time delta on and off, bidirectional against causal attention), a leakage check, and the rule "time < target_time" (history strictly earlier). Section 9.1 warns of GPU out-of-memory at history 15 and 20.
  - Preliminary results: history 5 on 10 files, best valid_ap 0.1293 (epoch 5), AUROC 0.9509. "The N=5 lift over the single-transaction baseline is real but modest, so the theme is: give the model more signal (data, history, features) and enough capacity to use it, then re-tune."
  - Section 10 open items: A more training data (100 files); B longer history ("the main sequence lever"); C enlarge the network; D more features, including high-cardinality ones; E pos_weight; F architecture, including two-level models and "predict every transaction at once"; G hyperparameter sweep and feature importance.
- **What it changed:** V1 was defined as the section 9 checks plus longer histories (10, 15, 20) plus Architecture B. All-position B (item F) was added to V1. V2's centrepiece is item A (100+ files). "Finishing the project" means items A to G. Yaqun's guide put broad tuning after the larger-data stage.
- **Status now:** V1 (15 runs) completed 13 to 14 Oct; final model Arch B H20 chunk. Not done: A (100 files), C (bigger network), D (features: planned, C53), E (pos_weight stays 1.0), G (sweep, feature importance). Whether chunked all-position B counts as item F (OQ-16) was superseded on 19 October and is no longer open [bridge/OWNER_QA.md:73].
- **Sources:** `docs/phase4_sequential_plan.md:124-153,205-296`; `bridge/OWNER_QA.md:1306-1309,1550-1563,1584-1594`

### C36. 5 Oct 2026: team discussion on preprocessing, encoding, feature priorities and tools

- **Date:** 5 Oct 2026
- **People:** Waqas and colleagues (attendees not listed); ideas attributed to Xiaoming ("Xiaming" in the notes) and to front-line (the LoB XGBoost / 15298 team)
- **Channel:** discussion; running notes, sections 1 to 6
- **Kind of text:** original text (Waqas's running notes)
- **What was said:**
  1. Fit preprocessing artifacts on more than 5 parquet files. This "produces a new artifact version", and everything trained so far "would need to be retrained".
  2. High-cardinality fields (merchant_category_xcd, merchant_postal_xcd, merchant_state_xcd, atm_network_xid) are excluded. "Front-line has already done work here" with frequency and target encoding. "For neural networks specifically, target encoding is said to be the better choice." "Staged rollout plan (per Xiaming): ... pilot it first on a small range (5-10 parquet files) ... then refine/re-fit using all historical files."
  3. Use "front-line's existing feature-importance ranking (reference: 15298 MDD)", with the caveat that their ranking uses engineered features and the foundation model's importances may be post-encoding dimensions.
  4. Spark is not used. "Karpathy autoresearch", "reportedly used by Xiaming for some autoresearch", proposed for generating feature-engineering candidates.
  5. Already tracked: more features, more data past 100 files, larger network, extracting CLS token embeddings.
- **What it changed:**
  - Added a safe-rebuild rule: a refit is a new artifact version and a reset point; a rebuild writes version 2 and never overwrites version 1, which every A and B run reads.
  - Target and frequency encoding: never implemented. Later made a conditional study needing chronological out-of-fold construction. The 26 Oct plan feeds codes raw ("Codes go in raw") and adds MCC, merchant postal, merchant state and ATM network as ordinary categorical inputs.
  - The 15298 ranked list arrived later (94 features); 60 are proposed.
  - The CLS-embedding idea became exporting each row's head input (out[:,1:]), not the CLS token.
  - Autoresearch (Karpathy's project): kept as a future idea.
- **Status now:** refit rule in force. Encoding ideas not implemented. Feature expansion planned, not run. Autoresearch deferred.
- **Sources:** `waqas/docs/meeting_notes.md:1-100`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:106,144,173,178,188,197`; `waqas/feature_work/README.md:10-15`; `bridge/DECISIONS.md:91`

### C37. 6 Oct 2026: meeting with Xiaoming and Yaqun on features and longer histories

- **Date:** 6 Oct 2026
- **People:** Waqas, Xiaoming, Yaqun
- **Channel:** meeting; notes section 7 "Meeting with Xiaoming and Yaqun"
- **Kind of text:** original text (Waqas's raw notes, "as given, lightly grouped"). Some fragments are marked unclear in the notes themselves. Waqas's later clarification (7 Oct) is relayed by Waqas.
- **What was said:**
  - "We want more features; longer transaction histories. Yaqun has this on his document already."
  - Look at "feature importance v22_v17; debit card 15298, top 10 features; CHP models; derived transaction-level (and categorical) variables, front-line did frequency-based encoding on these. Reference: Table 2.35, 'summary of the top 10 features,' page 93."
  - Xiaoming's warnings: target encoding, "can't have too many of them, because they end up highly correlated with each other"; "It might be 94; the XGBoost LOB" (unclear); "Need a chip-card feature: count how many authorizations have been done for this specific chip-enabled card"; "Useful one is we need to coarse through" (unclear); a counter that "shows 1000 today but was 2000 yesterday" flagged as an issue; "Cards can be fake/spoofed"; use "yesterday's feature value (a lagged aggregate)"; "The content itself does not contain signal" (unclear).
  - Approach: "Start from the raw features MMR already provided" and learn what each raw field represents before engineering.
  - Also noted: no "days since first transaction" feature exists; delta features on raw continuous fields proposed; a rolling 90-day lookback window proposed.
  - Later clarification (relayed by Waqas, 7 Oct): "version 22 is like the latest version they have. They also have a previous version called version 17"; "V17 don't worry about it. It's all the same features V22 just expanded"; "CHP is card holder present, I believe, or chip"; 15298 is "a debit card, like XG boost model that we currently have at the company"; "table 2.35, page 93 was just like a list of like engineered features"; "V2 is going to be the feature expansion". On 12 Oct he added that Yaqun wanted more features.
- **What it changed:**
  - Longer histories: V1 ran history 0 to 20; the winner uses H20.
  - More features: the V2 feature expansion (166 proposed: 90 TFM V22B, 60 from 15298, 16 built). V22B only; V17 ignored; all 120 V22B importance rows reviewed.
  - Raw-features-first adopted: map every field to the 224 columns before engineering.
  - No target encoding adopted.
  - Chip-card count: catalogued as E20 (needs a stable card key, a chip rule and reset rules). Not built.
  - Counter drop, yesterday's value, delta features: deferred (reset clocks and as-of rules unresolved).
  - Spoofed cards: account ID is not treated as card ID.
  - Days-since: 11 of 15298's days-since features are in the 26 Oct proposal.
  - Rolling window: not built. Count features over 5 minutes, 1 hour, 24 hours, 7 days and 30 days are proposed instead; 90 days needs more history than the extract has.
  - Unconfirmed links: "It might be 94" may mean 15298's 94 features; 15298's atc_card_cnt (rank 15, in the proposed 60) may relate to the chip-card counter.
- **Status now:** features proposed, not built or trained. Follow-up questions 1 to 8 in the notes are mostly unanswered, except v22_v17, CHP, 15298 and Table 2.35.
- **Sources:** `waqas/docs/meeting_notes.md:104-202`; `bridge/OWNER_QA.md:1954-1967,2514`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:9,105,117-123,134,140`; `bridge/plans/CH/2026-10-12-v22-feature-proposal/ENGINEERING.md:11,41,60,76`

### C38. 6 Oct 2026: meeting with executive-director and senior quants

- **Date:** 6 Oct 2026, about 2:00 pm Eastern
- **People:** Waqas; executive-director quants and senior quants ("PhD level")
- **Channel:** meeting
- **Kind of text:** relayed by Waqas (Waqas said on 5 Oct that this meeting was happening). No notes of the meeting exist.
- **What was said:** Waqas had a meeting "at about 2:00 pm Eastern with executive-director quants and senior quants, PhD level" and had to "be able to explain every single thing in the project and answer their questions". What was said in the meeting is not recorded.
- **What it changed:** the learning guide (`guide/`) and project guides were written to prepare. No decision from the meeting is recorded. It may be the same day and occasion as C37; the sources do not confirm this.
- **Status now:** scheduled; whether it took place and its outcome are not recorded
- **Sources:** `bridge/threads/001-guide.md:3-12`; `guide/README.md:3-11`

### C39. 7 to 8 Oct 2026: Yaqun's availability and the Monday review

- **Date:** 7 Oct and 8 Oct 2026; review on Monday 12 Oct 2026
- **People:** Waqas, about Yaqun; an unnamed reviewer for the Monday review
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas
- **What was said:** 7 Oct: "my next review is on Monday. But he leaves on Friday, so I want to have a lot of work done by Friday. If not all." 8 Oct: "hes out of office for a while but we need to finish". About anything else from Yaqun: "no, Yakun didn't say anything else. Everything else is in the thing, in the notes."
- **What it changed:** work targeted for Friday 9 Oct and the Monday 12 Oct review. Questions for Yaqun were held or redirected: the avlble_merch_day_cash_lmt_amt field (described as "Available daily merchandise limit", but values run from 42,590,700 to 58,561,130 while the remaining daily merchandise limit tops out at 25,500; it is one of the 23 inputs) stays a recorded data note; external_1_scr timing and the equal-timestamp rule went to the data-owner list (C49). Work continues without him.
- **Status now:** who held the Monday review and what happened at it are not recorded. The field question is unresolved.
- **Sources:** `bridge/OWNER_QA.md:1844-1847,1869-1870,1896-1899,1974-1975`; `explainer/08_DECISIONS_LOG.md:71-72`

### C40. 12 Oct 2026: Xiaoming's email "Best Practice in Feature Engineering"

- **Date:** Mon 12 Oct 2026, 8:39 AM
- **People:** Xiaoming (manager), to "Team"
- **Channel:** email
- **Kind of text:** original text for Xiaoming's own email (lines 1 to 24). The same file also holds two Copilot discussions (lines 26 to 392). They are not Xiaoming's words: the answers are Copilot's text. Lines 397 to 403 hold Jie Chen's reply as relayed by Waqas (C41).
- **What was said (Xiaoming's words):**
  - "We have strongly encouraged everyone to engineer additional features and build benchmark models to independently challenge the LOB's models. However, please be extra careful when using class-specific downsampled data provided by the LOB for feature engineering, especially for cross-row historical aggregation features. These features can be materially distorted and thus biased by the sampling process."
  - "1. Engineer features using full population with sufficiently long history. For example, if VAA (10786) provides 3-month retro- data, we have to use the 3-months retro- data for estimation. However, historical or cross-row features should ideally be engineered using a dataset with a longer lookback window and a population that preserves the relevant transaction history. This naturally leads to the question: Where can we obtain reliable, longer-history data for feature engineering?"
  - "2. Build portfolio-level feature stores to support holistic validation rather than model specific validation." Portfolios named: Debit Card, Credit Card, DDA Accounts including Deposit Checks, Inclearing Checks, and Digital Money Movements.
  - "The longer-term goal should be to move away from repeatedly engineering features within each individual validation dataset and toward portfolio-based feature stores with sufficiently long, representative histories."
- **What the included Copilot answers say (not Xiaoming's words):** a 7-day account count built after keeping all fraud and 1% of good rows is "strongly biased"; the correct order is "Full population → point-in-time historical feature engineering → downsampling → train/test dataset"; untouched validation and test sets keep the natural fraud rate.
- **What it changed:** became a binding V2 rule: full raw account stream, then point-in-time feature replay, then split and target selection, then optional training-target downsampling, then model. Never build aggregates from a sampled table; keep non-target rows as history; validation and test at natural prevalence; explicit cold-start flags; future-invariance and history-deletion tests added to the V2 feature gate. V1 was checked and found aligned (natural prevalence, no class downsampling, whole-account files, strictly earlier history, no labels as inputs). The feature-store idea shaped the embedding store design (account plus time key). The 26 Oct plan states "Every feature uses only data from before the transaction".
- **Status now:** rules in force for V2 features. Not built: stores for portfolios beyond card, a longer-history data source, cross-account aggregates.
- **Sources:** `waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md:1-24,26-392`; `waqas/additional_info/email_from_xiaoming_for_feature_information/README.md:3-14`; `updates week_10-14-2026/updates 10-14-2026/readme.md:743-806`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:143`

### C41. 13 Oct 2026: Jie Chen's reply on account-level sampling

- **Date:** relayed 13 Oct 2026; the reply's own date and time were not given
- **People:** Jie Chen (director), replying to Xiaoming's email; relayed by Waqas
- **Channel:** email reply, relayed by Waqas
- **Kind of text:** relayed by Waqas. The reply text was supplied by Waqas; the original message file was not.
- **What was said:** "If we do time series-based feature engineering, I think it is more appropriate to do account/customer level sampling rather than transaction level sampling." Waqas added: "We need to think of what allat means".
- **What it changed:** a sampling note was written: sample whole accounts or customers and keep their histories, or sample targets but read full histories from a kept source; account, card and customer are not interchangeable. V1 uses every transaction (no downsampling), so nothing changed in V1; V1's uncertainty ranges already resample whole accounts.
- **Status now:** rule documented; nothing decided; no account-sampling comparison run. Downsampling stays a candidate for the 100-file stage.
- **Sources:** `waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md:397-403`; `bridge/OWNER_QA.md:2506-2516`; `bridge/plans/CH/2026-10-12-v22-feature-proposal/SAMPLING_FOLLOWUP_2026-10-13.md:1-64`

### C42. 13 to 14 Oct 2026: LoB field metadata spreadsheet

- **Date:** undated spreadsheet; parts entered 13 to 14 Oct 2026
- **People:** LoB (provider); Waqas entered it
- **Channel:** spreadsheet "meta data ALL features provided by LoB.xlsx"
- **Kind of text:** original text (spreadsheet supplied by the business; parts typed into the repo)
- **What was said:** about 714 rows of field metadata (columns A to G, including an MIFM_feature flag). Entered in separate batches: rows 1 to 123, 124 to 248, 249 to 600.
- **What it changed:** feeds the V2 field mapping and feature catalogue. A master feature index of 311 rows was built (94 features of model 15298 with ranks, 106 raw or source columns, 94 crosswalk rows, 17 V2 candidate families). The MIFM flag is read only as "the incumbent team thought this worth flagging" (for example "24hr count of same MCC").
- **Status now:** partly entered. The meaning of MIFM_feature is not documented.
- **Sources:** `waqas/feature_related/part_124_248/README.md:1-25`; `waqas/feature_related/part_249_600/README.md:1-15`; `explainer/CHANGE_JOURNAL.md:169-178`; `bridge/assist/features/CATALOGUE.md:45,94`

### C43. 14 Oct 2026: Confluence results: TFM vs LoB XGBoost vs Xinyu's offset model

- **Date:** page read 14 Oct 2026; the results' own date is not given
- **People:** results attributed to FL (LoB XGBoost), the TFM and Xinyu's offset model
- **Channel:** Confluence page "Foundation Model for Fraud" (Waqas's PDF export, kept on the work laptop)
- **Kind of text:** summary (numbers as copied into the 14 Oct update readme). This part of the page is not in the MRM_1 Confluence export.
- **What was said:** on the 952,905-row June 2025 out-of-time set (KS, AUC, DR@0.006, VDR@0.006, FPR@0.006): FL original 0.8410, 0.9727, 0.5486, 0.5631, 6.3402; TFM score alone 0.8215, 0.9685, 0.5664, 0.6877, 6.1629; offset (FL plus 20 TFM embedding columns) 0.8390, 0.9730, 0.5678, 0.6207, 6.0925. The offset's embeddings were taken on the TFM's own training rows (in-sample), from the fraud-fine-tuned model.
- **What it changed:** showed a sequence transformer alone beats the LoB model at the operating point, which supports the project direction. Embedding consumers must be trained on rows the encoder never saw. Added the plan step "repeat with FL's features in Xinyu's offset framework", later the manager's offset-model use (C55).
- **Status now:** context. The offset-style test with our vector has not been run.
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:23,63-64,86-87,243-253,377-381`

### C44. 14 Oct 2026: requests to Xinyu, LoB and MMR

- **Date:** listed 14 Oct 2026; status checked 20 Oct 2026
- **People:** Xinyu / LoB; MMR
- **Channel:** planned questions (open-questions table in the 14 Oct update readme and the V2 plan)
- **Kind of text:** summary (list of planned asks). No record that the asks were sent.
- **What was said:** "Exact DR / VDR / FPR@0.006 definitions" (Xinyu / LoB); "Where FL's features live and how to access them" (Xinyu); FL features or an approved interface, and FL row-level scores (Xinyu); TFM embeddings for our downstream rows and the offset implementation (Xinyu); "Does the TFM use Muon + AdamW?" (MMR).
- **What it changed:** until answered, DR, VDR and FPR are "not computed", the frontline and TFM-embedding consumer arms wait, and results are research results, not production claims.
- **Status now:** open. The 20 Oct coverage review: "no record that Xinyu was ever asked".
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:405-418`; `updates_week_10-14-2026/Updates 10-15-2026/V2_execution_plan_proposal.md:299-306,443-456`; `bridge/reviews/CL/2026-10-20-end-to-end/COVERAGE.md:13,67,88,127,189,244`

### C45. 14 to 16 Oct 2026: Waqas's email to Nengfeng on the feature-store framing

- **Date:** written 14 Oct 2026; sent around 14 to 16 Oct
- **People:** Waqas to Nengfeng (manager)
- **Channel:** email
- **Kind of text:** summary. The email text is not archived in either repository; the 14 Oct update readme records its points.
- **What was said:** the "feature store" / two-step framing of the work; it refers to the internal PFM/TFM work and Xinyu's offset model, and offers the CoLES paper. Related points recorded the same day: "Can features be built for models other than 15298? Yes. Embeddings from the raw-field encoder are model-agnostic and can be joined by transaction ID. Xinyu's offset model is the internal precedent." "We are not building a TabFM; we are building an FT-based transaction representation model."
- **What it changed:** set the framing that the product includes reusable embeddings for several XGBoost models. Led to Nengfeng's reply (C48).
- **Status now:** sent
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:193-202`

### C46. 15 Oct 2026 (received): Xiaoming's email on reusable decision models and a tabular backbone

- **Date:** received 15 Oct 2026; the email's own date is not given
- **People:** Xiaoming and cross-team colleagues; mentions "Jev/Laya-style work"
- **Channel:** email ("Email 1")
- **Kind of text:** summary (section 15.1 of the 14 Oct update readme). The original email is not in either repository.
- **What was said:** a reusable decision model "is envisioned as a relatively cheap, fast classifier for tasks such as routing, risk categorization, policy gating, confidence, escalation and model challenge. Xiaoming argues that tabular applications should prefer a tabular-native backbone because conversion into a generic LLM token space can lose information, and that task fine-tuning should outperform direct use of a pretrained model" (mechanism given as Q and K representations becoming "more aligned").
- **What it changed:** no architecture change (the FT tokenizer is already tabular-native). Added a planned test: frozen embedding plus new head against end-to-end fine-tuning, on an encoder-unseen split. Wording: the work is a fraud-domain case study plus a reusable representation, not a Tabular FM or a production feature store. Jev/Laya-style work treated as nearby research, not a dependency.
- **Status now:** frozen-backbone test planned for after the core model is stable; not run
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:700-741,796-806`

### C47. 15 Oct 2026 (received): Xiaoming's full-history feature thread, with Sidney

- **Date:** received 15 Oct 2026; the emails' own dates are not given
- **People:** Xiaoming and cross-team colleagues, including Sidney
- **Channel:** email ("Email 2"), the full-history, point-in-time feature-engineering thread
- **Kind of text:** summary (section 15.2 of the 14 Oct update readme). The original thread is not in either repository. Whether it is the same thread as C40 with replies is not stated.
- **What was said:** "Serial correlation lives within an account/customer, so account history must be preserved. Historical aggregates must be computed from the full, point-in-time transaction stream before any class-specific target downsampling." Full-window aggregates "also leak future information and post-fraud account closure into earlier rows." "Sidney's narrower argument about activity_interval is plausible but should not become a waiver" (a full-window max(date) is still future leakage).
- **What it changed:** same binding V2 order as C40, plus: closure-sensitive features (activity span, recency, tenure, inactivity) treated as high risk and defined as of the target time; zero fills replaced by cold-start flags; inclusion probabilities recorded and probabilities recalibrated if target downsampling is ever used. Confirmed: "Our history-aware FT model is the transformer-based approach Xiaoming describes for within-account serial correlation."
- **Status now:** in force for V2 features (not yet built)
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:743-806`

### C48. 16 Oct 2026 (received): Nengfeng's reply on the feature-store direction

- **Date:** received 16 Oct 2026
- **People:** Nengfeng (manager)
- **Channel:** email reply to C45
- **Kind of text:** summary (section 15.4 of the 14 Oct update readme). The original email text is not in either repository.
- **What was said:** "Nengfeng agreed that the all-position results are promising if they hold as history and training size increase. He confirmed that the feature-store objective is not merely a better FT-Transformer: the key question is whether the embeddings contain reusable signal that improves downstream fraud models. He endorsed comparing against the frontline XGBoost model and the transaction foundation model, then evaluating embeddings through offset models or other downstream consumers." He asked us to examine: "1. Correlation between FT embeddings, foundation-model embeddings and existing model scores. 2. PCA or other dimensionality-reduction methods for embedding export. 3. Whether embeddings can be standardized as reusable feature-store assets rather than remaining model-specific features."
- **Note on wording:** the same readme section then lists an 8-step "manager-aligned representation workstream" (export, alignment, correlations and PCA, downstream XGBoost arms, a feature-store contract with ID key and valid-from time, and step 8 "Test reuse in at least one second consumer"). Those steps are the project's own interpretation, not Nengfeng's words. Later records sometimes call the "second consumer" a manager requirement.
- **What it changed:** added the representation workstream: export each row's out[:,1:] plus score and ID; align with TFM embeddings and the frontline score; correlations; PCA (PCA 8 and PCA 16 columns in the planned export table); downstream XGBoost arms; compare with the frontline XGBoost model and the TFM. A first "second consumer" (account-level fraud in the next 14 days) was added on 21 Oct and replaced on 27 Oct (C55). The immediate order did not change: data and validation first, best encoder, then the representation work.
- **Status now:** planned. The embedding export runs only after the final 100-file model. Not run.
- **Sources:** `updates week_10-14-2026/updates 10-14-2026/readme.md:808-849`; `updates_week_10-14-2026/Updates 10-15-2026/V2_execution_plan_proposal.md:5-11`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:406-436`

### C49. 20 Oct 2026: question list for the data owner

- **Date:** list built 20 Oct 2026; questions first raised 9 to 10 Oct
- **People:** the data owner / data-feed owner (not named); Yaqun "when he is reachable"; Waqas
- **Channel:** question list "Questions only a person can answer" in the V2 runbook (`runbook/v2/RUNBOOK.md`, on the V2 branch)
- **Kind of text:** original text of the prepared list. No record that it was sent or answered.
- **What was said:** eight plain questions for the data owner and seven items for Waqas:
  - Same-second visibility: are transactions in the same second visible at authorisation? (public question 11)
  - What moment transaction_dttm records, UTC or local, and summer-time clock changes (15)
  - Whether external_1_scr (the Visa fraud score), transaction_pin_verify_xcd, cvv_verify_xcd, authzn_rqst_crypto_valid_xflg and avs_request_xcd are set before the bank's fraud decision, and what their codes mean, plus the card-present code (12)
  - How long fraud labels take to settle (13)
  - Whether transaction_advice_xcd rows are decisions at the time or later notices (14)
  - Which limit field (20); declines (21); whether the merchant postal code is the physical location for card-present rows
  - Waqas's items include which evaluation files are untouched (item e).
- **What it changed:** until answered: the model scores every row and FINAL is also reported without advice rows; results using the five fields are conditional (register R-014); same-second rows never see each other (strict rule). Questions the data can answer became a pod script (`waqas/v2/scripts/data_look.py`).
- **Status now:** open; no answers recorded
- **Sources:** `bridge/OWNER_QA.md:24-26,65-71,85,933,966-970,1026`; `code_tour/05_v2_tools.md:45`; `bridge/reviews/CL/2026-10-20-end-to-end/DISPOSITIONS.md:293`

### C50. 20 to 21 Oct 2026: what the managers want from the feature store (Waqas's account)

- **Date:** 20 Oct and 21 Oct 2026
- **People:** Waqas, about Xiaoming's email and about what "they" (the people asking for the feature store, not named) want
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas. Which Xiaoming email Waqas meant is not stated.
- **What was said:** Xiaoming's email describes account-level features built from the full history, then attached to whatever row needs them. Waqas's reading: "the feature store thing I believe is more experimental we just want to see I think if we can build a feature store using embedddings? Can build it...for the storage and stuff, idk doesn't matter we can do whatever w need". On what the bank receives: "I don't have a clue". On 21 Oct: "I thought they wanted like transaction level features and some how those features adapt regardless of account? Is that even possible".
- **What it changed:** the feature store is treated as an experiment: can the FT embeddings serve as a feature store. The reusable asset is the trained encoder: a function of a transaction and that account's recent transactions, with no per-account parameters, so it gives a vector for any account, including new ones. The store holds the score and vector for transactions scored so far, keyed by account and time ("account level" means the join key only). Real-time serving is not built; only its latency would be measured. Store code exists (PR #28, commit 71f3f30).
- **Status now:** experiment in scope; not run on bank data
- **Sources:** `bridge/OWNER_QA.md:318,774,812,862-892`

### C51. 21 Oct 2026: payment foundation model feature list; the portfolio is card

- **Date:** 21 Oct 2026
- **People:** Waqas, about the payment foundation model (PFM) team and LoB
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas
- **What was said:** "Well ya this is just for debit card modeling I'm pretty sure so we don't need to worry about stuff like checks etc. don't recall if it's debit or credit, but it's card." "I'm gonna give you all the features used in the companies payment foundation model, they utilized the LoB xgboost models features and their own, but removed (I believe) features that aren't available at time of transaction. So that would provide us with more insight onto what features are available or not, idk how to find that info out but can always ask someone." "I know we had the feature importance table for the XGB model and the payment foundation model too..so I was hoping to measure if a feature actually provides life or not" (he means lift) and "had work like this been done before?"
- **What it changed:** scope fixed to the card portfolio. Plan for the PFM list: map every feature to the 224 columns and the catalogue, mark availability at authorisation (the PFM team's removals are evidence; the data owner's confirmation is the rule), and feed candidates into the feature screen. Importance tables measure use, not lift. The 26 Oct plan used the TFM V22B importance list and the 15298 list instead. Per C25, "removed features not available at transaction time" fits v30, not v22b.
- **Status now:** the full PFM feature list was not received or mapped. Per-field availability is open.
- **Sources:** `bridge/OWNER_QA.md:816,847-860`; `MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md:237`

### C52. 21 Oct 2026: Shaunak's earlier work and the "FEATs framework"

- **Date:** 21 Oct 2026
- **People:** Waqas, about Shaunak (previous QAP)
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas. Shaunak's work itself was not supplied.
- **What was said:** Shaunak's earlier work used something called a "FEATs framework" to "find automatic cross section and temporal feature engineering". Waqas asked how similar it is to our work.
- **What it changed:** nothing yet. No file in either repository mentions Shaunak or a FEATs framework, and no public framework of that name was found (likely internal). A real comparison needs Shaunak's code, write-up or feature list.
- **Status now:** open; nothing received
- **Sources:** `bridge/OWNER_QA.md:758-764`

### C53. 26 Oct 2026: weekly presentation: seed check, final model, training setup, features

- **Date:** presented 26 Oct 2026; Appendix D changed 27 Oct
- **People:** Waqas presenting; audience not named (possibly the same 2 pm senior-quant meeting, C54)
- **Channel:** presentation document `WEEKLY_2026-10-26.md`
- **Kind of text:** original text (the presentation document)
- **What was said:**
  - "Seed stability check: complete." Seed results (average precision): chunk 0.1020 / 0.0912 / 0.1013 vs sliding 0.0955 / 0.0743 / 0.0753 (mean 0.0982 vs 0.0817).
  - "Final model: Arch B H20 chunk", with its full specification and reasons.
  - "Next: features, then scale. Add 166 features: 90 TFM V22B fields, the 60 model-15298 features that TFM and our inputs do not already cover, and 16 we build ourselves. Redo preprocessing, retest on 10 training files, then train on 100 training files."
  - Training order: map features to the 224 columns, new preprocessing fitted on files 1-10, retest, feature importance and group selection on holdout files 8206-8216, then files 1-100.
  - Test 1 = evaluation files 8000-8010; Test 2 = TFM V22B's 952,905 transactions.
  - 7 status fields left out under the TFM developer's warning (C25). About 189 inputs in all.
  - Appendix D: embedding export proposal (changed on 27 Oct to the manager's named uses, C55).
- **What it changed:** fixed the plan of record for the next stage.
- **Status now:** presented. Feature stage, 100-file training, Test 2 comparison and embedding export not yet run.
- **Sources:** `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:1-165,406-436`; `bridge/OWNER_QA.md:320-326,417-423`

### C54. 26 Oct 2026, 14:00: meeting with senior quants

- **Date:** Monday 26 Oct 2026, 14:00
- **People:** Waqas; senior quants (model risk, ML and statistics reviewers; names not given)
- **Channel:** meeting
- **Kind of text:** relayed by Waqas (Waqas said on 25 Oct that this meeting was happening). No notes of what was said exist. A briefing pack was prepared beforehand.
- **What was said:** Waqas needed "to be able to explain everything to senior quants". Prepared positions (from the briefing, not a record of the meeting): the winner is the all-position chunk model, "average precision 0.098 across three random seeds ... against 0.082 for B-H20 ... It was ahead on every seed"; known limits: month is an input, three seeds is small, SELECT looked at many times, not benchmarked against the incumbent, alert budgets not run, code of record not in the repository, inputs not confirmed by the data owner, calibration not checked; prepared answer to "Would you approve it today?": "We are not asking for approval; today it should be rejected", with the path to approval.
- **What it changed:** no decision from the meeting is recorded. The manager's embedding uses relayed on 26 to 27 Oct (C55) may come from it; not confirmed.
- **Status now:** scheduled; whether it took place and its outcome are not recorded
- **Sources:** `bridge/OWNER_QA.md:530-536`; `bridge/plans/CL/2026-10-25-meeting/BRIEFING.html:93-137,263-292`

### C55. 26 to 27 Oct 2026: the manager's named uses of the embedding

- **Date:** relayed 26 Oct 2026; adopted 27 Oct 2026 (decision D-012)
- **People:** Waqas's manager (not named), relayed by Waqas
- **Channel:** relayed by Waqas
- **Kind of text:** relayed by Waqas. The manager's own words are not recorded.
- **What was said:** the manager named two uses: (1) our vector added to model 15298 (the bank's frontline debit-card XGBoost model) as an offset model, with the lift over 15298 alone measured; (2) a correlation check of our vector and score against TFM V22B's embeddings and the existing model scores. Waqas questioned the earlier account-level use (predict fraud on the account in the next 14 days), which nobody had asked for.
- **What it changed:** D-012. Downstream uses are now: (1) transaction-level XGBoost on raw fields plus fraud score plus our vector, against raw fields plus fraud score; (2) 15298 as an offset model: "15298's own score is the fixed starting point, an XGBoost on our vector learns only the correction", lift measured as AP against 15298 alone on the same transactions; (3) "a correlation check of our vector and score against TFM V22B's embeddings and the existing model scores." Removed: the 14-day account-level task ("withdrawn"). Appendix D of the presentation updated.
- **Status now:** adopted; not run. Use 2 needs 15298's scores for the downstream transactions (not yet obtained, see C44).
- **Sources:** `bridge/OWNER_QA.md:196-205,312-318`; `bridge/DECISIONS.md:176-182`; `bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md:406-436`

---

## 3. Impact map

| What was said | Who, when | What we did because of it | Status |
|---|---|---|---|
| Fraud label as an input gave a 99% AUC; labels are not mature at decision time | Xinyu, 30 Jul (C03); repeated 17 Aug (C07) | No past fraud labels as inputs in any model (decision 2) | In force; label maturity still a data-owner question |
| Raw data folders, Oct 2024 to May 2025 training, June 2025 test with May history, 10,000 account buckets | Sumegha, 17 Aug email (C08) | Code reads these folders; June-only view for out-of-time claims; July holdout removed; split redesign proposed, not adopted; DS_TRAIN moved to files 4001-4010 | In force |
| transaction_dttm is the time column; descriptions are in metadata tables | Developer, 17 Aug Teams (C09) | Four calendar inputs come from transaction_dttm; field meanings from the LoB spreadsheet | In force; clock (UTC or local) open |
| Best TFM uses the last 17 transactions; count limit matters, not lookback time | Sumegha and Xiaoming, 18 to 19 Aug (C10) | History 20 kept close to 17; prefer shorter history if as good; row cap in the final model | Applied |
| An account is in one file; files 5001-7999 not used; TFM converges early | Developer, 31 Aug (C17, C18) | Whole-account files relied on; plan stays 10 then 100 files | In force; 100-file run not done |
| Review the TFM with attention to leakage | Xinyu to Xiaoming, Yaqun, Hanyu, 27 Aug (C14); scope 31 Aug (C16) | TFM validation: rerun and independent fine-tune | Partly done; ablations, chronology, explainability open |
| FT-Transformer best; fork pytorch-tabular; 23 predictors from Sumegha; missing-value rules | Yaqun, 27 Aug and 3 Sep (C15, C21, C23) | Project built on the fork; 23 inputs and preprocessing as described | In use |
| v22b holds fraud proxies (status / card-inactive date); do not use as is | Developer, 8 Sep email (C25) | 7 status fields left out of the feature plan (95 to 90 TFM fields) | Leakage open; plan not trained |
| Start replication, v22b first | Internal participant, 8 Sep Teams (C26) | v22b only | v22b done; v30 not started |
| Benchmark is 952,905 targets from 317,672 accounts; repeat replication on Shubham's clean repo | Sumegha, Xinyu, Xiaoming, Sep threads (C28) | Test 2 defined; account-clustered bootstrap; three padding rows removed | Clean-repo rerun not done; Test 2 not run |
| "It should be exactly the same" (rerun) | Team, relayed by Waqas, about 20 Sep (C30) | Exact-match analysis in the rerun report (84.2891%) | Documented |
| Phase 4 design decisions 1 to 11 | Yaqun, 25 Sep (C34) | Sequence builder and model reused; shuffle buffer; eval stride 1; batch pieces adding to 4096 | In force; capacity sweep not run |
| Open items A to G; history is "the main sequence lever" | Yaqun, 28 Sep (C35) | V1 (histories 0 to 20, Arch B, all-position B); V2 centred on 100 files | V1 done; A, C, D, E, G not done |
| Refit preprocessing on more files; target encoding pilot; use the 15298 ranking; autoresearch | Team and Xiaoming, 5 Oct (C36) | Refit = new artifact version; codes fed raw; 15298 list used; autoresearch deferred | Encoding not built; refit planned |
| More features, longer histories; chip-card count; lagged values; spoofed cards; caution on target encoding | Xiaoming and Yaqun, 6 Oct (C37) | 166 features proposed; H20 winner; chip-card count catalogued; no target encoding | Features proposed, not built |
| Yaqun leaves Friday; out of office for a while | Relayed by Waqas, 7 to 8 Oct (C39) | Work aimed at 9 Oct and the 12 Oct review; questions for Yaqun held or sent to the data-owner list | Review outcome not recorded |
| Build features on the full population, point-in-time; portfolio feature stores | Xiaoming, 12 Oct email (C40) | Binding V2 order; V1 checked aligned; store keyed by account and time | Rules in force; stores not built |
| Sample whole accounts or customers, not transactions | Jie Chen, 13 Oct, relayed by Waqas (C41) | Sampling note; V1 unchanged (no downsampling) | No comparison run |
| TFM beats LoB XGBoost at the operating point; offset adds embeddings to FL | Confluence, read 14 Oct (C43) | Consumers must train on encoder-unseen rows; offset test planned | Not run |
| Tabular-native backbone; task fine-tuning beats direct use | Xiaoming, received 15 Oct (C46) | Frozen-embedding vs fine-tune test planned; wording set | Not run |
| Keep account history; aggregates from the full stream; activity_interval is no waiver | Xiaoming and Sidney, received 15 Oct (C47) | Closure-sensitive features treated as high risk; cold-start flags | In force for V2 |
| Embeddings must improve downstream models; correlation, PCA, standardise as store assets | Nengfeng, 16 Oct (C48) | Representation workstream planned; PCA 8 and 16 in export table | Planned, not run |
| Card portfolio; PFM removed features unavailable at transaction time | Relayed by Waqas, 21 Oct (C51) | Scope fixed to card; per-field availability check planned | PFM list not received |
| Use 15298 as an offset model; correlate with TFM V22B embeddings | Waqas's manager, relayed 26 Oct (C55) | D-012; 14-day account task withdrawn | Adopted 27 Oct; not run |

---

## 4. Open items raised by managers or the team (not done)

### From managers

1. **Downstream value of the embedding** (Nengfeng, 16 Oct, C48): correlation between FT embeddings, foundation-model embeddings and existing model scores; PCA or other reduction for export; whether embeddings can be standardised as reusable feature-store assets. Not run. The export comes after the final 100-file model.
2. **Manager's named uses** (26 Oct, C55): 15298 plus our vector as an offset model, and the correlation check against TFM V22B embeddings and existing scores. Adopted (D-012), not run. Needs 15298 scores for the downstream transactions.
3. **Longer-history data and portfolio-level feature stores** (Xiaoming, 12 Oct, C40): where to get reliable longer-history data; stores for Debit Card, Credit Card, DDA, checks and digital money movements. Not built; only the card portfolio is in scope.
4. **Account or customer-level sampling** (Jie Chen, 13 Oct, C41): rule documented; no comparison run. Nothing decided.
5. **Frozen embedding plus new head vs end-to-end fine-tune** (from Xiaoming's 15 Oct email, C46): planned, not run.
6. **Xiaoming's 6 Oct feature ideas** (C37): chip-card authorisation count, lagged (yesterday's) aggregates, the counter-drop case, delta features, rolling 90-day window. None built. Three note fragments are still unclear ("It might be 94", "coarse through", "content itself does not contain signal").
7. **Target-encoding pilot on 5 to 10 files, then refit** (attributed to Xiaoming, 5 Oct, C36): not built; the current plan feeds codes raw.
8. **Preprocessing refit on more files** (5 Oct, C36): planned as a new artifact version fitted on files 1-10 with the new features. Not done.

### From the TFM developers and the TFM review

9. **v22b status-date leakage** (Developer, 8 Sep, C25): open model-risk issue. The tabular fraud plan leaves out 7 status fields.
10. **Repeat replication on Shubham's cleaned shared repository** (Sumegha, C28): not done.
11. **Rerun report next steps** (C33): repeat the rerun after the LEW41 change window; review findings with Sumegha (runtime configuration, tokenizer adjustment, duplicate rows, score differences); update the conclusion; benchmark TFM against baselines on the same population; test frozen TFM embeddings on a baseline; ablations (history, pooling, downsampling, auxiliary signals); prediction-time availability and leakage controls. None recorded as done.
12. **31 Aug review scope** (C16): ablations, chronology checks and explainability still open.
13. **Last 17 transactions vs window_size=None** (C10): needs reconciliation.
14. **v30 package**: not started (C26, C28).
15. **Questions drafted for the developer** (C32): sending not recorded.

### From Yaqun's plan

16. **Open items A, C, D, E, G** (C35): 100+ training files; bigger network; more features (planned as 166, C53); pos_weight tuning (stays 1.0); hyperparameter sweep and feature importance. The capacity sweep of decision 6 (C34) is not run. Whether chunked all-position B counts as item F (OQ-16) was superseded on 19 October and is no longer open [bridge/OWNER_QA.md:73].
17. **Inference latency** (Yaqun's open question 5, C23): no latency test.
18. **The avlble_merch_day_cash_lmt_amt field** (C39): values do not fit the description; question not sent to Yaqun; still a data note.

### Requests waiting on other people

19. **Xinyu / LoB** (C44): exact DR, VDR and FPR@0.006 definitions; where FL's features live; FL row-level scores; TFM embeddings for our downstream rows and the offset implementation. No record that Xinyu was asked.
20. **MMR** (C44, C28): "Does the TFM use Muon + AdamW?"; the P0/P1 question list (filter predicates, proxy columns, label definition, metric definitions, v30 package). No answers recorded.
21. **Data owner** (C49): same-second visibility; the transaction_dttm clock; timing and codes of external_1_scr and the four verification fields; label maturity; advice rows; which limit field; declines; merchant postal code for card-present rows. No answers recorded.
22. **PFM feature list** (C51): not received or mapped.
23. **Shaunak's work** (C52): not received.
24. **Meaning of the MIFM_feature flag** in the LoB spreadsheet (C42): not documented; rows 1-123 and the rest of the sheet only partly entered.

### Plan of record still to run

25. **Feature stage and scale-up** (C53): map features to the 224 columns, new preprocessing on files 1-10, retest, group selection on files 8206-8216, train on files 1-100, then the Test 2 comparison against TFM V22B and the embedding export.

### Missing records

26. What was said at the 6 Oct and 26 Oct senior-quant meetings (C38, C54), at the 12 Oct Monday review (C39) and in the 5 Aug code walkthrough (C06) is not recorded anywhere in the sources.
