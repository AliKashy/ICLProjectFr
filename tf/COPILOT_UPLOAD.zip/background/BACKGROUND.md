# Project background

Card-fraud FT-Transformer project ("tabular fraud") at a bank. Owner: Waqas (K194855). Original author of the handoff code: Yaqun.

This file is for a reader (GitHub Copilot, ChatGPT or Claude) who has never seen the project. It covers what the project is, the model it has to beat, the foundation-model work beside it, the people, the data, Yaqun's handoff, the infrastructure, the work done since, the timeline, what the Confluence page says, and where things stand on 1 November 2026. Every communication with managers and the team, and what each one changed, is in COMMUNICATIONS.md next to this file.

## 0. How to read this file

- Every fact ends with its source in square brackets, written as path:lines.
- A path with no prefix is relative to the root of the tabular fraud repository: GitHub AliKashy/tabular_fraud, branch main (local copy /home/user/tf_main; work-laptop copy C:\Users\K194855\Downloads\tabular_fraud_local) [U1014:3-5; RC1015:3-4].
- A path that starts with MRM_1/ is relative to the root of the sibling repository: GitHub AliKashy/MRM_1, branch main (local copy /home/user/MRM_1).
- Short names for the most-cited files. Each short name stands for exactly this path:

| Short name | Exact path |
|---|---|
| CONF | MRM_1/confluence/Foundation Model for Fraud (Confluence export, 132 lines, no file extension) |
| PKG | MRM_1/project_communication/TFM_V22B_Finalized_Package_PARTIAL.md |
| RERUN | MRM_1/my_notebooks/FineTune_Rerun/TFM_v22b_Model_Object_Rerun_and_Fine_Tuning_Comparison.md |
| DECK | MRM_1/Transaction_Foundation_Model_Exact_Match_v4(1).pptx (cited by slide number) |
| OQA | bridge/OWNER_QA.md (the owner's recorded answers) |
| DEC | bridge/DECISIONS.md |
| WEEKLY | bridge/plans/CL/2026-10-26-weekly/WEEKLY_2026-10-26.md |
| U1014 | updates week_10-14-2026/updates 10-14-2026/readme.md |
| RC1015 | updates_week_10-14-2026/Updates 10-15-2026/complete_reviewer_context.md |
| STORY | explainer/03_STORY_SO_FAR.md |
| DLOG | explainer/08_DECISIONS_LOG.md |
| CJ | explainer/CHANGE_JOURNAL.md |
| GUIDE | guide/GUIDE.md |
| PG | claude/PROJECT_GUIDE_claude.md |
| MN | waqas/docs/meeting_notes.md |
| XEMAIL | waqas/additional_info/email_from_xiaoming_for_feature_information/2026-10-12_best_practice_in_feature_engineering.md |
| DATAEMAIL | waqas/additional_info/data_path_information_email/data_path_information_email.md |

- CL is Claude. CH is ChatGPT, which sometimes hands work to Codex (OpenAI's coding agent). Copilot is GitHub Copilot, which the owner uses on the work laptop and on the pod [explainer/09_HOW_THE_TEAM_WORKS.md:6-19].
- The correct spelling of the original author is Yaqun (owner, 1 November 2026: "its yaqun.") [OQA:138-144]. Older files spell the name Yakun or Ya, and old file names keep the old spelling, for example explainer/05_CHANGES_FROM_YAKUN.md [OQA:138-144; OQA:1436].
- Some explainer chapters cite OQA by line numbers from an older, shorter version of OQA, so those pointers can be off. For example the decisions log cites ':822' and ':1347' for quotes that now sit at OQA:1880 and OQA:2405 [DLOG:15; DLOG:248; OQA:1880; OQA:2405].
- Where sources disagree, both are given. Section 11 lists the disagreements and the points no source settles.

## 1. What the project is and why the bank wants it

- The bank wants a better fraud detector for debit-card transactions: a model that gives every card transaction a fraud score, high when fraud is likely, so the riskiest ones are checked first [PG:21-27; explainer/01_ONE_PAGE.md:3; GUIDE:33-39].
- The project tests whether a transformer can do better than the current model by (a) reading the raw transaction fields directly and (b) reading the account's recent transaction history alongside the transaction being scored [PG:21-27; GUIDE:33-39].
- The model is an FT-Transformer that scores each debit-card transaction using that account's recent history [waqas/docs/waqas_roadmap.md:5-16,77-82; PG:22-33].
- Yaqun's problem statement: the fraud system works on individual transaction records (categorical and numerical features, binary target). Yaqun's hypothesis: "A fraudulent transaction may look normal in isolation but suspicious when viewed alongside the account's recent transaction history." [docs/fraud_detection_plan_overall.md:16-28].
- Yaqun's three goals: (1) a baseline FT-Transformer on single transactions with PyTorch Tabular; (2) a sequential model that combines history with the target transaction using separation tokens; (3) a streaming loader for large parquet files in S3 [docs/fraud_detection_plan_overall.md:16-28].
- The honest framing recorded for presentations: "we are testing whether history-aware transformers add signal over a per-transaction tree model", not "transformers beat trees" [GUIDE:35-36,144-145,1446-1457,1674].
- Agreed wording: "We are not building a TabFM; we are building an FT-based transaction representation model." [U1014:315-316]. Later wording decision: describe the work as a fraud-domain case study plus a reusable representation, not a Tabular FM or a production feature store [U1014:796-806].
- The deliverable also includes a reusable 48-number vector (embedding) per transaction that other fraud models can consume, and an experimental feature store built from it. Manager Nengfeng: the key question is "whether the embeddings contain reusable signal that improves downstream fraud models" [U1014:808-849; OQA:878-892; WEEKLY:406-436].
- The standard the owner sets: "This is a production at a trillion-dollar company." and the goal is "the best production ready model" [OQA:1155-1170; OQA:1010-1026].
- Portfolio: card fraud only. Owner: "this is just for debit card modeling I'm pretty sure so we don't need to worry about stuff like checks etc. don't recall if it's debit or credit, but it's card." [OQA:847-857].
- Serving: scoring one transaction needs the account's last N transactions, so a store keyed by account with the frozen preprocessing applied. The model is small (about 10^5 weights), but attention cost grows with the window. Latency and history retrieval have not been benchmarked. "Serving is explicitly out of scope so far; nothing has been built." [GUIDE:1622-1627]. Yaqun listed inference latency as open question 5 and production deployment as a Phase 3 optimisation item [docs/fraud_detection_plan_overall.md:139-151].

## 2. The incumbent model and the foundation-model work beside it

### 2.1 The incumbent: debit-card XGBoost model 15298

- The production fraud model is XGBoost (gradient-boosted trees). It scores one transaction at a time from hand-engineered features. Waqas's roadmap calls it "the baseline to beat" [PG:23-27,236-239; guide/parts/01_foundations.md:258-277].
- Owner (7 October): "CHP is card holder present, I believe, or chip. [...] that model is like a debit card, like XG boost model that we currently have at the company. And that model document number is 15298. [...] table 2.35, page 93 was just like a list of like engineered features" [OQA:1954-1957].
- Names used for it in the records: front-line, frontline, FL, LOB XGBoost, LoB XGBoost, model 15298, 15298 MDD [waqas/docs/waqas_roadmap.md:5-16; PG:22-33; MN:1-100]. The TFM deck's benchmark row is "XGBoost LoB v1.2 (engineered features)" [DECK slide 31]. Whether that row is model 15298 is likely but not stated (section 11).
- Its feature list: 94 ranked features, with external_1_scr at rank 1, plus a crosswalk and 106 raw or source columns, in waqas/feature_work/all_features_master.csv [waqas/feature_work/README.md:8-15; waqas/feature_work/all_features_master.csv:1-5]. The master index (commit 9bbaab6) has 311 rows: 94 features of 15298 with ranks, 106 raw or source columns, 94 crosswalk rows and 17 V2 candidate feature families. Its README reports 0 mismatches against the Excel file and CSV [CJ:169-178].
- Owner (19 October): "Yes, features were ranked p sure; I know that the VAA was most important." [OQA:1064-1087; OQA:1073].
- 15298 uses label-encoded codes (derived_le1__, derived_le3__) and days-since encodings, plus recency and window counts (days since events, minutes since the last authorisation, 24- and 48-hour counts). It has no month input [OQA:516; OQA:206; WEEKLY:144].
- No head-to-head comparison of the transformer against the incumbent on the same transactions has been run. The cheapest possible win, adding the transformer's score as one more XGBoost feature, has not been run either [GUIDE:35-36,144-145,1446-1457,1674].
- Two published readings of the LoB XGBoost:
  - TFM deck, slide 31, at the 0.6% outsort: XGBoost LoB v1.2 (engineered features), Jun25: UDR 0.548, VDR 0.580, FPR 5.79. "LoB model uses 94 features with vendor model VAA score; we use 98 tokenized features excluding VAA score." [DECK slide 31].
  - Confluence page, as recorded in the 14 October update from the owner's PDF export, on the 952,905-row June 2025 out-of-time set: "FL original (LOB XGBoost)" KS 0.8410, AUC 0.9727, DR@0.006 0.5486, VDR@0.006 0.5631, FPR@0.006 6.3402 [U1014:243-253].

### 2.2 The Confluence effort "Foundation Model for Fraud"

- Both the TFM review and this project came out of the same Confluence page, "Foundation Model for Fraud" [CONF:9-20]. Overview: "This project evaluates and applies foundation models (TSFMs / transformer-based models) for fraud detection." [CONF:24-41].
- The page's dated updates run from 28 July to 3 September 2026 in the MRM_1 export. They show three phases: TFM introduction and GPU access (28 July to 4 August); LLM in-context learning on debit-card data by Xinyu and Waqas (17 to 31 August, stopped 31 August); review of the in-house fine-tuned TFM with a leakage focus (27 August onward). In parallel, Yaqun's tabular transformer work (27 August and 3 September) became this project [CONF:9-20].
- The full entry-by-entry summary is in section 9.

### 2.3 The transaction foundation model (TFM), also called the payment foundation model (PFM)

What it is
- An in-house transformer model of transaction sequences built by MMR (Sumegha's team). COM-001 names the presentation "2026-05-15 FrontierAI Transaction Foundation Model presentation" [PKG:54-67]. Owner: "It's a payment foundation model or a transaction foundation model. [...] So version 22 is like the latest version they have. They also have a previous version called version 17." [OQA:1954-1957].
- Supplied code README, titled "Payment Foundation Model": "A transformer-based foundation model for payment-transaction sequences". It supports pretraining (causal plus masked LM, regression) and fraud fine-tuning ("9 pooling strategies, DCNv2, focal loss, composite ranking-aware loss, auxiliary signals, streaming data"). The base is a GPT-style causal LM: token embedding, sinusoidal positional embedding, N transformer blocks, optional RoPE and delta-temporal bias, SwiGLU, RMSNorm, tied LM head. FraudClassifier runs the base model with skip_lm_head=True, pools, and applies an MLP or DCNv2 head to one fraud logit. Design decisions: hybrid attention mask, Muon plus AdamW, streaming file-batch loading (local or s3://), dual learning rates, composite fraud loss [MRM_1/supplied_files/README:1-140].
- 19 tokenized transaction components: delta time, hour, day of week, channel, terminal type, cardholder present, category, type, amount, daily cash limit, balance, MCC, merchant country, merchant postal (hashed), cardholder country, travel country, cardholder postal (hashed), PIS status, IP address (hashed). Data pipeline stages: acc-trans, gen-token, gen-frd, frd-join-past, gen-seq [MRM_1/supplied_files/README:1-140].
- Fraud evaluation metrics in the TFM code: AUC-ROC, AP, AUC-PR, KS, best F1 and F2, log loss, UDR, VDR and FPR at 0.6%, 1% and 5% outsort, calibrated FPR with true_fraud_rate default 0.16%, and per-file metrics [MRM_1/supplied_files/README:1-140].
- Scale (deck): 1B parameter model, 1024/2048 token input, embedding 2048, 16 decoder blocks, 32 heads, head dimension 64, MLP 8192, next-token objective; weighted CLM plus MLM objective; training grew from 5B tokens (5% of October data, 10 GPU-hours) to 330B tokens (3.9B transactions, 576 GPU-hours), "Scale matters!!!"; "97 raw features produce 5,164 tokens across 8 types" (v17) [DECK slides 12, 14, 15, 16, 21, 25]. Claude's deck intake also lists 18.8B transactions, 38.8M accounts and 17 months (Mar 24 to Jul 25), and notes the deck describes FSDP training, which the supplied code does not implement [MRM_1/claude/DECK_INTAKE_claude.md:74-99,226-247].
- Metric terms used by the TFM work and the bank: outsort is the fixed top share of ranked transactions acted on (0.6% is the operating point). UDR is the share of fraud incidents caught in the outsort; VDR is the share of fraud value caught. FPR in this codebase means false positives divided by true positives ("FPR = non-fraud/fraud in 0.6% outsort"), not the textbook rate. Calibrated FPR rescales to a production fraud rate (true_fraud_rate 0.0016, hard-coded and not exposed on the command line) [MRM_1/claude/COMPLETE_SYSTEM_GUIDE_claude.md:61-112; DECK slide 31; MRM_1/claude/CLI_AUDIT_claude.md:217-234].

Versions
- v17: what the deck describes. "The deck describes v17. The work in progress is v22b." (confirmed by the owner) [MRM_1/claude/DECK_INTAKE_claude.md:8-25].
- v22b: "older BMG data containing fraud proxies including status date, which should not be used in current form because of potential leakage from card inactive date" (Developer, 8 September). Package root s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/ [PKG:230-243].
- v30: "newer, production-oriented CSCA data with LoB engineered features and features unavailable in production removed". Package root s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v30/ [PKG:230-243]. v30 work has not started in these sources [PKG:245-258].
- The best v22b used "the last 17 transactions, had no maximum time-based lookback, was limited by fixed sequence length, and could pad sequences shorter than max sequence length 2048" (Developer, 18 August) [PKG:114-127].
- v22b vocabulary: 5,378 entries (owner had said about 5,300) [RERUN:71; MRM_1/claude/DECK_INTAKE_claude.md:107-174].
- Delivered v22b parquets are about 12% fraud in training and about 0.1% in evaluation (owner's observation); Claude resolved the train downsample as about 85 to 100 [MRM_1/claude/DECK_INTAKE_claude.md:107-174; MRM_1/claude/WORK_INVENTORY_claude.md:393-405]. Deck slide 28: "Keep all fraudulent transactions and down-sample to 1% of non-fraud"; "Training data July 2024 to December 2024, ~52M sequences. Validation data April 2024." [DECK slide 28].

Waqas's TFM validation work (MRM_1)
- Assignment: on 27 August, "Xinyu and Waqas will review the in-house fine-tuned TFM, with special attention to feature leakage issues." The 31 August entry sets the review scope (code and architecture, fine-tuning replication, downsampling, leakage, new features, hyperparameters and seeds, uncertainty, explainability) [CONF:16; CONF:18].
- 8 September: v22b first and only; v30 kept separate [PKG:245-258].
- Controlled V22B fine-tuning run (package snapshot): script /home/jovyan/k194855/TFM/Validation/V22B/Reproduction/accum_4/scripts/distributed_finetune_accum4_full.py; run folder .../accum_4/runs/controlled_10000step_accum4; start checkpoint .../runtime_assets/checkpoint-intermediate-step-6500; tokenizer .../accum_4/runtime_assets/tokenizer_runtime; train s3://mrmcd-analytics-mrm-mmr-dsai/tfm_v22b_dropcpr_falcondecline/train/ (5,000 Parquets); eval .../eval/ (10 Parquets); muon_adamw; 10,000 steps; batch 32; accumulation 4; effective batch 128 on one GPU; base and head LR 1e-4; weight decay 0.2; warmup 300; pool strategy last; composite loss BCE 1.0, pairwise 0.5, approx outsort 0.0, top-k UDR 2.0; amount weighting on; BF16; checkpoint every 500 steps; training-time eval every 500 steps on one eval file with a 20% stratified subsample. It "reached step 4,000"; the last completed checkpoint is 3,500. "Final claims must come from standalone scoring on the complete selected OOT population." [PKG:13-48].
- Package open gates: train and eval duplicate target IDs, train/eval overlap, label conflicts (all "Unresolved"); historical exact command, config and selected checkpoint ("Missing"); last-17 against window=None ("Needs reconciliation"); status-date leakage ("Open model-risk issue"); training-time eval comparability ("Controlled limitation"). Acceptance criteria: reach step 10,000, complete checkpoints, matching finetune_config.json, full target-ID audit, standalone OOT scoring, coverage reporting, leakage kept separate from execution results, no mislabeled evidence class [PKG:275-337]. The later rerun found no duplicate fi_transaction_id in the one evaluation Parquet it used, which only partly answers the eval gate [RERUN:663-665].
- Model rerun (Sumegha's delivered final step-10,000 checkpoint on cross-file-8000-8200-seed-42_1.parquet): one GPU, one scoring process, BF16, batch 64, max sequence 2,048, files per batch 1, seed 42, no shuffle; exit code 0; about two hours; strict state-dict loading; exact population and metadata alignment (952,905 common IDs, no label, amount, timestamp or source-file mismatch). Tokenizer loader adjustment: mask_token='<MASK>', fill_missing=False, add_mask_token=False (vocabulary stayed 5,378; IDs unchanged; token_ids not regenerated). Logit differences: median 0, mean 0.00187448, 95th percentile 0.015625, max 0.0703125. Supplied duplicates 2f683a25a70c5d5d, 4b683a255f1d286c, 6e685d29810125c8 (all non-fraud identical pairs); removing them changed metrics by less than 0.0000006 [RERUN:141-213,539-621].
- Results on 952,905 unique transactions (1,418 fraud, 951,487 non-fraud) [RERUN:5-37,374-396]:

| Metric | Supplied (Developer) | Model Rerun | Fine-Tuned Model (Waqas) |
|---|---|---|---|
| ROC AUC | 0.9684955047 | 0.96849262 | 0.96619768 |
| KS | 0.8214189678 | 0.82124737 | 0.80633894 |
| Average Precision | 0.2736735573 | 0.27361014 | 0.24806854 |
| PR-AUC | 0.2768044244 | 0.27672673 | 0.25114480 |
| Log loss | 0.2770421477 | 0.27704246 | 0.14536295 |

- Rerun against supplied: 803,195 exact probability matches (84.2891%), mean absolute difference 0.00013460, maximum 0.01409278; the differences come from the model forward output, not the sigmoid [RERUN:15-17,389-396,582-591]. Earlier relayed figures (about 84.7% identical, max about 0.007) are superseded [MRM_1/claude/REPRODUCIBILITY_NOTE_claude.md:1-16].
- Independent fine-tuned model: Developer's distributed_finetune.py from the local step-6500 checkpoint, v22b tokenizer (5,378), 5,000 training Parquets, one H200, batch 32, accumulation 8 (256 per update), Muon plus AdamW, composite amount-weighted loss, 10,000 updates, checkpoint every 500. Only 5,086 (0.53%) exact matches with the rerun; mean absolute difference 0.06633727. At equal review capacity the rerun beat it: 0.6% UDR 56.56% vs 55.15%, VDR 68.37% vs 66.42%, FP/TP 6.13 vs 6.31; 1%: UDR 65.02 vs 63.89, VDR 77.03 vs 75.44, FP/TP 9.34 vs 9.52; 5%: UDR 85.12 vs 83.85, VDR 92.60 vs 91.49, FP/TP 38.47 vs 39.07. Selection overlap 87.67%, 86.19%, 80.78%. The Developer's historical device setup and file exposure are "not established" [RERUN:215-323,374-511].
- The report's next steps: repeat the rerun after the LEW41 change window ends on 20 September 2026; review findings with Sumegha (historical runtime configuration, tokenizer adjustment, duplicate rows, remaining same-checkpoint differences); update the final conclusion; benchmark TFM against established baselines on consistent populations; test whether frozen TFM embeddings improve an established baseline; controlled ablations (history length, pooling, downsampling, auxiliary signals); validate prediction-time availability and leakage controls [RERUN:513-537].

Claude's TFM findings and plan (MRM_1/claude, 20 September)
- (1) The script's command-line defaults override the dataclass defaults documented in FINETUNING_GUIDE.md (guide: accumulation 8 and dcnv2; script: 4 and last). (2) --fp16 cannot take effect in distributed_pretrain.py, distributed_finetune.py and fraud_eval.py (--bf16 default=True); pretrain_eval.py has the correct --no_bf16 pattern. (3) true_fraud_rate and outsort_percentiles are not exposed on the command line; amt_tag_col, corn_threshold and autocompute_corn_pos_weight are never used. (4) V17: the top-k UDR loss floor min_k = n_nonfraud // 2 always wins, so topk_udr_percentile is dead config; it carries the heaviest weight (2.0) and is live for the delivered run. (5) V16 (last_txn padding defect) and V12 (cold-start zeroing) apply only to segmented pooling (enhanced_mlp, dcnv2), not to the delivered last-pooling model. (6) The leakage guard for days_since_status_dt is commented out in the supplied tokenizer, with a gen-frd patch (inactv_positive_ids to inactv_missing_id). (7) use_hybrid_attention, use_shared_position_ids and use_field_type_embedding default off. (8) pos_class_weight 20 plus train about 12% fraud against eval about 0.1% means outputs are ranking scores, not calibrated probabilities (V11). (9) No determinism controls; bf16 inference by default [MRM_1/claude/RUN_CONFIG_RESOLVED_claude.md:9-190; MRM_1/claude/CLI_AUDIT_claude.md:141-334; MRM_1/claude/WORK_INVENTORY_claude.md:204-391; MRM_1/claude/CODE_CHECK_LIST_claude.md:27-65; MRM_1/claude/COMPLETE_SYSTEM_GUIDE_claude.md:2331-2435; MRM_1/claude/REPRODUCIBILITY_NOTE_claude.md:249-283].
- Work inventory: validation items V1 to V22, experiments E1 to E6 (TFM score as an XGBoost feature, TFM embeddings as features, segment analysis, pooling ablation, window size, feature ablation), operational items O1 to O4 (determinism, latency, interpretability, runbook). Four phases to January; critical path V1, V2, V5, E1, E3; hard rules "E1 after V5", "V9 after V5", "V7 early"; a check list (L1, A1 to A4, B1, B4, B6) to confirm against the k102157 source [MRM_1/claude/WORK_INVENTORY_claude.md:1-699; MRM_1/claude/PLAN_30_DAY_claude.md:1-135; MRM_1/claude/CODE_CHECK_LIST_claude.md:333-344].
- Leverage paths: Path A, TFM score as one extra XGBoost column (fraud_eval.py already writes eval_logits.npz with fi_transaction_ids as join keys); Path B, TFM embeddings (PCA 20 to 50) as XGBoost features; Path C, TFM as primary model (multi-quarter). Warning: TFM leakage would flow into XGBoost through a tfm_score column [MRM_1/claude/COMPLETE_SYSTEM_GUIDE_claude.md:2541-2611].
- ChatGPT's MRM_1 deliverable: MRM_1_Payment_Foundation_Model_Complete_Guide.docx, a beginner-first technical guide; snapshot 9a04eb42f0de1c0454e550bcc758c0744b332e27, review date 2026-09-20. It notes that the controlled v22b snapshot used last pooling, which avoids the very large DCNv2 head [MRM_1/ChatGPT_OpenAI/README.md:1-17].
- MRM_1 git history: supplied TFM files uploaded 2026-09-19; deck (9a04eb4), Claude's guides and ChatGPT's guide 2026-09-20; Metrics notebook and the rerun report 2026-09-21 (last commit e6a96ac) [git log of AliKashy/MRM_1].
- After early October the owner's main work is this tabular fraud project. Whether the TFM validation plan continued is not stated in the sources [MRM_1/claude/WORK_INVENTORY_claude.md:6-8,590-599].

### 2.4 How the TFM connects to this project

- Origin. The 27 August Confluence entry has Yaqun planning to "Explore more one these models using MMR's model 15298 data when GPU is available." On 3 September Yaqun recommended forking Pytorch-Tabular for "our internal fraud model development" and took "an initial predictor list for our internal data (from Sumegha)" [CONF:17; CONF:19]. This repository is "Forked from pytorch_tabular v1.1.0" [README.md:3,9].
- Same raw data. This project reads the raw TFM data the Developer copied in August: s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/ for training and validation and s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/ for evaluation [PKG:84-97; fraud/configs/preprocessing.yaml:10; fraud/configs/eval.yaml:16; fraud/configs/sequential.yaml:22-25,84; fraud/configs/smoke_test.yaml:12-18]. The TFM's own prepared fine-tuning package (tfm_v22b_dropcpr_falcondecline) is a different, tokenized dataset [PKG:22-23].
- Test 2. Test 2 is the 952,905 transactions of TFM V22B's evaluation file cross-file-8000-8200-seed-42_1.parquet (from evaluation files 8000 to 8200). TFM V22B scored AP 0.2737 and AUROC 0.9685 there, "its developer's results, reproduced in our rerun of the TFM model". This project scores the same transactions from the raw evaluation files with each account's earlier history. 52,202 Test 2 transactions are also in Test 1. AP depends on the fraud rate, so Test 2 numbers are compared only with TFM on the same rows [WEEKLY:88-101; RERUN:89-93]. Status: planned; the same-row benchmark tooling shipped in package 009 but has not been run, and the returned benchmark file lacked a directly usable score column [code_tour/README.md:232,243; 11_01_2026/request_1/ANSWER.md:392-395,596].
- TFM V22B features in the next model. The V22B importance chart has 120 rows, about 117 input fields (time shows as three tokens, one row looks duplicated); 5,378 is a token count. The next model adds 90 new V22B fields (about 20 are already inputs; 7 status fields are left out) [WEEKLY:113-146]. V22B time inputs are time gap, hour of day and day of week, with no month [OQA:185]. The bank-decision fields FALCONDECLINE_INDICATOR, PREDECLINE_INDICATOR and PROCESSOR_REASON are used for earlier transactions only, "As TFM does for FALCONDECLINE_INDICATOR" [WEEKLY:145]. VAA is rank 1 (6.69%) in the V22B chart and is believed to be Visa's score [waqas/features/feature_importance_v22_v17_highlighted/README.md:15-29].
- Leakage rule carried over. The Developer's 8 September warning about the v22b status date is applied to 7 status fields: INACTV_DT, the account status-change date, two online-banking login-block dates and three account and card status codes, because "a status can change because of the fraud itself". Two 15298 status dates (positions 22 and 78) are left out under the same rule [PKG:237; WEEKLY:139,146].
- Embeddings. The TFM deck's next steps include "Foundation model as feature extractor for downstream models" and "XGBoost + Transformer embeddings"; the rerun report's next step 5 is "Test whether frozen TFM embeddings improve an established fraud-model baseline" [DECK slide 34; RERUN:535]. Under D-012 this project's embedding uses include a correlation check against TFM V22B's embeddings and existing scores [DEC:176-181; WEEKLY:406-436].
- History length target. Claude's guides borrow two ideas from the TFM: one vector per transaction (hierarchical design) and the 17-transaction window "as a target for history length"; the TFM is "a comparison point, not an ingredient" [GUIDE:958-961,1613-1618; PG:394-395].
- Downsampling. Claude's guide says the TFM team's configs "keep 1 in 100 legitimate rows, which gives about 14% fraud" [guide/parts/01_foundations.md:232-245]. The early roadmap says about 12% fraud [waqas/docs/waqas_roadmap.md:28-39]. MRM_1 evidence shows downsample: 100 in older configs and downsample: 1 in current ones [bridge/audits/claude_audits_chatgpt.md:98-101]. This project trains at the natural rate [WEEKLY:78-79].

### 2.5 The comparison recorded on the Confluence page (FL, TFM, offset model)

The owner read the Confluence page on 14 October from a PDF export (kept in project_info/ on the work laptop). On the 952,905-row June 2025 out-of-time set [U1014:63-64,243-253]:

| Model | KS | AUC | DR / VDR at 0.006 | FPR at 0.006 |
|---|---|---|---|---|
| FL original (LOB XGBoost) | 0.8410 | 0.9727 | 0.5486 / 0.5631 | 6.3402 |
| TFM score alone | 0.8215 | 0.9685 | 0.5664 / 0.6877 | 6.1629 |
| Offset (FL plus 20 TFM embedding columns, Xinyu's model) | 0.8390 | 0.9730 | 0.5678 / 0.6207 | 6.0925 |

- The offset's embeddings were extracted on the TFM's own training rows (in-sample; train DR 0.6095 against OOT 0.5678), and they came from the fraud-fine-tuned TFM [U1014:243-253,377-381].
- These results are not in the MRM_1 export of the page, whose dated updates end on 3 September; they come only from the owner's later PDF export [CONF:1-132; U1014:63-64].

## 3. People and roles

One line each. Names are spelled as the sources give them.

- Waqas: owner, employee key K194855 (lowercase k194855 in paths), GitHub account AliKashy; decides, and is the only person who runs anything inside the bank; Waqas's recorded answers are instructions to both assistants; spelled "Wakas" once in his own message [explainer/09_HOW_THE_TEAM_WORKS.md:6-19; OQA:2352-2354; OQA:2266].
- Yaqun (also Yakun, Ya): colleague and original author of fraud/, src/, docs/ and notebooks/; employee key K016730 (k016730 in Yaqun's pod paths); left on Friday 9 October and is "out of office for a while" [AGENTS.md:9; OQA:1844-1847,1896-1899; OQA:2017].
- Sumegha (once "Sumagha"): TFM developer in MMR; sent the raw-data email; gave Yaqun the first predictor list; supplied the v22b checkpoint package; named for the follow-up review [CONF:9,19; DATAEMAIL:1-29; RERUN:46; RC1015:238].
- Shubham: part of the TFM "Developer" group; owner of the cleaned shared TFM repository [PKG:9; U1014:619].
- "Developer": the TFM package's label for "Sumegha, Shubham, and the code-producing or artifact-supplying team" [PKG:9].
- Xinyu (Xinyu Zhou): colleague who ran the LLM in-context learning tests, co-reviewed the TFM with Waqas, built the offset model, and is the named contact for metric definitions and frontline features and scores [CONF:10,13-18; DATAEMAIL:1-29; U1014:405-418].
- Xiaoming (spelled "Xiaming" in MN, "Xiaomings" in an owner message): manager per the tabular fraud records; at the 28 and 31 July meetings; received the 17 and 27 August updates; wrote the 12 and 15 October feature-engineering emails; his role is not stated in MRM_1 [CONF:9,11,13,16; waqas/additional_info/email_from_xiaoming_for_feature_information/README.md:5-7; MN:40,73; OQA:2510].
- Nengfeng: manager; at the 28 July meeting; replied on 16 October with the feature-store direction [CONF:9; U1014:808-849].
- Jie Chen: director; replied to Xiaoming's email about account-level sampling [XEMAIL:397-403; OQA:2506-2516].
- Joel: led the 31 July GPU resource coordination meeting; thanked for the raw-data copy [CONF:11; DATAEMAIL:1-29].
- Sandhya: at the 31 July GPU meeting; appears only in MRM_1 [CONF:11].
- Hanyu: received the 27 August update [CONF:16].
- Tianshu: collaborator on "fine-tuning approaches, model selection and literature review, environment setup and troubleshooting" [CONF:93-96].
- Sidney: cross-team colleague whose argument about activity_interval is discussed in the 15 October email [U1014:743-806].
- Shaunak: "previous QAP"; earlier work using a "FEATs framework"; nothing of it has been received [OQA:758-764].
- Jev and Laya: named only as "Jev/Laya-style work", adjacent research [U1014:741].
- k102157: owner ID of the source repository k102157/txn-foundation-model (develop branch); the person is not named [PKG:174-187].
- Unnamed "internal participant" and "internal reviewer": appear in TFM communications COM-008, 009, 010, 012, 014 and 015 [PKG:159-273].
- MMR: team name in Confluence for the TFM builders; its bucket is mrmcd-analytics-mrm-mmr-dsai. FrontierAI: name on the 15 May TFM presentation [CONF:9; PKG:54-67].
- LoB (line of business): owns the XGBoost model and supplied the field metadata spreadsheet [explainer/CHANGE_JOURNAL.md:169-178].
- Data owner, also data-feed owner: not named; holds the answers on field meanings and timing [OQA:24-26].
- Waqas's manager: named only as "the manager" in OQA when giving the embedding uses; most likely Nengfeng, but OQA does not say so (section 11) [OQA:196-205,318].
- Senior quants and executive-director quants: audience of the meetings scheduled for 6 October and 26 October (briefings prepared; outcomes not recorded) [bridge/threads/001-guide.md:3-12; OQA:530-536].
- Independent reviewer (not named): reviewed packages through 005, "found and fixed the file-sharding bug, wrote the test code" [RC1015:1-60].
- Claude (CL): equal AI assistant; marks its work "Generated by Claude Code" plus a Claude-Session line; project manager in its coordinating session from 11 October [explainer/09_HOW_THE_TEAM_WORKS.md:6-19,17].
- ChatGPT (CH), with Codex: equal AI assistant; commits start [bridge:CH] or [CH] [explainer/09_HOW_THE_TEAM_WORKS.md:6-19].
- GitHub Copilot: the owner's local assistant on the work laptop and the pod, used to install, compare and diagnose [GUIDE:41-50; OQA:1155-1170].
- Independent auditor (AUDIT): separate chat opened 14 October, posts on issue #7, not an approval step [explainer/09_HOW_THE_TEAM_WORKS.md:15].
- Helper chats: research pair and audit pair from 19 October (Claude members RS-CL and AU-CL), features chat FE-CL, Project explainer E1 (archived 19 October), reviewer sessions (opened 9 October, archived 19 October). Gemini was added 26 October and withdrawn 27 October [OQA:1089-1113; OQA:1054-1062; OQA:1192-1203; DEC:155-174].

## 4. The data

### 4.1 Where it is

- Training and validation files: s3://mrmcd-analytics-mrm-mmr-dsai/tfm_raw_data/ (part_1.parquet to part_5000.parquet). Evaluation files: s3://mrmcd-analytics-mrm-mmr-dsai/tfm_EVAL_raw_data/ (part_8000.parquet to part_10000.parquet), a separate extract [docs/fraud_detection_plan_detailed.md:11-13,26,101-107; GUIDE:655-663].
- The Developer's description (17 August): training data 102024 to 052025; testing data 062025 "but has 052025 histories", so the testing files cover 052025 to 062025; "partitioned by account into 10000 buckets totally"; "we use at most 5000 files for training and 2000 files for testing" [DATAEMAIL:1-29; PKG:84-97].
- Files 5001 to 7999 were not used by the TFM (Developer, 31 August) and do not exist ("Training files 5001-7999 do not exist, which matches the data owner's email", 23 October inventory) [PKG:159-172; updates_10_23_2026/M01_V2_results__through_l3.part_1.md:79-82].
- Size: training bucket 446 GB, evaluation bucket 49 GB. Every file read had the same 224 columns (406 file footers read). No account appeared in two files among the 416 files checked (86,320 file pairs). The data provider separately documents the account partitioning [updates_10_23_2026/M01_V2_results__through_l3.part_1.md:83-87,329,353-355; DATAEMAIL:1-29] [updates_10_23_2026/M01_V2_results__through_l3.part_1.md:78-87].
- Buckets: data in mrmcd-analytics-mrm-mmr-dsai; preprocessing artifacts in mrmcd-analytics-mrm-users [OQA:735-737]. Yaqun's area s3://mrmcd-analytics-mrm-users/K016730/tabular_fraud/ holds predictors.csv and preprocessing artifacts under artifacts/<artifact_version>/ (version 1 used) [docs/fraud_detection_plan_detailed.md:26,101-107]. Every Phase 4 config reads artifacts from K194855/.../artifacts/1, while Yaqun's fraud/configs point to K016730 [OQA:2017]. Whether Waqas's copy was copied or refit is an open question raised by both audits [GUIDE:742-744,790-793].

### 4.2 Size and shape

- About 840,000 rows per file (part_1 has 841,428) and about 3,300 accounts per file (3,334 in part_1). Transactions per account in part_1: median 133, 10th percentile 3, 90th percentile 670, 99th percentile 1,333, maximum 2,296 [PG:41-45; OQA:296-302].
- Each account is fully inside one parquet file, so history windows are built inside one file with no cross-file joins (measured true on the pod in run-001) [GUIDE:665-671,753; docs/phase4_design_decisions.md:22; explainer/04_HOW_THE_MODEL_WORKS.md:10-12]. Owner: "Yeah no accounts cannot span files. I'm pretty sure." [OQA:1929-1932].
- 10 files are about 8.4 million rows; 100 files about 84 million [GUIDE:753]. Evaluation files are about a quarter the size of training files (about 224 thousand against 867 thousand rows) [OQA:2111-2125].

### 4.3 Splits, dates and fraud rates measured on the pod (run-001, 12 October)

| Split (files) | Rows | Frauds and rate | Accounts | Dates |
|---|---|---|---|---|
| Training (1-10) | 8,622,629 | 12,757 (0.148%) | 33,876 | 2024-10-01 to 2025-05-31 |
| Validation (4950-4954) | 4,292,059 | 7,285 (0.170%) | 16,792 | 2024-10-01 to 2025-05-31 |
| Evaluation, Test 1 (8000-8010) | 2,466,461 | 3,818 (0.155%) | 31,474 | 2025-05-01 to 2025-06-30 |

- No account appears in two sets, so validation tests other customers in the same months. May overlaps the last training month and June is later than all training data. Timestamps are whole seconds [explainer/04_HOW_THE_MODEL_WORKS.md:14-24; STORY:88; OQA:65].
- Training files 1 to 100: 86,683,008 rows, 143,338 frauds, 0.1654% (measured by Waqas on 2026-10-03) [guide/parts/01_foundations.md:109-120; WEEKLY:88-99].
- Labels have exactly two classes, none missing (run-001) [OQA:71].
- About 51% of Test 1 rows are May rows inside the training period and 48.7% are June, so Test 1 is only half out-of-time [U1014:331-351].
- Because the evaluation extract starts on 1 May, early-May targets have little history: H20 strict coverage is 80.4% in evaluation against 93.6% in training; H5 is 94.2% against 98.2% [OQA:1576; OQA:1614].

### 4.4 Fraud rate and what it means

- About 1 in 600: 0.1654% in training files 1-100 and 0.155% in evaluation files 8000-8010. Yaqun's smoke splits: validation part_4950 0.151% (1,332 of 882,259); test part_8000 0.127% (290 of 228,043) [guide/parts/01_foundations.md:109-120; STORY:28; docs/fraud_detection_plan_detailed.md:149-154,160-162].
- Accuracy (about 0.998) is useless and never used. A random score has AP equal to the prevalence (about 0.0015 to 0.0016). A batch of 4,096 holds about 7 frauds, so per-batch metrics mean nothing [docs/monitoring_and_eval.md:63-64; WEEKLY:20].

### 4.5 The label and when it is known

- Label: frd_tag, binary, positive value 1, meaning the transaction was later confirmed as fraud [docs/fraud_detection_plan_detailed.md:8].
- Fraud is confirmed days or weeks later, so an account's earlier labels are unknown at scoring time. Owner: no earlier label may be an input "because, of course, of the label maturity issue"; a label can change weeks later and "dirties the results" [OQA:1944-1947; explainer/04_HOW_THE_MODEL_WORKS.md:34].
- History slots get only predictors, a time gap and a mask. predict_every_transaction uses history labels as training targets, never as inputs [OQA:2020].
- The plan for a final number is "a later, untouched cohort with mature labels" [GUIDE:1631-1636]. The exact maturity window is not stated anywhere and is on the data-owner question list [docs/monitoring_and_eval.md:87-88; OQA:24-26].
- The label-maturity concern started with the 30 July Confluence test (99% AUC from feeding labels) [CONF:10].

### 4.6 Key non-feature columns, time and ties

- transaction_dttm: the order key; orders history and gives the calendar fields; never a raw input. Type datetime64[ns] with no time zone; whether it is UTC or local is not documented [docs/fraud_detection_plan_detailed.md:8-10,70-71; OQA:2013-2014].
- Nmap_account_reference_xid: the account key that groups history; float64 with values up to 37,389,549 (exact as a float). fi_transaction_id: string; joins predictions back and breaks ties on equal timestamps. Nmap_merchant_xid: an excluded identifier [PG:46-50; GUIDE:677-688; OQA:2013-2014].
- Same-second transactions: in training files 1-10 they are 1.98% of rows but hold 6.68% of frauds (852 of 12,757), 3.37 times the normal rate [STORY:88; GUIDE:892-897]. In training file 1 alone: 2.02% of rows and 7.07% of frauds [OQA:65]. Other records round this to "about 2% of rows, 6.7% of training frauds" [STORY:87-89].
- Yaqun's plan rule is "time < target_time", but Yaqun's code ordered same-second rows by transaction id (compared as text) and let the first count as history for the second. Waqas's copies use the strict rule: a same-second transaction never sees its twin. Cost: at most 0.0094% of full-depth rows lose a slot [docs/phase4_sequential_plan.md:38; explainer/04_HOW_THE_MODEL_WORKS.md:58; GUIDE:892-897; OQA:378]. Whether transaction ids follow arrival order is unknown (owner: "i dont know") [OQA:65; OQA:1655-1666].

### 4.7 The 23 inputs (fraud/configs/predictors.csv, version 1)

- Continuous (6): transaction_amt, external_1_scr ("External score from Visa to evaluate fraud risk", 0 to 99), avlble_merch_day_cash_lmt_amt, available_daily_cash_limit_amt, remain_day_merchandise_lmt_amt, total_available_balance_amt [docs/fraud_detection_plan_detailed.md:26-66; fraud/configs/predictors.csv:3].
- Categorical, low cardinality (13): transaction_type_xcd, segment, transaction_category_xcd, transaction_pos_condition_xcd, avs_request_xcd, pos_security_xflg, transaction_pin_verify_xcd, cardholder_present_xflg, pos_card_capture_xflg, cvv_verify_xcd, authzn_rqst_crypto_valid_xflg, pos_off_premises_xflg, pos_terminal_attend_xflg [docs/fraud_detection_plan_detailed.md:26-66].
- Calendar, from transaction_dttm (4): month, day, hour, day_of_week [fraud/configs/predictors.csv:21-24].
- Plus 6 <col>_isna flags. The history model adds a time-gap continuous input (Arch A and default B: log(1 + seconds before the target transaction); strict all-position B: the gap to the latest strictly earlier timestamp in its chunk [waqas/phase4a/sequence_builder.py:314-315; waqas/phase4b/sequence_builder.py:254-259,492-509]), giving 30 tokens per transaction: 7 numeric and 23 categorical [docs/fraud_detection_plan_detailed.md:26-66; WEEKLY:77,119].
- The CSV (feature, type, source, version, description) is the single source of truth. Selection rule: known at authorisation time, low cardinality, not an identifier [GUIDE:692-712,739-740].
- These are the 19 raw fields from Sumegha's list plus the 4 calendar fields, as written on Confluence on 3 September [CONF:19].

### 4.8 Excluded fields and data-quality notes

- Excluded on purpose: identifiers (fi_transaction_id, Nmap_account_reference_xid, Nmap_merchant_xid), the raw timestamp, high-cardinality merchant, category, postal, state, network and device-IP fields (merchant id has 288,000 distinct values in two files), prior_action_db_expiration_dt, transaction_advice_xcd (95% missing), and labels of earlier transactions [docs/fraud_detection_plan_detailed.md:68-75; GUIDE:705-709].
- Highest-missing kept fields: avs_request_xcd (65%) and pos_security_xflg (82%). Run-001 found one cash-limit field missing in 96.5% of sampled training rows [GUIDE:705-709; explainer/04_HOW_THE_MODEL_WORKS.md:36].
- Month is unknown to the model for 48.69% of sampled evaluation rows, because June never appears in training (October 2024 to May 2025 is seen once). Kept as a stated V1 limit; month handling moved to V2 [explainer/04_HOW_THE_MODEL_WORKS.md:36; OQA:1004-1006].
- avlble_merch_day_cash_lmt_amt is described as "Available daily merchandise limit" but Yaqun's EDA shows values from 42,590,700 to 58,561,130, while the remaining daily merchandise limit tops out at 25,500. It is one of the 23 inputs. The question was never sent to Yaqun and stays a recorded data note [OQA:1844-1847].
- About one transaction in twenty has a value in transaction_advice_xcd; whether those rows are decisions at the time or later notices is a data-owner question. Until answered, the model scores every row and FINAL is also reported without advice rows [OQA:85].
- Location fields that exist: merchant_postal_xcd, merchant_state_xcd and cprsrvc__pisinfo_cardholder_postal_xcd. There are no coordinates. Distance features need a postal-code-to-coordinates table on the pod [OQA:966-970].

### 4.9 Preprocessing (Yaqun's design)

- Finding: the fork's handle_missing_values imputes categoricals but not continuous NaNs, so continuous NaNs are handled before fit() [docs/fraud_detection_plan_detailed.md:15-26].
- Rules: continuous median impute plus a <col>_isna flag; categorical vocabulary with 0 = UNK/OOV, 1 = MISSING, known values from 2; calendar fields categorical (sin/cos optional, unused); everything driven by YAML config [docs/fraud_detection_plan_detailed.md:79-85; fraud/data/preprocessing.py:6,14,35,76].
- Frozen artifacts are fitted once on training files 1 to 5 in full (manifest.json plus one JSON per feature), versioned, and applied identically to training, validation, evaluation and scoring. A rebuild must get a new version number. The in-memory Phase 2 baseline is the exception (it fits its own imputer) [docs/fraud_detection_plan_detailed.md:101-117; PG:121-133; explainer/04_HOW_THE_MODEL_WORKS.md:38-45; OQA:2091-2109].

### 4.10 Sets used for validation, testing and downstream work

- Yaqun's plan: smoke validation on part_4950; "larger training uses part_4950..part_5000". Yaqun's streaming config validates on part_4950 to part_4954, Yaqun's history-model config and some generic A and B configs name part_4950 only; the V1 experiment configs set history validation to part_4950 to part_4954 [fraud/configs/streaming.yaml:24-25; fraud/configs/sequential.yaml:26-27; waqas/phase4a/configs/sequential.yaml:27-28]. No config validates on files it trains on [docs/fraud_detection_plan_detailed.md:22; OQA:2111-2125].
- Evaluation: part_8000 alone (290 frauds) or part_8000 to part_8010 (3,818 frauds). Yaqun's configs default to one evaluation file; Yaqun's 11-file numbers came from an explicit override. Rule: select on validation, never on evaluation. The 11-file set was "peeked at repeatedly" [guide/parts/01_foundations.md:86-105; GUIDE:1341-1355; explainer/04_HOW_THE_MODEL_WORKS.md:128].
- V2 froze set roles named EPOCH_VAL, DEV_OOT, SELECT, DS_TRAIN/DS_SELECT and FINAL. DS_TRAIN was planned on files 5001-5010, which do not exist, so it became training files 4001-4010 [RC1015:76-79,193-218; updates_10_23_2026/M01_V2_results__through_l3.part_1.md:79-82]. A split redesign (train October to April, validate May, test June) was proposed [U1014:554-591].
- From 26 October the presentation uses [WEEKLY:88-101]:
  - Training today: files 1-10 (8,622,629 transactions, 12,757 frauds). Scale-up: files 1-100 (86,683,008; 143,338).
  - Validation: files 4950-4954 (picks the epoch).
  - Test 1: evaluation files 8000-8010 (May and June 2025), the main results so far and every future test.
  - Test 2: the 952,905 transactions TFM V22B was evaluated on.
  - Holdout: evaluation files 8206-8216 (2,504,003 transactions, 4,187 frauds), used for the seed check's second reading and for feature selection.
  - Downstream embedding work: training files 4001-4010 to fit downstream models and evaluation files 8217-8227 to test them (accounts the model never trained on) [WEEKLY:420-425].
- Owner (26 October): "realistically we only need epoch val and dev oot right?" [OQA:404-516].

### 4.11 How models are scored

- PR-AUC (scikit-learn average precision, valid_ap and eval_ap) drives model selection. ROC-AUC is reported but not used for decisions (it sits near 0.93 to 0.95 for every model). Both are computed once over the complete split, never per batch (StreamingBinaryMetrics in fraud/callbacks.py). Early stopping and checkpointing watch valid_ap with patience 5; best.ckpt is the best epoch [docs/fraud_detection_plan_detailed.md:23,147,160-162; docs/phase3_streaming_plan.md:52-63; PG:421-446].
- "AP around 0.14 is not 14% accuracy or recall. It is a ranking summary" (ChatGPT audit). Precision and recall at alert budgets (0.1%, 0.5%, 1%) should be shown beside AP [explainer/04_HOW_THE_MODEL_WORKS.md:104,114; guide/parts/01_foundations.md:124-180].
- Comparisons get a range by resampling whole accounts (account-clustered bootstrap) [explainer/04_HOW_THE_MODEL_WORKS.md:97; U1014:595-696].
- DR, VDR and FPR at 0.006 have not been computed for this project because their exact definitions were never obtained from Xinyu or the LoB [U1014:405-418; bridge/reviews/CL/2026-10-20-end-to-end/COVERAGE.md:13,67].

### 4.12 Feature sources available for the next model

- TFM V22B feature-importance workbook: the V22B sheet only, 120 rows, matching feature_importance.csv [OQA:2021; waqas/features/feature_importance_v22_v17_highlighted/README.md:15-29].
- Model 15298: 94 ranked features and a crosswalk (section 2.1).
- LoB metadata: "meta data ALL features provided by LoB.xlsx", about 714 rows in columns A:G with an MIFM_feature flag; rows 124-248 and 249-600 typed into waqas/feature_related/ in batches; the meaning of MIFM_feature is not documented [waqas/feature_related/part_124_248/README.md:1-25; waqas/feature_related/part_249_600/README.md:1-15; CJ:169-178].
- The company PFM feature list that the owner said would be provided: not received in the sources [OQA:816,847-860].

## 5. Yaqun's handoff

### 5.1 Phase 0: choosing the model (before 3 September)

- Benchmark on the public UCI Bank Marketing dataset (45,211 rows, about 12% positive), on OCP GPU, NVIDIA H200 144GB, PyTorch 2.13.0+cu130, Python 3.12.9, 10 epochs: SAINT (intersample) AUROC 0.822, SAINT_S 0.851, CategoryEmbedding MLP 0.921, FT-Transformer 0.935 (138K params) [docs/tabular_transformer_models.md:1-30,95-116; CONF:19].
- "No hyperparameter tuning was performed"; results are "directional". Recommendation: "Use PyTorch Tabular with FT-Transformer for production." [docs/tabular_transformer_models.md:95-116].
- Why fork: the sequential model needs changes to the backbone, tokenizer, datamodule, masking, input shape and data loading that "cannot be achieved through configuration or subclassing" [docs/fraud_detection_plan_overall.md:30-43].
- What the fork really is: unmodified upstream pytorch_tabular v1.1.0 plus the stacking model from upstream main. src/pytorch_tabular/models/ft_transformer_seq is an empty placeholder with a TODO. The history models were written from scratch with nn.TransformerEncoder; only the single-transaction models (Phases 1 to 3) use the library's FTTransformerModel. Audits found Yaqun's streaming code needs a field that first appears in pytorch_tabular 1.1.1 [README.md:9-12; PG:107-119; GUIDE:121-124,1377].

### 5.2 Phases 1 and 2 (smoke test, 3 September)

- Phase 1: lock predictors, write predictors.csv v1, derive calendar fields, build artifacts [docs/fraud_detection_plan_detailed.md:77-93].
- Phase 2 smoke on an H200, 1 epoch: train part_1 and part_2 (1,676,127 rows), validation part_4950 (882,259), test part_8000 (228,043); FT-Transformer about 142K params (input_embed_dim 32, 8 heads, 3 blocks), AdamW weight_decay 1e-5, batch 256. Validation ROC-AUC 0.9275, AP 0.1051; test ROC-AUC 0.9521, AP 0.0940 (about 60 to 75 times chance). score_eval.py re-scored part_8000 from the saved model and reproduced 0.9521 / 0.0940, showing no train/eval preprocessing drift [docs/fraud_detection_plan_detailed.md:129-158; STORY:18].

### 5.3 Phase 3: streaming (8 and 9 September)

- Streaming IterableDataset reads parquet in 65,536-row blocks, applies the frozen artifacts, shuffles rows within the block, 4 workers; model built by hand-constructing InferredConfig; Lightning trainer; full-stream valid_ap [docs/phase3_streaming_plan.md:1-46].
- 8 September smoke: 10 files, 2 epochs, valid AP 0.1085, AUROC 0.9414; streaming score on part_8000 AP 0.0732, AUROC 0.9479 [docs/phase3_streaming_plan.md:1-46].
- 9 September scaling: 10 files 10 epochs 0.1131 (epoch 7); 100 files early-stopped 0.1247 (epoch 2), AUROC 0.9493. Evaluation on part_8000 to 8010 (2,466,461 rows, 3,818 positives): AUROC 0.9514, AP 0.0940 with shuffle; 0.9508 / 0.0923 without [docs/phase3_streaming_plan.md:13-46].
- Findings: in-block row shuffling is decisive (without it, batch 512 collapsed to about 0.5 AUROC); more data helps modestly; metrics plateau at epochs 2 to 5 with loss about 0.008, read as "feature-limited"; "Next lever: Phase 4 transaction history." Out of scope then: Phase 4, global shuffling, class weighting by default [docs/phase3_streaming_plan.md:52-63,90-94].
- Two separate AP 0.0940 results exist: the 3 September in-memory baseline on part_8000 alone (290 frauds) and the 9 September 100-file streaming model on part_8000 to 8010 (3,818 frauds). The guide treats "0.0940 (11 files)" as Yaqun's comparison number [docs/fraud_detection_plan_detailed.md:149-152; docs/phase3_streaming_plan.md:13-15,30-35; GUIDE:1047]. One explainer page lists which one is meant as not recorded [STORY:124].
- Yaqun's evaluation results on files 8000-8010 as later verified: single-transaction 10 files 0.0792; single 100 files 0.0940; flat H5 10 files 0.0871; flat H5 100 files 0.0965 [RC1015:81-96].

### 5.4 Phase 4: transaction history (plan 25 September, first result 28 September)

- Plan status "planning (2026-09-25). No code yet." Sample: target = txn[i], history = the N strictly prior transactions of the same account, N = 5, stride 1, never skip a fraud target; left-pad short histories with PAD and a mask; same 23 frozen-artifact features plus a time delta; no historical frd_tag; flat architecture A first (hierarchical B documented for later); transaction-level position embedding only; attention bidirectional by default, causal optional; moderate capacity (embed 48 to 64, 4 blocks) then a sweep; window shuffle buffer across many accounts; train_stride may exceed 1, eval_stride always 1; bf16-mixed, start batch about 4096, watch nvidia-smi. Sequence about 180 tokens. Success test: "Phase 4 succeeds if it clears that ceiling" (about 0.125 validation, 0.094 evaluation). Verification: smoke, parity and lift, ablations (history 0 against 5, time delta on/off, bidirectional against causal), leakage check [docs/phase4_sequential_plan.md:1-48,60-118,205-214; docs/phase4_design_decisions.md:1-33].
- Implementation: fraud/data/sequence_builder.py builds windows (T = N + 1, target last, time_delta = log(1 + seconds before target)); fraud/sequential_model.py is the flat model (30 tokens per slot, CLS first, 4 pre-norm blocks, 181 tokens at N = 5). The plans speak of SEP tokens but the model has none (a naming difference, not a defect). notebooks/sequence_smoke.ipynb checked 28,054 windows from 30 accounts against a manual rebuild [docs/phase4_sequential_plan.md:287-296; PG:169-212].
- First result (28 September, H200): history 5, 10 files, validation 4950-4954, best valid_ap 0.1293 (epoch 5), AUROC 0.9509, against 0.1131 single-transaction at the same scale and 0.1247 at 100 files [STORY:22; docs/phase4_sequential_plan.md:287-296].
- Deferred: hierarchical architecture B; causal "predict every transaction at once"; historical frd_tag only if label availability at inference is confirmed; longer histories [docs/phase4_design_decisions.md:35-40].
- Open items A to G ("The N=5 lift over the single-transaction baseline is real but modest"): A scale data (100 to 200 to 500+ files, grow validation too); B longer history (N 5 to 20, "the main sequence lever"); C bigger network (more blocks, wider embed, lower LR plus warmup); D more and richer features, high-cardinality fields with hashing or frequency or target encoding; E tune pos_weight; F architecture (account pooling, two-level design, block-causal predict-every-transaction); G hyperparameter sweep and feature-importance ablation. He notes the pod has 1 GPU [docs/phase4_sequential_plan.md:238-284].

### 5.5 What was handed over, and when

- Handover set: fraud/ (loaders, preprocessing, SequenceBuilder, streaming and sequential models, callbacks, train/score/build/progress scripts, configs including predictors.csv), src/pytorch_tabular/ (the fork), docs/ (seven plans), tests/test_preprocessing.py (6 tests), notebooks/eda.ipynb and notebooks/sequence_smoke.ipynb [PG:105-220].
- Yaqun's documents are dated 3 to 28 September. "No commits exist for them, because the repository did not exist yet." The GitHub repository was created from his files on 1 to 2 October [STORY:12,38-39]. The explainer gives two commit ranges for that: 60f9f89 to eabee6d, and 64cce77 to 05092b2 [STORY:12; explainer/01_ONE_PAGE.md:17].
- Yaqun's pod instructions: project root ~/k016730/projects/tabular_fraud, environment via "source ~/k016730/scripts/setup_gpu.sh", "git pull" first; preprocessing artifacts built once on a CPU pod; treat the GPU as shared (check nvidia-smi first) [docs/monitoring_and_eval.md:8-9,128-147; docs/phase4_sequential_plan.md:215-234].
- Seed 42 is Yaqun's seed (fraud/configs/sequential.yaml:67, fraud/configs/streaming.yaml:58) [OQA:1439].
- Yaqun "leaves on Friday" (9 October) and is "out of office for a while" [OQA:1896-1899; OQA:1844-1847]. Owner: "no, Yakun didn't say anything else. Everything else is in the thing, in the notes." [OQA:1974-1975].
- A list of eleven questions for Yaqun was drafted (label maturity window, external_1_scr timing, file partitioning, the REF-SINGLE recipe and others) and held "for when he is reachable" [bridge/plans/CL/2026-10-09-roadmap/sweep/owner-side.md:59,67].
- Known stale points in Yaqun's material: README.md:44-52 still says Phase 2 is "Coming Soon" and links to ../saint/docs/fraud_detection_plan.md, which does not exist; docs/fraud_detection_plan_overall.md:12 links to benchmark_results.md, but the file is docs/tabular_transformer_models.md [README.md:44-52; docs/fraud_detection_plan_overall.md:12].

## 6. Infrastructure

### 6.1 The pod and the GPU

- Work runs inside the bank on a GPU pod on Red Hat OpenShift AI. The pod has no GitHub connection: the owner uploads the files the assistants provide and returns complete result files [OQA:1901-1906; explainer/07_RUNNING_ON_THE_PODS.md:3,132].
- One NVIDIA H200 GPU (143,771 MiB; owner: "one gpu, one run at a time; we have memory of like 132 gb or so"; budget confirmed "9. 1 GPU." on 19 October). Each training run uses one device [OQA:1840-1842; OQA:1084; OQA:604-606; OQA:1501].
- No GPU-hour limit (owner: "I don't have like a limit for GPRs.") [OQA:1891-1894].
- Project folder /home/jovyan/k194855/tabular_fraud; Python environment /home/jovyan/k194855/tabular_fraud_s3_venv_FAIfNI ($PY in runbook/v2/RUNBOOK.md); pip install works on the pod [OQA:83; OQA:95; OQA:2466].
- Measured run times on older code: A h10 4.9 GPU hours, A h15 9.7 GPU hours (6 October). V1 was planned at about 65 to 68 GPU hours [STORY:30,40; OQA:1307].
- The TFM work used a separate shared pod, LEW-extrasmall-6, under /home/jovyan/k194855/TFM/Validation/V22B/Reproduction, with shared storage "MAN41 PVC" and a "LEW41 change window" ending 20 September [PKG:144-157,204-213; RERUN:529].

### 6.2 How files move

- The assistants build a reviewed, numbered ZIP. Public copies go to AliKashy/ICLProjectFr under tf/releases/, with placeholders where the owner's values go; private release records sit in bridge/releases/ (tf-stage1-v0.1.0/, tf-v1.0.0/, tf-v1.0.1/, tf-v2.0.0/, each with package/ and returns/) [OQA:2313; OQA:2336; OQA:894-900].
- On the pod the owner runs personalize.py, which fills in the owner's real values (ID K194855, reference ID K016730, data bucket, artifact bucket, package name waqas) [OQA:735-740; OQA:894-900].
- A manifest of file fingerprints (github_source_manifest.csv) records, at the time of each check, which covered files match the reviewed code and which differ (original-source differences are warnings). It does not prove that all current pod code equals the reviewed code [runbook/2026-10-07/preflight_pod.py:476-500; updates_10_23_2026/M01_V2_results__through_l3.part_1.md:43-59] [explainer/07_RUNNING_ON_THE_PODS.md:45; DLOG:27-29].
- Stages: pre-flight (read-only checks: tests, manifest, columns, dates, duplicates, same-second ties, history depth, versions, artifact fingerprints; no GPU test), smoke, the runs, then analysis on the pod that returns totals only. "A stage is done when its return has been read." Long commands use setsid nohup [explainer/07_RUNNING_ON_THE_PODS.md:1-61,104-140].
- Model files (*.ckpt) and prediction files (*.parquet) stay on the pod; everything else comes back [explainer/07_RUNNING_ON_THE_PODS.md:18,114]. From 24 October row-level files may be shared for review when a check needs them [OQA:560].
- Packages so far: 001 replaced by 002 (12 October, pre-flight); 004 (12 October, from d4205d4); 005 (13 October, from 96ed240, installed in place, used for V1); 006 (14 October, its 100-file steps postponed); 007 and 008 (20 October; 008 never installed); 009 (21 October, 009_20261021_180056_UTC from 60232e9, SHA-256 ending 8d09), the first V2 package on the pod, used for L2, L3 and the seeds; 010 rehearsed 22 October; pod reorganisation package pod_reorg_20261027 (v3 in ICLProjectFr tf/releases/pod_reorg_20261027_v3.zip with tf/POD_REORG.md, commit 42fd162) [OQA:2336-2345; OQA:2444; CJ:89-106,194-201; OQA:935-941,750-756,791-797,582; OQA:188-194].
- Runbook: runbook/v2/RUNBOOK.md is the one end-to-end runbook (steps 0, 1a to 1g, 2, 3 and on to 9). It stays on GitHub; Claude gives each command in chat [OQA:24; OQA:678-684].
- Copilot on the work laptop reviews packages before upload; personalisation is done on the pod, not on Windows [OQA:694-748].

### 6.3 Repositories, folders and coordination

- AliKashy/tabular_fraud (private; 3,259 files, 27.9 MB on 26 October): the project. AliKashy/MRM_1 (194.7 MB): the TFM validation work with the Confluence export. AliKashy/ICLProjectFr (public): numbered ZIPs and public question and answer pages under tf/ [OQA:278; OQA:480; OQA:692; OQA:2313].
- MRM_1 layout: confluence/, project_communication/, supplied_files/ (Developer code, read-only), claude/, ChatGPT_OpenAI/, my_notebooks/FineTune_Rerun/ (report in .md and .docx, figures, Visuals/Metrics.ipynb), the deck in the root [MRM_1/ChatGPT_OpenAI/README.md:11-14; MRM_1/claude/README_claude.md:9-17; MRM_1/my_notebooks/FineTune_Rerun/README.md:1-42].
- tabular_fraud layout: Yaqun's folders fraud/, src/, root tests/, pyproject.toml and requirements.txt are not edited, apart from the approved two-line exception in section 7.5 (a repository change; it does not show the pod has the same change); Waqas's code and all fixes live under waqas/ (corrected copies in waqas/base/); bridge/ holds coordination (OWNER_QA.md, DECISIONS.md, plans/, reviews/, releases/, memory/); claude/ and chatgpt/ are frozen audits with corrections in bridge/errata/; guide/, explainer/ and code_tour/ explain the project; runbook/ holds pod instructions [OQA:75; OQA:1142-1150; GUIDE:49-50; CLAUDE.md:4].
- Coordination: GitHub issue #7 is the coordination and results log; draft PRs #13 ([INBOX to CL]) and #14 ([INBOX to CH]) wake each assistant; both assistants use Waqas's GitHub account [explainer/09_HOW_THE_TEAM_WORKS.md:19,86-95; OQA:1225-1238].
- The 1 November Copilot setup lives in 11_01_2026/ at the root of tabular_fraud main (COPILOT_PROMPT.md, README.md, request_1 to request_4, COPILOT_UPLOAD). The owner's new Copilot chat is in "tab_fraud_reorg" [OQA:2605-2637; CJ:307].

## 7. Work done since the handoff (summary)

### 7.1 Waqas's own work before V1 (early October)

- Rule from Waqas's roadmap: "Yaqun's base in fraud/ is never edited. Anything I changed is duplicated into my phase folders" [PG:226-234; OQA:1866].
- Five levers: architecture (A flat against B hierarchical), input representation (linear against periodic numeric embedding), context (history 5, 10, 16; time encoding), training recipe (optimizer, EMA, sampling), pretraining (scratch, masked autoencoder, supervised contrastive) [PG:224-345].
- Phase 4a: flat model with periodic embedding option, optimizer factory, EMA callback, unused Optuna tuner, sweep driver run_ablations.py. Phase 4b: hierarchical FTTransformerHierModel (2 transaction-level plus 4 sequence-level blocks, embed 48); sweep started 2026-10-04 23:09. Phase 5: masked autoencoder, SupCon, finetune, embedding export; no result. Scoring toolkit: calibrate_and_report.py, ensemble.py, leaderboard.py, temporal_eval.py. 22 offline tests [PG:224-345; GUIDE:932-1011].
- Pre-fix sweep results (now "history only"): history 5 finder winner linear + bidirectional + AdamW, valid AP 0.1365 (eval 0.0893 on part_8000 only); linear beat periodic in all four pairs by about 0.008; h10 0.1399; h16 0.1383 (eval 0.1171, one file); h5 at 100 files 0.1416; reproduction of Yaqun's h5 0.1333 against his 0.1293. Marked "Superseded (2026-10-07)" [PG:254-289; GUIDE:66-91,1015-1075].

### 7.2 Audits (5 October) and fixes (6 October)

- Both assistants independently found: (1) loader sharding defect: with 4 workers and shuffling, each worker shuffled the file list on its own, so about a third of training files were skipped each epoch and others read twice; (2) the "causal" mask leaked through CLS from layer 2 (the default bidirectional mask is unaffected); (3) SupCon loss paired wrong rows with labels; (4) the masked autoencoder could not tell two hidden numeric fields apart; (5) sweep evaluation used one file; (6) each sweep run overwrote the previous prediction file; (7) smaller items (EMA checkpoint, pyproject.toml typo, vendored library one version old, loss column is the last mini-batch) [GUIDE:93-124].
- Fixed on 6 October in Waqas's copies (GitHub 24fa955, main 3e21773): shared deterministic file shuffle before worker slicing, causal mask, padding NaN, EMA timing, runner precedence and run-name forwarding, per-run prediction files, evaluation range 8000-8010. SupCon and autoencoder fixes were not applied (Phase 5 parked) [GUIDE:1417-1430; STORY:48,53-55; Update Overview/Changes Made - 2026-10-06 11-02 AM ET.md:1-189].
- A later 104-finding register (4 blockers, 24 major, 46 minor, 30 small) ranked every reviewer finding [STORY:69-73].

### 7.3 V1 (12 to 14 October)

- Definition: Yaqun's code with all corrections at longer histories; find the best architecture (A or B) and history length. 15 runs, seed 42: REF-SINGLE, A-H00, A-H05, A-H10, A-H15, A-H20, B-H00, B-H05, B-H10, B-H15, B-H20, B-ALLPOS-H5, A-MASK05-C, A-GAP05-OFF, A-GAP10-OFF [explainer/01_ONE_PAGE.md:13-23; explainer/04_HOW_THE_MODEL_WORKS.md:53,87-102].
- Recipe: AdamW LR 3e-4, weight decay 1e-5, up to 10 epochs, patience 5, batch 4,096 (smaller pieces adding to the same total at long history), bf16, pos_weight 1.0. REF-SINGLE is Yaqun's Phase 3 model (size 32, 3 layers, batch 8192, LR 0.001, files 1-100 in his original) retrained through the corrected loader [explainer/04_HOW_THE_MODEL_WORKS.md:87-102; OQA:1550-1553].
- Results (Test 1 AP): B-H20 0.095465, B-H15 0.095459, A-H15 0.092822, REF-SINGLE 0.092476, A-H20 0.0817, B-H05 0.0674; B-ALLPOS-H5 0.092670 scored on chunks and 0.093420 scored on sliding windows [CJ:45-57; OQA:944-956; OQA:423].
- Reading: the leading history models were not resolved against REF-SINGLE (leaders +0.0003 to +0.0030 AP); A-H05 was worse than REF-SINGLE (AP 0.0728 against 0.0925, difference -0.0197, account-bootstrap interval -0.0276 to -0.0127, one seed) [waqas/results_from_pod/v1_results_2026-10-13/reviewer_update_v1/analysis_outputs/paired_report_finalist.md:85-95]; history 5 did poorly; history 10 beat 5; A and B not told apart; long history against no history was never tested; finalist picks used evaluation AP against V1's validation rule; validation AP predicts evaluation AP poorly (rank correlation 0.114); B-H15 and B-H20 are provisional because scripts never linked their scores to saved models [explainer/01_ONE_PAGE.md:23; CJ:135-167].

### 7.4 V2 (from 14 October) and the chosen model

- V2 definition: more training data ("100+" files), new optimizers, new features known at the moment of the transaction [explainer/01_ONE_PAGE.md:21].
- Results through L3 and the seed runs were uploaded on 23 October (updates_10_23_2026/) and reviewed in bridge/reviews/CL/2026-10-24-results-l3-seeds/ [OQA:550-568].
- Seed check, Test 1 AP [WEEKLY:22-44]:

| Seed | Arch B H20 chunk (ALLPOS-H20-CHUNK) | Arch B H20 sliding (default B-H20) | Difference |
|---|---|---|---|
| 42 | 0.1020 | 0.0955 | +0.0065 |
| 43 | 0.0912 | 0.0743 | +0.0169 |
| 44 | 0.1013 | 0.0753 | +0.0261 |
| Mean (SD) | 0.0982 (0.0061) | 0.0817 (0.0120) | +0.0165 |

- AUROC was ahead for chunk at seeds 43 and 44 and behind at seed 42 (0.9431 against 0.9520) [WEEKLY:32-44].
- Holdout (files 8206-8216), chunk against sliding: seed 42 (June rows, 1,215,218 transactions, 2,081 frauds) 0.1103 vs 0.0928; seed 43 (full files) 0.1001 vs 0.0666; seed 44 0.0995 vs 0.0756 [WEEKLY:46-54].
- At seed 42, ALLPOS-H20-CHUNK beat the same design trained on sliding windows (ALLPOS-H20-SLIDE, a separate fit, not Arch B H20 sliding): 0.1020 against 0.0743. Context, grouping and gradient aggregation change together, so this does not show which of them causes the difference; the gap +0.028 has a 95% range of +0.017 to +0.038 from resampling whole accounts 1,000 times [WEEKLY:56-67].
- On 24 October the owner took ALLPOS-H20-CHUNK as the winning model; on 26 October it was presented as "Final model: Arch B H20 chunk" [OQA:550-560; WEEKLY:6-8].

### 7.5 How much of Yaqun's code changed

- From 25e1165 to PR #3 0d727d8: Yaqun's folders changed in 2 lines of 1 file, the approved feature__ fix in fraud/data/preprocessing.py lines 203 and 215. In waqas/: 37 of 84 files edited, 17 moved (phase5_pretrain to future_experiments/pretrain), 57 new. Model designs and training settings unchanged; edits are the strict history rule, the all-position fix, run bookkeeping, checks and reporting [OQA:1348-1351].
- The full list of changes is in bridge/plans/CL/2026-11-01-changes-to-yakun/CHANGES_TO_YAKUN.md [OQA:121-153].

## 8. Timeline, 28 July to 1 November 2026

| Date | What happened | Source |
|---|---|---|
| 2026-05-15 | Date of the TFM presentation referenced by COM-001 (FrontierAI) | PKG:54-67 |
| 2026-07-28 | First Confluence entry: meeting with Sumegha on the TFM built by MMR | CONF:9 |
| 2026-07-30 | Xinyu's TFT trial on old Visa data gets 99% AUC through label leakage | CONF:10 |
| 2026-07-31 | GPU coordination meeting with Joel; Xinyu and Waqas get GPU access | CONF:11 |
| 2026-08-04 | Xinyu walks Waqas through Chronos-2 and the fraud-label input problem | CONF:12 |
| 2026-08-05 | Two-hour TFM code walkthrough in Teams (COM-002) | PKG:69-82 |
| 2026-08-17 | First ICL results; raw-data copy email (COM-003); transaction_dttm chat (COM-004) | CONF:13; PKG:84-112 |
| 2026-08-18 | Best v22b uses the last 17 transactions (COM-005) | PKG:114-127 |
| 2026-08-19 | Operational history retention (COM-006) | PKG:129-142 |
| 2026-08-21 | ICL update with meta features and account history | CONF:14 |
| 2026-08-24 | Waqas's ICL framework (best ROC AUC 0.8867); GPU pod LEW-extrasmall-6 handed over (COM-007) | CONF:15; PKG:144-157 |
| 2026-08-27 | ICL with 100 and 200 examples; Xinyu and Waqas assigned to review the TFM; Yaqun runs SAINT and finds pytorch-tabular | CONF:16-17 |
| 2026-08-31 | ICL stops; TFM review scope set; files 5001-7999 confirmed unused (COM-008); repository identified (COM-009); Xinyu's reply on the data email | CONF:18; PKG:159-187; DATAEMAIL:1-29 |
| 2026-09-01 | No training notebook exists (COM-010) | PKG:189-202 |
| 2026-09-02 to 09-03 | Shared storage clean-up request (COM-011) | PKG:204-213 |
| 2026-09-03 | Yaqun's benchmark; FT-Transformer chosen; 23 predictors; Phase 2 smoke; Xinyu's workflow summary | CONF:19-20; docs/fraud_detection_plan_detailed.md:129-158 |
| 2026-09-04 | "Model Replication Data" email; Waqas added (COM-012) | PKG:215-228 |
| 2026-09-08 | v30 and v22b roots and v22b leakage warning (COM-013); v22b first (COM-014); Yaqun's streaming validated | PKG:230-258; docs/phase3_streaming_plan.md:1-46 |
| 2026-09-09 | Workflow summary access fixed (COM-015); Yaqun's Phase 3 scaling, "feature-limited" | PKG:260-273; docs/phase3_streaming_plan.md:52-63 |
| 2026-09-19 | Supplied TFM files uploaded to MRM_1 | git log of AliKashy/MRM_1 |
| 2026-09-20 | TFM deck, Claude's and ChatGPT's MRM_1 guides added; LEW41 change window ends | git log of AliKashy/MRM_1; RERUN:529 |
| 2026-09-21 | TFM v22b rerun and fine-tuning comparison report | RERUN:5-37 |
| 2026-09-22 | Last date of the "Model Replication Data" thread span | U1014:595-696 |
| 2026-09-25 | Yaqun's Phase 4 design discussion and plan | docs/phase4_design_decisions.md:1-33 |
| 2026-09-28 | Yaqun's first history result, valid_ap 0.1293 | STORY:22 |
| 2026-10-01 to 10-02 | tabular_fraud GitHub repository created from Yaqun's files | STORY:12 |
| 2026-10-03 | Waqas measures fraud rates; a laptop session copies pytorch_tabular 1.1.0 into src/ | STORY:28; OQA:58 |
| 2026-10-04 | Waqas's Current Standing document; B sweep started 23:09 | STORY:29; GUIDE:932-1011 |
| 2026-10-05 | Two independent audits; bridge/ created; meeting notes sections 1-6 | STORY:47-50; MN:1-100 |
| 2026-10-06 | Fixes applied on the pod; A h10 and h15 rerun; meeting with Xiaoming and Yaqun; 2 pm meeting with senior quants scheduled (outcome not recorded) | STORY:53-55; MN:104-202; bridge/threads/001-guide.md:3-12 |
| 2026-10-07 | Run protocol; shared OWNER_QA file; learning guide assembled 01:06 UTC | STORY:58-62; GUIDE:1-5 |
| 2026-10-08 | Never edit Yaqun's folders; one GPU, one run at a time; Yaqun out of office | STORY:64-67 |
| 2026-10-09 | Reviewer sessions; 104-finding register; Phase 5 parked; Yaqun's last day | STORY:69-73 |
| 2026-10-10 | Joint roadmap draft (D-009) | STORY:76 |
| 2026-10-11 | Yes to fixes; pre-flight first; issue #7 opened | STORY:80-83 |
| 2026-10-12 | run-001 pre-flight; V1 and V2 defined; Xiaoming's best-practice email; Monday review; V1 code merged (PR #15); package 004 | STORY:86-102; XEMAIL:1-24 |
| 2026-10-13 | V1 runs (package 005); Jie Chen's reply relayed; LoB field list; 15298 list promised | STORY:112-117; OQA:2506-2516 |
| 2026-10-14 | V1 finished; package 006; owner asks for a sweep first; auditor opened; Confluence results read; email to Nengfeng | explainer/01_ONE_PAGE.md:23; U1014:23-24 |
| 2026-10-15 | Xiaoming's emails 1 and 2; reviewer handoff; data facts D1 to D7 recorded | U1014:554-806; RC1015:1-60 |
| 2026-10-16 | Nengfeng's reply: feature-store direction | U1014:808-849 |
| 2026-10-19 | Team reorganised; delegation to Claude with ChatGPT; features chat | OQA:1010-1123 |
| 2026-10-20 | One end-to-end runbook; data-owner questions; packages 007 and 008 | OQA:918-942 |
| 2026-10-21 | PR #26 fixes, PR #28 feature store; package 009; PFM feature-list relay; Shaunak question | OQA:694-820 |
| 2026-10-22 | Owner's staged programme; seeds for the leaders | OQA:616-642 |
| 2026-10-23 | Results through L3 and seed runs uploaded | OQA:550-560 |
| 2026-10-24 | ALLPOS-H20-CHUNK taken as the winning model | OQA:550-560 |
| 2026-10-25 | Meeting preparation pack | OQA:530-536 |
| 2026-10-26 | Weekly presentation prepared; 2 pm senior-quant meeting scheduled (outcome not recorded); Test 2 defined; 166 features proposed | WEEKLY:1-165; OQA:404-536 |
| 2026-10-27 | D-012 embedding uses; month decision; pod clean-up first; Gemini withdrawn | DEC:155-182; OQA:171-270 |
| 2026-10-28 | Code tour published | OQA:155-161 |
| 2026-11-01 | Spelling Yaqun; full rundown; Copilot recovery prompt; Request 4 (this background pack) | OQA:121-153; OQA:2605-2637 |

## 9. What the Confluence page says, entry by entry

The MRM_1 export is 132 lines. Dated updates are at lines 9 to 20; the standing sections follow from line 24.

Dated updates
- 28 July (line 9): "Meeting with Sumegha to discuss the TFM developed by MMR" (with Nengfeng, Xiaoming, Xinyu, Waqas). "MMR is organizing the repo, and we will be ready to get access soon." "It will take time for TSFM installation as security and other checks are going." [CONF:9].
- 30 July (line 10): "Xinyu completed one testing trial of TFT model with old Visa credit card data (training: 2022-07 - 2022-08, valid: 2022-09, OOT: 2022-10)". All accounts with fraud kept, accounts without fraud downsampled to 2%; the fraud label used as a feature "unknown variable in prediction"; "Obtain 99% AUC in OOT data." "Data leakage issue exists since a target transaction cannot see a finalized fraud label at the un-maturated time point. We need a better design of how to input the fraud label." [CONF:10].
- 31 July (line 11): "Meeting with Joel about GPU resource coordination (participant: Joel, Sandhya, Xiaoming, Xinyu, Waqas)". "Xinyu and Waqas have GPU access now." [CONF:11].
- 4 August (line 12): Xinyu and Waqas catch-up; Xinyu goes through Chronos-2; discussed the fraud-label issue "for an input design to transformer model" [CONF:12].
- 17 August (line 13): Xinyu shared initial ICL results with Xiaoming: vectorised transaction data turned into text for LLM in-context learning on transaction-level downsampled debit-card data (202410 to 202507); balanced few shots; "No account history information." Downsampled OOT "KS: 0.5889, AUC: 0.8718, DR@15%: 0.7195". Next: only metadata in the text; add account history "but do not include the label of history transactions due to label maturity issue." [CONF:13].
- 21 August (line 14): 10 meta features as sentences; history from the previous 5 to 10 transactions; 20 few-shot examples in four groups of 5. "KS: 0.3649, AUC: 0.7272, DR@11% (fraud rate): 0.3364, VDR@11% (fraud rate): 0.4293". Next: more examples up to the token limit, more meta features [CONF:14].
- 24 August (line 15): Waqas's ICL framework: prompts P0 to P3; feature families "F0: 94 engineered features" and "F1: five available natural transaction features"; retrieval D0 (deterministic pseudo-random), D1 (cosine), D2 (Euclidean); Low (1 and 1) and High (10 and 10) demonstration policies; representations R0 (natural language) and R2 (JSON); "over 96 different possible configurations". Best: "P3 and the engineered feature set: ROC AUC 0.8867, KS 0.6394, and PR-AUC 0.5804". Next: "Use TFM data for future experiments", keep the framework, vectorise tabular data, 10x more examples, account history, run the grid, "Research on updated list of Tabular Foundation Models" [CONF:15].
- 27 August, Xinyu (line 16): 100 or 200 training examples in the prompt plus more meta features and the VAA score. On 6,102 transactions: 100 examples "5668 valid outputs, KS: 0.5831, AUC: 0.8524, DR@11% (fraud rate): 0.4325"; 200 examples "5093 valid outputs, KS: 0.5983, AUC: 0.8561, DR@11% (fraud rate): 0.4306". "The current model gemini-2.5-pro may not be well configurable with long prompt." "100 can be a bottleneck". VAA alone "KS: 0.6952, AUC: 0.8946, DR@11%: 0.6815. The result is reasonable given VAA was trained on much more data size." Next: batch mode; "Xinyu and Waqas will review the in-house fine-tuned TFM, with special attention to feature leakage issues." Sent to Xiaoming, Yaqun and Hanyu [CONF:16].
- 27 August, Yaqun (line 17): "Migrated the SAINT code to run on OCP using CPU. Successfully ran the model training for 1 epoch on its example bank data (Only 1 epoch because it is slow with CPU)." "Found a package pytorch-tabular which is well-maintained and implements several deep NN models for tabular data including FT-Transformer. Confirmed it can be installed on OCP." Next: "Explore more one these models using MMR's model 15298 data when GPU is available." [CONF:17].
- 31 August (line 18): batch-mode ICL: "Out of 6102 transactions, there are 4400 transactions with valid output score, worse than individual prediction"; one invalid output voids the whole prompt; "overall performance is similar". "Xinyu and Waqas will focus more on transaction foundation model": review code and architecture; review fine-tuning (full, LoRA) and replicate; analyse any transaction-level downsampling; "Examine potential data leakage issues"; investigate how the model adapts to new features (how the token is created); review hyperparameters and random seed settings; check special neural-network techniques and "Quantify it by how much uncertainty it introduced to model output"; "Review the NN architecture for potential data leakage issues"; "Explore possible ways to explain the contribution of each feature on the score or embedding results." [CONF:18].
- 3 September, Yaqun (line 19): GPU environments for "SAINT and Pytorch-Tabluar packages" (source spelling). 10-epoch results on SAINT's public bank data: SAINT (intersample) AUROC 0.822, loss 0.491, 66.9K params, 33 it/s; SAINT_S 0.851, 0.468, 40.8K, 55; CategoryEmbedding (MLP) 0.921, 0.212, 15.5K, 112; FT-Transformer 0.935, 0.199, 138K, 68. "FT-Transformer has the best performance. The intersample attention of SAINT doesn't help much but makes the model slow." "Pytorch-Tabular's code is better structured and implemented." "We may want to focus more on FT-Transformer model and fork the Pytorch-Tabular code for our internal fraud model development." First predictor list "(from Sumegha) with 19 transaction-level raw variables that are either continuous or low-cardinality categorical variables. Also, derived four variables from transaction time: month, day, hour, and day-of-week. So totally there are 23 predictors". "Numerical: median-impute + _isna flags; Categorical: adding two categories, 'UNKNOWN/UNSEEN' and 'MISSING'." The next-plan items for this entry are not in the export [CONF:19].
- 3 September, Xinyu (line 20): "Xinyu summarized TFM workflow, see the document." "The document is on the share folder and can be continuously modified." [CONF:20].

Standing sections
- Overview and focus: "This project evaluates and applies foundation models (TSFMs / transformer-based models) for fraud detection." Focus: "Multi-series fraud modeling (accounts, transactions, entities)", "Fine-tuning pre-trained models on fraud data", "Building a reproducible environment for development and validation". Objectives: "Identify suitable foundation models for fraud use case", "Develop a fine-tuning pipeline", "Establish a consistent environment (GCP / PyFARM)", "Benchmark performance vs existing models" [CONF:24-41].
- Candidate models: Chronos "best overall (multi-series + covariates)"; TimesFM "strong baseline"; TTM (IBM) "lightweight and validation-friendly"; Moirai (optional) "advanced multivariate capability". Fine-tuning: "LoRA / PEFT for large models", "Full fine-tuning for small models"; start from pre-trained models, apply LoRA, train on fraud panel data, evaluate with forecasting and detection metrics [CONF:45-57,82-87].
- Environment: "OCP / alternate platforms for restricted data", "PyFARM for execution and validation workflows"; training GPU-based, validation CPU-friendly for reproducibility. Challenges: conda, packages and setup; dependency and version conflicts; memory and GPU needs; "Stability of OCP/GCP local kernel workflows" [CONF:61-132].
- Collaboration: "Worked with Tianshu on: fine-tuning approaches, model selection and literature review, environment setup and troubleshooting" [CONF:93-96].
- Validation considerations: full reproducibility; document setup and configurations; "Provide justification for using foundation models"; align with validation and governance [CONF:61-132].
- Next steps: finalise environment; "Select initial model (Chronos recommended)"; LoRA pipeline; benchmark dataset and evaluation framework [CONF:120].
- What happened to the shortlist: no later entry records a Chronos fine-tune. Work moved to in-context learning (17 to 31 August) and then to the in-house TFM (31 August onward). Whether Chronos was formally dropped is not stated [CONF:12-20].

Later version of the page (owner's PDF export, 14 October)
- The owner's PDF export, kept in project_info/ on the work laptop, adds the FL, TFM and offset results table in section 2.5. It also notes the past-label leak with a meaningless 99% AUC (the 30 July TFT trial) [U1014:63-64,243-253; guide/parts/01_foundations.md:246-254].

## 10. Where things stand now (1 November 2026)

Chosen model
- Arch B H20 chunk (run name ALLPOS-H20-CHUNK). Seed check complete: ahead of Arch B H20 sliding on all three seeds (mean 0.0982 against 0.0817 on Test 1) and on the holdout set [WEEKLY:6-52].
- Specification [WEEKLY:70-84]:
  - Architecture B: a per-transaction encoder (2 transformer blocks) feeding a sequence encoder (4 blocks); width 48, 8 heads, dropout 0.1; 171,506 weights outside the categorical tables [OQA:394].
  - Causal attention: a transaction sees itself and earlier seconds only; same-second transactions do not see each other.
  - History at scoring: the 20 most recent earlier seconds in which the account transacted (one second counts as one time point), at most 32 rows per window; a longer window keeps its 32 most recent rows (0.003% of Test 1 windows).
  - Training: each account cut into non-overlapping chunks of 21 time points; every transaction in a chunk is a target and sees only earlier transactions of its chunk (0 to 20); nothing downsampled.
  - Loss: unweighted cross-entropy. AdamW, LR 0.0003, weight decay 0.00001, LR halved after 4 epochs without validation-loss improvement; up to 10 epochs, stop after 5 without a better validation AP (epoch 4 kept at seed 42); about 4,100 targets per update, 2,103 updates per epoch on files 1-10; one H200; bf16 training and validation, float32 test scoring.
  - Scoring: one window per transaction ending at that transaction; the score is the fraud probability at the last position.
- An earlier OQA description says chunks of "at most 21 transactions (20 history plus 1)"; the presentation's wording is 21 time points [OQA:452-462; WEEKLY:18].

Next steps (plan of record from 26 October)
1. Map 166 new features to the 224 columns: 90 TFM V22B fields, the 60 model-15298 features not already covered, and 16 built (ratios, location jumps, longer count windows), about 189 inputs before selection [WEEKLY:105,113-160].
2. Redo preprocessing (new artifact version) fitted on training files 1-10; every history feature uses only data before the transaction [WEEKLY:106; OQA:2091-2109].
3. Retest Arch B H20 chunk with the features on files 1-10; score on Test 1 and Test 2 [WEEKLY:107].
4. Feature importance and group selection on the holdout set 8206-8216 [WEEKLY:108].
5. Train on files 1-100 [WEEKLY:109].
6. Then export embeddings from the final 100-file model (48 numbers per transaction, PCA 8 and 16, latest vector before T and 30-day average) and run the three D-012 uses: transaction-level XGBoost test, 15298 offset model, correlation against TFM V22B embeddings and existing scores [WEEKLY:406-436; DEC:176-181].
7. Feature-store experiment (designed and built by ChatGPT in PR #28, not yet run on bank data), data-owner certification of inputs, one FINAL reading and the incumbent benchmark [OQA:766-781; bridge/plans/CL/2026-10-24-roadmap/ROADMAP.md:1-35].

Current state of the work
- Month: the V2 feature model drops month and keeps the time gap, hour, day of week and day of month; no separate no-month test; no request for data before October 2024 [OQA:171-186]. See section 11 for the conflicting statements.
- 27 October: pod clean-up is the only priority; the move-only reorganisation package was published [OQA:171-186,209-270]. Whether it has been run is not recorded.
- 1 November: the owner asked for a full record and a Copilot recovery prompt, and said "nothing needs to continue for now", reconcile only [OQA:2605-2644]. Claude's 11_01_2026/COPILOT_PROMPT.md was chosen over ChatGPT's request 2 prompt [OQA:2626-2630].
- Not yet done: the feature stage, the 100-file run, Test 2, the incumbent benchmark, embedding export and its uses, DR/VDR/FPR, data-owner answers (COMMUNICATIONS.md, open items).

## 11. Uncertain points and disagreements between sources

- Yaqun's spelling: "Yaqun" in Confluence, AGENTS.md:9 and code_tour; "Yakun" in claude/, guide/ and explainer/; "Ya" in ChatGPT's records. The owner confirmed "Yaqun" on 1 November [CONF:17; AGENTS.md:9; OQA:138-144; OQA:1436].
- Which manager named the embedding uses: OQA says "his manager" and "the manager's ask (14 October readme, section 15.4)" without a name. The 14 October readme records Nengfeng's 16 October reply with the same asks (comparison with the frontline XGBoost and the TFM, offset models, correlation with foundation-model embeddings and existing scores). So the manager is most likely Nengfeng; OQA does not name him [OQA:196-205,318; U1014:808-849].
- Xiaoming's role: "manager" in the tabular fraud email records; not stated in MRM_1 [waqas/additional_info/email_from_xiaoming_for_feature_information/README.md:3-14; CONF:9-16].
- PFM against TFM: the owner uses both names for one model in the 7 October answer; one reader of OQA could not confirm that every "payment foundation model" mention is the same TFM [OQA:1954-1957; OQA:847-857].
- The 94-feature model: the deck's "LoB model uses 94 features with vendor model VAA score", Waqas's 24 August "F0: 94 engineered features", and model 15298's 94 ranked features are likely the same feature set; no source says so [DECK slide 31; CONF:15; CJ:170].
- VAA and external_1_scr: the deck says the LoB model uses the "vendor model VAA score"; VAA is rank 1 in the V22B chart and "believed to be Visa's score"; external_1_scr is "External score from Visa" and rank 1 in 15298's list; the owner said "VAA was most important". Whether external_1_scr is the VAA score is not stated [DECK slide 31; waqas/features/feature_importance_v22_v17_highlighted/README.md:15-29; fraud/configs/predictors.csv:3; OQA:1073].
- LoB XGBoost numbers: the deck gives VDR 0.580 and FPR 5.79 (Jun25); the Confluence page gives VDR 0.5631 and FPR 6.3402 on the 952,905-row June set. The populations may differ; the sources do not say [DECK slide 31; U1014:243-253].
- TFM downsampled fraud share: "about 14% fraud" (guide), "about 12% fraud" (early roadmap, and the owner's observation of the v22b train parquets), downsample about 85 to 100 (Claude), "1% of non-fraud" (deck, v17) [guide/parts/01_foundations.md:232-245; waqas/docs/waqas_roadmap.md:28-39; MRM_1/claude/DECK_INTAKE_claude.md:107-174; DECK slide 28].
- Whether the deck is the 15 May FrontierAI presentation: probably, not stated [PKG:63; DECK slide 1].
- Whether Xinyu's 3 September workflow document is Fraud_Finetuning_Workflow_Summary.docx: very likely, not stated [CONF:20; PKG:260-273].
- "TSFM" (28 July) and "TFT model" (30 July) are written that way and not defined [CONF:9-10].
- Repository creation commits: 60f9f89 to eabee6d in one explainer page, 64cce77 to 05092b2 in another [STORY:12; explainer/01_ONE_PAGE.md:17].
- Rerun figures: about 84.7% identical and max about 0.007 (relayed early) against 84.2891% and 0.01409278 (final report) [MRM_1/claude/REPRODUCIBILITY_NOTE_claude.md:1-16; RERUN:389-396].
- TFM V22B field count: 120 chart rows, about 117 fields, 5,378 tokens; v17 deck 5,164 tokens; owner first said about 5,300 [WEEKLY:125; DECK slide 12; MRM_1/claude/DECK_INTAKE_claude.md:107-174].
- Feature pool: an early draft said 95 TFM fields and about 194 inputs; the current plan says 90 and about 189 [OQA:326; OQA:415-423].
- Month: 26 October "i dont think we're removing month"; 27 October "I think month is important for a model? Def in production correct?"; 27 October "I guess for v2 we can replace month but we need to have time delta on obv". The roadmap records stage 3 as resolved with the feature model dropping month; code_tour flags the conflict [OQA:404-516; OQA:196-207; OQA:171-186; code_tour/08_records.md:58].
- The 6 October senior-quant meeting was set for about 2 pm Eastern, but the learning guide was assembled at 01:06 UTC on 7 October, after that time. Whether the meeting moved is not recorded [bridge/threads/001-guide.md:3-12; GUIDE:1-5].
- The 6 October meeting with Xiaoming and Yaqun may be the same occasion as the senior-quant meeting; not stated [MN:104-202; bridge/threads/001-guide.md:3-12].
- The 26 October weekly presentation was probably given at the 2 pm senior-quant meeting; not stated [WEEKLY:1-3; OQA:530-536].
- The 15 October "Email 2" may be the 12 October thread with replies; not stated [U1014:743-806].
- Unclear phrases in the 6 October notes: "It might be 94; the XGBoost LOB" may mean 15298's 94 features; Xiaoming's chip-card counter may relate to 15298's atc_card_cnt (rank 15). Neither is confirmed [MN:104-202; WEEKLY:121-137].
- Outcomes never recorded: the 6 October and 26 October senior-quant meetings, the Monday 12 October review (and who it was with), the next-day meeting planned around 20 September, whether more GPU time was granted for the TFM work, COM-011's storage outcome, the accum-4 controlled TFM run's completion, the repeat rerun after LEW41, and the review with Sumegha [STORY:119-129; MRM_1/claude/PRE_2PM_BLOCK_claude.md:135-167; PKG:204-213; RERUN:529-532].
