# Results: history models for card fraud

Waqas, November 2026. This summarizes the models trained since the handoff and how they score. All numbers are average precision (AP) unless marked AUROC.

## Data

| Set | Files | Rows | Frauds |
|---|---|---|---|
| Training | part_1 to part_10 | 8,622,629 | |
| Validation (picks the epoch) | part_4950 to part_4954 | 4,292,059 | |
| Test 1 (evaluation folder) | part_8000 to part_8010 | 2,466,461 | 3,818 |
| SELECT (June targets only) | part_8206 to part_8216 | 1,215,218 | 2,081 |

Test 1 is the same set of files as the 100-file streaming result in `docs/phase3_streaming_plan.md` (AP 0.0940, AUROC 0.9514).

All models use the 23 predictors in `fraud/configs/predictors.csv` and preprocessing artifacts version 1. History models: AdamW, learning rate 3e-4, weight decay 1e-5, up to 10 epochs, early stopping after 5, seed 42. Batches of 4,096 windows (or 2,048 x 2 and 1,024 x 4 with accumulation at long history); the chunk-trained models update on about 4,100 targets per step. The streaming model keeps its own settings from `fraud/configs/streaming.yaml`, on training files 1 to 10.

## Models

- **streaming:** the single-transaction model (`fraud/streaming_model.py`), retrained with the corrected loader on training files 1 to 10.
- **sequential (flat):** feature tokens of the current transaction and its earlier ones in one transformer (`fraud/sequential_model.py`).
- **sequential_hier (hierarchical):** each transaction is encoded first, then a second transformer reads the sequence of transaction summaries. One target per window.
- **sequential_hier_allpos:** the hierarchical model with a causal mask that scores every transaction in a window. Trained either on non-overlapping chunks (`_chunk`) or on one window per transaction (`_sliding`), and scored on one window per transaction, ending at it (the first h5 chunk model was scored on chunks).

`hN` is the history length. For sequential and sequential_hier it is the last N earlier transactions of the account. For sequential_hier_allpos it is N earlier whole-second groups inside a chunk, and the window scored for each transaction is capped (32 rows at h20, 8 at h5). In every model a transaction with the same timestamp as the target is never history.

## Comparison at seed 42 (Test 1)

| Model | AP | AUROC |
|---|---:|---:|
| streaming | 0.0925 | 0.9487 |
| sequential h0 | 0.0816 | 0.9351 |
| sequential h5 | 0.0728 | 0.9409 |
| sequential h10 | 0.0824 | 0.9408 |
| sequential h15 | 0.0928 | 0.9437 |
| sequential h20 | 0.0817 | 0.9339 |
| sequential h5, no time gap | 0.0767 | 0.9430 |
| sequential h10, no time gap | 0.0808 | 0.9425 |
| sequential h5, causal mask | 0.0779 | 0.9436 |
| sequential_hier h0 | 0.0822 | 0.9322 |
| sequential_hier h5 | 0.0674 | 0.9388 |
| sequential_hier h10 | 0.0904 | 0.9475 |
| sequential_hier h15 | 0.0955 | 0.9473 |
| sequential_hier h20 | 0.0955 | 0.9520 |
| sequential_hier_allpos h5, chunk (scored on chunks) | 0.0927 | 0.9457 |

## Chunk training against sliding training (seed 42)

| Model | Test 1 | SELECT (June) |
|---|---:|---:|
| sequential_hier_allpos h20, chunk | **0.1020** | **0.1103** |
| sequential_hier_allpos h20, sliding | 0.0743 | 0.0615 |
| sequential_hier_allpos h5, sliding | 0.0866 | 0.0923 |

On the same transactions, h20 chunk minus h20 sliding is +0.0277 on Test 1 (95% interval +0.0170 to +0.0384, resampling whole accounts, for these fitted models) and +0.0488 on SELECT. Chunk and sliding training differ in more than one way (context, grouping and how gradients are averaged), so this shows which works better, not why.

## Seed check (Test 1)

| Seed | sequential_hier_allpos h20, chunk | sequential_hier h20 | Difference |
|---|---:|---:|---:|
| 42 | 0.1020 | 0.0955 | +0.0065 |
| 43 | 0.0912 | 0.0743 | +0.0169 |
| 44 | 0.1013 | 0.0753 | +0.0261 |
| Mean | 0.0982 | 0.0817 | +0.0165 |

The chunk-trained model is ahead at every seed and varied less across these three seeds (standard deviation 0.0061 against 0.0120). SELECT for seed 42 used June targets only; seeds 43 and 44 were scored on the full files, so their SELECT numbers are not shown here.

## Chosen model

**sequential_hier_allpos h20, chunk**: hierarchical, all-position, history 20, trained on non-overlapping chunks, scored on one window per transaction (window capped at 32 rows). Test 1 AP 0.1020 at seed 42 and 0.0982 over three seeds, trained on 10 files. For context, the 100-file streaming model in `docs/phase3_streaming_plan.md` scored 0.0940 on the same files; that run used 100 training files and the original loader, so it is not a matched comparison. The reference is sequential_hier h20. Its seed-42 score (0.0955) and that of sequential_hier h15 come from runs scored by hand after training.

## Changes to the shared code that affect training and scoring

- Data workers split the file list before shuffling, so every training file is read once per epoch.
- History uses strictly earlier timestamps; a same-second transaction is never history (1.98% of training rows are in such groups, holding 6.68% of training frauds).
- In causal mode no transaction reads the CLS token; padding is part of the mask, so short histories give no NaN.
- A missing label, account id or unreadable timestamp stops the run instead of being filled in.
- Each scoring run writes its own prediction file; a checkpoint is scored only with the feature list it was trained on.

## Next

In the order Waqas set: reproduce the chosen model from the organized code, tune its hyperparameters (not done so far), add new features (from TFM V32B and the 15298 model, with month removed), train on 100 files, then use the model's embedding downstream.
