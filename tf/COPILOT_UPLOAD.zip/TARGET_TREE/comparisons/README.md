# comparisons/

Side-by-side comparisons on the same transactions: architecture comparison, chunk against sliding, the seed check table, and the flat-model rescore table (sequential_rescore.csv).
