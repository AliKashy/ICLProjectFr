# archive/

Stays on the pod, listed in .gitignore, never pushed. Everything superseded: sweep runners and specs, runbook, package zips and folders, install records, patch scripts, receipts, hash and manifest files, retries, failed attempts, diagnostics, old outputs. Delete it when satisfied.
