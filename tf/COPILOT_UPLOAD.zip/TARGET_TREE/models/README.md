# models/

One folder per trained model and seed: models/<name>/seed<NN>/ with best.ckpt, config.yaml (the exact settings used), training_metrics.csv and scores/<population>.json (AP, AUROC, rows, frauds). Prediction files stay on the pod or S3, not in git. Names follow docs/EXPERIMENTS.md.
