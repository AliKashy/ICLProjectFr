# splits/

The file lists of each population: training, validation, Test 1, SELECT, FINAL, downstream training and selection, and the file inventory they were chosen from.
