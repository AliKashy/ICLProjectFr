# Target tree

The organized project, folder by folder. Each README says what goes in that folder. REORGANIZATION.md gives every move. Top level files: README.md (setup and exact commands), pyproject.toml, requirements.txt, .gitignore.
