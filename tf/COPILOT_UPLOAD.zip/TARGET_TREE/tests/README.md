# tests/

Yaqun's test plus the tests that prove the fixes: worker sharding, causal CLS mask, strict same-second history, all-position chunks and loss, input checks, target-ending windows.
