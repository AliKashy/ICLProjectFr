# docs/

From REORGANIZATION.md section 3 (the authoritative list):

- fraud_detection_plan_overall.md Yaqun: project plan (unchanged)
- fraud_detection_plan_detailed.md Yaqun: detailed plan and baseline record (unchanged)
- phase3_streaming_plan.md        Yaqun: streaming model plan (unchanged)
- phase4_sequential_plan.md       Yaqun: history model plan (unchanged)
- phase4_design_decisions.md      Yaqun: design decisions (unchanged)
- monitoring_and_eval.md          Yaqun: monitoring how-to (unchanged)
- tabular_transformer_models.md   Yaqun: model survey (unchanged)
- RESULTS.md                      score summary for Yaqun plus the 22-run reproduction table
- EXPERIMENTS.md                  every study: purpose, runs, command, result, decision
- CHANGES.md                      code changes since Yaqun's handoff and the old-to-new file map
- all_position_model.md           rules of the all-position model (was ALL_POSITION_CONTRACT.md)
- populations.md                  how the file inventory and the populations were made
- model_comparison.md             how compare_models.py pairs two models on the same rows
- business_metrics.md             alert-level and value metrics used by compare_models.py
