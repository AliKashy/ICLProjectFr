# fraud/

From REORGANIZATION.md section 3 (the authoritative list):

- __init__.py                     package exports (unchanged)
- callbacks.py                    CSV metrics, streaming AP/AUROC, and the EMA weight callback
- log_utils.py                    logging setup (unchanged)
- streaming_model.py              single-transaction FT-Transformer builder (corrected copy)
- sequential_model.py             flat history model, FTTransformerSeqModel (Arch A)
- sequential_hier_model.py        hierarchical model, one target or all positions (Arch B)
- sequential_hier_target_ending_model.py  Arch B subclass validated and trained on target-ending windows
- sequential_factory.py           builds the flat model from a config
- sequential_hier_factory.py      builds the hierarchical model and its dataset options
- tokenizer.py                    per-feature tokens, linear or periodic
- numerical_embeddings.py         periodic continuous embedding
- optim.py                        optimizer chosen by name
- source_files.py                 list of runtime source files the hierarchical trainer records
