# fraud/configs/

From REORGANIZATION.md section 3 (the authoritative list):

- .gitkeep                      Yaqun's placeholder
- streaming.yaml                base config: single-transaction model (default run models/streaming/seed42)
- sequential.yaml               base config: flat model (default history 15)
- sequential_hier.yaml          base config: hierarchical model (default history 20, the reference)
- sequential_hier_allpos.yaml   base config: all-position model (history 20, chunk training, the chosen model)
- preprocessing.yaml            Yaqun: preprocessing artifact build (unchanged)
- predictors.csv                Yaqun: the 23 predictors (unchanged)
- eval.yaml                     Yaqun: baseline scorer config (unchanged)
- smoke_test.yaml               Yaqun: baseline trainer config (unchanged; train_baseline.py reads it)
