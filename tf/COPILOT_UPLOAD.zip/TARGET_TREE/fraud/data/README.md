# fraud/data/

From REORGANIZATION.md section 3 (the authoritative list):

- __init__.py                   (unchanged, empty)
- .gitkeep                      Yaqun's placeholder
- preprocessing.py              fitted artifacts: imputation, scaling, encoding (unchanged)
- datetime_features.py          calendar features from the timestamp (unchanged)
- feature_list.py               predictor list loader (unchanged)
- s3_utils.py                   S3 filesystem and file lists, plus thin_read_filesystem
- parquet_loader.py             single-transaction streaming dataset (corrected copy)
- sequence_builder.py           history windows and all-position chunks (the history builder)
- target_ending.py              one window per transaction, ending at it, with a row cap
- input_checks.py               label, account and timestamp checks
- input_contract.py             record of ordered inputs and artifact identity saved in checkpoints
- checkpoint_contract.py        saves and checks that record in streaming checkpoints
- prediction_files.py           prediction file paths, id checks and parquet reading
