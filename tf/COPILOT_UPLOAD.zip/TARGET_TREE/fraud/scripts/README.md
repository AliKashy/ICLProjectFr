# fraud/scripts/

From REORGANIZATION.md section 3 (the authoritative list):

- .gitkeep                      Yaqun's placeholder
- build_preprocessing_artifacts.py  fit and write the preprocessing artifacts (unchanged)
- train_baseline.py             Yaqun's baseline training, corrected copy
- score_eval.py                 Yaqun's baseline scoring, corrected copy
- show_progress.py              print training metrics (unchanged)
- check_pid.sh                  check a training process (unchanged)
- fix_ssh_permissions.sh        fix SSH key permissions on a new pod (unchanged)
- train_streaming.py            train the single-transaction model
- score_streaming.py            score the single-transaction model
- train_sequential.py           train the flat model
- score_sequential.py           score the flat model
- train_sequential_hier.py      train the hierarchical and all-position models (chunk or sliding training, window validation)
- score_sequential_hier.py      score them; all-position checkpoints on capped windows
- train_sequential_hier_chunk_eval.py  hierarchical trainer that validates all-position models on chunks
- score_sequential_hier_chunk_eval.py  hierarchical scorer that scores all-position models on chunks
- data_inventory.py             count rows, frauds, accounts and months per data file
- select_splits.py              choose account-disjoint populations from the inventory
- measure_window_rows.py        measure window sizes and the window cap
- measure_chunk_widths.py       measure the widest strict chunk (max_chunk_rows)
- compare_models.py             paired comparison of models on the same rows, account bootstrap
- paired_bootstrap.py           bootstrap engine used by compare_models.py; also compares a run table
- business_metrics.py           alert-level and value metrics; fits amount bins
- temporal_eval.py              per-month report of one prediction file; history counts
- leaderboard.py                ranks prediction files by AP and AUROC
