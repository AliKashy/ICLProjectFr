# embedding/

Embedding export, its check, embedding diagnostics, downstream XGBoost, benchmark. Built, not run yet. The 15298 offset model and the TFM comparison are not built yet.
