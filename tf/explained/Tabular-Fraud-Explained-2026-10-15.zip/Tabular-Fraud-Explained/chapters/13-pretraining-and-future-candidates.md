# 13 · Pretraining and the ideas that are not yet results

**Prerequisite refresher.** An encoder turns inputs into a learned vector; a head turns that vector into an output such as fraud logits. Training changes parameters to reduce a chosen loss. A frozen preprocessing artifact is different: it records earlier fitted transformations and is reused consistently. If these pieces blur together, revisit Chapters 04, 06 and 08 before this chapter.

**Your concrete question:** “Can the model learn useful transaction structure before it is trained to predict fraud?”

Yes, that is a possible research strategy. The repository contains implementations of two such strategies under `waqas/future_experiments/pretrain/`. Their existence does not establish that they help the current fraud task. Phase 5 is parked in the current project state. This chapter teaches the mechanisms so you can explain the whole repository without presenting future experiments as completed V1 results.

## What “pretraining” adds

Ordinary supervised fraud learning begins with input features and known fraud labels. **Supervised** means labels guide learning. **Pretraining** means first training some parameters on an earlier objective, then using those parameters to start a later task. The earlier objective can use labels, ignore them, or use different labels. “Pretrained” alone does not tell you which.

Think of learning to recognize spreadsheet patterns before being asked to identify suspicious transactions. The analogy has limits: the network does not understand a business explanation as a person does. It finds parameter settings that reduce a mathematical objective. The only reliable way to know whether the earlier learning helps fraud ranking is a properly controlled downstream experiment.

The reusable component here is `TabularEncoder`. Its output is a vector with a configured number of coordinates. A coordinate is one number in that vector. The numbers jointly represent useful distinctions learned under the training objective; coordinate 12 is not automatically “customer honesty” or “merchant risk.”

## Route A: hide a field and reconstruct it

The **masked autoencoder** takes a transaction, hides selected feature tokens, and tries to reconstruct their original values. “Autoencoder” describes learning to reconstruct information from the input itself. **Self-supervised** means the training targets are derived from the input data, rather than requiring separate fraud labels for that objective.

Suppose a synthetic row contains normalized amount 0.6, normalized limit 0.9, and merchant category “travel.” Hide the amount token. The network sees the other features and a learned mask token at the amount position, then predicts the missing amount. The mask token signals that the value is hidden; feature identity tells it which field needs reconstruction. Without feature identity, “a value is missing somewhere” would be a much less useful task.

The implementation masks tokens randomly and ensures each row has at least one masked token. With mask ratio 0.3, each token is initially selected with probability 0.3. That is a probability, not a rule that exactly 30% of every row must be hidden. The fallback for empty masks also changes the final distribution slightly. This distinction matters when there are few features or a small final batch.

Continuous values use **mean squared error**, or MSE: subtract prediction from target, square the difference, and average. If two masked targets are 0.6 and 0.2 and predictions are 0.4 and 0.5:

`MSE = ((0.4 − 0.6)² + (0.5 − 0.2)²) / 2`

`= (0.04 + 0.09) / 2 = 0.065`.

Squaring makes positive and negative errors contribute positively, and gives larger misses more weight. The values are in the model's transformed feature space. A reconstruction error of 0.2 here is not necessarily a monetary error of 20 cents.

Categorical fields use cross-entropy because predicting a category is a classification problem. If the true category is “travel,” a prediction assigning travel probability 0.8 has loss `−log(0.8)`, approximately 0.223; assigning probability 0.2 has loss about 1.609. The model is penalized for failing to support the actual category.

The code adds the continuous reconstruction term and available categorical reconstruction terms. That loss is not fraud AP. A model can get better at reconstructing common transaction patterns while doing nothing useful for rare fraud. A high-cardinality field or noisy field can also complicate the objective. Treat objective design as a hypothesis.

## Route B: supervised contrastive learning

**Contrastive learning** learns a representation by comparing examples. In this project's **supervised contrastive** implementation, fraud labels decide which comparisons should be similar: views with the same class are positives, and different classes compete in the denominator. “Positive pair” here means a pair encouraged to be close; it does not necessarily mean two fraudulent transactions. Two legitimate examples are also a positive pair.

Each transaction produces two **views**, which are altered copies. The corruption function randomly replaces selected feature values with values from a randomly sampled batch row, sometimes the same row itself. It creates a learning challenge; it does not claim those altered transactions really occurred. The two altered copies retain the original transaction's label for this objective. That design assumes the corruption does not destroy the useful class information too often, something experiments must assess.

The encoder produces a representation, then a **projection head** transforms it for the contrastive loss. A projection head is a small additional neural network. It is separate from the eventual two-class fraud head. The contrastive representation is normalized so vector direction drives similarity. For vector `[3,4]`, length is `√(3²+4²)=5`; dividing each coordinate by 5 gives `[0.6,0.8]`, with length 1. The dot product multiplies matching coordinates and adds: this vector with itself gives `0.6²+0.8²=1`. With perpendicular vector `[-0.8,0.6]`, it gives `−0.48+0.48=0`. The dot product of normalized vectors is **cosine similarity**: 1 for the same direction, 0 for perpendicular directions, and −1 for opposite directions. An **anchor** is the view currently being compared with the other views.

For an intuitive arithmetic example, let one anchor have a same-class comparison with similarity 1 and a different-class comparison with similarity 0. At a toy temperature of 1, their exponentiated scores are approximately 2.718 and 1. The same-class comparison receives relative probability:

`2.718 / (2.718 + 1) ≈ 0.731`.

Its negative log contribution is about 0.313. If the two similarities were equal, the probability would be 0.5 and the loss about 0.693. The objective rewards the anchor putting more relative similarity on the same-class comparison. Real batches contain many comparisons; the code averages over eligible same-class comparisons and excludes self-comparison.

**Temperature** divides similarity before the probability calculation. A smaller positive temperature makes differences in similarity more influential. It is an objective parameter, not GPU temperature. The implementation uses a stable `logsumexp` calculation to avoid numerical problems in exponentiation; that computes the same kind of log-normalization more reliably.

Class imbalance still matters. In a batch dominated by legitimate transactions, the pattern of available same-class and different-class comparisons differs from a balanced batch. “We used contrastive learning” is not a sufficient explanation of how rare fraud is handled. Inspect the batch, labels and objective.

## Transfer, freezing and fine-tuning

After pretraining, the fraud classifier loads the encoder parameters and attaches a two-output head. **Fine-tuning** means continuing learning for the downstream fraud task. There are two useful experiment conditions:

| Condition | Encoder parameters | Fraud head parameters | Question |
|---|---|---|---|
| Frozen encoder, often called a linear probe here | Fixed | Learned | Does the representation already contain useful fraud information? |
| Full fine-tuning | Learned further | Learned | Does that starting point help after adapting the encoder? |

Freezing must also keep the encoder in evaluation mode; otherwise dropout could keep altering a supposedly fixed representation. The implementation explicitly handles that. A pretrained encoder checkpoint must be compatible and complete. The loader uses strict state loading and rejects a missing checkpoint unless an explicitly named scratch control permits it. A **scratch control** starts with fresh parameters so the comparison can isolate the value of pretraining.

Fair comparison requires more than “same final head.” Check data access, total training effort, feature definitions, validation selection and target cohort. Even an unlabeled pretraining dataset can introduce inappropriate information if it includes future distributions unavailable at the intended deployment time. “No labels” does not automatically mean “no leakage.”

## Exporting a vector is not finishing a new model

The export script can save per-transaction embeddings for downstream study. Possible consumers include a gradient-boosted tree model or nearest-neighbor classifier. A **gradient-boosted tree model** combines many decision trees added sequentially to improve predictions. A **nearest-neighbor classifier** predicts using nearby labeled examples in a chosen representation. Those names describe possible later consumers; their downstream training pipelines are not implemented by the export script.

Likewise, an exported embedding does not automatically become an input to the current A/B history models. That integration would need a defined feature contract, as-of timing, matching training/scoring behavior and a controlled experiment.

## Other future knobs: explain the proposed cause

An optimizer changes how parameters move. A numerical embedding changes how numbers are represented before attention. More attention blocks change the amount of computation and parameter capacity. Added merchant-category or account-velocity features change the information available. More training files change the data seen. Each intervention answers a different question.

A **velocity feature** summarizes activity in an earlier time window, such as the count of transactions during the preceding hour. It is not physical speed. Its definition must specify the entity, window, boundary, and whether the current row is included. A useful-looking feature available only after a decision is not a usable decision-time input.

The current update prioritizes a smaller-data screening sweep before the deferred 100-file fits. The H5 reader—a history-five evidence reader, not the HDF5 file format—and package 006 were delivered; that does not mean those fits or a full optimizer/feature sweep have produced bank results. The package-delivery record is separate from the runtime files tracked in the course's source snapshot. Optimizer candidates and feature proposals remain candidates. A paper showing an improvement on other datasets or another model family motivates a trial; it cannot supply this project's missing measurement.

## Where the mechanisms live

- `waqas/future_experiments/pretrain/ssl_pretrain.py`, `MaskedTabularAutoencoder._reconstruct`, lines 62–97: token masking and reconstruction losses.
- `waqas/future_experiments/pretrain/supcon.py`, `SupConLoss.forward`, lines 36–59, and `SupConPretrainer._corrupt`/`_views`, lines 93–114: labels define comparison pairs; corrupted views feed contrastive learning.
- `waqas/future_experiments/pretrain/ssl_finetune.py`, lines 48–83 and 102–137: freezing, strict encoder transfer, scratch-control handling and fraud training.
- `waqas/future_experiments/pretrain/scripts/export_embeddings.py`, module description, lines 1–6: embedding export exists; downstream consumers are possible experiments.
- `bridge/plans/CH/2026-10-14-improvement-pathway/SWEEP_FIRST_UPDATE.md`, lines 7–33: current proposed sequence and limits, rather than completed experimental gains.

## Predict, repair, explain

**Predict.** Reconstruction MSE falls, but held-out fraud AP is unchanged. Has pretraining succeeded for the business task?

**Repair.** A slide says, “Contrastive learning uses no labels; exported embeddings are our production classifier.” Correct both parts for this repository.

**Teach back.** Explain masked reconstruction, supervised contrastive learning, a frozen probe and full fine-tuning using one transaction as the story.

<details><summary>Answers and self-check rubric</summary>

The reconstruction objective improved; a downstream fraud improvement has not been demonstrated. This implementation's contrastive positives use fraud labels. Exported embeddings are representations, not a complete deployed fraud classifier. Full credit distinguishes inputs, target/objective, learned parameters and downstream evaluation in each route. Also say that Phase 5 is parked and these mechanisms are not evidence of a V1 gain.

</details>

**Recall without looking:** draw two roads into the same encoder—masked reconstruction and labeled contrastive comparisons—then draw frozen and fine-tuned fraud heads. If you cannot explain how either objective moves weights, repair with Chapter 04. To design the experiment that would establish a benefit, proceed to Chapter 14.
