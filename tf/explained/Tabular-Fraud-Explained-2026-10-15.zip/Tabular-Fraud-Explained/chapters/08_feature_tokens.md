# 08 · Turn a transaction into feature tokens

**Prerequisite refresher.** A row describes a transaction. A feature is an input the model may use, such as an amount or a category. A label is the answer used during training. Preprocessing turns raw values into consistent numbers using rules fitted on training data. A neural network contains adjustable numbers called parameters; training changes those parameters to reduce an error measure. If those ideas are blurry, revisit Chapters 03, 04 and 06 before the worked example.

**Your concrete question:** how can a transformer process a mixture of amounts, category codes and missing-value flags when those inputs mean different things?

The answer starts with a small translation layer. It turns each input feature into a list of learned numbers. Those lists are called **feature tokens**. The transformer will later mix information between them. A token here is a representation of one field, not a word, a transaction label or a fraud verdict.

## First picture: one row becomes several cards

Imagine a synthetic transaction described by three already-preprocessed inputs:

| Input | Value entering the model | Meaning |
|---|---:|---|
| Amount | 2 | An amount transformed using the frozen scaling rule |
| Time-related quantity | 0.5 | Another numerical input |
| Channel code | 3 | An integer identifying one category |

The value 2 is not necessarily two dollars. Chapter 06 explains why the model may receive a standardized value. Likewise, category code 3 does not mean three times as risky as code 1. It is a lookup address.

Give each field a card containing four numbers. The transaction now has three cards, each four numbers wide. In the real model that width is controlled by `input_embed_dim`, passed to the local tokenizer as `embed_dim`. We use width four for arithmetic; these numbers are synthetic and are not fitted project parameters.

A **vector** is simply an ordered list of numbers. **Embedding** means representing something by such a vector. It does not mean we have discovered its true meaning or assigned a human-readable interpretation to each coordinate. Training can make the vector useful for prediction without making coordinate 1 equal “risk” and coordinate 2 equal “trust.”

## Numerical features: multiplication plus an offset

The local linear tokenizer gives each numerical feature its own weight vector and bias vector. A **bias** is an adjustable offset added after multiplication. For one feature, the operation is:

```text
feature token = numerical value × that feature's weight vector + that feature's bias vector
```

For the synthetic amount input, choose:

```text
value  = 2
weight = [0.5, -1, 0.25, 0]
bias   = [0.1, 0.2, 0, 0.3]
```

Multiply 2 by each weight, then add the corresponding bias:

```text
[2×0.5+0.1, 2×(-1)+0.2, 2×0.25+0, 2×0+0.3]
= [1.1, -1.8, 0.5, 0.3]
```

The other numerical feature has a different learned weight and bias. Consequently, equal input values in different columns can produce different tokens. This is how field identity enters this representation: each numerical field owns its own parameters.

The linear operation by itself cannot express every curved relationship between input and outcome. That does not make the entire model linear. Later attention, activation functions and layers add nonlinear operations. “Linear numerical embedding” describes this first translation step, not the whole fraud model.

The multiplication expands one scalar into several coordinates. It does **not** create four independent observations or four extra historical transactions. All four numbers came from the same input and its learned parameters.

## Categories: selecting a learned row

A categorical feature uses an **embedding table**. Each category code selects one row of numbers. If the channel table contains this synthetic entry:

```text
channel_table[3] = [-0.2, 0.7, 1.1, 0.0]
```

then code 3 produces exactly that vector. It is a lookup, not “3 multiplied by the channel weights.” Every categorical feature has its own table, so code 3 for channel need not resemble code 3 for another field.

**Cardinality** is the number of legal codes that the table must accommodate. Frozen preprocessing determines the vocabulary and the reserved codes; the model creates tables of the required size. Missing and unknown values need the correct reserved treatment from Chapter 06. An integer outside the legal table range is not a new useful category; it is an invalid lookup.

At initialization, these table entries contain starting values. During training, the loss gradient reaches the looked-up entries and the optimizer updates them. The vocabulary mapping stays fixed while the model's vector for a code can change. This distinction is essential:

- Frozen preprocessing says which code corresponds to a category.
- Trainable embedding parameters say what vector that code contributes to the model.

If you silently rebuild the category vocabulary in a different order, old model parameters may be attached to the wrong categories. Matching array dimensions would not rescue that mistake. Chapter 12 explains why checkpoints record input contracts.

## Shapes: what the brackets count

A **tensor** is an array with one or more axes. Its **shape** lists how many entries lie along each axis. The phase-local tokenizer accepts:

```text
continuous:  [N, C]
categorical: [N, K]
output:      [N, C+K, d]
```

Read this out loud: “N rows; C numerical features; K categorical features; d coordinates per feature token.” Here `N` is the number of rows processed together, not the number of neurons. In later history models, several transactions from several windows are temporarily combined into this row axis.

For two transactions, two numerical fields, one categorical field and width four:

```text
continuous shape  [2, 2]
categorical shape [2, 1]
token shape       [2, 3, 4]
```

That final array contains `2 × 3 × 4 = 24` scalar numbers. The phase tokenizer puts numerical tokens first, then categorical tokens. Each transaction remains separate at this point. No attention has happened, and no past transaction has informed another transaction.

A **reshape** changes how existing entries are grouped into axes; it does not itself learn, summarize or shuffle their intended order. A model can temporarily reshape `[batch, time, features]` into `[batch×time, features]` to tokenize every row with the same function, then restore the time axis. That is bookkeeping, not memory across transactions.

## Periodic embeddings: another implemented translation choice

The repository also implements a numerical embedding using repeating waves. **Sine** and **cosine** describe two coordinated waves. You can picture a point moving around a circle: cosine is its horizontal coordinate and sine its vertical coordinate. One complete turn brings the coordinates back to their starting values.

For a numerical input `x`, the code first constructs angles `2π × x × c`, where `c` is a learned frequency coefficient. “Frequency” controls how many turns happen as the input increases. It computes sine and cosine for each frequency, joins those numbers together, then applies a learned linear projection to obtain a width-`d` token. Here π is approximately 3.14159, so `2π` means one full circle in radians, the angle unit used by the functions.

Use one frequency, `c=1`, and `x=0.25`:

```text
angle = 2π × 0.25 × 1 = π/2, a quarter turn
[sin(angle), cos(angle)] = [1, 0]
```

For `x=0`, the pair is `[0,1]`. A **projection** here is another weighted-total-plus-bias calculation. For a tiny width-two example, define its outputs as `[2×s+c, −s+0.5×c+0.1]`, where `s` and `c` are the sine and cosine values. The quarter-turn pair `[1,0]` produces `[2×1+0, −1+0.5×0+0.1]=[2,−0.9]`. Those projection weights and its bias are learned in a real model; ours are chosen only to show the arithmetic. With `F` frequencies, the intermediate representation has `2F` numbers: `F` sine values followed by `F` cosine values. In this implementation, the frequency coefficients are specific to each numerical feature, while the final linear projection is shared across features.

Why consider this? A richer input representation may help a network describe changing numerical relationships. Why be careful? It adds parameters and assumptions, may fit noise, and repeating waves can map separated values to similar coordinates. A single frequency with `c=1` gives the same pair for `x=0.25` and `x=1.25`. Multiple learned frequencies can change that behavior, but do not prove better fraud detection.

This option is **implemented**, with `linear` as the local model default. Its existence is not evidence that it is the proven V1 choice. The repository also has future experiment specifications; Chapter 13 explains their status. Do not confuse this general numeric representation with deliberately encoding a known clock cycle, such as hour of day, using a fixed period. Those are different feature design decisions.

## Where the actual source performs these operations

These references identify the checked source snapshot, not code you must memorize.

| Source location | What to inspect |
|---|---|
| `waqas/phase4a/tokenizer.py`, `FeatureTokenizer`, lines 15–40 | Per-feature numerical weights/biases, separate category tables, numerical-then-categorical output |
| `waqas/phase4b/tokenizer.py`, `FeatureTokenizer`, lines 15–40 | B's corresponding local tokenizer |
| `waqas/phase4a/numerical_embeddings.py`, `PeriodicNumericalEmbedding`, lines 13–25 | Learned feature-specific frequencies, sine/cosine concatenation and shared projection |
| `waqas/phase4b/numerical_embeddings.py`, `PeriodicNumericalEmbedding`, lines 13–25 | B's corresponding periodic option |
| `src/pytorch_tabular/models/common/layers/embeddings.py`, `Embedding2dLayer`, lines 224–310 | Reference FT embedding implementation, with configurable shared category components, biases, normalization and dropout |

The reference FT path and local A/B tokenizers serve a similar purpose but are not interchangeable implementations. For example, the reference embedding machinery supports a column-shared component inside categorical embeddings; local A/B use plain category tables. A **shared component** means some vector information is common to all categories of the same field. It helps identify the column, while category-specific parameters distinguish values. You should check the resolved model configuration before claiming which optional mechanism is active.

## Prediction, repair and teach-back

**Predict.** You have three transactions, five numerical fields, two categorical fields and embedding width eight. What is the tokenizer output shape? How many feature tokens does one transaction have?

<details><summary>Reveal the worked answer</summary>

The shape is `[3,7,8]`, because `5+2=7` features become seven tokens per transaction. There are `3×7×8=168` scalar coordinates in the complete output. Width eight is not eight transactions or eight original features.

</details>

**Repair.** Someone says, “Category code 8 must be twice as risky as category code 4. Also, once preprocessing is frozen, embeddings cannot learn.” Correct both claims.

<details><summary>Reveal the repair</summary>

Codes select rows from a table; numeric distance between codes does not impose a risk ordering. Frozen preprocessing fixes the code mapping and numerical transformations. Training still updates the model's embedding vectors. Confusing mapping with model parameters would hide a major part of learning.

</details>

**Teach back without looking.** Use the three-card picture to explain why the model knows that amount and channel are different fields, and why their tokens can have the same width.

<details><summary>Check your explanation</summary>

Give yourself one point each for: numerical fields have their own weights/biases; categorical fields have their own lookup tables; a common vector width makes later interaction possible; token coordinates are learned representations, not guaranteed human meanings. If you miss the frozen/trainable distinction, revisit Chapter 06 and then repeat this chapter's category example.

</details>

**Recall prompt for later:** draw the path from one standardized number and one category code to two tokens. Do the multiplication and the lookup from memory. Repair vector arithmetic in Chapter 02, learning in Chapter 04, and vocabulary handling in Chapter 06 before moving to attention in Chapter 09.
