# 17 · The project atlas: find the code behind the idea

You now know the main ideas. This chapter joins them into a map you can use while reading the actual repository. A **repository** is a versioned collection of source code, configuration, tests, and documents. A **module** is a Python file that groups related definitions. An **entry point** is the script you start; it calls definitions in other files. A **configuration** supplies choices such as history length without rewriting the model.

The paths below are relative source locators in the private project, not files bundled with this public course. The ZIP contains teaching material and synthetic labs, not bank data, credentials, checkpoints, or the application's source tree. Source access is needed to open the implementation itself. Use the pinned commit in Chapter 00 so line references do not drift underneath you.

## First, separate four layers

| Layer | Where to look | What it means |
|---|---|---|
| Original project and common helpers | `fraud/`, `docs/` | Ya's original pipeline and design material; some helpers remain imported by the corrected paths |
| Corrected reference and history models | `waqas/base/`, `waqas/phase4a/`, `waqas/phase4b/` | The core implemented experiment paths explained in this course |
| Experiment launch and analysis | `runbook/2026-10-07/`, `waqas/scoring/` | Launches, records, scores, and compares experiments |
| Evidence, historical material, and future work | `bridge/`, `guide/`, `explainer/`, `waqas/future_experiments/` | Records and explanations of different dates, plus parked experiments; existence does not establish current adoption |

The `src/pytorch_tabular/` directory contains a local version of a tabular-model library. A **library** is reusable code. It contains many model families because it was brought into the repository as a library; this does not mean every family participates in the fraud experiments. The active reference uses FT-Transformer. A and B have their own implementation. You do not need to master unrelated library models to explain this project's execution path.

One source-reading trap is already visible in the top-level README: it describes the sequential model as “coming soon.” Current implementation files show that history models exist. Read a document as a statement made at a point in time, then verify against the current code and configuration.

## Follow the runtime, one call at a time

An entry point reads configuration, sets up data, creates a model and trainer, then starts the run. **Importing** a name makes a definition from another module available to use. Imports matter: an excellent fix in one file does nothing if the training script still imports the old implementation.

| Your question | Source entry or symbol | What to inspect |
|---|---|---|
| Which columns are inputs? | `fraud/configs/predictors.csv`, `fraud/data/feature_list.py` | Declared names and continuous/categorical grouping |
| What happens to missing values and categories? | `fraud/data/preprocessing.py` | Saved artifact loading and frame transformation |
| How are calendar features made? | `fraud/data/datetime_features.py` | Timestamp-derived fields, not arbitrary arithmetic on category codes |
| Which rows reach REF? | `waqas/base/data/parquet_loader.py` | Reading, worker ownership, batches, input validation |
| Which earlier rows reach A? | `waqas/phase4a/sequence_builder.py` | Strict history, padding, timestamps, labels returned separately |
| What changes for B's all-position mode? | `waqas/phase4b/sequence_builder.py` | Distinct-second chunks, per-row labels, actual history counts |
| How are values made into vectors? | `waqas/phase4a/tokenizer.py`, `numerical_embeddings.py`; corresponding B files | Numerical transformations and categorical lookups; the model adds its own CLS and transaction-position embeddings |
| Where is A's forward computation? | `waqas/phase4a/sequential.py` | `FTTransformerSeqModel`, masks, positional embeddings, `forward` and training steps |
| Where is B's computation? | `waqas/phase4b/sequential_hier.py` | `FTTransformerHierModel`, row encoder, temporal encoder, mode-specific masks and loss |
| Where does REF come from? | `waqas/base/streaming_model.py`, `src/pytorch_tabular/models/ft_transformer/ft_transformer.py` | Model construction and library backbone; it is not simply A with H set to zero |
| What starts training? | `waqas/base/scripts/train_streaming.py`; A/B `scripts/train_sequential.py` | Configuration overrides, data setup, callbacks, optimizer, trainer |
| What starts scoring? | `waqas/base/scripts/score_streaming.py`; A/B `scripts/score_sequential.py` | Load chosen checkpoint, restore input contract, produce scores and output records |
| Which comparisons exist in V1? | `runbook/2026-10-07/analysis_runs.py`, `v1_contrasts.csv` | Fifteen selected run names and the intended pairwise questions |
| How are comparisons calculated? | `runbook/2026-10-07/paired_report.py` | Pairing rules, account resampling, metric differences, qualification of labels |

You may see different definitions with similar names in original and corrected paths. Follow imports from the specific entry point rather than choosing whichever filename looks familiar. The model's forward computation does not need the target label, but the existing offline scoring loaders still expect labeled datasets. Conceptual label-free prediction is not proof that this repository already contains an unlabeled production-serving endpoint.

## A run creates a chain of evidence

Suppose you ask, “Does A benefit from five earlier transactions?” A credible answer needs more than a table cell:

```text
Question
  → two declared configurations
  → actual resolved settings and source version
  → data and frozen preprocessing identity
  → a training attempt for each
  → selected checkpoint for each
  → predictions for the same assessment rows
  → paired comparison
  → qualified interpretation
```

**Resolved settings** means the final settings after defaults and command-line changes are combined. **Identity** means enough information to distinguish the exact thing used from another version. A **hash** is a reproducible fingerprint of bytes; matching hashes support a claim that the bytes are the same, not that those bytes are scientifically correct.

An **attempt** is one execution of a run. If a run fails and you retry, those are two attempts at the same intended configuration. A **ledger** is a table tracking which attempts started, finished, failed, and produced outputs. Keeping these distinct prevents a failed run from being silently treated as a valid result or an older prediction file from being attached to a newer model.

The current runner and analysis files are designed to keep this chain explicit. In `analysis_runs.py`, the `V1_RUNS` list names the expected experiments. `find_runs` looks for successful attempts and associated evaluation predictions. `post_scored` checks that a later scoring record matches the recorded checkpoint and has not silently changed the evaluation range. A missing output leads to a missing comparison; it should not be filled with a guess.

This is useful even without GPUs. Given an existing run record, you can ask whether its checkpoint, predictions, and configuration belong together. You are checking evidence already produced, not retraining the model.

## A short history of the design, without memorizing every meeting

The useful sequence is: single-transaction baseline, scalable reading and frozen preprocessing, history-aware models, corrections to the experimental machinery, then matched experiments. The reason to know this history is to understand why the repository has both original files and corrected copies.

The original single-transaction route establishes a reference: what can the current row tell us? Flat A tests learning interactions across feature tokens from a history window. Hierarchical B first summarizes individual transactions, then learns across those summaries. B's all-position mode asks a different training and context question, so it is reported separately rather than automatically treated as a longer-history equivalent.

Several corrections explain seemingly fussy pieces of code:

| Failure pattern | Why it matters | Mechanism to understand now |
|---|---|---|
| Workers independently shuffle before claiming files | Some files can be repeated while others are missed | Coordinate file ownership; current loaders use explicit partitioning rules |
| Earlier tokens can read a summary token that already read later tokens | Information can travel backward indirectly through multiple layers | Check the complete attention graph, including CLS |
| Same-time transactions are ordered by an arbitrary identifier | Sorting is deterministic but may not prove real arrival order | Strict earlier-time history in active A/B |
| Time gaps for an early prediction reference a later target | A numerical feature itself can reveal future information | Per-position legal time semantics in all-position B |
| A scorer uses a different feature/history configuration from training | The same weights receive a different meaning of input | Save and check the model's input contract |
| Metrics or predictions are mixed between attempts or epochs | The reported model does not correspond to one actual saved state | Associate checkpoint, predictions, settings, and metric records |

These are mechanisms, not a claim that every historical file is now safe to launch. For example, the corrected older sequence reference under `waqas/base/data/sequence_builder.py` and the active A/B builders do not have identical history semantics. Chapters 07, 10, and 11 identify the exact active path. Historical audit documents describe their own dated findings; this course does not turn them all into current open defects or current fixes.

## What “version 1” means at this snapshot

The current V1 analysis list has 15 cells and seed 42. A **cell** is one chosen combination of experiment settings. It includes REF-SINGLE, A and default-B history ladders at 0, 5, 10, 15, and 20, A time-gap-off controls at 5 and 10, A's causal-mask control at 5, and B's separate all-position H5 condition. That is 1 + 5 + 5 + 2 + 1 + 1 = 15.

It is not “15 independent confirmations of a winner.” Many cells answer different questions; one training seed does not measure sensitivity to different random initializations. REF and A/B retain recipe differences. Chapter 14 explains how to state those comparisons honestly.

Later feature, optimizer, data-size, and pretraining ideas belong to separate questions. At the checked snapshot, Phase 5 is parked. Candidate branches and a plan to try an optimizer are not evidence that it improves this fraud task. The latest project records also distinguish the delivered larger-data package from the subsequent choice to defer those fits while prioritizing smaller-data exploration. Those workflow records explain status; they do not substitute for run evidence.

The course ends at knowing how to interpret the results. It deliberately does not ask you to memorize a historical leaderboard. Results change; the ability to verify the chain above remains useful.

## Repair challenge: which file would you inspect?

A colleague says, “B at H5 must always receive exactly six real rows.” Another says, “A-H00 and REF-SINGLE are the same experiment.” A third says, “The best evaluation AP identifies the unbiased final winner.”

<details markdown="1">
<summary>Reveal the investigation, not just the answer</summary>

For the first claim, ask which B mode. Default B uses a target window with padding as needed. Strict all-position B groups distinct whole-second values and can contain more than H+1 rows because multiple transactions share a second; boundaries also affect available history. Inspect B's sequence builder and model contract. Return to Chapter 11.

For the second, compare REF's construction and configuration with A's. They differ in model implementation and training recipe, even with no historical rows. A-H00 is a within-A history control; REF is the retrained single-transaction benchmark. Return to Chapters 09–10 and 14.

For the third, repeated use of evaluation to choose models makes it development evidence. Use validation for intended selection and acknowledge reuse of evaluation and uncertainty. Return to Chapters 05 and 15.
</details>

**Teach-back:** without opening the table, point to the conceptual place you would investigate a missing-value error, a history leak, a bad checkpoint pairing, and an unfair metric comparison. Name the layer first, then the file. Remembering the exact spelling of a filename is less important than understanding why it is the right place.

**Source check:** `analysis_runs.py` lines 30–53 (`V1_RUNS`), 71–83 (`post_scored`), 86–110 (`find_runs`); `parallel_v1.py` lines 1–12 and 43–59 (execution/queue intent); `waqas/base/README.md` (copy structure). Model and data details are sourced in Chapters 05–12. Current/proposed status also uses the latest dated CH continuity record; it is reported workflow context, not observed bank execution in this course build. Package006 capabilities belong to its delivered branch/package; its `waqas/v2/` runtime is not present in this pinned main source tree.
