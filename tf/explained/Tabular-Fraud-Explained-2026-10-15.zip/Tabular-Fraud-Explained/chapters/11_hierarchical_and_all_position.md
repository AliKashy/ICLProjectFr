# 11 · Architecture B: summarize rows, then history

**Prerequisite refresher.** A feature tokenizer creates one vector per input field. Attention combines allowed value vectors using learned weights. CLS is a learned collector. Architecture A places all feature tokens from a window into one attention sequence and scores its final target. A causal mask blocks later-to-earlier information flow, but input construction must also respect what was available at the decision time.

**Your concrete question:** can we compare a long transaction history without making every feature token attend directly to every feature token in every other row?

Architecture B uses two stages. First, it summarizes the features **within each transaction**. Then it compares the resulting transaction vectors **across the history**. “Hierarchical” means this two-level organization. It does not mean a hierarchy of employee roles, classes of fraud or separately trained models.

## Stage 1: one shared transaction reader

Suppose each transaction has three feature tokens of width four. B adds a transaction CLS token to those three tokens, runs a token-level transformer, and keeps that transaction's CLS result. The output is one width-four vector summarizing the row.

It repeats this operation for all transaction slots, using the **same learned weights**. Sharing weights means that amount and channel are processed by the same function whether the row is old or current. There is not a separate feature encoder trained for each account or slot.

During stage 1, one row's feature tokens do not attend to another row's tokens. In ordinary single-target B, a supplied time-gap feature may already refer to the target time, as Chapter 10 explained. Thus “independently encoded” means there is no cross-row attention at this stage; it does not claim every supplied input was constructed without reference to the window.

## Stage 2: compare the transaction summaries

B restores the history axis, adds a learned transaction-position vector to each row summary, prepends a **sequence CLS**, and runs another transformer over those transaction vectors. The sequence CLS is different from the transaction CLS:

- The transaction CLS collects feature information within one row.
- The sequence CLS collects information across rows in a window or chunk.

In default single-target B, the classification head reads sequence CLS and produces two logits for the final target. The target's label remains outside the inputs.

Use the same toy dimensions as Chapter 10: two windows, three transaction slots, three feature tokens per transaction and width four.

| Operation | Shape |
|---|---|
| Tokenize six transaction slots | `[6,3,4]` |
| Add transaction CLS to each | `[6,4,4]` |
| Token encoder and select transaction CLS | `[6,4]` |
| Restore windows | `[2,3,4]` |
| Add position, prepend sequence CLS | `[2,4,4]` |
| Sequence encoder | `[2,4,4]` |
| Select sequence CLS, apply head | `[2,2]` |

A stage-2 attention link therefore compares two learned transaction summaries. It does not directly compare one historical amount token with one target channel token at that stage. Useful feature information must survive the stage-1 summary. This is a tradeoff: it reduces cross-transaction attention size, while asking a fixed-width vector to carry the relevant contents of each row.

## Count the attention work, then state the limits

A has roughly `(1+T×F)²` attention entries per head per layer per window. B has a within-row term `T×(F+1)²` for each transaction-encoder layer and a sequence term `(T+1)²` for each sequence-encoder layer. The `+1` terms are the appropriate CLS tokens.

With `T=3` and `F=3`, A's table has `10²=100` entries. One layer at each of B's stages has `3×4² + 4² = 48+16=64` entries. This toy comparison does not compare complete configured models: B may use different numbers of layers at its two stages, different widths, and additional projection/feed-forward work.

Using the current time-gap-enabled schema from Chapter 06, `F=30`. With `H=15`, ordinary windows have `T=16`: A has `(1+16×30)²=481²=231,361` entries. B has `16×31² + 17² = 15,376+289=15,665` for one layer in each stage. These are attention-table counts, not measured speedups. In the checked B base configuration, stage 1 has two blocks and stage 2 has four; a fair accounting applies those depths and the rest of the computation. Do not advertise a ratio of table entries as a benchmark result.

Default B and A can both use bidirectional attention for a final target, or causal sequence information flow. B's causal sequence CLS follows the same one-way collector rule: it may read all valid rows, while row vectors cannot read sequence CLS. Padding is hidden from real readers, with the same diagonal safeguard for otherwise fully masked padded queries. Stage 1 has no temporal cross-row attention to mask.

## All-position B is a different data and prediction contract

The optional `predict_every_transaction` mode attaches the head to every output transaction vector rather than only sequence CLS. That sounds like a small output change, but making the predictions honest requires a different dataset construction.

Default B uses **sliding target windows**: one window per chosen target, with up to H earlier rows. Those windows overlap. If you simply trained on all labels in every overlapping window, a row could become a training target multiple times, and its supplied features could include time gaps to a later final target. “One loss per row” would then be false.

The implemented all-position contract instead uses **nonoverlapping chunks**. A chunk is a disjoint consecutive group of rows from one account within one file. Each real row owns one prediction and one target label. There is no history carried across chunk or file boundaries. Early rows in a chunk have less context than late rows. This is an actual change in the experiment, not a faster implementation of exactly the same H-history task.

The configuration must explicitly opt in to nonoverlapping chunks and causal attention. It also requires stride one, so every real row is a target. **Stride** controls which ordinary target positions are selected; using stride greater than one would violate this all-row ownership contract.

The output shape becomes `[B,W,2]`: `B` is the number of chunks in the batch, `W` is the padded number of row slots per chunk, and 2 counts class logits per slot. The shape letter `B` means batch size here; it is not a reference to the architecture name. `W` is explained below; in strict mode it is not always `H+1`.

## Strict all-position time policy: work a tied-timestamp example

In the strict policy, row `i` can read itself and real rows in its chunk whose parsed timestamps are strictly earlier. Two rows with exactly equal timestamps cannot read one another, even if a tie-break sort puts one first. A deterministic display order does not prove information availability.

Consider synthetic timestamps `[10,20,20,30]`, denoting whole seconds for this example. Give the tied rows descriptive names “first row at 20” and “second row at 20”; these are not actual transaction identifiers.

| Row | Can read other real rows | Backward gap | Strictly earlier row count |
|---|---|---:|---:|
| At 10 | None | 0 | 0 |
| First at 20 | At 10 | 10 | 1 |
| Second at 20 | At 10 | 10 | 1 |
| At 30 | At 10 and both at 20 | 10 | 3 |

Every row may also read itself. The gap is seconds since the latest strictly earlier timestamp **inside the chunk**, or zero when none exists. Its input is `log(1+gap)`, giving `[0,2.398,2.398,2.398]` approximately. It is not a gap to the final row in the chunk.

Why give both tied rows the same position index? If their position embeddings were simple slot numbers 1 and 2, adding a same-time sibling could change the second row's representation even though attention forbids reading that sibling. The code instead indexes the position table using the number of real rows with strictly earlier timestamps, capped at H. With `H=2`, the example indices are `[0,1,1,2]`: the final count 3 is capped at 2 because the table has indices 0 through 2.

Capping merges some later positions into the same learned position vector. It does not drop the earlier rows or change the timestamp mask. It is a defined representation choice that should stay in the checkpoint's recorded contract.

The word “strict” compares the parsed timestamp at its stored precision, represented internally in nanoseconds. **Nanoseconds** are billionths of a second; this integer representation can distinguish subsecond timestamps when present. The gap channel is expressed in whole seconds. Two timestamps in one whole second can therefore be strictly ordered yet have a zero-second gap. Do not confuse whole-second gap arithmetic with the exact equality test used for visibility.

## Why strict chunks can contain more than H+1 rows

Strict chunk boundaries are cut between whole seconds. Each strict chunk contains at most `H+1` distinct whole-second values for an account. It does **not** have a hard maximum of `H+1` transaction rows.

With `H=2`, the example `[10,20,20,30]` contains three distinct seconds and therefore fits into one strict chunk of four rows. The next new second begins the next chunk. This avoids moving a row into a different chunk merely because a same-second sibling was added or removed.

The builder emits a width of at least `H+1`, expands when a chunk has more rows, and right-pads each batch to its widest chunk. If one chunk has four rows and another has two, a width-four batch represents the second as `[real,real,pad,pad]`. This differs from the left padding of ordinary target windows.

Strict chunk context can exceed H earlier **rows**, because earlier seconds can contain many transactions. It is bounded by the selected distinct-second grouping, not by the ordinary sliding-window row count. Dense activity can therefore make W large. The sequence attention and its per-batch, per-head mask then grow roughly with `W²`. An optional `max_chunk_rows` cap raises an error when exceeded; it does not silently truncate or discard rows. This is a memory guard to configure from measured widths, not a promise that arbitrary data fits.

A separate supported `tiebreak` policy uses earlier chunk positions as availability order, chunks of `H+1` rows, ordinary slot positions, and previous-row gaps. For `[10,20,20]`, those gaps are `[0,10,0]`, versus strict `[0,10,10]`. It is an explicitly different policy requiring a justified availability interpretation. The current strict path must not be described using old positional semantics.

## How all-position labels contribute to loss

The builder supplies `target_seq` with one label for each real row and a sentinel value `-100` for padding. A **sentinel** is a reserved marker, not a genuine class. The real mask and label availability must agree exactly.

The model selects only real-row logits and labels. It sums their class-weighted cross-entropy terms and divides by the number of actual real transactions. For synthetic per-row terms `[0.2,0.6,1.0]`, the loss is `(0.2+0.6+1.0)/3=0.6`. Two padded slots do not change the denominator to five. A batch containing no real targets is rejected.

One subtle difference: default single-target B uses the library's usual weighted cross-entropy mean, whose denominator is the sum of selected class weights when class weights are enabled. All-position B deliberately divides its summed weighted terms by the number of real rows. When weights are all one, the distinction disappears. With non-unit class weights, raw loss scales should not be casually compared across modes. The all-position logging uses the real-target count so epoch aggregation also weights the actual predictions correctly.

All-position `embed()` still returns **sequence CLS**, a summary that can read the whole chunk. That is appropriate as a chunk-end representation. It must not be used as an earlier row's decision-time embedding. The safe per-row outputs are produced from their causally restricted transaction positions; a convenient summary export is not a substitute.

## Current implementation, historical paths and evidence

The source includes both default B and the explicit all-position contract. The V1 experiment set contains an all-position comparison, but the presence of a path or a reported comparison is not proof of general superiority. Results belong to the exact configuration, data, checkpoint and selection protocol described in Chapters 12–15.

Checkpoint loading compares a recorded **sequence contract**: architecture settings, layout, gap reference, input artifact identity and all-position time policy. Matching tensor shapes cannot reveal a changed vocabulary, shifted feature order or old tie policy. Old all-position checkpoints lacking the required contract are rejected; a historical checkpoint cannot be renamed into the corrected experiment. Legacy default single-target loading has narrower checks and warns about unverifiable artifact identity.

| Source location | Source-checked operation |
|---|---|
| `waqas/phase4b/sequential_hier.py`, constructor and `forward`, lines 96–170 and 276–325 | Shared transaction encoder, sequence encoder, two CLS roles and prediction head selection |
| Same file, `_build_causal_mask`, lines 226–274 | Causal collector rule, exact-time visibility and padding safeguard |
| Same file, `forward` and `_checked_times`, lines 297–348 | Strict earlier-count positions, width/time validation and distinct-second limit |
| Same file, `embed` and `_step`, lines 350–379 | Chunk-end summary limitation, exact target ownership and real-row loss denominator |
| Same file, `sequence_contract` and checkpoint hooks, lines 172–224 | Mode/time policy compatibility and legacy behavior |
| `waqas/phase4b/sequence_builder.py`, `_chunks_for_file`, `_chunk_spans`, `_chunk_gaps`, lines 415–512 | Disjoint targets, distinct-second chunks, backward gaps and row cap |
| `waqas/phase4b/factory.py`, `sequence_dataset_options`, lines 11–34 | Explicit mode, causal mask, layout, stride and time-gap requirements |

## Prediction, repair and teach-back

**Predict.** With `H=2`, a strict chunk contains times `[10,10,20,30]`. Can it contain four rows? What position indices and backward gaps does it use?

<details><summary>Reveal the worked answer</summary>

Yes: it has three distinct whole seconds, so it fits the `H+1=3` distinct-second budget. Strict earlier counts are `[0,0,2,3]`, capped to indices `[0,0,2,2]`. Backward gaps are `[0,0,10,10]`: neither first tied row has a strictly earlier row in this chunk; the row at 20 looks back to time 10. Attention excludes same-exact-time siblings but includes all strictly earlier real rows. The gap values are then transformed with `log1p`.

</details>

**Repair.** “All-position B is just default B with more labels. Its `embed()` gives the right vector for every transaction, and H=15 means no more than 15 earlier rows.”

<details><summary>Reveal the repair</summary>

All-position changes target ownership, overlap, chunk boundaries, time gaps, output positions and the loss calculation. `embed()` gives a whole-chunk summary, which includes later context relative to early rows. Strict chunks have a distinct-second budget; tied seconds can produce more than H earlier rows for a later prediction. Ordinary sliding-window H and strict chunk H must not be treated as identical context definitions.

</details>

**Teach back.** Draw A, default B and all-position B. Explain where feature information is summarized, which output receives the loss, and when each row's inputs were available.

<details><summary>Use this rubric</summary>

For A: feature-level flat sequence and one target CLS loss. For default B: independent shared row encoder, sequence encoder, one target sequence-CLS loss. For all-position B: disjoint chunks, causal per-row sequence outputs, backward gaps, strict tie handling, one real target per row and no padding targets. Include the whole-chunk CLS caveat and the fact that context resets. Missing either availability or ownership means the comparison is not yet defensible; return to Chapters 05, 07 and 10 before explaining the speed tradeoff.

</details>

**Recall prompt:** explain why B can reduce attention work yet still needs a fair experiment; then reconstruct the tied-time example without looking. Repair attention in Chapter 09 and target-time semantics in Chapter 10. Chapter 12 follows these forward calculations into training, checkpoints and reproducible runs.
