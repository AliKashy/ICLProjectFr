# 15 · Turn scores into metrics you can explain by hand

**Prerequisite refresher.** A label is the known target, here 1 for fraud and 0 for legitimate. A logit is an unrestricted model output before probability conversion. A score is a number used to rank or decide. Chapter 04 explained loss; Chapter 14 explained comparisons and uncertainty. You now learn what the main numbers actually measure.

**Your concrete question:** “How can a fraud model have 99.9% accuracy and still be useless?”

If only 10 of 10,000 transactions are fraudulent, predicting every transaction legitimate produces `9,990 / 10,000 = 99.9%` accuracy while catching zero fraud. **Class imbalance** means the class frequencies are very unequal. It makes ordinary accuracy a poor headline measure for many fraud decisions. The right metric depends on what action the scores support.

## From logits to scores, then decisions

The current A/B binary classifiers produce two logits per scored transaction. **Softmax** exponentiates each logit and divides by the sum, producing two nonnegative values that add to one. For synthetic logits `[0, log(3)]`, the exponentiated values are `[1,3]`; the fraud-class score is `3 / (1 + 3) = 0.75`.

That arithmetic does not prove “75% of these transactions will be fraud.” Such a probability interpretation requires calibration evidence. The output is usable as a ranking score even when its probability scale is imperfect. **Calibration** means that among cases assigned a given risk level, the observed event rate broadly matches that level in the relevant population.

A **threshold** turns a score into an action rule: for example, alert when score is at least 0.60. A threshold is a policy choice; 0.50 is not automatically appropriate for rare fraud or limited investigation capacity. A business may instead choose a fixed **alert budget**: investigate the highest-scoring 200 transactions each day, or the top 1%.

## A single synthetic example for several metrics

Use the same six fictional transactions throughout this section. They are already sorted from highest to lowest score:

| Rank | Label | Score |
|---:|---:|---:|
| 1 | 1 | 0.90 |
| 2 | 0 | 0.80 |
| 3 | 1 | 0.70 |
| 4 | 0 | 0.40 |
| 5 | 1 | 0.30 |
| 6 | 0 | 0.10 |

At threshold 0.60, the top three alert. Two are fraud; one is legitimate. Of the bottom three, one is fraud and two are legitimate. The **confusion matrix** names these four counts:

| | Actually fraud | Actually legitimate |
|---|---:|---:|
| Alert | True positive: 2 | False positive: 1 |
| No alert | False negative: 1 | True negative: 2 |

“Positive” means the event class being detected. A false positive is a legitimate transaction flagged as fraud. A false negative is fraud that was missed. The terms describe the rule relative to known labels, not moral judgments about a customer.

**Precision** asks, “Of the alerts, what fraction are fraud?” Here it is `2 / (2 + 1) = 2/3 ≈ 0.667`. **Recall**, also called true positive rate, asks, “Of all fraud, what fraction did we alert?” It is `2 / (2 + 1) = 2/3` here too. The equal numbers are a coincidence caused by this tiny table.

The **false positive rate** asks, “Of legitimate transactions, what fraction were alerted?” It is `1 / (1 + 2) = 1/3`. Its denominator is legitimate transactions; precision's denominator is alerts. Mixing those denominators is a common interview error.

At threshold 0.85, only the first row alerts: precision becomes 1/1 = 1, recall becomes 1/3. At threshold 0.25, the top five alert: precision is 3/5 = 0.6 and recall is 3/3 = 1. Lowering a threshold cannot remove alerts from the same fixed score set. Recall therefore cannot decrease, though precision need not change monotonically at every threshold.

## Average precision: reward finding fraud early in the ranking

**Average precision**, or AP, summarizes precision as recall increases across the ranking. With distinct scores, a convenient calculation is to record precision at each positive row and average those values. In our table, fraud appears at ranks 1, 3 and 5:

- At rank 1, precision is `1/1 = 1`.
- At rank 3, precision is `2/3`.
- At rank 5, precision is `3/5`.

`AP = (1 + 2/3 + 3/5) / 3 = 34/45 ≈ 0.7556`.

Why average those positions? Each newly encountered positive increases recall by one third in this example. AP adds `precision × increase in recall`. The general expression is the sum of those precision-weighted recall increases. It handles the curve's steps rather than drawing arbitrary straight lines between points.

With tied scores, process the tied score group together. Arbitrarily sorting positives first within a tie would manufacture performance the model did not provide. The project's `average_precision_score` handles ties by threshold groups. The learning lab implements the same grouped-score concept for tiny examples.

Some project outputs call AP `pr_auc`. Read the implementation: the core metric is scikit-learn's **average precision**, not a generic trapezoidal area under a precision-recall curve. Those calculations can differ. “PR-AUC” without defining the computation is ambiguous.

Fraud prevalence is the fraction of rows with label 1. Here it is 3/6 = 0.5. In real rare-event data it is much lower. Prevalence provides a useful rough no-skill reference for a precision-recall curve; finite-sample random AP can deviate. AP values across cohorts with different prevalences and difficulty are not directly interchangeable.

## AUROC: compare a fraud case with a legitimate case

**AUROC**, area under the receiver operating characteristic curve, summarizes true positive rate against false positive rate over thresholds. A particularly useful interpretation is pairwise ranking: choose one fraud and one legitimate example. How often does fraud receive the higher score? A tie counts as half a win.

Our three fraud scores are 0.90, 0.70 and 0.30. The legitimate scores are 0.80, 0.40 and 0.10. There are `3 × 3 = 9` fraud–legitimate pairs. The 0.90 fraud wins all three comparisons, 0.70 wins two, and 0.30 wins one:

`AUROC = (3 + 2 + 1) / 9 = 6/9 ≈ 0.6667`.

AP and AUROC differ because they summarize different properties. AP emphasizes precision as fraud is recovered in the ranked list. AUROC measures all positive-negative pair ordering. Under severe imbalance, a strong AUROC does not guarantee an attractive precision at a small alert budget. Read both, and include the operating point the business can use.

If a cohort contains only one class, AUROC is undefined: there are no fraud-legitimate pairs. The project's ranking reporting requires both classes; the validation callback skips those metrics for a one-class validation stream. An undefined metric is not a score of zero.

## Alert budgets, dollars and costs

If investigators can handle two alerts from the six-row example, the top two contain one fraud: precision at that budget is 1/2 and recall is 1/3. If the cutoff intersects a tied score group, there must be an explicit tie policy. The project's budget utility reports expected metrics under uniform selection within a cutoff tie, rather than exploiting label order.

Transaction recall and fraud-dollar recall answer different questions. Catching one high-value fraud can dominate dollars while missing many smaller fraud transactions. To measure dollar recall, specify the amount field, valid units, available-at-decision semantics and numerator/denominator. Do not silently infer economic savings from AP.

A simple synthetic cost illustration: suppose each false alert costs 2 units to review, and each missed fraud costs 50 units, with all fraud equal for this toy example. Threshold 0.60 gives cost `1×2 + 1×50 = 52`. Threshold 0.25 gives `2×2 + 0×50 = 4`. This does not choose a real bank policy: real costs, recovered losses, customer friction, intervention effects and capacity all matter. It shows why a ranking metric is not a complete business decision.

## Probability quality and calibration

The **Brier score** averages squared differences between predicted probability and binary label. For predictions `[0.8,0.2]` with labels `[1,0]`:

`Brier = ((0.8−1)² + (0.2−0)²) / 2 = 0.04`.

Lower is better under this measure. Like other aggregate measures it must be interpreted with prevalence and a suitable baseline. A model can rank well while probabilities are too extreme, or produce conservative probabilities with a poor ranking.

The calibration utility can fit a sigmoid-based mapping or **isotonic regression**, a flexible nondecreasing mapping. It fits on validation predictions and applies to separate test predictions, checking identifier overlap. Calibration does not retrain the fraud encoder. Isotonic mapping may create score ties; changing ties or ordering can change ranking measures. Do not promise that calibration always preserves AP or improves every metric. This utility exists; it is not evidence that the V1 scores were calibrated or a deployed threshold was selected.

## Read a results row as a chain of evidence

Begin with run identity: which source, recipe, data cohort, artifact versions, seed and checkpoint? Then inspect row/fraud counts, missing or duplicate predictions, and score validity. Only after that compare AP, AUROC and applicable operating-point measures. For differences, read the paired interval and its assumptions from Chapter 14.

Next distinguish selection from evaluation. `valid_ap` may identify the best epoch; evaluation AP measures that chosen checkpoint on the evaluation cohort. A training-metrics CSV may round displayed values, so a formatted six-decimal number is not the full underlying value. “Best validation epoch” and “highest evaluation history setting” are different selections.

Finally read provenance. **Provenance** is the record of where an artifact or claim came from. An implemented scorer, a reported bank run, a returned aggregate file and an independently reproduced run are different evidence types. The course inspected source and available reported artifacts; it did not rerun native transaction joins or generate new bank performance. The current reviewed evidence does not establish a history-model winner over REF.

One implementation boundary matters for deployment questions. Mathematically, a forward pass uses features and learned parameters, not the unknown fraud label. The current offline loaders/scorers nevertheless require the target column in their input contract, even when metric computation is disabled. They are tools for labeled offline evaluation. An unlabeled live-serving input adapter and operational service are separate work; they are not already implemented merely because a `score` script exists.

## Where these calculations connect to code

- `fraud/callbacks.py`, `StreamingBinaryMetrics`, lines 62–79: softmax scores and whole-validation-stream AP/AUROC.
- `waqas/phase4a/scripts/score_sequential.py`, `main`, lines 103–170: load selected state, evaluate without gradients, align scores/labels/metadata, check probabilities and report checkpoint identity.
- `waqas/scoring/leaderboard.py`, lines 307–342: AP is computed by `average_precision_score` even where output uses `pr_auc` naming.
- `waqas/scoring/calibrate_and_report.py`, `_fit_calibrator`/`_calibrate`, lines 100–113, and `main`, lines 176–200: validation-fitted calibration, separate evaluation and Brier/budget reporting.
- `waqas/scoring/_prediction_utils.py`, `at_budget`, lines 112–134: the utility's tie-aware budget calculation.

## Predict, repair, explain

**Predict.** A model alerts nobody on a set with 0.1% fraud. What are accuracy and recall? Is precision meaningful with zero alerts?

**Repair.** Someone says, “AP 0.20 means exactly 20% of all predictions are correct, and a score of 0.80 proves an 80% fraud probability.” Correct both interpretations.

**Teach back.** Recompute AP and AUROC from the six-row table without looking at the worked answers, then explain one reason neither automatically chooses an alert threshold.

<details><summary>Answers and self-check rubric</summary>

Accuracy is 99.9%; recall is zero. Precision has a zero denominator with no alerts and needs an explicit undefined/reporting convention. AP summarizes precision over recall changes, not overall accuracy. Probability interpretation needs calibration evidence. The table gives AP 34/45 ≈ 0.7556 and AUROC 6/9 ≈ 0.6667. Full credit uses correct denominators, states the tie rule, and connects a threshold to costs or capacity rather than assuming 0.5.

</details>

**Recall without looking:** explain score, threshold, precision, recall, AP, AUROC and calibration as seven different things. If ratios remain difficult, repair with Chapter 02. If a small AP difference still feels like a proven win, return to Chapter 14. Chapter 16 turns these calculations into runnable CPU experiments.
