# 14 · Ask a fair question, then measure how uncertain the answer is

**Prerequisite refresher.** A model turns inputs into scores; training uses labels to learn parameters; validation selects settings or checkpoints; evaluation measures chosen models on a separate cohort. A history length of five means a target may use up to five eligible earlier transactions, not that every target possesses five. Chapters 05–07 explain eligibility. Chapter 12 explains why the resolved run settings matter.

**Your concrete question:** “If B scores higher than A, can I say the hierarchical model is better?”

Sometimes the evidence supports a narrower statement. First ask what changed, which examples were compared, how the models were selected, and how uncertain the difference is. These are not formalities added after the result. They determine what the result means.

## A hypothesis needs an exact comparison

A **hypothesis** is a testable expectation, such as “adding eligible history improves fraud ranking.” An **experiment condition**, also called a cell, is one fully specified run recipe. An **ablation** changes or removes a component to study its contribution. A **contrast** is the numerical difference between specified conditions, with a stated direction such as `A-H05 minus A-H00`.

To ask whether history helps flat A, compare A at history five with A at history zero while matching the other intended settings. A-H00 still uses A's architecture and recipe; it is not automatically the same model as REF-SINGLE. REF has its own dimensions, depth, batch size and learning rate. Comparing A-H05 against REF asks whether one complete recipe beats another practical reference. It does not isolate history as the only cause.

The V1 plan contains 15 conditions:

| Family | Conditions | Main question |
|---|---|---|
| REF | Single-transaction reference | What is the existing recipe's benchmark on the matched cohort? |
| A | H0, H5, H10, H15, H20 | How does flat A behave across requested history lengths? |
| Default B | H0, H5, H10, H15, H20 | How does hierarchical B behave across requested history lengths? |
| A controls | Causal mask at H5; gap off at H5 and H10 | What changes with these information/computation choices? |
| All-position B | H5-labeled chunk condition | How does this distinct training/scoring mode behave? |

All use the current V1 seed 42. Config files for additional seeds or capacity sweeps exist, but files on disk are not proof those experiments belong to the completed V1 study. The results are reported as completed; this course does not rerun their bank workloads.

## “Only one change” requires inspection

A **confound** is another difference that makes the intended causal explanation ambiguous. Suppose GAP-OFF uses a different micro-batch size from GAP-ON. Both may have the same nominal effective batch after accumulation. Their actual grouping and stochastic computation can still differ. The observed difference cannot be attributed to the gap alone with the strongest possible interpretation. That is a qualification to report, not a reason to discard every measurement.

All-position B changes several things together: chunk construction, information masks, gap reference, which positions carry loss, and batch meaning. A depth-matched subset compares selected targets with a comparable amount of eligible context. It does not make the entire training procedures identical. Its result answers a subset question, not “all-position training alone caused the difference.”

The word **matched** must name what matches: same target rows, labels, history availability, preprocessing, seed, architecture, compute budget or training recipe. These are separate properties. Two models can be matched on evaluation rows and deliberately differ in architecture.

## Match the actual predictions before comparing scores

Suppose model X predicts synthetic targets `{a,b,c,d}` and model Y predicts `{a,b,c}`. Computing AP on each set compares different exams. Keeping only `{a,b,c}` silently changes the target cohort and hides the missing prediction. The current paired report instead counts mismatches and marks the affected contrast invalid for numeric comparison.

The project uses a composite key formed from transaction identity and account identity to align predictions. A **join** matches records using keys. Keys are bookkeeping for alignment; their role in joining does not make them model features. Duplicate keys, missing keys, extra keys, nonbinary labels, nonfinite scores and label disagreements must be checked. A **finite** score excludes values such as infinity or “not a number.”

After a clean join, both models must be measured on the same labels in the same aligned row order. A high AP attached to the wrong rows is not useful evidence.

## Sampling uncertainty: what another group of accounts might show

A measured score depends on which examples were available. **Sampling uncertainty** describes how an estimate might vary across plausible samples from the population represented by the observed data. The **bootstrap** approximates that variability by repeatedly resampling the observed units with replacement and recomputing the statistic.

“With replacement” means a selected unit can appear again. If the observed accounts are A, B and C, one bootstrap draw might select `B, B, C`. Every transaction belonging to B then has multiplicity two, C multiplicity one and A multiplicity zero. This keeps each account's transactions together.

Why accounts? Transactions from one account can be related. Treating every transaction as independent can give a misleading sense of how much independent information the dataset contains. Whole-account resampling preserves within-account bundles. It still makes assumptions: account clusters should represent meaningful sampling units, and it does not model every shared merchant, calendar or future shift.

For a paired comparison, use the **same account draw for both models**, then subtract their statistics inside that draw. If X AP is 0.24 and Y AP is 0.21 in one draw, the difference is `0.24 − 0.21 = +0.03`. Another draw might give `0.18 − 0.20 = −0.02`. Collect many such differences. You are measuring the variability of the difference directly.

This is stronger reasoning than separately drawing unrelated samples for X and Y or subtracting the endpoints of two individual intervals. Those methods do not preserve the shared easy/hard cases in the same way. Pairing uses the fact that both models answered the same exam.

## Read an interval with the right claim

A 95% **percentile bootstrap interval** takes lower and upper percentiles of the bootstrap difference distribution. With many draws, the 2.5th and 97.5th percentiles give the usual 95% interval. “Percentile” means the value below which a specified fraction of ordered draws falls.

Consider three entirely synthetic examples:

| AP difference X − Y | Interval | Defensible reading |
|---:|---|---|
| +0.012 | [−0.006, +0.030] | The observed difference is positive; this interval includes both signs. |
| +0.012 | [+0.004, +0.020] | This account-resampling interval supports a positive difference for these fixed models and cohort assumptions. |
| −0.010 | [−0.018, −0.002] | The interval supports a negative difference under those same limits. |

An interval crossing zero does not prove equality, no benefit, or noninferiority. **Noninferiority** is a separately designed claim that a method is not worse by more than a predefined acceptable margin. An interval entirely above zero does not prove production value or immunity to future drift.

A confidence interval is also not a guarantee that 95% of future transactions fall between its endpoints. Its endpoints concern a population-level statistic or difference, not individual scores. The repeated-sampling intuition is that a well-behaved 95% interval procedure, under appropriate assumptions, would cover the target in about 95% of repeated comparable studies. That nominal coverage relies on the method and assumptions; do not read it as a direct probability statement that a fixed unknown difference is inside this particular interval.

## Which uncertainty is missing?

These account bootstrap intervals keep the trained checkpoints fixed. They do not retrain the network on each draw. Therefore they do not capture **training-seed uncertainty**: how random initialization and training variation affect the outcome. Seed 42 alone cannot estimate the distribution across training seeds. **Standard deviation** summarizes how spread out values are around their mean; for seed results, it measures observed run-to-run spread. An output displaying a seed standard deviation of zero when only one seed exists means there is no observed seed spread to estimate, not that training is deterministic.

They also do not capture future temporal shifts, repeated architecture selection, or the possibility that another split would tell a different story. **Pointwise** means each interval applies to its own comparison. If you inspect many comparisons and celebrate whichever is largest, the ordinary individual intervals do not automatically correct for that search.

A **post-hoc** comparison is chosen after looking at the data. It can be useful for exploration, but it should be labeled. A fresh confirmation should use an appropriate untouched cohort. Once evaluation results repeatedly guide model choice, that evaluation set has become development evidence. Renaming it “test” does not restore independence.

## The report's study rule is more specific than “interval above zero”

The paired report has a decision rule that combines validation direction with evaluation intervals. In current one-seed V1, a positive conclusion requires the relevant validation difference to be positive and the evaluation interval to be wholly positive, with extra validation-interval requirements only when validation predictions are supplied. Missing or incomplete validation evidence is explicitly qualified. The richer multi-seed machinery remains available for later studies.

This rule is a project convention, not a law of statistics. Report a numeric evaluation difference honestly even when the combined study label remains “not resolved.” A disagreement between validation and evaluation deserves investigation; it is not automatically proof that validation is useless.

The latest reviewed status retains REF as the benchmark and B-H15 as a provisional research candidate. The finalist contrasts against REF remain unresolved. That is the boundary for this course: learn how to interpret the evidence, without inventing a new winner or rerunning results.

## Where to verify the claims

- `runbook/2026-10-07/analysis_runs.py`, `V1_RUNS`, lines 32–53: the 15 named conditions and source specifications.
- `runbook/2026-10-07/tests/test_v1_matrix.py`, `BATCH1`/`BATCH2`, lines 20–38: expected condition matrix.
- `waqas/base/configs/ref_single.yaml`, lines 1–10: REF's distinct recipe and matched cohort intent.
- `runbook/2026-10-07/paired_report.py`, module contract, lines 28–63; `map_run`, lines 202–230; `draw_multiplicities`, lines 236–251: alignment rules, shared account draws and inference limits.
- `bridge/reviews/CH/2026-10-14-v1-results-next/README.md`, lines 5–11 and 29–58: reported study status, unresolved finalist comparisons and run-configuration qualifications.

## Predict, repair, explain

**Predict.** The measured difference is +0.004 with interval [−0.003,+0.011]. Which claim is supported: X is proven better, X and Y are equal, or the comparison remains uncertain?

**Repair.** A colleague chooses the best evaluation result from 40 variants and presents its ordinary interval as an untouched confirmatory experiment. Explain the selection problem and an appropriate next step.

**Teach back.** Use three fictional accounts to explain one paired bootstrap draw and name three kinds of uncertainty it does not measure.

<details><summary>Answers and self-check rubric</summary>

The comparison remains uncertain; the observed estimate is positive, but the interval includes zero and negative differences. The chosen result benefited from evaluation-guided selection. Label it exploratory and confirm the chosen hypothesis using a suitable untouched cohort and prespecified comparison; additional seeds address a different uncertainty. Full-credit bootstrap explanation keeps every account's rows together, uses identical draws for both models, subtracts within each draw, and distinguishes account sampling from training randomness, future time shifts and selection uncertainty.

</details>

**Recall without looking:** complete the sentence, “This interval measures ___ while holding ___ fixed; it does not prove ___.” If AP itself is still a black box, repair with Chapter 15. If cohort equality is unclear, return to Chapter 05.
