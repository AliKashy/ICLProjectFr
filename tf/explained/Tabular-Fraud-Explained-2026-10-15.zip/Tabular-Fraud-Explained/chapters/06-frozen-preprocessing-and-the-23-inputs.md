# 06 — Turn the 23 predictors into consistent model inputs

**Your question:** How does a transaction containing amounts, codes, missing values, and a date become numbers a neural network can use?

**Prerequisite refresher.** A row is one transaction. Features are the fields allowed to help predict its outcome. Training data teaches the model; held-out data assesses it. Learned conversion rules must be fitted on the designated fitting data, then reused. Chapter 05 explains why calculating those rules afresh on evaluation data changes the experiment.

**Preprocessing** is the conversion between the original record and the model's input numbers. It is not the neural network learning a fraud rule. For example, turning the category “card absent” into integer 3 is preprocessing; learning what that category suggests in combination with amount and history belongs to the model.

We will continue the invented **Target** transaction from Chapter 05: account Ember, **2026-10-15 10:00:12**, amount **150**. All values, category names, dictionaries, and statistics below are synthetic teaching examples, not actual bank encodings.

## The complete original input list

The source of truth for the original version is `fraud/configs/predictors.csv`. It lists **6 continuous**, **13 raw categorical**, and **4 derived calendar** features: `6 + 13 + 4 = 23`.

**Continuous** means numerical magnitude is meaningful. A balance of 200 is twice a balance of 100, if the units match. **Categorical** means a value names a kind or state. Category code 7 is not necessarily “more” than category code 3. The model uses a separate learned lookup representation for categories, introduced in Chapter 08.

| # | Original feature | Meaning you should be able to explain | Synthetic Target value |
|---:|---|---|---|
| 1 | `transaction_amt` | Amount in the transaction currency | 150 |
| 2 | `external_1_scr` | An externally supplied card-network fraud-risk score; a pre-existing signal, not this model's answer | Missing |
| 3 | `avlble_merch_day_cash_lmt_amt` | Available daily merchandise limit, as described in the predictor list | 800 |
| 4 | `available_daily_cash_limit_amt` | Remaining daily ATM cash limit before this transaction | 200 |
| 5 | `remain_day_merchandise_lmt_amt` | Remaining daily merchandise limit before the transaction, documented in USD | 700 |
| 6 | `total_available_balance_amt` | Available balance for the accessed account immediately before the transaction | 2,000 |
| 7 | `transaction_type_xcd` | Transaction type | `PURCHASE` |
| 8 | `segment` | Transaction category/group | `RETAIL` |
| 9 | `transaction_category_xcd` | Method used for the transaction | `ONLINE` |
| 10 | `transaction_pos_condition_xcd` | Point-of-sale/service conditions; POS means point of sale | `REMOTE` |
| 11 | `avs_request_xcd` | Address Verification Service request indicator | `REQUESTED` |
| 12 | `pos_security_xflg` | Transaction security indicator | `SECURE` |
| 13 | `transaction_pin_verify_xcd` | Personal identification number verification information | Missing |
| 14 | `cardholder_present_xflg` | Whether the cardholder was present | `ABSENT` |
| 15 | `pos_card_capture_xflg` | Terminal's capability to retain a card | `NO` |
| 16 | `cvv_verify_xcd` | Card Verification Value outcome for the entry mode | `NEW_OUTCOME` |
| 17 | `authzn_rqst_crypto_valid_xflg` | Authorization-request cryptogram result; a cryptogram is a transaction security value | `VALID` |
| 18 | `pos_off_premises_xflg` | Off-premises terminal indicator | `NO` |
| 19 | `pos_terminal_attend_xflg` | Unattended-terminal indicator | `UNATTENDED` |
| 20 | `month` | Month derived from the transaction timestamp | 10 |
| 21 | `day` | Day of month derived from the timestamp | 15 |
| 22 | `hour` | Hour derived from the timestamp | 10 |
| 23 | `day_of_week` | Monday = 0 through Sunday = 6 | 3, Thursday |

The names can be awkward. Learn the meaning before memorizing spelling. Do not invent extra precision the feature description does not provide. For example, the available-merchandise-limit description does not establish every accounting relationship among the three limit fields. Transaction amount and one limit also explicitly use different currency descriptions, so a raw ratio is not automatically meaningful. The published predictor list specifies the original features; adding merchant categories or engineered ratios belongs to a separately checked feature change.

Neither the account identifier nor transaction identifier is one of these 23 features. They support grouping, ordering, or matching output records. The raw timestamp is an ordering source and generates calendar features; it is not itself one of the original 23 predictive fields. The fraud label is the answer, also outside this list.

## First conversion: replace a missing number

**Imputation** means filling a missing input with a defined substitute. The saved continuous statistics use the **median**, the middle observed value after sorting. For observed values `[20, 40, 60, 80, 100]`, the median is 60. It is not a guess that the true missing value was definitely 60; it is a consistent way to make the numeric input usable.

The **mean** is the total divided by the number of observations. The same five values have mean `(20 + 40 + 60 + 80 + 100) / 5 = 60`. The median and mean need not match. For `[20, 40, 60, 80, 1000]`, the median stays 60 but the mean becomes 240. The middle is less moved by that one extreme amount.

If all values for a continuous feature are missing in the fitting data, the helper falls back to a fill and mean of zero. If the stored standard deviation is zero or undefined, it uses 1. Those are implementation fallbacks, not evidence that an all-missing field is informative.

Target's external score is missing. Suppose the **saved training-derived median is 480**. Its imputed score becomes 480. We also preserve the fact that it was missing with a separate indicator, explained shortly.

## Second conversion: put numbers on a consistent scale

**Standardization** expresses a value relative to a saved center and spread:

`standardized value = (filled value - saved mean) / saved standard deviation`

The **standard deviation** is a measure of typical distance from the mean. You need its practical role here before memorizing its full formula: a larger deviation means values vary more. The preprocessing helper calculates it from the nonmissing fitting values using the population convention: add the squared deviations, divide by the number of observed values, then take the square root.

With values `[50, 150]`, mean is 100. Deviations are `[-50, 50]`; squared deviations are `[2500, 2500]`. Their average is 2500. The square root is 50, so the population standard deviation is 50. The standardized values are then -1 and +1. Negative standardized amount does **not** mean a negative payment; it means below the saved mean.

Here is a complete synthetic conversion for Target's six numerical predictors. We deliberately choose simple saved statistics to expose the arithmetic.

| Field | Raw | Saved median | Saved mean | Saved standard deviation | Model number |
|---|---:|---:|---:|---:|---:|
| Amount | 150 | 100 | 100 | 50 | `(150 - 100) / 50 = 1` |
| External score | Missing | 480 | 500 | 100 | `(480 - 500) / 100 = -0.2` |
| Available merchandise limit | 800 | 600 | 600 | 200 | `(800 - 600) / 200 = 1` |
| Remaining cash limit | 200 | 300 | 300 | 100 | `(200 - 300) / 100 = -1` |
| Remaining merchandise limit | 700 | 500 | 500 | 100 | `(700 - 500) / 100 = 2` |
| Available balance | 2,000 | 1,000 | 1,000 | 500 | `(2000 - 1000) / 500 = 2` |

Target's six-number continuous vector is therefore `[1, -0.2, 1, -1, 2, 2]`. A **vector** is an ordered list of numbers. Order matters: swapping external score and balance changes what the numbers mean to the model.

Standardization does not force values between 0 and 1, remove outliers, or prove that all features now have equal predictive importance. A value can legitimately standardize to 8. The network still has to learn which patterns matter.

## Missing versus unfamiliar categories

A **vocabulary** is a saved dictionary from a category's text representation to an integer index. Each categorical feature has its own dictionary. The implementation reserves:

| Index | Meaning |
|---:|---|
| 0 | Unknown/out of vocabulary: a present value absent from the fitted dictionary |
| 1 | Missing: no value is available |
| 2 onward | Known fitted categories |

For a synthetic cardholder-present dictionary, imagine `PRESENT → 2`, `ABSENT → 3`. Target's `ABSENT` becomes 3. A newly encountered text `NOT_RECORDED_BY_THIS_VENDOR` becomes 0 if it is not in the dictionary; an actual null/missing value becomes 1. An empty text string is still a present string unless upstream parsing converted it to a missing value. The integer 3 is a lookup address, not “three units of absence.”

Our synthetic Target has a missing PIN-verification value, so that feature becomes **1**. Its CVV text `NEW_OUTCOME` is present but absent from the synthetic saved dictionary, so it becomes **0**. These are distinct conditions, and the network receives distinct lookup indices for them. Known values are assigned indices beginning at 2 based on the fitted category-count ordering; you should not expect a universal `ABSENT = 3` mapping across arbitrary artifacts.

There are 17 original categorical fields: 13 raw and four calendar fields. Although hour is written as an integer such as 10, the default model treats it as a category and looks it up through its saved vocabulary. A calendar category absent during fitting can therefore map to unknown at scoring time. Merely calling a value a month does not guarantee that every month was observed in fitting data.

The source also offers cyclical calendar encoding using sine and cosine, but it is a different configured conversion. Do not silently switch a trained categorical model to it. Chapter 13 separates current inputs from candidates.

## Why 23 predictors becomes 29 or 30 inputs

For each of the six continuous fields, the active configuration adds a **missing flag**: 1 if the raw value is missing, 0 otherwise. These six flags are appended to the categorical inputs as two-valued categories. They do not use the unknown/missing vocabulary scheme; each flag has exactly two choices, 0 and 1.

Target's missing flags, in the same order as its six continuous features, are `[0, 1, 0, 0, 0, 0]`. Filling the external score with its median did not erase the evidence that the original value was absent. Another transaction whose observed score was exactly 480 would receive the same standardized score, -0.2, but a missing flag of 0.

The count is now **6 continuous + 17 categorical + 6 flags = 29** scalar input fields per transaction. A history model with the optional time-gap feature adds one continuous field, making **7 continuous + 23 categorical = 30**. That extra field describes timing relative to the history window and is explained in Chapter 07. “23 original predictors” and “30 fields reaching a history tokenizer” can both be correct because they count different things.

One precision point: the active loaders build flags from raw `isna()` checks, while numeric conversion can also turn malformed numeric strings into missing values for imputation. Thus raw missingness and “failed numeric conversion” are not guaranteed to have the same flag. This is a reason to check source types and malformed values, not to assume every imputed value must have flag 1.

## Frozen means saved and reused

An **artifact** is a saved product of a computation. Here it means the numerical statistics and category dictionaries, not a mysterious extra model. The builder writes a manifest plus one JSON file per feature, using filenames such as `feature__transaction_amt.json`. The manifest records the feature names, version, creation date, and fitting file names.

The configured original artifact-building default uses files 1–5 in full, processing selected feature groups to limit memory. That is a default recipe, not proof that a particular saved artifact was built with it. The active artifact contents and recorded provenance must be inspected. The runtime's job is to **load** those saved conversions and reuse them across training, validation, and scoring, rather than refitting each batch.

Imagine two scoring batches with amounts `[50, 150]` and `[150, 250]`. If each batch fitted its own mean and standard deviation, the same amount 150 would become +1 in the first batch and -1 in the second. Frozen statistics stop the meaning of an input from moving merely because different rows happen to share its batch.

The checkpoint's **input contract** records the ordered input columns, category sizes, date conversion settings, and a content fingerprint of the active artifacts. A fingerprint is a compact identifier computed from contents. Matching the label “version 1” is weaker than matching those contents: someone could replace a file without changing its version label. The contract helps detect that mismatch. It cannot prove that the original upstream data was correct.

## Source trail and practice

| What to inspect | Exact source coordinates |
|---|---|
| All 23 original predictors | `fraud/configs/predictors.csv`, lines 2–24 |
| Fitted statistics and vocabularies | `fraud/data/preprocessing.py`, `fit_continuous_stats` and `fit_categorical_stats`, lines 89–134 |
| Apply saved categorical and numerical conversions | `fraud/data/preprocessing.py`, `encode_categorical` and `standardize_continuous`, lines 165–180 |
| Calendar extraction | `fraud/data/datetime_features.py`, `_extract_field` and `derive_datetime_features`, lines 48–94 |
| Missing-flag order and two-choice sizes | `waqas/base/data/parquet_loader.py`, lines 33–53 and 151–166 |
| Artifact builder and manifest provenance | `fraud/scripts/build_preprocessing_artifacts.py`, `main`, lines 76–116 |
| Contents bound into the input contract | `waqas/base/data/contracts.py`, `build_input_contract`, lines 8–38 |

**Predict.** An observed amount is 50, with saved mean 100 and deviation 50. What are its standardized amount and missing flag?

**Repair.** Someone proposes adding a new category to the vocabulary during evaluation so it will no longer be unknown. Explain why the saved checkpoint may no longer match.

**Teach back.** Explain why median imputation does not claim to know the true missing value, then explain why its flag is still useful.

<details markdown="1"><summary>Answers and self-check rubric</summary>

The amount is `(50 - 100) / 50 = -1`; its flag is 0 because it was observed. Changing the vocabulary can change its size or the meaning of embedding indices. The trained model learned its category representations against a particular mapping, so reuse the saved mapping and handle unfamiliar categories with its unknown index. A sound teach-back says imputation supplies a consistent usable number, while the flag distinguishes a substitute from an actually observed value. Check all four ideas: arithmetic, raw missingness, dictionary identity, and imputation uncertainty.

</details>

**Recall without looking:** Reconstruct the path “raw → fill → scale” for a number and “raw → saved lookup” for a category. Explain the counts 23, 29, and 30. If the arithmetic is the obstacle, repair Chapter 02. If you can calculate but cannot explain why fitting is restricted, repair Chapter 05. Chapter 08 will show what the neural network does with these numbers.
