# 02 — The numbers and tiny programs underneath the project

## The minimum toolkit

**Prerequisite refresher:** a feature is an input, a label is the known answer, and a model converts inputs into scores. Training changes adjustable numbers called parameters. Scoring normally uses those numbers without changing them.

Your question is: **How do numbers and a few lines of code describe that process precisely?**

You do not need to finish a mathematics degree or a Python course before continuing. You do need to recognize a small set of ideas that recur everywhere in this project. We will practice each with invented values and explicitly name what every dimension means.

## Fractions, percentages and signs

A **fraction** expresses one quantity relative to another. If four of ten alerts are fraud, the fraction is `4/10`. Division gives `0.4`; multiplying by 100 gives `40%`. These are three ways of writing the same proportion.

A percentage increase has a different meaning from a percentage-point increase. Moving recall from 40% to 50% is an increase of ten **percentage points**. Relative to the original 40%, the increase is `10 ÷ 40 = 25%`. Keeping these separate prevents an experiment report from sounding larger or smaller than it is.

A negative number is below zero. Negative values inside a model are ordinary; they do not mean “negative money.” A standardized amount can be negative because it is below a reference average. A weight can be negative because increasing its input reduces the next calculated value, with everything else held fixed.

Multiplication happens before addition unless parentheses specify otherwise. Thus `2 + 3 × 4 = 14`, while `(2 + 3) × 4 = 20`. We use `×` in prose and `*` in Python-like code. We use `÷` in prose and `/` in code.

## Variables, functions and adjustable parameters

A **variable** is a name attached to a value. In a tiny program:

```python
amount = 200
amount_in_hundreds = amount / 100
```

The second value is `2`. The equals sign here means “assign this value to this name.” It is an instruction, rather than a claim that two expressions are forever equal. A later instruction could assign a new value.

A **function** is a reusable calculation with inputs and an output. Here is conceptual teaching code, not copied project runtime:

```python
def simple_score(amount_in_hundreds, online_flag):
    raw_score = 0.5 * amount_in_hundreds + 0.2 * online_flag - 0.3
    return raw_score
```

`def` introduces the function. Indentation places the next two lines inside it. `return` gives its result back. An online flag of `1` means online in this example; `0` means not online. Calling `simple_score(2, 1)` calculates `0.5 × 2 + 0.2 × 1 − 0.3 = 0.9`.

The two inputs change from transaction to transaction. In a learned model, numbers like `0.5`, `0.2` and `−0.3` would be parameters that training can change. A **weight** multiplies an input. A **bias** is an added offset. You will see both repeatedly in Chapter 03.

A **hyperparameter** is a setting chosen for the learning procedure or architecture rather than learned by that ordinary parameter-update step. The learning rate, number of model layers and requested history length are examples. A configuration file records settings. A learned parameter lives in model state. Changing a configuration name does not automatically retrain an existing checkpoint.

## Collections: list, dictionary and table

A **list** holds items in order. In Python notation, `[20, 80, 200]` contains three amounts. Python counts positions starting at zero, so element `0` is `20`, element `1` is `80`, and element `2` is `200`.

A **dictionary** associates names with values:

```python
example = {
    "continuous": [2.0, 0.5],
    "categorical": [1, 3],
    "target": 1,
}
```

`example["target"]` retrieves `1`. The keys help the program distinguish input kinds and labels. **Continuous** inputs are numerical quantities for which magnitude is meaningful, such as a transformed amount. **Categorical** inputs encode membership in categories, such as a channel. Category number `3` does not generally mean three times category `1`. Often these numbers are lookup addresses rather than quantities to multiply directly.

A table can contain strings, numbers and missing entries. The model's numerical arrays have more specific layouts. Preparing those layouts is part of preprocessing, which Chapter 06 teaches. A missing value means the source information is absent; it is not automatically the same as a genuine value of zero.

## Scalar, vector, matrix and tensor

These words describe how numbers are organized.

| Word | Plain meaning | Invented example | Shape |
|---|---|---|---|
| Scalar | One number | `0.7` | No axes |
| Vector | An ordered line of numbers | `[2, 1]` | `(2,)` |
| Matrix | A rectangular grid | `[[2, 1], [0.5, 0]]` | `(2, 2)` |
| Tensor | A general numerical array; it may have any number of axes | Two histories, three rows each, two features per row | `(2, 3, 2)` |

An **axis** is a direction along which you index the array. A **shape** records the length of each axis. A matrix with two rows and three columns has shape `(2, 3)` and contains `2 × 3 = 6` numbers. A tensor with shape `(2, 3, 2)` contains `2 × 3 × 2 = 12` numbers.

“Tensor” does not mean a mysterious kind of number. A PyTorch tensor is a software object that stores values, their shape and properties such as numerical type and where computations occur. A **floating-point** value supports approximations to decimal numbers. An **integer** stores a whole number, often used for category indices. A **Boolean** stores true or false, useful for masks. Type matters: a category lookup expects valid integer addresses.

A **batch** groups examples so the computer can process them together. Suppose two examples each contain one current transaction plus two earlier slots, with two continuous features per transaction. Their continuous tensor has shape:

`(B, T, C) = (2, 3, 2)`.

Here `B` is batch size, `T` is the number of transaction positions including the target, and `C` is the count of continuous features. These letters are labels, not fixed universal values. Another file may use different letters. Always identify the meaning before manipulating the shape.

## Follow an exact shape transformation

Imagine the continuous values are:

```text
Example 0: [[0.2, 1.0], [0.8, 0.0], [2.0, 1.0]]
Example 1: [[0.0, 0.0], [0.0, 0.0], [0.5, 0.0]]
```

This is a synthetic `(2, 3, 2)` array. Example 1's first two slots are placeholders in this illustration. A separate **mask** says which slots are real:

```text
Example 0: [True, True, True]
Example 1: [False, False, True]
```

The mask has shape `(2, 3)`. Merely seeing zeros cannot tell you whether a slot is padding or a real transaction with zero-valued transformed features. The mask carries that distinction.

**Reshape** changes how the same values are grouped. Flattening the first two axes changes `(2, 3, 2)` into `(6, 2)`: six transaction slots with two features each. Both shapes contain 12 numbers. It does not average them, remove them or learn anything. After a per-transaction operation, the program can regroup the slots by example.

**Concatenation** joins arrays along an existing axis. Joining two continuous feature vectors and three categorical feature vectors for each transaction gives five feature vectors, provided their other dimensions agree. **Stacking** introduces a new axis. You will see both operations in the tokenizer code later.

**Broadcasting** lets a smaller array participate in a calculation across matching positions of a larger array. For example, adding `[10, 20]` to every row of `[[1, 2], [3, 4]]` gives `[[11, 22], [13, 24]]`. The program reuses the two offsets for each row. Broadcasting is convenient, but a mistaken shape can silently apply values to the wrong axis. Always explain the intended meaning, not just whether the program runs.

## A dot product is a weighted total

A **dot product** multiplies matching entries of two equal-length vectors and adds the products. For inputs `[2, 1]` and weights `[0.5, −0.5]`:

`2 × 0.5 + 1 × (−0.5) = 1 − 0.5 = 0.5`.

The order matters: the amount weight must multiply the amount input. Swapping column order while keeping weights fixed changes the calculation. This is one reason the project needs a stable feature order.

A **matrix multiplication** performs many such weighted totals. If a layer needs two outputs from two inputs, it can use two rows of weights:

```text
Input:       [2, 1]
Weight row 1: [ 0.50, -0.50] →  0.50
Weight row 2: [-0.25,  1.00] →  0.50
```

Each output is a separate dot product. Adding a bias to each output completes what the project often calls a linear layer. The term “linear” is conventional in code even when a bias makes the full operation affine in strict mathematics. You only need the calculation: weighted totals plus offsets.

A CPU is a general-purpose processor. A GPU can perform many suitable numerical operations in parallel, making large batches of matrix calculations faster. It does not supply labels, decide whether an experiment is fair, or make the underlying method correct. The small arithmetic in this chapter can be done on paper or a CPU while GPUs are unavailable.

## Read a miniature loop

A **loop** repeats instructions. An `if` statement chooses instructions based on a condition. This conceptual example combines both:

```python
scores = [0.2, 0.8, 0.6]
alerts = 0
for score in scores:
    if score >= 0.6:
        alerts = alerts + 1
```

Start at zero alerts. `0.2` is below the threshold, so the count stays zero. `0.8` qualifies, so it becomes one. `0.6` also qualifies because `>=` means “greater than or equal,” so the final count is two. `==` checks equality in Python; it differs from assignment `=`.

A **class** groups related state and functions. A model class can hold its weights and provide a `forward` method to compute outputs. `self` means the current instance of that class. You do not need to write an entire class now; recognizing these roles makes repository code easier to read.

## Where this appears in the actual project

- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.forward`, lines 146–156: reads named batch entries, unpacks `(B, T, C)`, reshapes transaction slots and later restores their grouping. Lines 161–164 expand a transaction mask into a feature-token mask.
- `waqas/phase4a/tokenizer.py`, `FeatureTokenizer.forward`, lines 32–40: transforms numerical values, looks up categorical representations and concatenates the results. This chapter explains the array operations; Chapter 08 explains their modeling purpose.
- `fraud/data/feature_list.py`, `FeatureList.all_features`, lines 35–37, and `load_feature_list`, lines 80–90: records a consistent continuous/categorical ordering and selects the requested feature version.

## Common wrong mental model

**Wrong:** “A tensor with more dimensions contains more advanced intelligence.”

**Repair:** Axes organize values. A `(B, T, C)` tensor explicitly records examples, transaction positions and features. Intelligence is not added by reshaping an array. Similarly, making category codes larger does not give those categories more meaning.

## Your shape-detective challenge

**Predict:** Three examples each contain four historical slots plus the target, and each transaction has six continuous features. Give the continuous tensor's shape and its total number of stored values. How many labels are needed if you predict only the target of each example?

**Repair:** A colleague changes `(3, 5, 6)` to `(15, 6)` and says the dataset has gained 12 new customers. Explain what actually happened.

**Teach back:** Calculate the two weighted totals above without looking, then explain input, weight and bias using one sentence each.

<details><summary>Open after attempting: answers and repair hints</summary>

The shape is `(3, 5, 6)` because the four historical slots plus the target make five transaction positions. It stores `3 × 5 × 6 = 90` continuous values, including any padded slots. Target-only prediction needs three labels, one per example. The reshape stores the same 90 values as 15 transaction slots; it creates no new information or customers.

The weighted totals are both `0.5`: `2 × 0.5 + 1 × (−0.5)` and `2 × (−0.25) + 1 × 1`. Inputs describe the example. Weights control how inputs contribute to a calculation. Biases shift calculated values even when inputs are zero.

If you gave 15 labels, you confused transaction positions with target predictions. Some later models can supervise more positions, but that is an explicit change in the task, not a consequence of storing a history tensor.

</details>

**Recall without looking:** explain `(B, T, C)` to someone who has never programmed. Then name one thing a reshape preserves and one thing it changes. **Repair route:** repeat this chapter's tiny examples for arithmetic or shape confusion; revisit Chapter 01 for examples versus rows; continue to Chapter 03 to turn weighted totals into a neural network.
