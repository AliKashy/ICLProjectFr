# 09 · Attention and the single-transaction FT-Transformer

**Prerequisite refresher.** Each feature token is a vector: a list of learned numbers representing one field. A forward pass transforms the current inputs into scores. A classification head converts the model's final representation into one score per class. None of those operations updates weights by itself; training adds loss, backward propagation and an optimizer step. Review Chapters 03, 04 and 08 if needed.

**Your concrete question:** how can the model decide that a transaction's amount should be interpreted together with its channel or other available fields?

It needs a way for one token to receive information from other tokens. **Attention** performs a learned, input-dependent weighted combination. It does not contain a fraud analyst, and the word does not imply human understanding. It names a calculation.

## Three roles for every token

Attention makes three transformed versions of each input token, using learned weights:

- A **query** describes what this token is currently seeking.
- A **key** describes what another token offers for matching.
- A **value** contains the information that can be combined into the answer.

Those descriptions are memory aids. In the program, queries, keys and values are numerical vectors created by linear layers. They are not English questions or database keys.

For a given query, the model compares it with each allowed key using a **dot product**: multiply matching coordinates and add the products. For example, `[1,2]` dotted with `[3,4]` is `1×3 + 2×4 = 11`. A larger match score tends to produce greater weight for that key, after a scaling and normalization step.

The score is divided by the square root of the query/key width. With width four, that divisor is two. This helps keep the score scale manageable as width changes; it is not a fraud-specific risk adjustment.

Then **softmax** turns the collection of match scores into positive weights that sum to one. For scores `s1, s2, ...`, each weight is `exp(si)` divided by the sum of all `exp(s)`. “exp” raises the constant `e≈2.718` to a power. You do not need to calculate exponentials by hand to understand the effect: larger scores receive larger weights, and changing one score changes the relative share of the others.

Finally, the model multiplies each value vector by its attention weight and adds them. That is the information the querying token receives from this attention head.

## Work a complete tiny attention calculation

Assume learned projections have produced a width-two query `[sqrt(2),0]`, two allowed width-two keys `[0,0]` and `[ln(3),0]`, and the width-two values below. Here `sqrt(2)≈1.4142` and `ln(3)≈1.0986`. The dot products are `sqrt(2)×0 + 0×0 = 0` and `sqrt(2)×ln(3) + 0×0 ≈ 1.5537`. Divide by the square root of the query width, `sqrt(2)`, to obtain scaled scores `0` and `ln(3)≈1.0986`. Their exponentials are 1 and 3. This is conceptual attention arithmetic, not a real project output; the numbers are chosen so every step remains traceable.

```text
softmax weights = [1/(1+3), 3/(1+3)] = [0.25, 0.75]
value 1 = [2, 0]
value 2 = [0, 4]
weighted result = 0.25×[2,0] + 0.75×[0,4] = [0.5, 3]
```

The result contains information from both values. It is not simply “pick the largest.” If the second key becomes disallowed by an attention mask, its weight becomes zero; the first allowed key receives weight one. The result becomes `[2,0]`.

A **mask** is a rule restricting which positions may provide information. Implementations can express a forbidden match as negative infinity before softmax, whose resulting weight is zero. If every key is forbidden, normalizing becomes invalid: there is no allowed share to allocate. Chapters 10 and 11 explain the project's padding safeguard for this case.

During training, **dropout** may randomly zero some attention contributions. Ordinary softmax weights sum to one before this dropout; a particular training-time dropped-and-rescaled realization need not. Dropout discourages reliance on the same exact path on every training example. It is disabled in evaluation mode.

## Multiple heads, then repeated blocks

One **attention head** is one set of query/key/value transformations and weighted combinations. **Multi-head attention** performs several such calculations in parallel. It joins their outputs and projects them back to the model width. Different heads can learn different interaction patterns. There is no promise that head 1 becomes “amount” and head 2 becomes “time.” Those are interpretations you would need to test.

A **transformer block** combines attention with additional operations. The following is a conceptual list of their jobs, not the exact execution order of every implementation:

1. Attention mixes information across tokens.
2. A residual or **skip connection** adds an earlier representation to a new contribution, giving information another route through the network.
3. **Layer normalization** rescales the coordinates within a token and applies learned scale/offset parameters. It helps control intermediate numerical behavior. It is different from preprocessing an amount with a training-set mean.
4. A **feed-forward network** transforms each token's coordinates using the same small neural network at every token position. It can expand the vector to a wider intermediate size, apply an activation, and shrink it back.

For concrete residual arithmetic, adding an earlier vector `[1,2]` to a new contribution `[0.5,3]` gives `[1.5,5]`. A simplified layer-normalization calculation has mean `(1.5+5)/2=3.25`, deviations `[-1.75,1.75]`, mean squared deviation `3.0625` and square root `1.75`. Dividing the deviations by 1.75 gives `[-1,1]`. The real operation adds a tiny stabilizer to its variance and applies learned scale/offset parameters; this example omits the stabilizer and uses scale one and offset zero. It normalizes coordinates **within one token**, not amounts across the training dataset. Chapter 06 explains the separate frozen preprocessing statistics.

A nonlinear **activation** allows the transformation to do more than another straight weighted sum. The local A/B models use GELU, a smooth function that passes positive values strongly and suppresses negative values more gradually than a hard cutoff. The reference FT implementation uses a gated GELU feed-forward module by default. A **gate** multiplies one learned transformation by another, allowing the contribution to vary with the input.

The precise ordering matters. Repeating blocks lets later computations use information already combined by earlier blocks. A multi-layer attention system can therefore transmit information indirectly, even when two tokens never interact directly in the first layer. That fact will matter for causal masks.

## The CLS collector and the fraud head

The reference model adds a learned special token called **CLS**, short for classification. It starts as the same learned vector for every row in a forward pass. After attention, it can contain an input-specific summary of that transaction's feature tokens.

This is **pooling**: turning multiple token representations into one representation for prediction. CLS pooling is learned; it is not the arithmetic mean of all feature values. The reference implementation appends CLS at the end and returns the final token representation to its prediction head.

With two transactions, three feature tokens per transaction and embedding width four:

```text
feature tokens             [2, 3, 4]
after adding one CLS each  [2, 4, 4]
transformer block outputs  [2, 4, 4]
select each CLS            [2, 4]
binary classification head [2, 2]
```

The two output numbers for a row are **logits**, unnormalized class scores. Their positions correspond to classes 0 and 1; fraud is the positive class in this project. Softmax across those two logits gives class probabilities. A fraud probability is a model score, not a guarantee that a single event is fraudulent. Calibration and decision thresholds arrive in Chapter 15.

To make the head concrete, suppose the CLS vector is `[1,2]`. Give class 0 head weights `[0,0]` and bias 0, producing `0×1+0×2+0=0`. Give class 1 weights `[1,0]` and bias `0.0986`, producing `1×1+0×2+0.0986=1.0986`. The logits are `[0,1.0986]`, so softmax gives approximately `[0.25,0.75]`. These synthetic head parameters are chosen for arithmetic. No 75% label was input; the model produced a score from available features. During training, the known label supplies the loss signal that can change all these learned transformations.

## What “FT” means in this project

**FT-Transformer** means a transformer using feature tokenization for tabular inputs. The single-transaction reference path processes one transaction's feature tokens. It does not receive an A/B sequence of several raw transactions through this architecture. An individual input field could itself summarize previous activity if such a feature is in the approved predictor set; that is different from adding a sequence transformer over past rows.

The reference streaming builder constructs the model from frozen preprocessing dimensions. “Streaming” describes how batches arrive; it does not magically give the network long-term memory. Once a batch is scored, the model does not retain an account's preceding rows unless a surrounding system explicitly supplies them.

One additional reference detail matters: frozen preprocessing and model **batch normalization** are separate. In the checked vendored reference configuration, `batch_norm_continuous_input` defaults to true. Its embedding layer applies this to numerical inputs even though the streaming builder disables another preprocessing normalization pass. Batch normalization uses statistics across a batch for each numerical field during training, updates stored running statistics, and normally uses those stored statistics during evaluation. It also has learned scale and offset parameters. For intuition, a two-row numerical column `[2,4]` has batch mean 3 and standard deviation 1, giving approximately `[-1,1]` before learned scale/offset; the real formula includes a small stabilizer. This differs from LayerNorm across one token's coordinates and from the frozen training-set preprocessing artifacts. A/B's local feature tokenizer does not add this input BatchNorm layer. Model evaluation mode therefore matters for more than switching off dropout. Source: `src/pytorch_tabular/config/config.py`, lines 815–818; `src/pytorch_tabular/models/common/layers/embeddings.py`, lines 280–291; and `src/pytorch_tabular/models/common/layers/batch_norm.py`, lines 27–40.

The checked reference recipe uses token width 32, eight heads and three blocks. Do not assume it is identical to A with history zero. A and B are separate model implementations, with different encoder structure and defaults. Their zero-history cases are useful controls within their families, but they do not automatically reproduce the reference model.

## Source facts that prevent a misleading textbook story

| Source location | Implemented fact |
|---|---|
| `waqas/base/streaming_model.py`, `build_streaming_model`, lines 54–116 | Constructs the single-row FT model with frozen dimensions, two output classes and the training recipe |
| `waqas/base/configs/streaming.yaml`, `model`, lines 41–47 | Reference base recipe: width 32, eight heads, three attention blocks |
| `src/pytorch_tabular/models/ft_transformer/ft_transformer.py`, `FTTransformerBackbone`, lines 30–82 | Appends CLS, runs blocks and selects the last token |
| `src/pytorch_tabular/models/common/layers/transformers.py`, `MultiHeadedAttention`, lines 34–69 | Query/key/value projections, scaled dot products, softmax, weighted values and output projection |
| Same file, `TransformerEncoderBlock.forward`, lines 124–128 | Exact reference block data flow |
| `src/pytorch_tabular/models/common/layers/gated_units.py`, `PositionWiseFeedForward.forward` and `GEGLU`, lines 142–185 | Activation, multiplicative gate and output linear layer |

There are two details worth being able to explain under questioning. First, this reference attention implementation defaults each head's width to the full input embedding width. With width 32 and eight heads, its internal concatenated head width is `8×32=256`, before projection back to 32. The A/B PyTorch encoder instead divides its model width across heads: width 48 with eight heads gives width six per head. The head count alone is not a fair capacity comparison.

Second, the checked reference block applies normalization **after** adding contributions. Its feed-forward branch receives the attention result `y` in the actual source, while the residual branch contains the normalized sum. A/B use the PyTorch encoder with normalization **before** its attention/feed-forward sublayers. You do not need to memorize these formulas on the first pass. You should remember that the source, rather than a generic transformer diagram, determines the architecture actually compared. This course describes the implemented reference faithfully; it does not silently rewrite it into a more familiar design.

Attention weights also are not a complete causal explanation of a prediction. Value vectors, multiple heads, residual connections, nonlinear layers and subsequent blocks all affect the result. “This token received 0.75 attention” is a statement about one calculation; “this business field caused 75% of the fraud decision” does not follow. The repository's reference feature-importance helper is explicitly marked as not thoroughly tested in its source.

## Prediction, repair and teach-back

**Predict.** Attention weights are `[0.2,0.8]` and the values are `[10,0]` and `[0,5]`. What combined vector results? If a mask forbids the second key, what should happen?

<details><summary>Reveal the calculation</summary>

The weighted sum is `[2,4]`. If the second key is forbidden before softmax and the first remains allowed, the remaining key receives weight one and the result becomes `[10,0]`. Merely zeroing the already-computed second contribution without renormalizing would give a different calculation.

</details>

**Repair.** A colleague says, “We have eight heads, so we have eight fraud models; the largest attention weight tells us the reason; A at H=0 must equal REF.”

<details><summary>Reveal the repair</summary>

Heads are learned parallel information-combination operations inside one network, not eight independently trained complete models. Attention weights alone do not prove causal importance. H=0 removes historical rows from A but does not change A into the reference implementation: embedding details, block data flow, head width and training recipe still matter.

</details>

**Teach back.** Explain the path from feature tokens to a fraud score using only a calculator and index cards. Include what learns and what stays fixed during one forward pass.

<details><summary>Use this rubric</summary>

One point each: learned projections produce queries/keys/values; matching scores become normalized weights; values are combined; blocks transform and preserve representations through additional paths; CLS collects information; a head produces logits and softmax produces probabilities; parameters stay fixed during the forward calculation but can be updated during training. If you cannot distinguish a parameter from an intermediate attention weight, return to Chapter 04, then work the two-value example again.

</details>

**Recall prompt:** redraw `features → tokens + CLS → attention blocks → CLS vector → two logits → fraud score`, then say why a batch of independent rows is not account history. Repair token shapes in Chapter 08 and score/loss concepts in Chapters 03–04. Chapter 10 adds history explicitly.
