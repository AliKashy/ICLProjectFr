# 16 · Learn and test while the GPUs are down

**Prerequisite refresher.** Chapter 04 gave you the learning step, Chapter 07 the history rule, Chapter 14 paired comparisons, and Chapter 15 the metrics. You do not need to train a large neural network to test those ideas. A **CPU** is a general-purpose processor. A **GPU** performs many numerical operations in parallel and is useful for large neural-network workloads. Python's ordinary arithmetic works on a CPU.

**Your concrete question:** “What can I meaningfully verify today, and what would still need real execution later?”

This chapter turns you into a small-scale investigator. Each mission has a prediction, an executable demonstration, a deliberate change and a verbal explanation. The included programs use only Python's standard library and synthetic values. They do not read bank data, load project checkpoints or run the actual Transformer. Their purpose is to make mechanisms visible. They are distinct from the repository's own tests of its real implementations.

## The test detective's four questions

Before running anything, ask:

1. **What property should hold?** For example, a future transaction must not alter an earlier target's available history.
2. **What input exposes a failure?** Use one earlier row, one same-time row and one later row instead of thousands of ordinary rows.
3. **What observation would refute the property?** A future row appearing in the target's selected history is a clear failure.
4. **What does a pass actually establish?** It establishes that this tested implementation behaved correctly on the checked cases; it does not prove all possible data, models and deployments are correct.

An **assertion** is a program statement that checks a condition and stops with an error if it is false. A useful test needs an independent expectation. Checking that a function returns exactly the same thing as a duplicate of its own implementation can repeat the same bug twice. Hand arithmetic, a different algorithm, and carefully designed counterexamples are stronger checks.

## Start the offline labs

Extract the course ZIP, open a terminal in its `Tabular-Fraud-Explained` folder, and check that Python 3 is available. A terminal accepts text commands; `python --version` prints the installed version. Some computers use `python3` instead of `python`; use that spelling consistently if needed. The commands below assume the extracted folder contains `labs/`.

```text
python labs/01_learning_step.py
python labs/02_metrics.py
python labs/03_paired_accounts.py
python labs/04_contracts.py
```

Each command runs one small file. No package installation, server or GPU is required. The course includes `labs/EXPECTED_OUTPUT.txt` for comparison. These scripts make no persistent changes to project data. If Python is unavailable, complete the arithmetic and prediction tasks by hand; the browser demos in this course also explain the learning step and threshold trade-off.

## Mission 1: prove that one learning step moves the right way

Open `labs/01_learning_step.py`. It is an original teaching program for a one-weight logistic model, not a copy of the fraud model. The input feature is 2, the label is 1, and the weight begins at 0. Its logit is `weight × feature = 0`. The sigmoid score is 0.5. Binary cross-entropy is `−log(0.5) ≈ 0.693147`.

For this model, the derivative of loss with respect to the weight is:

`gradient = (score − label) × feature`

`= (0.5 − 1) × 2 = −1`.

With learning rate 0.1, gradient descent makes `new weight = 0 − 0.1×(−1) = 0.1`. The new logit is 0.2, score approximately 0.549834, and loss approximately 0.598139. The model moved toward the positive label and reduced loss on this one example. It has not learned a general fraud detector.

The script independently checks the gradient using a **finite difference**: slightly increase and decrease the weight, calculate both losses, and divide their difference by the total weight change. This approximates local slope. Agreement is evidence that the analytic derivative is implemented correctly for this example.

**Before running:** predict the sign of the gradient. **After running:** change the label to 0 and predict the direction before rerunning. Then change the update from subtraction to addition. The assertions should expose the broken update. Restore your learning copy afterward; this exercise never edits project runtime.

<details><summary>Mission 1 repair answer</summary>

For label 0 at weight 0, the gradient is +1 and a descent step makes the weight −0.1, lowering the score toward 0. Adding the gradient instead of subtracting makes the loss worse here. A pass on one toy step verifies this arithmetic, not AdamW, Transformer backpropagation or model usefulness.

</details>

## Mission 2: own the confusion matrix and ranking metrics

Run `labs/02_metrics.py`. It uses Chapter 15's six synthetic transactions. Expect AP 0.755556 and AUROC 0.666667. At threshold 0.60, expect two true positives, one false positive, one false negative and two true negatives.

**Before running:** calculate recall at threshold 0.85 and precision at 0.25. **After running:** change the second score from 0.80 to 0.95. That legitimate transaction now outranks the first fraud. Predict whether AP improves or worsens before you look. The original arithmetic assertions will fail because the dataset has changed; update an expected value only after calculating the new answer independently.

The shared `toy_metrics.py` groups equal scores before computing AP. Its small implementation is intentionally readable. A separate tied-score assertion requires `[1,0]` with scores `[0.5,0.5]` to have AP 0.5 and AUROC 0.5. Neither tied example deserves to be placed ahead because of its hidden label.

<details><summary>Mission 2 repair answer</summary>

Recall at 0.85 is 1/3. Precision at 0.25 is 3/5. Moving the legitimate score to 0.95 changes positive ranks to 2,3,5, giving AP `(1/2 + 2/3 + 3/5)/3 = 53/90 ≈ 0.588889`. The fraud score 0.90 now loses to one negative, so AUROC becomes 5/9 ≈ 0.555556. You should explain the rank change, not only repeat the new number.

</details>

## Mission 3: see why paired account draws matter

Run `labs/03_paired_accounts.py`. Six fictional accounts contain two rows each, with fixed scores from toy model X and toy model Y. The script makes 1,000 whole-account draws with a fixed random seed, computes AP for both models on each identical draw, and stores `X − Y`.

The expected full-cohort difference is approximately −0.076587. The synthetic percentile interval is approximately [−0.392857,+0.125417]. One draw contains only one class and is counted as undefined, leaving 999 valid draws. The interval is deliberately wide: six accounts are very little evidence. These numbers say nothing about the project's V1 models.

**Before running:** say what `B,B,C` means. **After running:** describe why repeating B twice must repeat its rows in both X and Y. Change `draw_count` from 1,000 to 2,000 in a learning copy. Does this create more independent accounts? No: it refines the resampling calculation on the same six accounts. The displayed count and accounting assertion both read that same setting, so your intentional change stays internally consistent.

**Deeper repair task:** replace all X scores with the corresponding Y scores. Every valid difference must become zero. This is an **invariant**, a property that must hold under a stated transformation. It checks a comparison mechanism without requiring a known fraud-model performance number.

<details><summary>Mission 3 repair answer</summary>

`B,B,C` contains all B transactions twice and all C transactions once. Other accounts are absent. Both models receive exactly that same weighted exam. More bootstrap draws reduce simulation noise in the interval calculation; they do not add accounts, retrain models, or measure seed variation. Identical predictions must produce zero differences. A one-class draw must be reported using an explicit undefined convention, not silently treated as a poor model.

</details>

## Mission 4: break the rules on purpose

Run `labs/04_contracts.py`. Its target is account A at time 20. Candidate rows are A at time 10, A at time 20, A at time 30, and B at time 5. Under strict-earlier same-account history, only the first qualifies. Its amount is 3, so a simple history-sum toy score equals 3.

The program changes same-time and future amounts dramatically, then checks that the selected-history sum stays 3. This is a **perturbation test**: alter information that should be irrelevant and ensure the permitted output does not change. The real project performs stronger tests through actual model forward passes; this lab teaches the idea at the history-selection boundary.

**Before running:** name the reason each excluded row is excluded. **After running:** change `<` to `<=` in the eligibility test. Predict the failing assertion. That one character changes “earlier” into “earlier or simultaneous.” It is a semantic bug even if array shapes and model dimensions still look valid.

The same file tests cohort identity. Reordering `a,b,c` to `c,a,b` is acceptable once aligned by identity; dropping c, duplicating b, or adding d is rejected. A pure row-count check would miss replacing c with a second b. The test therefore checks the actual multiset and uniqueness, not just length.

<details><summary>Mission 4 repair answer</summary>

The same-time row fails strict-before; the future row fails past-only availability; the other-account row fails entity identity. Changing the inequality admits the peer and violates the expected history. The toy sum does not prove the real attention mask is correct. The real model needs perturbation tests that traverse preprocessing, history, masks and output computation as relevant.

</details>

## How the repository tests its real implementation

A **unit test** checks a relatively small component. An **integration test** checks components working together, such as loader → model → checkpoint → scorer. A **regression test** preserves a behavior after a bug has been fixed. A **smoke test** runs a small representative workflow to catch obvious failures before a costly run. These categories can overlap.

Useful existing examples include:

- `waqas/tests/test_training_loader_coverage.py`, `test_training_loader_preserves_all_targets`, lines 23–73: unequal files, multiple worker counts and epochs must not omit or duplicate targets.
- `waqas/tests/test_b_allposition_strict_time.py`, `test_changing_a_later_or_same_second_row_never_changes_an_earlier_or_same_second_score`, lines 261–281: perturb forbidden information and compare actual outputs.
- `waqas/tests/test_a_checkpoint_contract.py`, `test_shape_preserving_checkpoint_drift_is_rejected`, lines 64–86: settings can change meaning even when tensor shapes still match.
- `waqas/tests/test_ema_lifecycle.py`, lines 83–108: optimizer-step timing, partial accumulation and resumed versus uninterrupted raw/EMA state.
- `runbook/2026-10-07/tests/test_paired_report.py`, lines 48–88 and 254–277: compare AP against an independent library, check account versus row resampling, and ensure cohort mismatches are counted rather than hidden.

These source files demonstrate what the repository checks. Their presence is not a claim that this course reran the full repository suite. Running them needs the project's installed dependencies and environment; they are not required for the standard-library learning labs.

## What remains beyond a CPU lesson

No unit test proves the features carry useful fraud signal. No synthetic smoke test establishes bank throughput, GPU memory capacity, real-data quality, fairness across operational populations, or economic impact. Those need relevant data and execution evidence. Conversely, a high AP does not prove the data loader, as-of timing, checkpoint mapping or live service is correct.

The current scoring pipeline is offline labeled evaluation tooling. Although mathematical forward prediction does not need the unknown label, the existing input readers expect a label column. A production service would need an unlabeled input path, matching feature availability, latency and monitoring behavior, plus a defined business action. Do not tell an interviewer that offline scoring alone means deployment is finished.

Your completed-work statement should be precise: “I ran four synthetic CPU learning labs and checked their expected outputs.” A repository test run needs its own source version, environment and results. A bank training result needs its own run artifacts. Keep these three claims separate.

**Final teach-back:** explain one test you would write for each of these: label leakage, missing targets, wrong checkpoint, same-second history, misleading AP, and interrupted EMA training. State the failure observation and the limit of a passing result.

<details><summary>Capstone rubric for this chapter</summary>

Full credit gives six concrete properties: changing labels cannot alter model inputs; every intended target appears exactly once; incompatible input/model contracts fail loading; same-time peers remain invisible under strict mode; hand or independent metric calculations match; resume preserves relevant raw, optimizer and EMA states. Also state that passing finite tests is evidence, not a proof of all program behavior or business performance.

</details>

**Recall without looking:** tell the whole story `claim → revealing example → expected observation → deliberate failure → scope of evidence`. If your metric check is uncertain, return to Chapter 15. If your history check is uncertain, return to Chapter 07. Then use Chapter 18's oral defence to connect these mechanisms into one project explanation.
