# 18 · Take the controls: capstone and oral defence

This is where you turn recognition into explanation. You can reread a definition and feel that you know it, yet struggle when someone changes the example. The exercises here require you to connect the pieces, state assumptions, and recover when a claim is too strong.

Use paper, a blank note, or the course notes box. First answer without reading the worked response. Then score each answer:

| Score | What happened |
|---|---|
| 0 | I could not explain the mechanism, or my answer used information the model would not have |
| 1 | I got the basic idea but needed the answer, missed a step, or omitted an important qualification |
| 2 | I explained the mechanism, used a concrete example, and stated the limit without looking |

The score is a practice aid, not a competence certificate. A useful target is to explain each core topic twice on separate days, once with a changed example. If you get stuck, repair the specific chapter instead of memorizing the sample wording.

## Capstone A: draw the whole system from memory

Draw twelve boxes: business question; usable input fields; fraud label; data split; frozen preprocessing; legal history; feature tokens; chosen architecture; class scores; training loss and updates; saved checkpoint and predictions; evaluation and business interpretation.

Connect them. Put a large boundary between information used to make the current prediction and the answer used afterward to judge it. Draw separate training and scoring arrows. Now explain each box in one sentence to someone who has never studied data science.

<details markdown="1">
<summary>Check your diagram</summary>

Your diagram should make these relationships visible:

- A fraud label is a target for training and an outcome for assessment, not an input feature for the current prediction.
- Learned preprocessing rules are fitted on designated training/fitting data, without fitting to held-out feature values or answers, then reused consistently.
- A history includes only permitted earlier transactions from the appropriate account; padding is not an actual event.
- The reference uses a single transaction. A combines feature tokens across the window. Default B summarizes each transaction before attending across time.
- The head turns learned representations into class logits. Softmax converts the two logits to class shares summing to one; the fraud share is used as the score. The score's calibration requires checking.
- Training measures prediction error and backpropagates derivatives so an optimizer can adjust parameters. Scoring loads the chosen parameters without updating them.
- Predictions must remain paired with their outcomes and identity before computing metrics or model differences.
- A useful metric does not alone establish business value or deployment readiness.

If you connected the current fraud label to the input tokens, return to Chapter 05. If you cannot explain the arrow from loss to parameters, return to Chapter 04. If you drew A and B as identical, return to Chapters 10–11.
</details>

## Capstone B: be the history builder

All of the following rows are invented. The target is account Maple's transaction at 10:05:00. History limit H is 3. You have these candidate transactions:

| Account | Time | Amount |
|---|---|---:|
| Maple | 09:50:00 | 12 |
| Maple | 10:00:00 | 18 |
| Birch | 10:01:00 | 22 |
| Maple | 10:05:00 | 40 |
| Maple | 10:06:00 | 70 |

The row at 10:05:00 in the table is a different transaction from the target but has the same timestamp. Which rows are eligible? Where does padding go? What are the eligible rows' time gaps to the target? Can a transaction identifier's alphabetical order resolve the same-time uncertainty?

<details markdown="1">
<summary>Reveal the answer and reasoning</summary>

Only Maple at 09:50 and 10:00 is eligible under the active strict-earlier rule. Birch belongs to another account. Maple at 10:05 is tied with the target and is excluded; 10:06 is later and is excluded. The ordinary left-padded window is `[PAD, Maple09:50, Maple10:00, target]`.

The real history gaps are 900 and 300 seconds; the target gap is zero. A log1p transformation gives log(901), log(301), and log(1)=0 before the numerical embedding. Padding needs a mask, even if its numerical values happen to be zero.

Sorting by an identifier can make repeated runs deterministic, but it does not prove that the same-time transaction was available earlier. The active strict rule does not infer chronology from that sort.

In a real extract, earlier eligible transactions may be absent because of file or extraction boundaries. The implementation cannot retrieve events that were not supplied. See Chapter 07.
</details>

Now change H to 1 and answer again. Then keep H=3 but give the tied row time 10:04:59. Those changes should alter the answer for specific reasons, not because “history is whatever came above it in the table.”

## Capstone C: diagnose a suspicious improvement

A colleague presents an invented comparison: Model A has AP 0.12 and Model B has AP 0.14. They say B catches “two percent more fraud” and is ready to replace the existing system. Their table does not state the evaluation rows, chosen checkpoint, input fields, batch recipe, or how many models they tried.

Write five questions that would materially change your interpretation. Then explain why 0.14 minus 0.12 is not a fraud-capture improvement at an alert budget.

<details markdown="1">
<summary>A strong investigation</summary>

Ask whether the models were evaluated on exactly the same eligible rows and outcomes; how their checkpoints were selected; whether every feature was available at decision time; what differed in the full training recipe; and how selection across many trials affected the reported comparison. Also ask about account-level uncertainty, training-seed variability, operating threshold or alert capacity, false-positive costs, fraud amounts, latency, and independent later evaluation.

The AP difference is 0.02, or two percentage points of the AP metric. AP summarizes ranking quality over recall changes. It is not the number or value of frauds captured at a particular threshold. To answer the operational question, compare recall and precision at a fixed review capacity or false-positive burden, using appropriate amounts and costs when available. A gain in AP may or may not be useful at the bank's working point.

If the comparison selected its own winner using this evaluation cohort, call that development evidence. Do not repair the wording by calling the same consulted cohort an untouched test. See Chapters 14–15.
</details>

## Capstone D: trace an actual source path

With repository access, choose the A training entry point. Find where it loads configuration, imports its dataset, creates its model, and sets up training. Then follow one batch to the tokenizer, encoder, head, loss, and optimizer. Use Chapter 17 only when needed.

For every function you inspect, write three things: what comes in, what goes out, and what could go wrong if an assumption fails. For example: “The model flattens a batch of windows into transaction rows for the tokenizer. The tokenizer receives category indices and continuous values, and produces learned feature vectors. The model then restores the window grouping. Indices outside the saved vocabulary range are invalid.” You are learning contracts between components, not trying to memorize the entire file.

You can complete the conceptual version from this course without repository access. Do not pretend that reading an explanation is the same as having executed the source. Chapter 16 provides small runnable labs for hands-on verification.

## The oral defence

Ask a friend or another assistant to choose questions out of order, wait for your answer, then ask one follow-up. Use the rubric above. These are explanations to understand, not lines to claim as personal achievements.

### 1. What is the actual research question?

<details markdown="1"><summary>Worked response</summary>
We want to know whether transaction details and eligible earlier history improve fraud ranking, and which model/training recipe does that under a fair comparison. We compare a corrected single-transaction reference, flat A, and hierarchical B with controlled history and time/mask variants. We must distinguish the question from a claim that a model already improves bank profit. Repair: Chapters 01 and 14.
</details>

### 2. What is a neural network, without using another unexplained label?

<details markdown="1"><summary>Worked response</summary>
It is a composition of numerical operations with adjustable parameters. Inputs are multiplied by weights, shifted by biases, transformed through nonlinear functions, and combined into outputs. Learning changes the adjustable numbers to reduce a defined error over examples. The project uses attention-based neural networks, a particular organization of these operations. Repair: Chapters 03–04.
</details>

### 3. What is the difference between forward propagation, backpropagation, and an optimizer?

<details markdown="1"><summary>Worked response</summary>
The forward pass computes outputs from inputs and current parameters. The loss measures error against known labels. Backpropagation uses the chain rule to calculate how changing each parameter would locally change the loss. The optimizer uses those derivatives and its update rules to change the parameters. Backpropagation computes a signal; it is not itself the optimizer. Repair: Chapter 04.
</details>

### 4. If the model makes a prediction, why do we need labels?

<details markdown="1"><summary>Worked response</summary>
Labels supply answers for supervised learning and evaluation. The model can produce a score without seeing the current answer, but we need outcomes to learn what patterns predict fraud and to assess whether the scores are useful. Fraud outcomes can arrive late or change, so label maturity matters. Repair: Chapters 01 and 05.
</details>

### 5. What is an embedding, and is it a probability?

<details markdown="1"><summary>Worked response</summary>
An embedding is a vector of numbers used to represent an input. A category selects a learned vector; a continuous feature is transformed into a vector by the numerical embedding. Its coordinates are not class probabilities. They are learned representations that later computations can combine. Repair: Chapter 08.
</details>

### 6. What does attention do?

<details markdown="1"><summary>Worked response</summary>
It computes compatibility between a token's query and permitted tokens' keys, normalizes those scores into weights, and forms a weighted combination of their value vectors. Learned projections determine the query/key/value spaces. Masks remove prohibited connections. Multiple heads allow different learned combinations. Attention weights alone are not a causal explanation of the prediction. Repair: Chapter 09.
</details>

### 7. Why use CLS? Can it cause leakage?

<details markdown="1"><summary>Worked response</summary>
CLS is a learned summary token used to collect information for prediction. In a causal design, if an early token can read CLS after CLS has read later tokens, later information can reach the early token indirectly. Preventing direct later-token access is not enough; the entire multilayer information path matters. The current relevant masks account for this. Repair: Chapters 09–11.
</details>

### 8. Is bidirectional attention always a data leak?

<details markdown="1"><summary>Worked response</summary>
No. For a prediction about the final target, all tokens in a correctly constructed window may represent information already available at that target's decision time. Letting those inputs interact does not automatically introduce future events. Predicting an earlier position in the same window is different: later-position inputs may then be unavailable and require strict masking and appropriate time features. Repair: Chapters 10–11.
</details>

### 9. How are A and B different?

<details markdown="1"><summary>Worked response</summary>
A puts feature tokens from multiple transactions into one attention sequence. B first summarizes the features within each transaction, then attends across the transaction summaries. This changes the routes by which information interacts and the computational cost; it does not guarantee B performs better. All-position B also changes the supervision and context available per row. Repair: Chapters 10–11.
</details>

### 10. Does H=5 mean six real events everywhere?

<details markdown="1"><summary>Worked response</summary>
For ordinary target windows, H=5 permits up to five earlier transactions plus the target; short histories require padding. In strict all-position B, the chunk groups distinct whole-second values, can contain more rows because of ties, and different positions have different actual earlier histories. The H setting is not sufficient to prove matched context. Repair: Chapters 07 and 11.
</details>

### 11. Is A-H00 the reference model?

<details markdown="1"><summary>Worked response</summary>
It is A's no-history control. REF-SINGLE is the separately constructed single-transaction benchmark. Even without historical rows, the architecture and recipe differ. A-H05 versus A-H00 helps examine history within A; A-H05 versus REF asks whether one overall recipe outperforms another on matched data. Repair: Chapters 09, 10, and 14.
</details>

### 12. Why freeze preprocessing?

<details markdown="1"><summary>Worked response</summary>
Saved medians, vocabularies, and feature ordering give inputs consistent meanings across training and scoring. Refitting on evaluation data lets assessment information influence the pipeline and may change what category indices or feature values mean. Frozen artifacts still need provenance and compatibility checks; the word frozen is not proof that their original fitting data was appropriate. Repair: Chapter 06.
</details>

### 13. Why can 99% accuracy be poor?

<details markdown="1"><summary>Worked response</summary>
If fraud is rarer than one percent, a model that predicts every transaction as nonfraud can exceed 99% accuracy while finding no fraud. We need metrics that expose positive-class detection and false-alert burden. Accuracy is not mathematically invalid; by itself it answers the wrong question for this rare-event decision. Repair: Chapters 01 and 15.
</details>

### 14. What do AP, AUROC, and calibration tell us?

<details markdown="1"><summary>Worked response</summary>
AP summarizes precision as recall increases over the ranked list. AUROC measures ranking across positive-negative pairs, with appropriate treatment of ties. Calibration asks whether groups receiving a score such as 0.2 actually have fraud rates near 20%. A model can rank well and be poorly calibrated. None alone gives business value at a fixed alert budget. Repair: Chapter 15.
</details>

### 15. How do you know an improvement is real?

<details markdown="1"><summary>Worked response</summary>
First verify comparable inputs, data, selected checkpoints, and paired rows. Then quantify uncertainty appropriate to related observations, such as account-cluster resampling. Check training-seed variability and later cohorts when the decision warrants them. A positive observed difference on one consulted cohort and one seed is not universal proof. Repair: Chapter 14.
</details>

### 16. Why resample accounts instead of individual transactions?

<details markdown="1"><summary>Worked response</summary>
Transactions from one account can be related. Redrawing entire accounts keeps those within-account groups together while varying which accounts are represented. Paired resampling applies the same draw to both models. It assesses a particular source of sampling variability under its assumptions, not every uncertainty about the experiment. Repair: Chapter 14.
</details>

### 17. Does an interval crossing zero prove the models are equal?

<details markdown="1"><summary>Worked response</summary>
No. It means the comparison remains unresolved by that analysis at that uncertainty level. Demonstrating practical equivalence would require a justified equivalence margin and a suitable design. Failure to establish a positive difference is not proof of no difference. Repair: Chapter 14.
</details>

### 18. What is the difference between validation and evaluation here?

<details markdown="1"><summary>Worked response</summary>
Validation is used during training and intended model/checkpoint selection. The separate evaluation data assesses those chosen models, but its repeated use in project development means it cannot simply be advertised as an untouched final holdout. Dataset names do not override how people actually used them. Repair: Chapters 05, 12, and 15.
</details>

### 19. Does gradient accumulation perfectly reproduce one large batch?

<details markdown="1"><summary>Worked response</summary>
It accumulates gradients across smaller pieces before an update, reducing memory needed for activations. Under suitable loss normalization and operations it can approximate the larger-batch update, but batch-dependent layers, stochastic operations, floating-point ordering, and final partial groups can differ. Compare the actual recipe, not just the product of two batch numbers. Repair: Chapter 12.
</details>

### 20. What can you test while GPUs are down?

<details markdown="1"><summary>Worked response</summary>
You can trace source, check arithmetic, test synthetic histories and leakage invariants, validate pairing and metric calculations, and run suitably small CPU tests when dependencies are installed. These checks can find correctness problems but do not establish full-scale GPU throughput, memory use, or bank performance. The bundled labs exercise concepts using invented data. Repair: Chapter 16.
</details>

### 21. Why not use XGBoost or a simpler model?

<details markdown="1"><summary>Worked response</summary>
A simpler method is a legitimate baseline. XGBoost is software for gradient-boosted decision trees: trees ask branching questions about features, and successive trees are trained to improve the combined prediction. The transformer family provides another way to learn feature and history interactions, but architecture popularity is not evidence of superiority for this dataset. A fair comparison needs matching usable features, data, tuning budgets, and operational metrics. The current V1 reference is the corrected single-transaction FT recipe; that fact is not a claim that a current matched XGBoost comparison has been completed. Repair: Chapters 01, 09, and 14.
</details>

### 22. Is pretraining already helping this project?

<details markdown="1"><summary>Worked response</summary>
The repository contains parked pretraining experiments, including reconstructing masked information and contrastive objectives. Their presence means there is code to study, not a demonstrated V1 gain. Pretraining would require its own leakage-safe data design and a matched downstream comparison. Repair: Chapter 13.
</details>

### 23. What would production require beyond a good experiment?

<details markdown="1"><summary>Worked response</summary>
Define the action the score controls, available features and label timing, latency (how long a response takes) and failure behavior, history storage, calibration and threshold policy, monitoring, feedback delays, versioning, and rollback (returning to a known earlier version after a problem). Validate on appropriate later data and measure costs and harms of false alerts and missed fraud. These are engineering and decision requirements, not proof this repository already implements them. Repair: Chapters 01, 05, and 15.
</details>

### 24. What is your most honest one-minute project explanation?

<details markdown="1"><summary>A structure to adapt after understanding it</summary>
“This project studies fraud prediction from tabular transaction data. We preprocess inputs with saved rules and compare a single-transaction FT-Transformer reference with two history-aware designs. A attends over feature tokens across the whole window; B summarizes each transaction before attending across history. We restrict history to information available at the target time, train with labeled examples, and select checkpoints using validation. We evaluate paired predictions and metrics suitable for rare fraud, with uncertainty and explicit limits from the data and experiment design. The current work is research evidence; deployment and a lasting business improvement need further validation.”

Do not use this as a claim that you personally implemented or ran every component. Your strongest answer names what you understand, what the records establish, and what remains unverified.
</details>

## The final memory test

Tomorrow, without opening the course, explain one transaction's journey and answer three questions chosen at random. A week later, change the example: a missing amount, an unseen category, two same-time events, or a suspiciously large AP improvement. If you can reason through those variations, you are developing the ability to defend the project rather than only repeat its vocabulary.

**Repair route:** choose the earliest point where your explanation became vague and return to that chapter's worked example. “It does transformer stuff” sends you to 08–09. “It learns from errors somehow” sends you to 03–04. “We got a better score” sends you to 14–15.
