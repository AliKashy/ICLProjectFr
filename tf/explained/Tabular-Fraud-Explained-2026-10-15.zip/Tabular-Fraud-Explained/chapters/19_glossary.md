# 19 · The glossary you can actually use

Use this as a repair tool. Find the word, say the definition in your own words, then return to the chapter with the worked example. Definitions are reminders; the mechanisms and qualifications are taught in the linked chapters. A few words have a special meaning in this repository, so avoid substituting a familiar meaning from another project.

## Data and decisions

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Tabular | Arranged in rows and columns; here a row describes a transaction | [01](#chapter-01) |
| Observation / example | One item whose inputs and outcome we may learn from or evaluate | [01](#chapter-01) |
| Feature / predictor | An input used to make a prediction, such as an authorized amount field | [01](#chapter-01) |
| Target / label | The answer used for learning or judging a prediction; not the current answer fed into the predictor | [01](#chapter-01) |
| Positive class | The outcome designated 1; here fraud under the configured label mapping | [05](#chapter-05) |
| Continuous feature | A numerical quantity for which magnitude matters | [06](#chapter-06) |
| Categorical feature | Membership in a group, often represented by a code whose arithmetic distance has no natural meaning | [06](#chapter-06) |
| Cardinality | Number of categories represented in a categorical vocabulary, including reserved entries as implemented | [06](#chapter-06) |
| Missing | The original value is absent or recognized as missing by the pipeline | [06](#chapter-06) |
| Unknown category | A present category that has no entry in the fitted vocabulary | [06](#chapter-06) |
| Imputation | Filling a missing feature value with a defined replacement; not inventing a missing target or timestamp | [06](#chapter-06) |
| Median | The middle of ordered values, averaging the middle pair for an even-sized list | [06](#chapter-06) |
| Mean | The sum of values divided by the number of values | [06](#chapter-06) |
| Standard deviation | A measure of how spread out values are around their mean | [06](#chapter-06) |
| Standardization | Subtracting a saved mean and dividing by a saved standard deviation in this numerical pipeline | [06](#chapter-06) |
| Preprocessing artifact | A saved data-preparation object, such as a median or category vocabulary | [06](#chapter-06) |
| Frozen | Reused unchanged for a specified experiment; does not by itself prove correct original fitting | [06](#chapter-06) |
| As-of availability | Whether a value was actually available at the time the prediction would have been made | [05](#chapter-05) |
| Label maturity | Whether enough time has elapsed for outcomes such as confirmed fraud to become sufficiently settled | [05](#chapter-05) |
| Leakage | Information enters learning or prediction in a way that would be unavailable or improper for the claimed evaluation | [05](#chapter-05) |
| Cohort | The particular collection of rows included in an experiment or comparison | [05](#chapter-05) |
| Split | A separation of data into roles such as training, validation, and evaluation | [05](#chapter-05) |
| Entity split | Separating accounts or other entities between roles, rather than merely splitting their individual transactions | [05](#chapter-05) |
| Temporal split | Separating data using time; its exact dates, label timing, and overlap determine what claim it supports | [05](#chapter-05) |
| Account bucket | A grouping of accounts into source files here; a larger file number is not automatically a later date | [05](#chapter-05) |
| Distribution shift | The pattern of inputs or outcomes changes between settings or periods | [05](#chapter-05) |

## Learning and mathematics

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Scalar | One number | [02](#chapter-02) |
| Vector | An ordered list of numbers | [02](#chapter-02) |
| Matrix | A rectangular array of numbers | [02](#chapter-02) |
| Tensor / shape | A multidimensional numerical array / the sizes of its dimensions | [02](#chapter-02) |
| Dot product | Multiply corresponding coordinates and add the products | [02](#chapter-02), [09](#chapter-09) |
| Parameter | An adjustable value inside the model learned during training | [03](#chapter-03) |
| Hyperparameter | A setting such as learning rate or number of layers selected outside ordinary parameter updates | [12](#chapter-12) |
| Weight / bias | A learned multiplier / an added learned offset in a numerical layer | [03](#chapter-03) |
| Layer | A stage of numerical operations in a model | [03](#chapter-03) |
| Activation / nonlinearity | A transformation that lets stacked layers express more than a single linear transformation | [03](#chapter-03) |
| ReLU | The function that keeps positive inputs and replaces negative ones with zero | [03](#chapter-03) |
| GELU | A smooth activation used in the transformer; unlike ReLU, it does not sharply zero every negative input | [09](#chapter-09) |
| Logit | An unconstrained class score before conversion to a probability-style output | [03](#chapter-03) |
| Softmax | Exponentiate scores and divide each by their sum to obtain positive shares summing to one | [03](#chapter-03) |
| Sigmoid | A function mapping one logit to a number between zero and one; used in a teaching simplification | [03](#chapter-03) |
| Forward propagation | Calculating outputs from inputs through the current model | [03](#chapter-03) |
| Loss | A numerical penalty for predictions relative to known targets | [04](#chapter-04) |
| Cross-entropy | A loss that penalizes low probability assigned to the true class; severe confident errors get large penalties | [04](#chapter-04) |
| Derivative / gradient | Local sensitivity to one variable / the collection of sensitivities to many parameters | [04](#chapter-04) |
| Chain rule | The rule for combining sensitivities through a sequence of dependent operations | [04](#chapter-04) |
| Backpropagation | Efficiently applying that rule backward through the computation to obtain parameter gradients | [04](#chapter-04) |
| Optimizer | An algorithm that updates parameters using gradients and possibly stored update statistics | [04](#chapter-04) |
| Learning rate | A scale controlling the size of updates; not a direct measure of intelligence or learning speed | [04](#chapter-04) |
| SGD | Stochastic gradient descent; a basic update using gradients from sampled examples or batches | [04](#chapter-04) |
| AdamW | An optimizer with adaptive gradient statistics and decoupled weight decay; the current default route | [04](#chapter-04) |
| Weight decay | A rule shrinking selected weights during updates, discouraging uncontrolled parameter growth | [04](#chapter-04) |
| Regularization | A technique intended to reduce overfitting, such as weight decay or dropout | [04](#chapter-04) |
| Overfitting | Learning patterns that suit the training examples but do not transfer adequately to new examples | [04](#chapter-04) |
| Generalization | Performance beyond the examples used to fit or select the model | [05](#chapter-05) |
| Batch | A collection of examples processed together; all-position batches require special counting care | [12](#chapter-12) |
| Epoch | One traversal of the training data as implemented by the loader and sampling rules | [12](#chapter-12) |
| Gradient accumulation | Combining gradients from smaller batches before updating, reducing peak activation memory | [12](#chapter-12) |
| Scheduler | A rule that changes the learning rate over training, separately from the optimizer's parameter updates | [12](#chapter-12) |
| Early stopping | Ending training when a monitored validation criterion stops improving under a chosen rule | [12](#chapter-12) |
| Seed | A starting value for pseudorandom procedures; useful for reproducibility but not a universal determinism guarantee | [12](#chapter-12) |
| EMA | Exponential moving average of model weights, an optional smoothed copy; disabled in the V1 default recipe | [12](#chapter-12) |

## Transformer and history vocabulary

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Embedding | A vector representation of an input, usually learned here | [08](#chapter-08) |
| Token | One representation unit passed to attention; here typically a feature vector, not necessarily a word | [08](#chapter-08) |
| Tokenizer | Code turning the input feature values into those feature tokens | [08](#chapter-08) |
| FT-Transformer | Feature Tokenizer plus transformer processing for table-shaped input | [09](#chapter-09) |
| Query / key / value | Learned projected vectors used to request, match, and combine information in attention | [09](#chapter-09) |
| Attention head | One learned attention calculation; several heads can model different relationships | [09](#chapter-09) |
| CLS | A learned summary token, used to gather information for a prediction | [09](#chapter-09) |
| Residual connection | Adding a layer's input to a transformed version, providing a direct information and gradient path | [09](#chapter-09) |
| Layer normalization | Normalizing a token's internal coordinates with learned scale/shift, distinct from input standardization | [09](#chapter-09) |
| Feed-forward sublayer | A small neural network applied to each token within a transformer block | [09](#chapter-09) |
| Dropout | Randomly omitting selected contributions during training under a configured probability | [09](#chapter-09) |
| Position embedding | A representation of a token or transaction's place in the structure | [10](#chapter-10) |
| Mask | A rule marking connections or positions as allowed, prohibited, or padding; conventions differ by API | [10](#chapter-10) |
| Padding | Placeholder slots added to align shapes; they are not real transactions | [07](#chapter-07) |
| Causal attention | Attention constrained to respect the specified information order; mask and input features must both be safe | [10](#chapter-10) |
| Bidirectional attention | Permitting interaction in both positional directions among included inputs | [10](#chapter-10) |
| History length H | The configured history setting; actual available real history depends on data and mode | [07](#chapter-07) |
| Time gap / delta | Elapsed time used as an input; ordinary target-relative and all-position backward gaps differ | [07](#chapter-07), [11](#chapter-11) |
| Flat A | Attention over feature tokens from the whole window in one sequence | [10](#chapter-10) |
| Hierarchical B | Feature attention within each transaction, then attention across transaction summaries | [11](#chapter-11) |
| All-position | B mode predicting each real row in a nonoverlapping chunk under its own strict information contract | [11](#chapter-11) |
| H5 | History setting five in this project's experiment names; not an HDF5 file-format reference | [11](#chapter-11) |
| Pretraining | Learning parameters with an earlier objective before a later downstream task | [13](#chapter-13) |
| Self-supervised | Constructing learning targets from the data itself, such as hidden feature values | [13](#chapter-13) |
| Contrastive | An objective bringing chosen representations closer and separating others; pairing policy matters | [13](#chapter-13) |
| Fine-tuning | Updating a previously learned model for a later task | [13](#chapter-13) |
| ICL | In-context learning: adapting predictions from examples supplied in context; not the active fraud-transformer training method here | [00](#chapter-00) |

## Experiments, software, and results

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Baseline / reference | A comparison method that makes an improvement claim meaningful | [14](#chapter-14) |
| Ablation | Deliberately remove or change a component to examine its contribution under specified conditions | [14](#chapter-14) |
| Interaction | The effect of one change depends on another setting | [14](#chapter-14) |
| Checkpoint | Saved training/model state from a particular point, selected under a stated rule | [12](#chapter-12) |
| Inference / scoring | Computing predictions with chosen parameters rather than updating them | [12](#chapter-12) |
| Threshold | A cutoff converting scores into actions or predicted classes | [15](#chapter-15) |
| Alert budget | A limit on the number of cases investigated; often a more meaningful comparison point than threshold 0.5 | [15](#chapter-15) |
| Precision | Of the cases flagged, the fraction actually positive | [15](#chapter-15) |
| Recall | Of the actual positives, the fraction flagged | [15](#chapter-15) |
| False positive / negative | A legitimate case flagged / a fraud case missed | [15](#chapter-15) |
| AP | Average precision: a ranking summary weighting precision by recall increments | [15](#chapter-15) |
| PR-AUC | An area under a precision-recall curve; the exact convention matters and may differ from AP | [15](#chapter-15) |
| AUROC | Area under the receiver-operating-characteristic curve; a positive-negative ranking interpretation is useful | [15](#chapter-15) |
| Calibration | Agreement between model scores and observed outcome frequencies for similarly scored cases | [15](#chapter-15) |
| Paired comparison | Compare predictions on the same rows with consistent outcomes | [14](#chapter-14) |
| Bootstrap | Resample observed units with replacement and recompute a quantity to study sampling uncertainty | [14](#chapter-14) |
| Account-cluster bootstrap | Resample whole accounts while keeping their transactions together | [14](#chapter-14) |
| Confidence interval | An interval produced by a procedure with a specified long-run coverage goal under assumptions | [14](#chapter-14) |
| Repository / commit | A versioned file collection / one saved version | [17](#chapter-17) |
| Configuration / override | Declared run settings / a later setting that replaces a default | [12](#chapter-12) |
| Provenance | Records of where an artifact came from and how it was produced | [17](#chapter-17) |
| Hash | A fingerprint of bytes; useful for identity, not a correctness proof | [17](#chapter-17) |
| Contract | An explicit expectation about inputs, outputs, or compatible settings | [16](#chapter-16) |
| Unit test / integration test | Check a small component / check several components interacting | [16](#chapter-16) |
| Smoke test | A small run checking that a path can execute; not a full quality or performance assessment | [16](#chapter-16) |
| CPU / GPU | General-purpose processor / processor suited to many parallel numerical operations | [02](#chapter-02), [16](#chapter-16) |
| Worker | A helper process reading data; not the same thing as a GPU or an independent research experiment | [07](#chapter-07) |
| Streaming | Reading data progressively rather than loading the whole dataset at once; exact memory behavior varies by loader | [07](#chapter-07) |
| Parquet | A column-oriented data-file format used for the transaction tables | [07](#chapter-07) |
| Attempt / ledger | One execution / a record of executions and their artifacts | [17](#chapter-17) |
| Production | The operational system making real decisions, with service and monitoring requirements beyond a research run | [18](#chapter-18) |

## A final retrieval exercise

Choose any three terms from different tables. Explain how they connect. For example: “A frozen vocabulary creates categorical indices; embeddings turn those indices into vectors; a checkpoint must be scored with a compatible vocabulary so the vectors still mean the same thing.”

If you can only recite three separate definitions, return to the transaction trace in Chapter 07 or the model trace in Chapter 10 and connect them to a concrete input.
