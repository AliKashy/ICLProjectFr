# 07 — Build one history window, then feed millions of them

**Your question:** How does the program turn the prepared transactions into exactly the history Target is allowed to see, without loading the entire project dataset at once?

**Prerequisite refresher.** Chapter 05 established availability: current features and strictly earlier transactions from the same account are allowed, future and equal-time peers are excluded by the current strict rule. Chapter 06 converted a transaction into six continuous numbers and 23 categorical indices including missing flags. The optional history time feature adds a seventh continuous number. If “category index” still sounds like a fraud score, repair Chapter 06 first.

We will build a complete synthetic example by hand, then connect it to the actual loaders. You should be able to explain this chapter with paper and a pencil; a GPU is unnecessary.

## A file, a block, a batch, and a window

A **Parquet file** stores table data in a form that lets programs read selected columns efficiently. It is a storage format, not a neural network. A **read block** is a collection of rows brought into memory from a file. A **mini-batch** is a group of model examples processed together. A **window** is one history example: allowed earlier transactions plus the current target.

The corrected single-transaction reference, **REF**, streams read blocks and divides them into mini-batches of independent transaction rows. It does not construct transaction histories. Its continuous input has shape `[B, 6]`, where `B` is the number of transactions in the batch. Its categorical input has shape `[B, 23]` when the six missing flags are enabled.

The A/B single-target loaders work differently: they read one selected file's required columns, encode the file's rows, group them by account, and construct windows. They collect windows in a bounded shuffle buffer before emitting mini-batches. They avoid keeping the whole multi-file dataset in memory, but **they do hold a whole selected file's needed columns**, its encoded arrays, and buffered windows. “Streaming” does not mean constant tiny memory or one raw row at a time in every path.

**Shape** means the sizes of a numbered container's dimensions. A **tensor** is such a container; it can be a list, a grid, or a stack of grids. `[B, T, C]` means `B` examples, each containing `T` transaction slots, each slot containing `C` continuous values. No new mathematics is hidden in the brackets.

## Construct Target's window by hand

Let **history length H = 3**. This means up to **three previous transactions**, plus the current transaction, so the total number of slots is `T = H + 1 = 4`. It does not mean three days or three transactions including the target.

Reuse Chapter 05's synthetic records. For Target at 10:00:12, Old at 09:59:50 and Recent at 10:00:05 are eligible. Peer at 10:00:12 is excluded, as is Later at 10:00:20 and every Cedar-account row. Only two eligible prior transactions exist, so one empty slot is needed.

| Slot | Content | Why this slot exists | Real-row mask |
|---:|---|---|---|
| 0 | Padding | One of the three requested prior rows is unavailable | False |
| 1 | Old, 09:59:50 | Earlier Ember transaction | True |
| 2 | Recent, 10:00:05 | Latest eligible Ember transaction | True |
| 3 | Target, 10:00:12 | The current transaction being scored | True |

**Padding** is a placeholder that makes examples the same size. These ordinary A/B windows are **left-padded**, so the target always occupies the final slot. The **mask** marks real transactions separately from placeholders. The loader fills padded numerical and categorical arrays with zeros, but the mask is what identifies them as padding. A genuine amount may standardize to zero and an unknown real category may have index zero; neither fact makes a real transaction a placeholder.

If Ember had five strictly earlier transactions instead, H = 3 would keep the **three most recent**. The model cannot use the other two through this window. A long-lived account can still have a short effective history if the extract is incomplete, the file boundary cuts context, or same-time peers do not qualify.

## Add a clock to each real slot

For ordinary single-target windows, the optional `time_delta` input is:

`log1p(seconds from this slot's transaction to Target)`

`log1p(x)` means the natural logarithm of `1 + x`. The natural logarithm is a compression of positive numerical size: increasing an already large interval changes its encoded value less than the same increase near zero. The `+1` makes zero seconds valid and gives `log1p(0) = 0`. You do not need to calculate logarithms mentally; know what the number describes and why it is compressed.

| Slot | Seconds to Target | Encoded time input, rounded |
|---|---:|---:|
| Padding | No actual time | 0, ignored as padding |
| Old | `22` | `log(23) ≈ 3.1355` |
| Recent | `7` | `log(8) ≈ 2.0794` |
| Target | `0` | `log(1) = 0` |

This is **distance to the current target**, not distance to the previous row. Old's encoded time can change when it appears in a different target's window. Its amount and other frozen transaction features stay the same, but its age relative to the question has changed.

One source detail matters: history eligibility compares parsed timestamps at their stored precision, while this gap channel uses timestamps converted to whole seconds. With whole-second source records, that is straightforward. If a different source supplied fractional seconds, strictly earlier rows within one second could be eligible yet receive a zero whole-second gap. Do not infer perfect temporal resolution from the name `time_delta`.

Target's six continuous values from Chapter 06 were `[1, -0.2, 1, -1, 2, 2]`. In its own target slot the optional gap adds zero, producing `[1, -0.2, 1, -1, 2, 2, 0]`. Its 17 categorical indices plus six missing flags form the 23 categorical entries in that slot. This is the bridge from raw transaction to actual model input.

## Put two examples in a batch

Suppose a mini-batch holds two target windows, each with H = 3 and the time feature enabled. The shapes are:

| Batch entry | Shape | Read it aloud |
|---|---|---|
| Continuous | `[2, 4, 7]` | Two examples, four transaction slots, seven numbers per slot |
| Categorical | `[2, 4, 23]` | Two examples, four slots, 23 category/flag indices per slot |
| Mask | `[2, 4]` | One real-or-padding decision per slot |
| Target | `[2, 1]` | One fraud answer for each example's current transaction |

There are `2 × 4 × 7 = 56` stored continuous numbers, some belonging to padding. That is not 56 separate predictions. The ordinary mode predicts **two targets**, one per window. A/B have different neural-network architectures, but their ordinary single-target examples share this data organization.

The loader carries current target labels for loss or evaluation. Prior transaction labels are not appended to the feature arrays. The account and transaction identifiers can travel as **metadata**, supporting output alignment, but do not become extra learned predictors just because they accompany a batch. **Metadata** is information about the example's identity or handling rather than part of its predictive vector.

## Chronology first, shuffling afterward

The builder groups rows by account and sorts each group by time, then a configured tie-break identifier. Under `history_time_order: strict`, it finds the beginning of Target's equal-timestamp group and selects history ending before that group. This excludes all peers with Target's same timestamp, even those that sorted before Target.

Here is conceptual teaching pseudocode, not copied runtime code:

```text
for each target in an account's chronological records:
    eligible = records with time strictly earlier than target.time
    history = the latest H eligible records available in this file
    slots = left_padding + history + current_target
    emit features(slots), real_row_mask, current_target_label
```

Once windows are correctly built, the training loader can shuffle their order. That improves mixing between similar account examples without changing what any example is allowed to contain. If Target and the next transaction share most of their historical inputs, their windows overlap. This does not make their target labels the same; it means their examples are statistically related, a point that matters for uncertainty in Chapter 14.

A setting called **stride** can skip some nonfraud targets while preserving fraud targets. The active ordinary configurations use training and evaluation stride 1, which selects every target. If stride were 3, the code would select positions 0, 3, 6, and so on in the full sorted account sequence, plus every fraud target at any other position. It counts positions across all account rows, not only nonfraud rows. This changes training composition; it is not simply “run the identical experiment three times faster.” Rows skipped as targets can still exist in another target's history.

## Separate workers must divide the files correctly

A **data-loader worker** is a helper process preparing input while the model does other work. With four files `[A, B, C, D]` and two workers, a clean assignment could be worker 0 → `[A, C]`, worker 1 → `[B, D]`.

If both workers independently shuffle the entire list *before* taking their positions, the assignment can overlap. Suppose worker 0's list is `[A, B, C, D]`, so it takes `[A, C]`. Worker 1's list is `[B, A, D, C]`, so it takes positions 1 and 3, also `[A, C]`. B and D are skipped while A and C are repeated. Each worker looks locally reasonable; together they do not cover the intended dataset.

The current corrected REF loader first partitions the common list, then lets workers shuffle their assigned portions. Current A/B instead construct the same seeded permutation in every worker and then take disjoint positions from it. Both produce a genuine partition. A **seed** sets a repeatable starting state for pseudo-random choices. A/B's file-order permutation repeats for the same shard seed; their window-buffer shuffle is a separate operation. Do not claim all shuffle orders are identical every epoch merely because the file partition is repeatable.

The original `fraud/` loader used independent shuffling before slicing. Its preserved presence does not mean the current REF experiment executes that path: REF uses the corrected `waqas/base/` loader. Source locations and run entry points matter more than a broad folder name.

## Know where context stops

The ordinary builder constructs histories **within one selected file**. It does not maintain a cross-file account-history service. If an account is divided across files, a target will not automatically recover a previous transaction from a different file. Account bucketing supports locality, but it is not evidence that all possible histories are complete. You should explain the actual available context, not an ideal unlimited customer history.

The **all-position B** mode is also different. Instead of one left-padded history window for every target, it constructs disjoint account-local chunks and predicts every real position. Under its strict policy, chunks count distinct whole seconds and do not split a same-second group. They can contain more rows than `H + 1` when times tie. Context resets at chunk and file boundaries, and gaps are measured to the latest strictly earlier timestamp *inside the chunk*. Chapter 11 explains this architecture and why the same H or batch size does not imply the same amount of usable context or work. Do not apply the single-target gap diagram above to all-position mode.

## Source trail and practical inspection

| Claim | Source coordinates |
|---|---|
| REF reads blocks and emits already batched row tensors | `waqas/base/data/parquet_loader.py`, `__iter__`, lines 168–184 |
| REF partitions worker files before local shuffling | Same file, `_get_worker_files`, lines 127–136 |
| A/B share a seeded file permutation before worker slicing | `waqas/phase4a/sequence_builder.py`, `_get_worker_files`, lines 214–225; `waqas/phase4b/sequence_builder.py`, lines 290–300 |
| A builds strict windows, pads left, and adds target-relative gaps | `waqas/phase4a/sequence_builder.py`, `_windows_for_file`, lines 280–321 |
| A emits tensors after a window shuffle and reads each file as a whole selected table | Same file, `_emit_batches` and `__iter__`, lines 324–355 |
| Ordinary B mirrors the single-target construction | `waqas/phase4b/sequence_builder.py`, `_windows_for_file`, lines 367–414 |
| B all-position chunk boundary and time semantics differ | Same file, `_chunks_for_file`, lines 416–460; `waqas/phase4b/ALL_POSITION_CONTRACT.md`, lines 12–28 |

**Predict.** Target has two eligible prior transactions. If H changes from 3 to 5, how many slots and padding positions will it have? Does this change create three extra real transactions?

**Repair.** A reviewer calls zero categorical indices padding without reading the mask. Describe a real transaction this would incorrectly discard.

**Teach back.** Explain Target's entire journey in this order: file → account grouping → time eligibility → latest H → padding → encoded gap → batch. Then state which label is predicted.

<details markdown="1"><summary>Answers and self-check rubric</summary>

H = 5 creates six total slots, with three padding positions, two prior rows, and Target. It creates no real history. A real unfamiliar category has index 0, so zeros alone cannot identify padding; the mask does. A complete teach-back preserves the same account, excludes equal and later timestamps, selects the latest eligible rows, pads on the left, measures ordinary gaps to Target, and produces one answer for Target. If you said “previous row” for the ordinary gap or included Peer, repair the corresponding section before moving on.

</details>

**Recall without looking:** Draw `[pad, Old, Recent, Target]`, its mask, and the gaps `[ignored, 22, 7, 0]`. Explain why shuffling those finished examples is compatible with strict histories. Repair chronology in Chapter 05, numeric encoding in Chapter 06, and shape notation in Chapter 02. You are now ready for Chapter 08: how these arrays become learned feature representations.
