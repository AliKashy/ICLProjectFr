# 01 — What problem are we trying to solve?

## Start with a decision, not a model name

**Prerequisite refresher:** none. A *transaction* is an event such as a payment. A *table* organizes events into rows and their properties into columns. Every number in this chapter is invented for learning; none is a bank result.

Your question for this chapter is: **When a transaction arrives, what information can we use to decide whether it deserves attention?**

Imagine that you help a team review payments. Most are legitimate. A few are fraudulent. Reviewing every payment would be expensive and slow. Ignoring every payment would miss fraud. You need a way to prioritize attention using information available when each payment occurs.

A simple human rule might be: “Review every payment above 500.” That is easy to explain, but it would flag an ordinary large purchase and miss a small fraudulent one. A more useful assessment could combine amount, payment channel, time and relevant earlier behavior. A *model* is a calculation that takes such information and produces an output. In this project, the output supports ranking transactions by suspected fraud.

A model is only one part of the decision system. A *score* is a number used to order cases. A *threshold* is the cutoff for an action. For example, “review scores at least 0.70” is a policy applied to model scores. Investigators, operating costs and capacity still matter. A score is not itself a verdict, an investigation or a guarantee.

## Read one row correctly

Consider this fictional table:

| Transaction | Account | Time | Amount | Channel | Later confirmed fraud? |
|---|---|---|---:|---|---:|
| Example A | Customer Red | 09:00 | 20 | In person | 0 |
| Example B | Customer Red | 09:10 | 80 | Online | 0 |
| Example C | Customer Red | 09:20 | 200 | Online | 1 |
| Example D | Customer Blue | 09:25 | 40 | In person | 0 |

A **row** is one transaction. A **feature**, also called a predictor or input, is a property supplied to the model. Amount and channel could be features. The **label**, also called the target or outcome, is the answer used to teach or evaluate the model. Here `1` means fraud and `0` means non-fraud.

Those digits are a convention, not a statement that fraud is “bigger” than non-fraud. A **binary classification** task chooses between two classes. The word *classification* means assigning or scoring membership in categories. *Binary* means there are two categories.

Not every table column belongs in the model. Account references may help assemble a customer's earlier transactions. Transaction identifiers may help reconcile records. An identifier used to join or check records need not be a predictor. Most importantly, the later confirmed outcome is not an input when making the original prediction. Giving the answer to the model would make a practice exercise look impressive while making it unusable for real decisions.

For Example C, the practical question is:

> Using information available by 09:20, how suspicious is this transaction?

The later label teaches us whether the prediction was useful. It does not travel backward in time to help produce the prediction. Chapter 05 will make that boundary precise.

## What “tabular” and “history-aware” mean here

**Tabular** means the original information is organized like a table. It does not mean the model is an ordinary spreadsheet formula or that every column is a number.

There are two broad views of Example C:

1. **Single transaction:** assess the current row using its available predictors.
2. **Transaction history:** assess the current row together with selected earlier transactions belonging to the relevant account.

In the fictional example, a history-aware model might receive A, B and C while predicting C. D belongs to a different account and is later anyway. A history length of two means up to two earlier transactions, plus the current transaction. It does not mean “two days.” If the customer has only one earlier transaction, the system must represent the missing slot safely rather than inventing a payment.

The project contains a single-transaction reference called **REF**, and two history-model structures called **A** and **B**. A processes feature representations from the sequence together in a flat arrangement. B first builds a representation for each transaction and then combines information across transactions. A *representation* is simply a collection of numbers the model uses internally to carry information. You will build this idea gradually in Chapters 03 and 08–11.

The models use a family of neural networks called FT-Transformer. For now, read that name as a label on a box whose behavior we will unpack. You do not need to know what a neural network, token or attention mechanism is yet. Chapters 03, 08 and 09 teach those concepts before relying on them.

More history is a hypothesis, not an automatic improvement. It may provide useful context, or it may add distracting patterns and computational work. A bigger model can learn more useful structure, but it can also learn accidental patterns in the examples it saw. We need comparable experiments to find out.

## The whole project as one journey

Picture a transaction moving along this route:

**Recorded events → permitted inputs → consistent numerical form → current row plus allowed history → model → two class scores → fraud score → evaluation → human interpretation.**

Each arrow represents work. “Consistent numerical form” means that the same category and amount receive the same interpretation during training and later scoring. “Allowed history” means past information that satisfies the project's time and account rules. “Two class scores” means the model makes a numerical output for each of the two classes; we will convert these into a fraud score in Chapter 03.

There is also a separate learning loop:

**Training examples + known labels → predictions → a numerical penalty for mistakes → calculated parameter changes → updated model.**

A **parameter** is an adjustable number inside the model. Training changes these numbers. A **training example** is the input presented for one prediction together with its known target when available. A history-aware example can contain several transaction rows while still predicting one target transaction.

After learning, **inference** means using the model to calculate outputs for inputs. In ordinary scoring, parameters are fixed: the model does not automatically learn from each payment as it arrives. A **checkpoint** saves learned model state so a particular version can be loaded again. A file called “best” is not automatically the best possible fraud model; it records the selection rule used in that experiment.

Training, checking development choices and evaluating final performance serve different purposes. **Training data** supply the examples used to change parameters. **Validation data** help choose settings or checkpoints. **Evaluation/test data** support an assessment of the selected procedure. Their exact roles and boundaries matter more than the names on the files. We will return to them in Chapters 05, 12 and 14.

## Worked business example: accuracy can flatter a useless system

Suppose a fictional set contains 1,000 transactions: 10 fraudulent and 990 legitimate. A system that predicts “legitimate” for every transaction gets 990 correct.

Its **accuracy**, the fraction of all predictions that are correct, is:

`990 ÷ 1,000 = 0.99 = 99%`.

That sounds excellent until you ask how much fraud it found. It found `0 ÷ 10 = 0%` of the fraudulent transactions. A high percentage can answer the wrong business question.

Now imagine a model whose chosen threshold flags 20 transactions. Of those, eight are fraudulent and 12 are legitimate. Two fraudulent transactions remain unflagged.

- **Precision** asks: of the cases we flagged, how many were fraud? `8 ÷ 20 = 40%`.
- **Recall** asks: of all the fraudulent cases, how many did we flag? `8 ÷ 10 = 80%`.
- Review workload is 20 transactions, or `20 ÷ 1,000 = 2%` of this fictional set.

Precision and recall have different denominators because they answer different questions. Precision helps describe the quality of the review queue. Recall helps describe the coverage of fraud. Neither alone gives financial value. Missing one large fraudulent payment may cost more than missing several tiny ones; reviewing legitimate customers also has costs.

Do not attach these figures to REF, A or B. They are an arithmetic exercise. Chapter 15 teaches the project's measured metrics and how to read actual outputs without turning a small difference into an unsupported claim.

## Where this connects to the actual implementation

The course is grounded in the source snapshot identified in Chapter 00. Relative paths below locate source in the original repository; access to that repository may be required.

- `fraud/data/feature_list.py`, `FeatureList` and `load_feature_list`, lines 25–37 and 57–104: the project loads a versioned predictor list and separates continuous and categorical predictors. This is the code counterpart of deciding which columns have which role.
- `waqas/base/streaming_model.py`, `build_inferred_config`, lines 36–51: the reference builder specifies two output classes. `build_streaming_model`, lines 54–116, constructs its FT-Transformer from configuration and already prepared inputs.
- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 21–68: A stores `history_len + 1` transaction positions and builds a two-output prediction head. Its `forward`, lines 146–173, turns a batch into class scores.

These references establish implemented behavior. They do not establish which model wins on bank data. The course treats executed evidence, implementation and proposed experiments separately. Current results interpretation is covered later; no GPU run is needed to understand this chapter.

## Common wrong mental model

**Wrong:** “The model identifies fraud, so a score of 0.80 proves the transaction is fraudulent with an 80% real-world probability.”

**Repair:** The score is model output on a probability-like scale. Whether values correspond to observed frequencies is a separate question called **calibration**. Even a well-calibrated 0.80 score describes uncertainty; it is not certainty for one transaction. Training choices, population changes and data quality can all affect how useful a score is.

Another common mistake is “the latest architecture must be the strongest.” Model comparisons require the same intended evaluation task and carefully tracked differences. Complexity is a property of a design, not evidence of usefulness.

## Your case-room challenge

Before opening the answer, say your reasoning aloud or write it in the chapter's teach-back box.

**Predict:** You have 500 transactions, including five frauds. A rule flags ten transactions and catches four frauds. What are its precision and recall? Why would always saying “non-fraud” be a weak alternative even though its accuracy is high?

**Repair:** A colleague includes “investigator confirmed fraud next week” as a predictor for today's transaction. Explain the problem in one sentence.

**Teach back:** Trace Example C from its row to a review decision. Use the words input, label, score and threshold correctly. Explain how using history changes the input, and name one thing history does not guarantee.

<details><summary>Open after attempting: answer and a self-check rubric</summary>

Precision is `4 ÷ 10 = 40%`. Recall is `4 ÷ 5 = 80%`. The always-non-fraud rule gets `495 ÷ 500 = 99%` accuracy while finding no fraud. The future investigator outcome is unavailable at decision time, so using it gives the model information it would not have when deployed.

A strong teach-back says that permitted properties of C, and perhaps strictly earlier relevant history, become inputs. The model produces a score. A policy compares the score with a threshold to decide whether to review. The later known outcome is the label used for learning or evaluation. More history may help, but its value must be tested. You do not need to name any neural-network component yet.

If you mixed up precision and recall, circle the words “flagged” and “all fraud” before choosing a denominator. If you treated a score as a verdict, restate the distinction between model output and the action policy.

</details>

**Recall without looking:** draw the two journeys: producing a score, and training a model. Explain why they are different. **Repair route:** revisit this chapter for input/label/decision confusion; go to Chapter 02 for fractions and shapes, Chapter 05 for time boundaries, and Chapter 15 for evaluation measures.
