# 03 — Build a neural network you can calculate by hand

## Start with something you already know

**Prerequisite refresher:** an input vector is an ordered list of values. A weight multiplies an input; a bias adds an offset. A dot product adds matching input–weight products. A batch groups examples without changing what each example means.

Your question is: **What is a neural network actually doing when it produces a score?**

The name can make the idea sound more mysterious than it is. A **neural network** is a collection of connected numerical calculations with adjustable parameters. One calculation produces values that feed the next. Training adjusts the parameters so those calculations become more useful for a task.

The word “neural” is historical inspiration, not a claim that this software thinks like a human brain. For this project, you can picture a trainable calculation pipeline. Once you understand one small pipeline, the larger model becomes a question of organizing more calculations, not an entirely different kind of magic.

## One unit: weighted total, then activation

A simple **unit**, sometimes called a neuron, first calculates a weighted total plus a bias. It then applies an **activation function**, a rule that transforms that total. An activation can change which patterns a network is able to represent.

Our teaching network uses **ReLU**, short for rectified linear unit. Its rule is easy:

`ReLU(a) = a if a is positive; otherwise 0`.

So `ReLU(2) = 2`, `ReLU(−3) = 0`, and `ReLU(0) = 0`. The symbol `a` is just the number entering that activation.

Why transform a perfectly good weighted total? If you keep stacking only weighted totals and biases, the entire stack can be collapsed into one weighted-total calculation. Nonlinear activations, such as ReLU, break that restriction and allow more varied input–output patterns. **Nonlinear** here means the transformation is not one straight-line relationship across its full input range.

ReLU is a teaching choice, not a claim that every component of this project's Transformer uses it. The current A encoder explicitly uses another activation, GELU, which makes a smoother transformation rather than a hard cut at zero. The detailed Transformer computation comes in Chapter 09. The central idea is the same: combine values, then apply transformations that permit richer relationships.

## Our complete fictional model

We will follow one invented transaction through a network small enough to do by hand. It has:

- Two inputs: `x1 = 2`, a fictional amount measured in hundreds, and `x2 = 1`, a fictional online-channel flag.
- Two intermediate units, called a **hidden layer** because these are internal values rather than observed labels or final outputs.
- One final learned raw score and one fixed reference raw score, which together produce a fraud score.

This is conceptual teaching arithmetic. The real project has more inputs, learned feature representations and Transformer blocks. In particular, its current preprocessing is not “divide every amount by 100,” and its categorical features use learned lookup representations rather than this example's simple flag rule.

Here are all nine adjustable parameters in our tiny network:

| Calculation | Weight on first input | Weight on second input | Bias |
|---|---:|---:|---:|
| Hidden unit 1 | 0.50 | −0.50 | 0 |
| Hidden unit 2 | −0.25 | 1.00 | 0 |
| Fraud raw score, using the two hidden values | 1.00 | 2.00 | −0.50 |

The parameters are chosen by hand for this lesson. A real training run starts from an initialization procedure and learns parameter values. A learned weight's meaning depends on the rest of the model and the input transformation; it is rarely a direct standalone business explanation.

## Step 1: calculate hidden unit 1

Call the weighted total before activation `a1`:

`a1 = 0.50 × x1 + (−0.50) × x2 + 0`.

Insert our values:

`a1 = 0.50 × 2 − 0.50 × 1 = 1 − 0.5 = 0.5`.

Apply ReLU to get hidden value `h1`:

`h1 = ReLU(0.5) = 0.5`.

The distinction between `a1` and `h1` matters. `a1` is the input to the activation. `h1` is its output. They happen to match here because `a1` is positive. If `a1` had been `−0.5`, `h1` would have been zero.

## Step 2: calculate hidden unit 2

`a2 = (−0.25) × x1 + 1.00 × x2 + 0`.

`a2 = −0.25 × 2 + 1 × 1 = −0.5 + 1 = 0.5`.

`h2 = ReLU(0.5) = 0.5`.

The hidden representation of this transaction is now the vector `[0.5, 0.5]`. These are not new measured facts about the customer. They are intermediate values calculated from the inputs using the current parameters. Another set of parameters could represent the same transaction differently.

This is the seed of the **representation learning** idea: the model learns useful internal ways to encode inputs, as part of learning its final prediction task.

## Step 3: calculate the raw output

Call the fraud raw score `z1`:

`z1 = 1.00 × h1 + 2.00 × h2 − 0.50`.

`z1 = 1 × 0.5 + 2 × 0.5 − 0.5 = 1.0`.

For this tiny example only, set the non-fraud raw score `z0 = 0`. The output vector is `[z0, z1] = [0, 1]`.

A raw class score is called a **logit**. A logit can be any real number, including a negative number or a number larger than one. It is not yet a probability. The project's classifiers generally produce two logits per example, with both learned through their prediction head. We fixed one to zero only to make our arithmetic manageable.

A **prediction head** is the final part of the model that turns its internal representation into task outputs. The earlier calculations are often called the **backbone**. In this example, the two hidden units form the tiny backbone, and the last weighted total forms the head.

## Step 4: turn two logits into two class scores

**Softmax** turns a vector of logits into positive values that sum to one. For two classes, its fraud output is:

`p = exp(z1) ÷ [exp(z0) + exp(z1)]`.

`exp(a)` means the exponential of `a`, also written `e` raised to the power `a`. The constant `e` is approximately 2.71828. You do not need to derive it; a calculator provides `exp`. Useful values are `exp(0) = 1` and `exp(1) ≈ 2.71828`. Exponentials convert any finite logit into a positive number, and dividing by their total makes the class scores sum to one.

For `[0, 1]`:

`p = 2.71828 ÷ (1 + 2.71828) ≈ 0.73106`.

The non-fraud output is `1 ÷ 3.71828 ≈ 0.26894`. Their sum is one, apart from rounding.

For two logits, the same fraud score can be written:

`p = 1 ÷ [1 + exp(−(z1 − z0))]`.

That function is called the **sigmoid** of the logit difference. This is why some binary models use one logit and a sigmoid while others use two logits and softmax. Our actual project uses two-output classification paths. The algebra helps you recognize their relationship without assuming their training implementations are identical.

Softmax depends on relative logits. `[0, 1]` and `[10, 11]` produce the same class scores because their difference is the same. The magnitude of one logit alone is not enough to interpret a two-logit output.

## What has, and has not, happened

The complete **forward propagation**, often called a forward pass, was:

`[2, 1] → [a1, a2] = [0.5, 0.5] → [h1, h2] = [0.5, 0.5] → logits [0, 1] → fraud score 0.73106`.

“Propagation” means values are passed through the connected calculations. No parameter changed. No label was needed to calculate this score. We have computed a prediction, not performed a learning step.

If a fictional review policy flags scores at least 0.70, this example is flagged. At a threshold of 0.80, it is not. The network's parameters and output are identical in both cases; only the action policy changed.

The value 0.73106 lies on a probability scale, but calibration still needs checking. It does not by itself prove that roughly 73% of similar real-world transactions are fraudulent. It certainly does not prove that this one transaction is fraudulent.

## A small change you can predict

Keep the parameters fixed but change the channel flag from `1` to `0`, holding `x1 = 2`.

Hidden unit 1 receives `0.5 × 2 − 0.5 × 0 = 1`, so `h1 = 1`. Hidden unit 2 receives `−0.25 × 2 + 1 × 0 = −0.5`, so ReLU makes `h2 = 0`. The fraud logit becomes `1 × 1 + 2 × 0 − 0.5 = 0.5`. The fraud score becomes `1 ÷ [1 + exp(−0.5)] ≈ 0.62246`.

The input change affected different hidden units differently. One rose; the other dropped to zero. Their combined effect lowered the fraud score. This illustrates why interpreting a hidden network through one isolated weight can be misleading. It also illustrates why a network can be calculated exactly, even when it contains several moving parts.

## How this becomes the project's much larger model

The project shares the same broad pattern: inputs become internal numerical representations, several learned transformations combine them, and a head emits class logits. It uses **feature tokens**, one representation per feature, and **attention**, a learned way to combine information across representations. Those terms are previews; Chapters 08 and 09 explain their mechanics with their own worked examples.

Actual implementation connections:

- `src/pytorch_tabular/models/base_model.py`, `BaseModel.forward`, lines 396–404: the reference path explicitly calls input embedding, backbone computation and the head. `compute_head`, lines 383–394, constructs the output.
- `src/pytorch_tabular/models/ft_transformer/ft_transformer.py`, `FTTransformerModel._build_network`, lines 113–119: builds those three parts. `FTTransformerBackbone.forward`, lines 69–82, processes representations through its blocks and selects a summary representation.
- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 51–68: A creates its input representation machinery, Transformer encoder, linear two-output head and loss. Its `forward`, lines 146–173, ends by returning head logits. It does not end by making a business decision.

These are architecture facts. They do not turn our two-unit arithmetic exercise into an execution of the project model.

## Common wrong mental model

**Wrong:** “A neural network means every unit corresponds to an understandable fraud rule, and forward propagation improves those rules.”

**Repair:** Hidden units carry intermediate calculations that need not correspond to named rules. A forward pass calculates outputs using current parameters. Learning requires a label-based loss and a parameter-update procedure, which Chapter 04 will teach.

## Your prediction challenge

**Predict:** With the original parameters, calculate both hidden values for `[x1, x2] = [0, 0]`. Then calculate the logits and fraud score. You may use `exp(0.5) ≈ 1.64872`.

**Repair:** Someone calls `z1 = 1.0` a “100% fraud probability.” Explain the missing step and give the actual probability-scale score for our original `[0, 1]` logits.

**Teach back:** Without using the word “AI,” explain a neural network, a hidden representation and a forward pass to a colleague.

<details><summary>Open after attempting: worked answer and rubric</summary>

Both hidden weighted totals are zero, so both hidden outputs are zero. The fraud logit is `−0.5`, and the reference logit is zero. The fraud score is `1 ÷ [1 + exp(0.5)] ≈ 0.37754`. Zero-valued inputs do not require a zero logit because the head has a bias.

A logit is an unrestricted raw score. Softmax converts the two logits `[0, 1]` into about `[0.26894, 0.73106]`. Calling `1.0` “100%” skips that transformation and ignores the other class logit.

A good teach-back describes connected adjustable calculations, intermediate numerical representations and the passage of inputs through those calculations. It explicitly says that a forward pass alone does not update the parameters. If you forgot an activation, place separate boxes for weighted total and activation on your drawing.

</details>

**Recall without looking:** draw this network and recreate the original score 0.73106 from its nine parameters. **Repair route:** Chapter 02 for weighted totals or vectors; this chapter for logits and forward propagation; Chapter 04 for learning; Chapters 08–11 for the actual model's representations and structure.
