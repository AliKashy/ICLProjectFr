# 12 · From one learning step to a reproducible experiment

**Prerequisite refresher.** Chapter 04 separated a forward pass (make a prediction), loss (measure its error), backpropagation (calculate gradients: how small parameter changes would affect loss), and optimizer (use those gradients to update parameters). Chapters 10–11 explained the models that produce the prediction. Here you become the person who can explain how those steps become a complete run.

**Your concrete question:** “What exactly happens after I start training, and which saved model do I eventually evaluate?”

## Follow one example around the loop

Imagine a synthetic training set of 12 transactions. A **batch** is a group processed together. With batch size 4, the loader supplies three batches. The network predicts four pairs of logits, converts their errors into one loss, and computes gradients. Ordinarily, the optimizer then updates its parameters. The next batch sees those changed parameters. After all three batches, the training data has been visited once: that is one **epoch**. Another epoch revisits the data; it does not mean acquiring new transactions.

Training mode matters. **Dropout** randomly suppresses some internal activations during training, encouraging the network not to rely too heavily on a particular route. At validation and scoring, dropout is disabled. The model is still the same learned model, operating in its evaluation mode. A prediction can therefore differ between training mode and evaluation mode even before any parameter update.

At the end of a training epoch, the validation loader supplies held-out examples. The model predicts without using those labels for gradient updates. Validation labels are used to calculate metrics and make training decisions. This means validation influences model selection even though it does not provide ordinary training gradients. “Not used in backpropagation” is not the same as “never used in development.”

The framework **PyTorch Lightning** handles the repeated loop. A framework is reusable software that calls your model's functions at the right time. In this project, `training_step` returns loss, `validation_step` returns logits and labels, and callbacks handle shared work. A **callback** is a function invoked at a particular event, such as the end of validation; it is not another neural network.

## What the knobs actually mean

The **learning rate** controls the scale of optimizer updates. An excessively large step can overshoot useful parameter settings; an excessively small step can make learning slow. That intuition is useful, but AdamW also adapts updates using running information about past gradients, so a learning rate is not literally “move each weight this many units.” Chapter 04 gives the simpler gradient-descent calculation.

**Weight decay** discourages large parameter magnitudes as part of optimization. AdamW separates that decay from its adaptive gradient calculation. It is a training choice intended to help generalization; it does not guarantee a more accurate fraud model. **Generalization** means useful behavior on relevant examples beyond those used for fitting.

A **scheduler** changes the learning rate while training. A and B use `ReduceLROnPlateau`, which watches validation loss and reduces the learning rate by a factor of 0.5 after its configured non-improvement patience. If the learning rate is 0.0003, one reduction produces 0.00015. It does not halve the model size or the number of examples. The configured scheduler patience is 3; its exact trigger includes the library's definition of improvement and bad epochs.

**Early stopping** ends training when a monitored validation metric stops improving for the configured patience. The current A/B settings watch validation average precision, abbreviated `valid_ap`, maximize it, and use patience 5. **Checkpoint selection** also maximizes `valid_ap`. These decisions differ from the scheduler, which watches `valid_loss`. There is no contradiction: one measure guides update size, another selects the saved ranking model. Chapter 15 will calculate average precision by hand.

The maximum epoch setting is an upper bound, not a promise to complete that many epochs. A run with `max_epochs=10` can stop earlier. Nor does completing ten epochs mean epoch ten is the best checkpoint.

## Checkpoint selection: a small worked example

Suppose a synthetic run records:

| Completed epoch | Training loss | Validation loss | Validation AP |
|---|---:|---:|---:|
| 1 | 0.50 | 0.46 | 0.20 |
| 2 | 0.40 | 0.43 | 0.26 |
| 3 | 0.34 | 0.44 | 0.24 |

The best checkpoint is from epoch 2 because 0.26 is the highest validation AP. The last checkpoint is from epoch 3. Training loss improving from 0.40 to 0.34 does not override the selection criterion. A checkpoint contains saved model state; a results row is only a summary of measurements. You cannot recreate the model from its AP number.

The scorer must load the selected checkpoint and compatible feature/preprocessing/history settings. A **hash** is a compact fingerprint of file contents. It helps establish which checkpoint produced which predictions. It does not prove that the model was well designed. Changing a checkpoint's filename does not change its contents; changing its contents without changing its filename does change the hash.

## When a batch does not fit in memory

Longer histories make larger internal arrays, particularly for flat attention. **Gradient accumulation** processes several small batches before the optimizer update. A small batch here is often called a **micro-batch**.

With 1,024 examples per micro-batch and accumulation 4, the nominal number of examples contributing to an update is:

`1,024 × 4 = 4,096`.

The checked A-H10 specification uses that combination. A-H15's checked specification uses `256 × 16 = 4,096`; A-H20's uses `128 × 32 = 4,096`. The returned V1 records describe different micro-batch overrides for some runs while retaining the same nominal total. Learn to read the resolved run configuration, not only the template. The **resolved configuration** is the final set of settings after defaults and overrides have been combined.

Equal nominal batch size does not prove bitwise identical training. Final partial groups can contain fewer examples; dropout draws, floating-point arithmetic, and actual grouping can differ. All-position B additionally uses chunks containing multiple scored rows, so “256 chunks” does not mean “256 target transactions.” Record both the meaning of a batch and the accumulation policy.

**Mixed precision** performs selected calculations with lower precision to reduce memory and speed supported hardware. A/B configuration uses `bf16-mixed`. This is a numerical implementation choice, not extra training data or a different label definition. The reference trainer has its own recipe; do not infer its precision from A/B defaults.

## Randomness and reproducibility

A **seed** initializes a pseudorandom number generator: software that produces a repeatable sequence of seemingly random numbers. Parameter initialization, dropout and shuffling can use randomness. V1 uses seed 42. A seed is a recipe ingredient, not a certificate that two runs are identical.

For a meaningful reproduction, also match source version, resolved configuration, feature order, preprocessing artifacts, data cohort, checkpoint choice, package versions, and relevant hardware behavior. A **cohort** is the exact collection of examples being considered. Matching the same file count is weaker than matching the actual cohort.

The current training entry points explicitly reject unsupported distributed multi-process training because their iterable data are not partitioned by process rank. In plain terms, cooperating training processes would each need an assigned share of the data; otherwise they can repeat the same examples. A process's rank is its identifier within that cooperating group. Running independent experiments on separate GPUs is different: each GPU trains its own model. It does not automatically combine them into one larger training run.

## Optional EMA, explained without magic

**Exponential moving average**, or EMA, keeps a smoothed copy of parameters. With decay 0.9, old EMA weight 2.0 and new training weight 3.0:

`new EMA = 0.9 × 2.0 + 0.1 × 3.0 = 2.1`.

Most of the previous smoothed value remains; a little of the latest weight enters. EMA weights are not averaged transaction scores. The callback updates after completed optimizer steps, swaps EMA weights in for validation, and restores raw training weights afterward. Checkpoint handling preserves EMA inference weights plus raw and shadow state for resuming.

That lifecycle matters. Updating EMA on every micro-batch would smooth at a different rate when accumulation changes. Resuming training from the smoothed copy while retaining an optimizer state associated with raw weights would change the trajectory. The project has specific tests for these cases. EMA is implemented, but current A/B V1 configuration has `ema: false`. An available option is not a measured improvement.

## Where this is implemented

- `waqas/phase4a/scripts/train_sequential.py`, `main`, lines 59–115: seed, loaders, callbacks, one-device trainer and accumulation. The B entry point follows the corresponding phase-local structure.
- `waqas/phase4a/sequential.py`, `_step` through `configure_optimizers`, lines 181–201: loss, validation output and the loss-monitored scheduler. `waqas/phase4b/sequential_hier.py`, lines 389–395: B optimizer/scheduler.
- `waqas/phase4a/configs/sequential.yaml`, `training`, lines 60–78: A defaults, including AP selection and disabled EMA. A run specification can override these.
- `fraud/callbacks.py`, `StreamingBinaryMetrics`, lines 43–79: collect the complete validation stream before calculating ranking metrics.
- `waqas/phase4a/callbacks.py`, `EMACallback`, lines 39–107: step-aware smoothing, weight swapping and checkpoint state.
- `waqas/base/scripts/train_streaming.py`, `main`, lines 114–158: the reference has its own trainer construction and frozen-input contract callback.

## Predict, repair, explain

**Predict.** A run has validation AP 0.20, 0.28, 0.25 across three epochs. Which checkpoint should the scorer use? Does lower training loss in epoch 3 change that?

**Repair.** Someone says, “Our two jobs both used seed 42 and effective batch 4,096, so they must be identical.” Identify four missing pieces of evidence.

**Teach back.** In one minute, explain the difference between the optimizer, learning-rate scheduler, early stopping and checkpoint selection.

<details><summary>Answers and self-check rubric</summary>

Use epoch 2 under the stated AP-maximizing selection rule. Training loss does not change that rule. Possible missing evidence includes actual source, cohort, frozen artifacts, feature order, micro-batch composition, numerical precision, software versions, and checkpoint identity. Full-credit teach-back: optimizer changes weights using gradients; scheduler changes learning rate; early stopping decides when to end; checkpoint selection decides which saved state is best under the chosen validation measure. Give each its own job and name AP versus loss correctly.

</details>

**Recall without looking:** sketch `batch → logits → loss → gradients → optimizer update`, then add validation, best checkpoint and scoring as separate stages. If gradients still feel mysterious, repair with Chapter 04. If selecting the best checkpoint by AP feels arbitrary, continue to Chapter 15 and calculate AP yourself.
