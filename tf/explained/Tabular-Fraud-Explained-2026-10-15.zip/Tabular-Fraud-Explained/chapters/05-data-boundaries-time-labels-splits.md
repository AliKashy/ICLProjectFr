# 05 — Decide what the model is allowed to know

**Your question:** When we ask, “Is this transaction fraudulent?”, which facts may we show the model, and which facts must we hide?

**Prerequisite refresher.** A feature is an input used to make a prediction. A label is the answer used to teach or judge it. A model's weights are adjustable numbers; training changes them to reduce a loss, a numerical measure of prediction error. You do not need to calculate a gradient in this chapter. You need the distinction between *information used to predict* and *information used afterward to check the prediction*. Repair that distinction in Chapter 01 if necessary.

Imagine you are standing beside a payment terminal. The clock says **10:00:12**. A transaction arrives for **150 currency units**. Your job is to decide now. A customer complaint received tomorrow cannot travel backward in time to help today's decision. Much of this project is the work of enforcing that apparently simple rule.

All transactions and numbers in this chapter's worked examples are invented. They are not bank records or project performance results.

## The row we will follow

Our synthetic account is **Ember**. The transaction we want to score is **Target**, at **2026-10-15 10:00:12**. The account also has these records:

| Synthetic record | Account | Recorded time | Amount | What it means for Target |
|---|---|---|---:|---|
| Old | Ember | 09:59:50 | 20 | Earlier information |
| Recent | Ember | 10:00:05 | 40 | Earlier information |
| Peer | Ember | 10:00:12 | 900 | Same recorded instant; order unknown |
| Target | Ember | 10:00:12 | 150 | The transaction to predict |
| Later | Ember | 10:00:20 | 800 | Future information |
| Other | Cedar | 10:00:04 | 10 | Another account's transaction |

For the current A/B **strict history rule**, Target may use Old and Recent. A and B are the two history-model designs explored in Chapters 10 and 11. Target may not use Peer, Later, or Other. “Strict” means an earlier timestamp, rather than an earlier row in a sorted table. In the bank's whole-second data, two events recorded at 10:00:12 have the same time. Sorting their identifiers alphabetically makes the file reproducible; it does not establish which event was available first.

There are two distinct facts here. Target's own amount is allowed because this is the transaction being assessed. Target's own eventual fraud label is withheld from prediction. The current transaction is an input; its answer is not.

## A label is an outcome, with a reporting clock

The configured target column is `frd_tag`. The positive value is `1`, meaning the declared fraud class. The current encoder produces numerical 1 for values equal to the configured positive label and 0 for other observed, nonmissing values. It rejects missing labels. This is a configurable comparison, so inspecting actual label values and their types matters: a text value and a numeric value must not be assumed interchangeable.

In a training example the program carries both inputs and the answer. It first computes a prediction from the inputs, then compares it with the answer to calculate loss. Carrying a label in a training batch is necessary; using that label as a predictive feature would defeat the exercise.

The forward prediction itself does not need an answer. However, the current offline loaders and scoring workflow still read the target column and require nonmissing labels, because they prepare labelled training/evaluation data. A model capable of prediction and a complete production service for unlabeled live payments are different deliverables; this course does not claim the latter already exists.

**Label maturity** is the time needed for an outcome to become sufficiently settled. A purchase might look legitimate on Monday and be disputed later. That gives us two clocks: when the transaction occurred, and when its outcome became known. The project does not feed previous transactions' fraud labels into the ordinary A/B history features. This avoids treating a later investigation as if it had been known at the earlier decision.

That rule does not solve every maturity problem. Training and evaluation still need trustworthy target labels. A recent transaction with an unresolved outcome can make a good score look wrong or a wrong score look good. A loader can verify “the label is present”; it cannot establish “the customer's outcome has finished developing.” No universal maturity delay is proved by the source code. A statement such as “all labels are final after exactly 30 days” would need upstream evidence, so we do not make it here.

**Try the distinction.** On October 15 you score Target. Its final fraud label becomes available on October 29. Can that October 29 label ever be used?

<details markdown="1"><summary>Reveal the reasoning</summary>

Yes, afterward as Target's supervised training answer or evaluation outcome, if the dataset and evaluation design properly account for when labels become available. It cannot be inserted into the October 15 prediction inputs. Whether a past transaction's label is usable as an input in some different system depends on its actual availability at prediction time; this project's ordinary history inputs omit it.

</details>

## Three datasets have three jobs

A **split** is a designated group of examples with a particular role:

| Split | Job | What changes because of it? |
|---|---|---|
| Training | Practice examples with answers | The optimizer adjusts model weights |
| Validation | Check progress and compare planned settings | Decisions such as which saved epoch to keep |
| Evaluation/test | Measure the selected procedure on held-out examples | The reported assessment; it should not become an unlimited tuning target |

“Held out” means withheld from fitting the particular component being assessed. A model can overfit the training examples by learning details that do not carry over to other examples. Validation provides a separate check. Repeatedly choosing settings because they look best on evaluation gradually turns evaluation into another tuning set, even if no optimizer directly reads its labels. Chapter 14 explains how to compare experiments without confusing selection with proof.

The reported V1 experiment specifications use training file numbers **1–10**, validation **4950–4954**, and evaluation **8000–8010**. Inclusive ranges matter: 8000 through 8010 contains **11**, not 10, files, because `8010 - 8000 + 1 = 11`. Base configurations can have different default ranges; the experiment specification's overrides determine the effective run. Chapter 12 explains configuration resolution.

These numbers are **account buckets, not dates**. A bucket is a storage grouping of accounts. File 9 is not “day 9”; file 100 does not mean “a later period than file 10.” Expanding from 10 files to 100 changes the selected account population and amount of data. The number alone does not establish a tenfold transaction count, a longer time horizon, or a proportionate training cost.

The source extract description separates a training period from an evaluation extract containing a later testing month and an earlier history month. The current owner-selected V1 reporting scope uses the supplied training, validation, and evaluation files in their assigned roles and the overall evaluation cohort. Do not silently redefine that cohort while explaining results. It is still useful to understand that account separation and time separation are different properties; neither follows merely from a filename.

## Sampling, splitting, and shuffling are different actions

**Sampling** selects which records or entities to include. Selecting account buckets can preserve much of each selected account's observed sequence. Randomly selecting individual rows can remove the prior transactions that a history model needs. However, even account-based selection does not prove that the extract contains every transaction the account ever made.

**Splitting** assigns included data to training, validation, and evaluation roles. Suppose synthetic Ember has 100 transactions and Cedar has 80. Putting Ember in training and Cedar in evaluation creates an account-separated test. Putting Ember's earlier 70 transactions in training and later 30 in evaluation instead tests a different question: prediction later in time for a previously observed account. Neither description can be substituted for the other.

**Shuffling** reorders examples inside a designated split. It can reduce the chance that successive updates see only one account's very similar transactions. In this project, history windows are formed using chronological rules before the training window buffer is shuffled. Shuffling finished windows does not grant Target access to Later. Shuffling raw rows and then calling the previous table row “history” would be a different, incorrect procedure.

## Four ways information can cross the wrong boundary

**1. Future-feature leakage.** Leakage means information unavailable for the intended prediction enters model construction or assessment in a way that makes performance misleading. If “remaining balance” is accidentally measured after the transaction instead of immediately before it, its meaning has changed. If an investigation outcome is inserted as a predictor, the answer itself has leaked. The feature list describes intended meanings, but code alone cannot certify the upstream system's timing.

**2. History leakage.** Including Later is plainly wrong. Including Peer can also be wrong when its same-second ordering is unknown. An identifier can order records consistently without ordering their real-world availability. A/B defaults therefore exclude equal timestamps from Target's history.

**3. Preprocessing leakage.** Preprocessing converts raw values to model inputs. Suppose the training amounts are 50 and 150, whose mean is `(50 + 150) / 2 = 100`. A held-out amount of 1,000 changes the combined mean to `1,200 / 3 = 400`. If you calculate the mean using all three values, training now uses a scale influenced by held-out information. No label was needed for this boundary violation. Chapter 06 shows why the fitted conversion rules are saved and reused.

**4. Repeated-transaction leakage.** If the same transaction appears in both training and evaluation, a strong evaluation score may partly measure familiarity. Account overlap and repeated-transaction overlap are different checks. A shared account can have genuinely different transactions; a repeated account-plus-transaction identity can be the same target appearing twice. The preflight code reports both properties.

An account-disjoint evaluation can still have preprocessing leakage. A correctly frozen preprocessor can still receive future features. A strict history builder can still operate on labels whose maturity is unknown. These checks answer different questions; passing one does not answer all the others.

## Where this is implemented

Use these as source coordinates in the private project snapshot; this course does not include raw bank files.

| Claim to inspect | Source and checked lines |
|---|---|
| Nonmissing labels, account membership, and parseable time are checked before encoding | `waqas/base/data/input_contracts.py`, `encode_binary_target`, `require_account_ids`, `parse_required_timestamps`, lines 13–60 |
| A only selects strictly earlier history by default | `waqas/phase4a/sequence_builder.py`, constructor and `_windows_for_file`, lines 164–192 and 280–321 |
| B's ordinary single-target windows use the corresponding rule | `waqas/phase4b/sequence_builder.py`, `_windows_for_file`, lines 367–414 |
| V1 reference cohort and seed are explicit overrides | `waqas/base/configs/ref_single.yaml`, lines 20–34 |
| Artifact fitting provenance is checked against held-out files | `runbook/2026-10-07/preflight_pod.py`, `check_artifacts`, lines 1013–1027 |
| Account overlap and transaction overlap are distinct reports | `runbook/2026-10-07/preflight_pod.py`, lines 1250–1268 |

The older `fraud/` implementation and the corrected older sequence reference are not interchangeable with the current A/B builders. Some older paths select the previous rows in sorted order. When someone says “the project is causal,” ask which loader, configuration, and model mode they mean. Chapter 07 makes this precise.

## Checkpoint: defend the boundary

**Predict.** If Peer gets a smaller identifier than Target, should it enter Target's strict history?

**Repair.** A colleague fits category dictionaries using training plus evaluation, then says this is harmless because they never used evaluation labels. Explain the repair.

**Teach back.** In four sentences, explain training, validation, evaluation, and why a bucket number cannot prove temporal separation.

<details markdown="1"><summary>Answers and a self-check rubric</summary>

Peer stays excluded: its timestamp is still equal, and an identifier is not evidence of availability. Fit category dictionaries and numerical statistics on the designated fitting data, save them, and apply those saved rules to held-out examples. A valid teach-back assigns a distinct role to each split and says that account buckets are storage groups rather than calendar periods. Give yourself one point for each of those four facts. Below four, revisit “Three datasets have three jobs” and “Sampling, splitting, and shuffling.”

</details>

**Recall without looking:** Draw the decision clock, put the current features on one side and eventual label on the other, then name one leakage path that strict history alone cannot prevent. If features and answers blur together, repair Chapter 01. If fitting preprocessing is unclear, continue to Chapter 06 and return here afterward.
