# 04 — How a model learns: loss, backpropagation and optimizers

## Pick up the same transaction

**Prerequisite refresher:** our fictional network takes `[2, 1]`, calculates hidden values `[0.5, 0.5]`, produces logits `[0, 1]`, and assigns a fraud score `p ≈ 0.73106`. Its parameters have not changed. A forward pass needs inputs; learning also needs a way to judge its output.

Your question is: **How does “that prediction was wrong” become a specific numerical change to the model?**

Suppose the example's known label is `y = 1`, meaning fraud. Training uses three distinct pieces:

1. A **loss function** assigns a numerical penalty to the prediction relative to the label.
2. **Backpropagation** calculates how that penalty would change if each learned parameter changed slightly.
3. An **optimizer** uses those calculated sensitivities to update the parameters.

Keep the three jobs separate. The loss defines the immediate training objective. Backpropagation calculates gradients. The optimizer decides the update. None by itself establishes that the model will work on new transactions.

## Loss: a penalty that responds to confidence

If we scored predictions only as “right” or “wrong,” a model could move from a fraud score of 0.10 to 0.40 on a fraudulent transaction and get no credit until it crossed a threshold. Training benefits from a penalty that changes smoothly as the score changes.

For an unweighted binary example, **cross-entropy loss** is:

- If the actual label is fraud, `loss = −ln(p)`.
- If the actual label is non-fraud, `loss = −ln(1 − p)`.

`ln` is the **natural logarithm**, the inverse of the exponential used in Chapter 03. If `exp(a) = b`, then `ln(b) = a`. For a probability between zero and one, its logarithm is negative; the minus sign makes the loss positive. You may use a calculator rather than memorize logarithm values.

The core behavior is more important than the notation:

| Probability assigned to the correct class | Loss, approximately |
|---:|---:|
| 0.90 | 0.105 |
| 0.73 | 0.315 |
| 0.50 | 0.693 |
| 0.10 | 2.303 |
| 0.01 | 4.605 |

Confident correct predictions have a small penalty. Confident wrong predictions have a large one. For our fraud example, `−ln(0.73106) ≈ 0.31326`. If the label had been non-fraud with the identical output, the loss would be `−ln(0.26894) ≈ 1.31326`.

For several unweighted examples, an average loss adds their losses and divides by their count. Two fraud examples with scores 0.9 and 0.1 have average loss `(0.10536 + 2.30259) ÷ 2 ≈ 1.20397`. The confident error dominates the average. This number is an optimization objective, not “120% error” and not a direct amount of money lost.

The project supports weighting the fraud class more heavily. A **class weight** changes the loss contribution attached to a label. It differs from a learned network weight and from a review threshold. PyTorch's weighted mean cross-entropy divides by the sum of selected target-class weights, so “multiply fraud loss by ten” alone is not a complete description of batch reduction. The configured V1 A base recipe uses `pos_weight: 1.0`; our arithmetic here is unweighted.

The project passes raw logits into `CrossEntropyLoss`. That function handles the log-probability calculation stably. Do not add an extra softmax before it because this chapter displayed probabilities to explain the arithmetic.

## Gradient: “which way, and how sensitive?”

A **derivative** describes how one quantity changes when another changes by a very small amount. Picture standing on a sloped surface: the slope tells you whether a small move raises or lowers your height. Here the “height” is loss, and a direction is a change in a parameter.

A **gradient** collects the derivative with respect to each parameter. Its sign tells you which direction increases loss locally; its size describes the local sensitivity. If a parameter's gradient is positive, a small increase tends to increase loss, so decreasing the parameter is the downhill direction. If the gradient is negative, increasing the parameter is the downhill direction.

This is a local statement, not a guarantee that an arbitrarily large move improves the model. A surface can curve. The direction that helps near your current position can overshoot if you move too far.

For a binary sigmoid score with unweighted cross-entropy, a useful derivative simplifies to:

`change in loss per small change in fraud logit = p − y`.

For our example, `p − y = 0.73106 − 1 = −0.26894`. The negative sign makes sense: because the example is fraud, increasing its fraud logit should reduce its loss. If its label were zero, the derivative would be `+0.73106`, pointing toward lowering that logit instead.

This formula is the derivative with respect to the single variable logit in our teaching network. The actual two-logit cross-entropy has a derivative for each output logit. For class `k`, it is the predicted class score minus one if `k` is the correct class, otherwise minus zero, before any weighting or reduction factors.

## Backpropagation: trace responsibility backward

**Backpropagation** applies the **chain rule** through the calculation. The chain rule says that when a change travels through a sequence of calculations, multiply the local sensitivities along that path. When one parameter affects the outcome through several paths, add those path contributions.

You already understand a simple chain rule without calculus. If each extra reviewed transaction adds three minutes of work, and expanding a review queue by one batch adds two transactions, that batch adds `2 × 3 = 6` minutes. The two local effects combine by multiplication. Neural networks use derivatives for infinitesimal rather than coarse changes, but the responsibility-tracing idea is similar.

Name our final weights `v1 = 1`, `v2 = 2`, and final bias `c = −0.5`. The fraud logit is:

`z = v1 × h1 + v2 × h2 + c`.

Changing `v1` by a tiny amount changes `z` by that amount times `h1`. Therefore:

`gradient of v1 = (p − y) × h1 = −0.26894 × 0.5 = −0.13447`.

The gradient of `v2` is also `−0.13447`. The gradient of `c` is `−0.26894`, because adding to the bias adds the same amount to `z`.

Now trace backward into the hidden units. A small change in `h1` is multiplied by `v1 = 1` on the way to `z`, so its loss sensitivity is `−0.26894 × 1 = −0.26894`. A small change in `h2` is multiplied by `v2 = 2`, so its loss sensitivity is `−0.53788`.

Both pre-activation totals are positive in this example. ReLU therefore has local derivative one: a small increase in its input gives the same increase in its output. A negative pre-activation would have derivative zero for this ReLU path; at exactly zero the implementation uses a convention. We chose positive values to avoid that boundary in this worked update.

Finally, hidden unit 1's first weight multiplies `x1 = 2`, so its gradient is `−0.26894 × 1 × 2 = −0.53788`. Its second weight multiplies `x2 = 1`, so its gradient is `−0.26894`. The same method gives every parameter's gradient:

| Parameter | Old value | Gradient on this example |
|---|---:|---:|
| Unit 1 weight on x1 | 0.50000 | −0.53788 |
| Unit 1 weight on x2 | −0.50000 | −0.26894 |
| Unit 1 bias | 0.00000 | −0.26894 |
| Unit 2 weight on x1 | −0.25000 | −1.07577 |
| Unit 2 weight on x2 | 1.00000 | −0.53788 |
| Unit 2 bias | 0.00000 | −0.53788 |
| Head weight on h1 | 1.00000 | −0.13447 |
| Head weight on h2 | 2.00000 | −0.13447 |
| Head bias | −0.50000 | −0.26894 |

All gradients refer to the same old parameter state. Backpropagation does not update a layer and then use its new weights to compute the previous layer's gradients. Mixing old and updated values would change the procedure.

## One complete update with simple gradient descent

An **optimizer** turns gradients into parameter changes. Start with the simplest rule, gradient descent:

`new parameter = old parameter − learning rate × gradient`.

The **learning rate** controls the size of the move. For teaching, choose `0.1`. This is an illustrative setting, not the project's recommended rate.

The first hidden weight becomes:

`0.5 − 0.1 × (−0.53788) = 0.553788`.

Subtracting a negative means adding. Applying the same rule simultaneously to all nine parameters gives:

| Parameter group | New first weight | New second weight | New bias |
|---|---:|---:|---:|
| Hidden unit 1 | 0.553788 | −0.473106 | 0.026894 |
| Hidden unit 2 | −0.142423 | 1.053788 | 0.053788 |
| Head | 1.013447 | 2.013447 | −0.473106 |

Run the same transaction forward again using unrounded update values. The hidden outputs become approximately `[0.661365, 0.822730]`. The fraud logit becomes `1.853675`, the fraud score becomes `0.864558`, and the loss becomes `0.145537`.

The loss for this one training example fell from about `0.313262` to `0.145537`. That is evidence that this toy step helped this example. It is not evidence of improved bank performance, improved recall, or improved predictions on unseen transactions. A change that helps one example can harm another. Training on batches combines their gradient contributions, and evaluation checks whether the learned behavior transfers.

## What AdamW adds in the actual project

The current default optimizer is **AdamW**, not the simple gradient-descent rule we just used. Understanding the simple rule makes AdamW's purpose easier to see.

AdamW keeps two moving summaries for each parameter:

- An average of recent gradients, which carries a sense of direction and smooths fluctuations.
- An average of recent squared gradients, which estimates the scale of that parameter's recent gradients.

A moving average combines an older summary with a little of the new value. If the old gradient average is `0.2` and the new gradient is `0.6`, a 90%/10% blend is `0.9 × 0.2 + 0.1 × 0.6 = 0.24`. It remembers earlier steps while responding to the latest one.

To **square** a number, multiply it by itself: `0.6² = 0.6 × 0.6 = 0.36`. Squaring `−0.6` also gives `0.36`. A **square root** reverses that operation for a nonnegative number: `sqrt(0.36) = 0.6`. Averaging squared gradients tracks their size even when positive and negative gradients would cancel in their ordinary average.

The update uses the first summary divided by the square root of the second, with a tiny stabilizing number in the denominator. A correction accounts for the fact that these moving summaries start at zero. **Momentum** refers broadly to carrying information from previous gradient directions. **Adaptive** means Adam adjusts its effective step scaling separately for parameters based on their gradient history.

For an optional concrete first-step calculation, take our first weight's gradient `g = −0.53788`. With conventional Adam defaults, the first moving average is `m = 0.1 × g`, and the first squared-gradient average is `v = 0.001 × g²`. Correcting their zero-start bias recovers `g` and `g²`. Ignoring the tiny stabilizer, the normalized direction is `g ÷ sqrt(g²) = −1`. With the illustrative learning rate `0.1`, the gradient part of the update therefore adds approximately `0.1`, rather than gradient descent's `0.053788`.

The **W** refers to **decoupled weight decay**. This separately shrinks parameters toward zero in proportion to the learning rate, decay setting and current value. With teaching values `weight = 0.5`, learning rate `0.1`, and decay `0.01`, that shrinkage is `0.1 × 0.01 × 0.5 = 0.0005`. Combining the illustrative first Adam step and decay gives approximately `0.5 − 0.0005 + 0.1 = 0.5995`. This is a single-parameter demonstration; it is not the full-network update calculated in the table above.

Weight decay can discourage unnecessarily large parameters. It does not guarantee generalization, remove data leakage or automatically pick the right model. AdamW is an update algorithm, not a separate fraud classifier.

The A base configuration uses learning rate `0.0003` and decay `0.00001`. The reference builder's defaults use learning rate `0.001` and decay `0.00001`. Actual experiment overrides must still be checked; a default is not proof of every executed setting.

## The learning loop and the controls around it

Conceptual teaching pseudocode:

```python
for batch in training_batches:
    optimizer.zero_grad()
    logits = model(batch_inputs)
    loss = cross_entropy(logits, batch_labels)
    loss.backward()
    optimizer.step()
```

`zero_grad()` clears earlier stored gradients. The forward pass produces logits. The loss compares them with labels. `backward()` calculates gradients by automatic differentiation, which records the calculation graph and applies the relevant derivative rules. `step()` updates parameters. Libraries such as PyTorch and the project's training framework automate these operations; automation does not change their meaning.

A **training step** commonly means one optimizer update, though logs can also count batches. **Gradient accumulation** deliberately combines gradients from several smaller batches before an update. That is why clearing gradients after every tiny batch is not always the intended implementation. An **epoch** is one intended pass through the training examples; streaming loaders and limits require checking actual coverage.

A **learning-rate scheduler** changes the learning rate during training. The current A scheduler reduces the rate when validation loss stops improving according to its rules. **Early stopping** ends training when the monitored development measure fails to improve sufficiently. A **checkpoint-selection rule** decides which saved state to keep. These are distinct controls and may monitor different quantities. Chapter 12 will trace the actual training configuration and its validation metrics.

**Overfitting** means adapting too closely to training-specific patterns so performance on other relevant examples suffers. Falling training loss is compatible with overfitting. A model that memorizes known examples has not necessarily learned a useful general rule.

## Actual implementation anchors

- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 63–68: two-output head and optional weighted cross-entropy. `_step` and `training_step`, lines 181–191: calculate logits, labels and loss. `configure_optimizers`, lines 197–201: builds the optimizer and a `ReduceLROnPlateau` scheduler monitored on `valid_loss`.
- `waqas/phase4a/optim.py`, `build_optimizer`, lines 19–34: selects the named optimizer; lines 9–15 map `adamw` to PyTorch AdamW. Available names are implementation options, not evidence that alternatives have improved this project's results.
- `waqas/phase4a/configs/sequential.yaml`, `training`, lines 60–78: records A's base training settings, including AdamW, learning rate, decay, class weight and early-stopping monitor. A scheduler's `valid_loss` monitor is distinct from the configured checkpoint/early-stopping `valid_ap` monitor.
- `waqas/base/streaming_model.py`, `build_streaming_model`, lines 54–70 and 88–115: specifies reference optimizer defaults, scheduler configuration and optional class-weighted loss.

## Common wrong mental model

**Wrong:** “Backpropagation is the optimizer, lower loss proves higher fraud recall, and scoring keeps improving the model.”

**Repair:** Backpropagation computes gradients. The optimizer uses them to change parameters during training. Loss and recall answer different questions. Ordinary scoring calculates outputs from fixed parameters. Each distinction matters when you explain what a run actually did.

## Your learning-step challenge

**Predict:** A parameter is `0.4`, its gradient is `+0.6`, and the learning rate is `0.05`. What does one simple gradient-descent step produce? Explain the direction before calculating.

**Repair:** A colleague reduces the review threshold and says, “I retrained the network.” Explain what changed, and name what a real learning step requires.

**Teach back:** Explain the original toy example's journey from fraud label to lower training loss. Include the loss, the sign of `p − y`, the chain rule and the optimizer. Then give one reason that this is not yet evidence of better performance on future data.

<details><summary>Open after attempting: answers and rubric</summary>

A positive gradient points toward increasing loss if the parameter increases. Gradient descent therefore lowers it: `0.4 − 0.05 × 0.6 = 0.37`. Changing the review threshold changes which scores trigger action, not learned parameters. A learning step requires a training objective, gradient calculation and a parameter update, with the relevant inputs and supervision.

For the toy fraud example, cross-entropy loss is `−ln(p)`. The derivative `p − y` is negative, so increasing the fraud logit locally helps. The chain rule traces that sensitivity through the head and hidden units to each weight and bias. The optimizer then updates parameters. A second forward pass shows lower loss for that example. This may fail to transfer because other transactions differ, because the example is not representative, or because the model overfits training data.

If you said the gradient itself changes the weights, separate the gradient table from the update table. If you used the new head weight when deriving an old hidden gradient, repeat the rule that all gradients come from the same forward calculation state.

</details>

**Recall without looking:** give a sixty-second explanation of forward pass, loss, backpropagation and optimizer as four separate jobs. Then recreate one gradient from the network drawing. **Repair route:** Chapter 03 for the forward values; Chapter 02 for multiplication or signs; this chapter for gradients; Chapter 12 for training controls; Chapters 14–15 for what evidence is needed beyond training loss.
