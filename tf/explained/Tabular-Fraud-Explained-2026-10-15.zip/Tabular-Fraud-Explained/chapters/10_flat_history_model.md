# 10 · Architecture A: one attention table over transaction history

**Prerequisite refresher.** Chapter 07 built a window containing earlier transactions and a target transaction. Padding fills absent history slots, while a mask identifies which slots contain real rows. Chapter 08 made a vector token for each feature. Chapter 09 explained attention as a learned weighted combination and CLS as a collector used for prediction.

**Your concrete question:** how does Architecture A allow the target transaction to be interpreted using previous transactions from the same account?

A puts every feature token from the window into one long sequence. Attention can then combine feature-level information across transactions. The output is one prediction for the target, not one label for every historical row.

## Start with the data contract, not the architecture name

Let `H` mean the requested maximum number of earlier rows, and `T=H+1` mean the number of transaction slots including the target. In the ordinary strict sliding-window path, a target gets up to `H` rows with strictly earlier parsed timestamps from the same account within the file being processed. The target itself occupies the final slot. If fewer than `H` eligible rows exist, the missing slots are padded on the left.

For a synthetic account, suppose the eligible earlier rows are at seconds 10 and 20, and the target is at second 40. With `H=2`, the window is:

```text
slot             0       1       2
time            10      20      40
role         history history  target
real mask       True    True    True
```

The **label** for the row at 40 is stored separately for training or evaluation. It is not fed as a feature token. Target means “the transaction whose fraud status we are trying to predict,” not “the answer placed in the input.”

If only the row at 20 is available, the window becomes `[padding, row20, row40]` with real mask `[False, True, True]`. A padded zero vector and a genuine transaction containing zero-valued inputs are different cases because the mask identifies which is real.

## Walk the entire forward pass with shapes

Use a tiny teaching model with `B=2` windows in a batch, `T=3` slots, `C=2` numerical fields, `K=1` categorical field, and embedding width `d=4`. Here `B` counts windows, not transaction rows. Let `F=C+K=3` tokens per transaction.

| Step | Shape | What it means |
|---|---|---|
| Numerical inputs | `[2,3,2]` | Two windows, three slots, two numerical fields |
| Categorical inputs | `[2,3,1]` | Corresponding category codes |
| Temporarily combine batch and time | `[6,2]`, `[6,1]` | Six transactions to tokenize with shared parameters |
| Feature tokenizer | `[6,3,4]` | Three width-four tokens for each transaction |
| Restore the window axes | `[2,3,3,4]` | Window, transaction slot, feature, coordinate |
| Add transaction position | `[2,3,3,4]` | Every feature in one slot receives that slot's position vector |
| Flatten time and feature axes | `[2,9,4]` | Nine tokens per window |
| Prepend one CLS | `[2,10,4]` | One collector plus nine feature tokens |
| Transformer encoder | `[2,10,4]` | Updated token representations |
| Select CLS | `[2,4]` | One representation per window |
| Classification head | `[2,2]` | Two class logits for each target |

“Flatten” here means joining the time and feature positions into one ordered list. It does not average them. The sequence conceptually looks like:

```text
CLS, row10.feature1, row10.feature2, row10.feature3,
     row20.feature1, row20.feature2, row20.feature3,
     row40.feature1, row40.feature2, row40.feature3
```

Despite historical “SEP/CLS” wording in comments, the checked A forward pass does **not** insert a special separator token between transactions. Group boundaries are represented by the known layout, learned transaction-position vectors and any applicable attention mask.

## Position and elapsed time answer different questions

A **position embedding** is a learned vector looked up by slot number. Every feature token in slot 1 gets the same slot-1 position vector added to it. A model can then distinguish a feature from the older slot from the corresponding feature in the target slot.

Slot position does not tell you whether the rows were one second or one week apart. When the time-gap input is enabled, the builder appends another numerical feature to each row. For single-target A, it is:

```text
log(1 + seconds from that row to the target)
```

`log` here is the natural logarithm, the inverse of raising `e` to a power. It compresses large gaps: each equal-sized increase in the logarithm corresponds to a multiplicative increase in `1+gap`. The added 1 makes a zero-second gap legal and maps it to zero.

For times `[10,20,40]`, gaps to the target are `[30,20,0]`. Their transformed values are approximately `[3.434,3.045,0]`. These are a separate channel, then tokenized like the other numerical inputs. Position tells the model which slot; the gap supplies elapsed-time information relative to this prediction target.

A row at time 20 can therefore have different time-gap inputs when used in a window targeting 40 versus a window targeting 100. This is intentional for a model making a decision at the final target time. It is **not** a safe reusable input representation for pretending to score that historical row at time 20. A causal attention mask does not undo a future-relative feature already present in an input. Chapter 11 changes the time-gap contract for all-position prediction.

## Two masks address two different concerns

A **padding mask** tells attention not to read nonexistent transaction slots. It is expanded from `[B,T]` transaction validity to every feature token belonging to those transactions. CLS is always valid. This protects real outputs from treating the filler as real account activity.

An **attention mask** controls information flow among real tokens. A supports two modes:

**Bidirectional:** tokens may exchange information across the entire supplied valid window. If every supplied historical row was available before the final target, and only the final target is scored, this is not automatically future leakage. The target-time decision is allowed to use its own available fields and the supplied earlier history. Historical token representations may contain information from the target; they are internal parts of a target-time calculation.

**Causal:** feature tokens for transaction slot `i` can read feature tokens in the same slot and earlier slots, not later slots. This is transaction-level block causality: all feature tokens within one transaction can interact. It does not mean feature 2 is forbidden to read feature 3 of the same transaction.

The builder's strict timestamp selection and the encoder's causal attention are separate safeguards. The first decides which rows enter a target's history. The second controls how tokens already inside the window exchange information. Flipping the encoder setting does not reconstruct the dataset.

## Why the collector must be one-way in causal mode

Here is the causal rule with one vector standing in for each transaction group. Rows are readers (queries); columns are sources (keys). “Yes” means the reader may receive information from the source.

| Reader ↓ / Source → | Earlier 0 | Earlier 1 | Target | CLS |
|---|---|---|---|---|
| Earlier 0 | Yes | No | No | No |
| Earlier 1 | Yes | Yes | No | No |
| Target | Yes | Yes | Yes | No |
| CLS | Yes | Yes | Yes | Yes |

Although CLS is physically placed first in the array, the mask assigns it a logical time **after** every transaction. Array placement and causal position are different ideas.

Why prevent earlier tokens from reading CLS? Imagine two layers. In layer 1, CLS collects information from the target. If an earlier token reads CLS in layer 2, target information travels back to the earlier representation through the collector. A direct earlier-to-target block would not stop this indirect route. The checked implementation blocks real tokens from reading CLS in causal mode, while CLS remains able to summarize the entire window.

This fixes a historical causal-mask issue recorded in source comments. We teach the current implementation, not the old faulty graph. Do not infer that every historical experiment used the current checkpoint semantics; Chapter 12 covers why run provenance matters.

Padding creates a second subtlety. A left-padded query could otherwise have no allowed keys once both causal and padding restrictions are combined. An all-forbidden softmax can produce invalid numbers, which can contaminate gradients even if the padded output is not the chosen prediction. The current causal mask leaves a query's own diagonal entry available. This lets a padded query attend to its own unused token; other real queries still cannot read that padded key. Allowing this computational self-route does not convert padding into a real transaction.

## What A learns, and what its cost depends on

A learns feature embeddings, transaction-position embeddings, the CLS starting vector, attention transformations, feed-forward transformations and the classification head. The target loss sends training gradients through these components. `embed()` returns the pre-head CLS representation for the whole account-at-target window; it is not a fraud probability. That vector can be useful to inspect or export, but it still belongs to the window's target-time context.

A's attention sequence length is `L=1+T×F`. An ordinary full attention table has roughly `L×L` pairwise entries per head per layer per window. In the toy example, `L=10`, so there are 100 entries. If `T` rises from 3 to 6 while `F=3`, `L` becomes 19 and the table has 361 entries. Doubling history-related length can increase pairwise work by almost four times.

For the current schema described in Chapter 06, the 23 selected predictor fields expand to 29 feature tokens because six numerical missing-value flags are appended as categorical inputs. Enabling the sequence time-gap adds one numerical token, giving `F=30`. A time-gap-enabled `H=15` window therefore has `1+16×30=481` tokens, including CLS. Always derive this from the encoded input contract: the original predictor count is not the final token count.

That calculation describes the attention term, not a measured runtime prediction. Projection layers, embedding width, batch size, number of heads, number of blocks, feed-forward networks, precision, implementation and padding also affect time and memory. Causal masking does not guarantee that a dense implementation avoids computing the forbidden entries. The local code creates a per-batch, per-head causal mask, which itself uses memory.

`H=0` leaves one target transaction slot. That is a no-history A control; it still has A's tokenizer, PyTorch encoder and CLS/head. It is not automatically the reference FT model from Chapter 09. More history, more parameters or more attention links may help, hurt or do nothing on held-out data. The architecture does not settle the result.

## Source trail

| Source location | What the checked code does |
|---|---|
| `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 21–68 | Sets `T`, tokenizer, position embeddings, CLS, PyTorch encoder and two-class head |
| Same file, `forward`, lines 146–173 | Reshapes, tokenizes, adds position, flattens, prepends CLS, applies masks and produces target logits |
| Same file, `_build_causal_mask`, lines 105–144 | CLS logical-time rule and padded-query diagonal safeguard |
| Same file, `embed`, lines 175–179 | Returns the target-window CLS vector |
| `waqas/phase4a/sequence_builder.py`, `_windows_for_file`, lines 280–321 | Strict earlier history selection, left padding and target-relative logarithmic gap |
| `waqas/phase4a/sequential.py`, `sequence_contract` and checkpoint hooks, lines 70–103 | Records architecture and input semantics; legacy checkpoints cannot verify all artifact identity |

## Prediction, repair and teach-back

**Predict.** A window has `H=4` and six features per transaction. How many tokens enter A's encoder including CLS? If two historical transaction slots are padding, how many feature-token keys must be hidden from real readers?

<details><summary>Reveal the arithmetic</summary>

`T=H+1=5`. The sequence has `1+5×6=31` tokens. Two padded slots contribute `2×6=12` padded feature-token keys. The sequence still has those positions in memory; masking controls their use. CLS stays valid.

</details>

**Repair.** Someone adds a causal mask but leaves historical tokens able to read CLS. They test one layer and see no direct future edge. Why is their argument incomplete?

<details><summary>Reveal the repair</summary>

Across two layers, target information can enter CLS and then flow back into an earlier token. A mask must restrict indirect paths across layers, not only direct edges at layer 1. The current implementation places CLS logically after all transactions and forbids transaction queries from reading it.

</details>

**Teach back.** Draw one target window. Explain the real mask, position vector, time-gap feature, encoder mask and output label separately. Then explain why bidirectional attention can be valid for the final target without making earlier internal representations valid decision-time scores.

<details><summary>Check your explanation</summary>

You should distinguish five jobs: real mask excludes padding; position identifies slot order; time-gap supplies elapsed time; attention mask restricts exchange among tokens; label supplies the training answer outside the input. Bidirectional exchange uses the final target's available context to produce its one score. Historical representations may contain later-within-window information and target-relative gaps, so they should not be repurposed as earlier decisions. Repair any missing distinction in Chapters 05, 07 or 09.

</details>

**Recall prompt:** explain A in 90 seconds from a raw target window to two logits, including the formula `1+(H+1)F` and the one-way CLS rule. If your drawing loses an axis, return to Chapter 08; if time availability is unclear, return to Chapter 07. Next, Chapter 11 changes where the first summary happens.
