# 00 · Your mission: explain one transaction from beginning to end

You do not need to know a neural network, an optimizer, or a line of Python before starting. Those are things this course teaches. Your goal is to be able to draw the project from memory, follow a transaction through it, explain why each step exists, and challenge a misleading result.

This is **Tabular Fraud Explained**, built from the project source at commit `aa14bc9357401fe51e21c20580002b19fa53e5d9`, reviewed on 15 October 2026. A commit is a saved version of the repository, the project's collection of files. Fixing the version tells you which implementation this explanation describes. The public repository hosting this course is called ICLProjectFr; that does not make this fraud model an in-context-learning language-model experiment. The implemented fraud models here learn numerical parameters from transaction data.

The course takes you from the business question to the point where you can understand how results are produced, tested, and interpreted. It does not launch training or announce a new winning model. All little transactions, arithmetic examples, and interactive demonstrations in the lessons are **invented teaching examples**, not bank records or measured project results.

## A different way to work through it

Treat the course as learning to take over a small fraud research lab. At each stop, do four things:

1. **See it:** read a worked example and follow each intermediate number or transformation.
2. **Predict it:** stop before the answer, make a small prediction, then check what happened.
3. **Repair it:** explain what went wrong in a deliberately flawed example.
4. **Teach it:** close the explanation and answer aloud, in your own words.

The interactive reader gives feedback on practice questions and sends you back to the relevant chapter when an answer exposes a gap. You can always open any chapter. Reading a page, answering a quiz, and remembering it tomorrow are different achievements; the progress display keeps them separate. A correct multiple-choice answer is evidence of one answer, not certification that you can run a bank system.

Use the notes box to write a short explanation before revealing the worked answer. A useful note sounds like: “The missing-value flag tells the model that the filled-in amount was originally absent.” A less useful note is just “missingness indicator.” You are practising the explanation, not collecting terminology.

After a session, try three recall cards. Rate an answer “remembered” only if you could explain the reasoning before revealing it. Revisit material after roughly a day, a few days, and a week. Those intervals are a practical suggestion, not a scientific guarantee for every learner. The review queue helps you return to things you found difficult. Progress stays in your browser; export the JSON backup if you change browsers or machines. Nothing needs a GPU or sends your answers to a server.

## The whole project, before the details

Imagine a new transaction arrives. The research question is whether its details, and optionally earlier transactions from its account, help rank how likely it is to be fraud. A high score might later help an operational system decide which transactions to investigate. This repository's training and evaluation do not themselves prove that such an operational system has been deployed.

```text
Past examples with known outcomes
          |
          v
Define usable inputs and separate learning from assessment
          |
          v
Apply saved rules for missing values and categories
          |
          +-------------------+--------------------+
          |                   |                    |
   REF: one transaction   A: all feature      B: each transaction
                          tokens together     summarized, then history
          |                   |                    |
          +-------------------+--------------------+
                              |
                       Two class scores
                              |
                Convert to a fraud-class score
                              |
                  +-----------+-----------+
                  |                       |
          During training:         During evaluation:
          compare with label,      save predictions from
          calculate error,         a chosen checkpoint,
          adjust parameters        compare with outcomes
```

For now, “parameter” means an adjustable number inside the model. “Label” means the known training answer, such as fraud or not fraud. “Checkpoint” means a saved model state. Later chapters unpack every arrow.

The most valuable distinction in this picture is the bottom fork. During training, known answers help adjust the model. When predicting a transaction, its answer is not an input. You may subsequently compare the prediction with the outcome to measure performance. Feeding the answer into the predictor would defeat the purpose.

## Your chapter route

| Mission | Chapters | What you should be able to do afterward |
|---|---|---|
| Understand the question and the mathematics | 01–04 | Describe a row, calculate a tiny model's prediction, and explain learning as parameter updates |
| Know exactly what the model may see | 05–07 | Build a legal history, explain frozen preprocessing, and catch a data leak |
| Visualize the three main model routes | 08–11 | Draw tokens, attention, flat A, hierarchical B, and the all-position exception |
| Run a fair investigation in your head | 12–15 | Explain a training run, a comparison, an uncertainty range, and a useful fraud metric |
| Test and take ownership | 16–18 | Run small CPU exercises, locate the relevant implementation, and defend the project under questions |
| Look up a forgotten term | 19 | Recover a definition and return to the chapter that teaches it |

Each chapter is a stopping place, not a demand to finish the entire course in one sitting. A useful session can be one worked example and one teach-back. If a section feels hard, return to the particular dependency it names. Do not restart the whole course just because one word is unfamiliar.

## Three kinds of statement to keep separate

**Implemented** means the checked source contains a mechanism. **Measured** means a recorded execution produced an observation, subject to the quality of that record. **Proposed** means something is being considered or developed and does not establish a performance gain.

The repository contains old plans, historical findings, corrected copies, current runs, and parked experiments. They cannot all describe “the current model” simultaneously. The main training paths are the corrected single-transaction reference, flat A, and hierarchical B. Phase 5 pretraining is present as parked work. Later feature and optimizer work must not be described as an established V1 improvement. Chapter 17 is your map through those layers.

The existing evaluation cohort has been consulted during development. A label saying “evaluation” is not a magic guarantee of an untouched final test. Chapter 05 explains the boundary, and Chapters 14–15 explain the consequences for claims.

## First checkpoint: make a prediction before studying

You are given an amount, a merchant category, an account's recent transactions, and a column saying whether the current transaction was eventually confirmed as fraud. Which information should the predictor receive when deciding about the current transaction?

<details markdown="1">
<summary>Reveal the reasoning</summary>

It may receive authorized details available at that decision time and eligible earlier history. It must not receive the current transaction's future fraud outcome. That outcome is useful as a training target and later for evaluation. Even apparently ordinary inputs require an availability check: a field filled in after the decision can leak later information.

You do not yet need to explain how attention works. If you can separate inputs from the answer, you have the first piece of the project.
</details>

**Your first teach-back:** “We want to predict ___ using ___ that was available ___. We learn from ___ and test on ___.” Fill the blanks in plain language. Revisit this sentence after Chapter 05; your answer should become more precise.

**Next useful stop:** Chapter 01. If you already understand a section, use its challenge instead of simply marking it read.
