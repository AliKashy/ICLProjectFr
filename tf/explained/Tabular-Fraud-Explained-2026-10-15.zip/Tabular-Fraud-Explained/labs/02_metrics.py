"""Reproduce Chapter 15 arithmetic using six entirely synthetic transactions."""
from toy_metrics import average_precision, auroc, confusion


def main():
    labels = [1, 0, 1, 0, 1, 0]
    scores = [0.9, 0.8, 0.7, 0.4, 0.3, 0.1]
    ap = average_precision(labels, scores)
    auc = auroc(labels, scores)
    assert abs(ap - 34 / 45) < 1e-12
    assert abs(auc - 2 / 3) < 1e-12
    # Tied scores do not allow a fabricated ordering of positives before negatives.
    assert average_precision([1, 0], [0.5, 0.5]) == 0.5
    assert auroc([1, 0], [0.5, 0.5]) == 0.5
    print("Synthetic six-row ranking; no project model is loaded.")
    print(f"AP={ap:.6f}; AUROC={auc:.6f}")
    for threshold in (0.85, 0.60, 0.25):
        count = confusion(labels, scores, threshold)
        precision = count["TP"] / (count["TP"] + count["FP"])
        recall = count["TP"] / sum(labels)
        print(f"threshold={threshold:.2f}: {count}; precision={precision:.6f}; recall={recall:.6f}")
    print("PASS: hand calculations and tied-score checks agree.")


if __name__ == "__main__":
    main()
