"""Small independently written teaching metrics; not production project code."""


def average_precision(labels, scores):
    if len(labels) != len(scores) or not labels:
        raise ValueError("Need aligned nonempty labels and scores")
    positives = sum(labels)
    if positives == 0:
        raise ValueError("This teaching AP requires at least one positive")
    groups = {}
    for label, score in zip(labels, scores):
        if label not in (0, 1):
            raise ValueError("Labels must be binary")
        count, hits = groups.get(score, (0, 0))
        groups[score] = (count + 1, hits + label)
    seen = found = 0
    total = 0.0
    for score in sorted(groups, reverse=True):
        count, hits = groups[score]
        seen += count
        found += hits
        total += (hits / positives) * (found / seen)
    return total


def auroc(labels, scores):
    positives = [s for y, s in zip(labels, scores) if y == 1]
    negatives = [s for y, s in zip(labels, scores) if y == 0]
    if not positives or not negatives:
        raise ValueError("AUROC needs both classes")
    wins = sum(1 if p > n else 0.5 if p == n else 0
               for p in positives for n in negatives)
    return wins / (len(positives) * len(negatives))


def confusion(labels, scores, threshold):
    counts = dict(TP=0, FP=0, FN=0, TN=0)
    for label, score in zip(labels, scores):
        key = ("TP" if label else "FP") if score >= threshold else ("FN" if label else "TN")
        counts[key] += 1
    return counts
