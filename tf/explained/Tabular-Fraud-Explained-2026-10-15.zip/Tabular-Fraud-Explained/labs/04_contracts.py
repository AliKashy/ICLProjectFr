"""Small contract and causality demonstrations, not the repository's loader."""
from collections import Counter


def history(rows, target, length):
    eligible = [row for row in rows
                if row["account"] == target["account"] and row["time"] < target["time"]]
    return sorted(eligible, key=lambda row: (row["time"], row["id"]))[-length:] if length else []


def assert_same_cohort(expected, actual):
    if Counter(expected) != Counter(actual) or len(actual) != len(set(actual)):
        raise ValueError("Missing, extra or duplicate target keys")


def main():
    rows = [dict(id="old", account="A", time=10, amount=3),
            dict(id="peer", account="A", time=20, amount=999),
            dict(id="future", account="A", time=30, amount=8),
            dict(id="other", account="B", time=5, amount=9)]
    target = dict(id="target", account="A", time=20, amount=5)
    selected = history(rows, target, 5)
    assert [row["id"] for row in selected] == ["old"]
    # A toy score depending only on selected amounts cannot change when hidden rows change.
    before = sum(row["amount"] for row in selected)
    for row in rows:
        if row["id"] in ("peer", "future"):
            row["amount"] = -100000
    after = sum(row["amount"] for row in history(rows, target, 5))
    assert before == after == 3
    print("Synthetic strict-earlier history IDs: ['old']")
    print("PASS: same-time, future and other-account rows stay outside this target history.")
    print("PASS: changing hidden values leaves the toy history sum at 3.")
    assert_same_cohort(["a", "b", "c"], ["c", "a", "b"])
    for broken in (["a", "b"], ["a", "b", "b"], ["a", "b", "c", "d"]):
        try:
            assert_same_cohort(["a", "b", "c"], broken)
        except ValueError:
            continue
        raise AssertionError("A deliberately broken cohort was accepted")
    print("PASS: reordered equal cohorts pass; missing, duplicate and extra targets fail.")
    print("These demonstrations do not validate the actual Transformer or bank data.")


if __name__ == "__main__":
    main()
