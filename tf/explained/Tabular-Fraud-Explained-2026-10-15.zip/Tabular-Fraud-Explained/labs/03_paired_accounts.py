"""Conceptual paired account bootstrap; synthetic scores, fixed toy models.

It teaches the resampling mechanism. It is not a bank inference procedure,
does not retrain anything, and its interval is not evidence about V1.
"""
import random
from toy_metrics import average_precision


ACCOUNTS = {
    "A": [(1, .90, .70), (0, .60, .55)],
    "B": [(0, .80, .60), (1, .70, .65)],
    "C": [(0, .20, .30), (0, .10, .10)],
    "D": [(1, .40, .50), (0, .30, .40)],
    "E": [(0, .50, .45), (0, .15, .20)],
    "F": [(1, .35, .25), (0, .05, .05)],
}


def difference(draw, accounts=ACCOUNTS):
    rows = [row for name in draw for row in accounts[name]]
    labels = [row[0] for row in rows]
    if len(set(labels)) != 2:
        return None
    x = average_precision(labels, [row[1] for row in rows])
    y = average_precision(labels, [row[2] for row in rows])
    return x - y


def percentile(values, fraction):
    ordered = sorted(values)
    position = (len(ordered) - 1) * fraction
    lower = int(position)
    upper = min(lower + 1, len(ordered) - 1)
    return ordered[lower] + (position - lower) * (ordered[upper] - ordered[lower])


def main():
    names = list(ACCOUNTS)
    rng = random.Random(42)
    draw_count = 1000
    values, undefined = [], 0
    for _ in range(draw_count):
        draw = [rng.choice(names) for _ in names]
        delta = difference(draw)
        if delta is None:
            undefined += 1
        else:
            values.append(delta)
    print(f"Synthetic fixed-score paired account bootstrap; {draw_count:,} draws, seed 42.")
    print(f"Full-cohort AP difference X-Y={difference(names):+.6f}")
    print(f"Valid draws={len(values)}; one-class undefined draws={undefined}")
    print(f"Toy percentile interval=[{percentile(values, .025):+.6f}, {percentile(values, .975):+.6f}]")
    print("Draw [B, B, C] repeats all B rows twice and all C rows once in BOTH models.")
    # Exercise the actual comparison pipeline on identical and swapped models.
    identical = {name: [(label, x, x) for label, x, y in rows]
                 for name, rows in ACCOUNTS.items()}
    swapped = {name: [(label, y, x) for label, x, y in rows]
               for name, rows in ACCOUNTS.items()}
    for draw in (names, ["B", "B", "C"]):
        assert difference(draw, identical) == 0.0
        assert abs(difference(draw, swapped) + difference(draw)) < 1e-12
    assert len(values) + undefined == draw_count
    print("PASS: draw accounting, identical models and sign reversal pass; no model was retrained.")


if __name__ == "__main__":
    main()
