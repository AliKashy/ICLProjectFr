"""Synthetic teaching model: one logistic weight, not the project Transformer.

Run with Python 3: python labs/01_learning_step.py
Only standard-library modules are used. No data, credentials or GPU required.
"""
import math


def sigmoid(value):
    return 1.0 / (1.0 + math.exp(-value))


def loss(weight, feature, label):
    score = sigmoid(weight * feature)
    return -(label * math.log(score) + (1 - label) * math.log(1 - score))


def main():
    feature, label, weight, rate = 2.0, 1, 0.0, 0.1
    score_before = sigmoid(weight * feature)
    gradient = (score_before - label) * feature
    # A numerical derivative independently approximates the analytic gradient.
    epsilon = 1e-5
    numerical = (loss(weight + epsilon, feature, label)
                 - loss(weight - epsilon, feature, label)) / (2 * epsilon)
    assert abs(numerical - gradient) < 1e-8
    new_weight = weight - rate * gradient
    assert loss(new_weight, feature, label) < loss(weight, feature, label)
    print("Synthetic one-weight logistic model; ordinary gradient descent.")
    print(f"Before: weight={weight:.3f}, score={score_before:.6f}, loss={loss(weight, feature, label):.6f}")
    print(f"Gradient={gradient:.6f}; numerical check={numerical:.6f}")
    print(f"After: weight={new_weight:.3f}, score={sigmoid(new_weight * feature):.6f}, loss={loss(new_weight, feature, label):.6f}")
    print("PASS: gradient agrees with finite difference and this update lowers loss.")


if __name__ == "__main__":
    main()
