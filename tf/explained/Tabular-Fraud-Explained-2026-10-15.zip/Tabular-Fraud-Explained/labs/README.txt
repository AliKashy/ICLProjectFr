TABULAR FRAUD EXPLAINED — SYNTHETIC CPU LEARNING LABS

These independently written teaching programs are not the project's runtime.
They use Python 3 standard-library modules only, with no bank data, credentials,
GPU, package installation or network access. Run from the extracted course root:

python labs/01_learning_step.py
python labs/02_metrics.py
python labs/03_paired_accounts.py
python labs/04_contracts.py

Use python3 if that is your installed command. Compare EXPECTED_OUTPUT.txt.
Chapter 16 explains predictions, deliberate changes and repair answers.
toy_metrics.py is a shared helper, not a separate lab.

All data and numbers are synthetic. Passing these demonstrations does not
validate the repository's actual Transformer, data readers, bank data or results.
