# Tabular Fraud, Explained

An offline course that teaches the project from the ground up: data, neural networks, backpropagation, optimizers, preprocessing, transformers, history models, training, testing, and interpreting results.

## Start here

1. Extract the **entire ZIP** into a folder.
2. Open **index.html** in a modern browser.
3. Start with chapter 00. Read one worked example, predict the next step, and explain it aloud before revealing the answer.
4. Use **Practice** for feedback and repair routes, **Recall** for spaced self-testing, and **Visual labs** to change values and watch the calculations.
5. Write your own explanation in **Your teach-back**. Use **Export progress** to back up notes and learning progress.

The reader works offline. Browser progress is stored locally, not sent to a server. If the browser blocks storage, export before closing the tab. For reliable use, keep the extracted folder together. Mobile file viewers may not run local JavaScript; use the included PDF or book.html when that happens.

## What is included

- **20 chapters** covering the complete core project path and its prerequisites.
- **83 practice questions** with answer explanations and routes back to the relevant lesson.
- **113 recall cards**, including 24 oral-defence prompts and six whole-project prompts.
- Three visual activities: follow a transaction, take a gradient step, and move an alert threshold.
- **Four Python labs** using only Python 3's standard library and invented data.
- A project atlas, glossary, capstone challenges, and source evidence linked to a fixed project snapshot.
- **Tabular-Fraud-Explained.pdf**, a complete portable reading copy.
- **book.html**, a complete readable/printable book with practice answers, and **book.md**, the Markdown chapter edition.
- Individual chapter Markdown, question banks, recall cards, and **evidence.json**.
- **manifest.json**, containing SHA-256 fingerprints of the packaged files.

The visual learning demo uses a tiny logistic neuron to expose the arithmetic. It does not run the project's transformer or AdamW optimizer. The Python labs likewise teach and test small mechanisms with synthetic examples.

## Source and scope

Prepared on 15 October 2026 from Tabular Fraud source commit **aa14bc9357401fe51e21c20580002b19fa53e5d9**. Relative filenames in the lessons are source locators in that private project; the application source is not bundled here.

The course follows the corrected reference, flat A, hierarchical B, and the separate all-position mode through training and evaluation. It distinguishes active code, dated material, parked pretraining, candidate work, and reported execution. It ends at understanding and assessing results; this course build does not produce new bank-model results.

The package contains no bank transaction records, credentials, model checkpoints, private storage locations, or personal learning progress. New teaching text and synthetic programs were created for this course. Independent internal agents cross-reviewed the content and source references; see **REVIEW_AND_VALIDATION.md** for the checks and their limits.

## Run the optional CPU labs

In a terminal opened in the extracted folder:

```text
python labs/01_learning_step.py
python labs/02_metrics.py
python labs/03_paired_accounts.py
python labs/04_contracts.py
```

Use `python3` instead if that is your computer's Python command. Chapter 16 explains every experiment, predicted output, and deliberate change. No package installation or GPU is needed. Compare with **labs/EXPECTED_OUTPUT.txt**.
