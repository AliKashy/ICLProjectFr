/* Offline reader: no network requests, dependencies, or data submission. */
"use strict";
(() => {
  const course = JSON.parse(document.getElementById("course-data").textContent);
  const $ = id => document.getElementById(id);
  const el = (tag, className, text) => {
    const node = document.createElement(tag);
    if (className) node.className = className;
    if (text !== undefined) node.textContent = text;
    return node;
  };
  const storageKey = course.id + ":progress";
  const emptyState = () => ({version: 1, courseId: course.id, read: {}, answers: {}, recall: {}, notes: {}});
  let state = emptyState();
  let storageWorks = true;
  let active = course.chapters[0].id;
  let view = "read";
  let currentCard = null;
  let recallRevealed = false;
  const sessionSkipped = new Set();
  const validViews = new Set(["read", "practice", "recall", "labs"]);
  const byId = new Map(course.chapters.map(chapter => [chapter.id, chapter]));

  function notice(message) {
    $("notice").textContent = message;
    $("notice").hidden = false;
  }

  function validateProgress(value) {
    if (!value || value.version !== 1 || value.courseId !== course.id) throw new Error("This file is not a progress backup for this course.");
    const clean = emptyState();
    for (const chapter of course.chapters) {
      if (typeof value.read?.[chapter.id] === "boolean") clean.read[chapter.id] = value.read[chapter.id];
      if (typeof value.notes?.[chapter.id] === "string") clean.notes[chapter.id] = value.notes[chapter.id].slice(0, 100000);
    }
    for (const q of course.quizzes) {
      const answer = value.answers?.[q.id];
      if (answer && Number.isInteger(answer.choice) && answer.choice >= 0 && answer.choice < q.options.length) {
        clean.answers[q.id] = {choice: answer.choice, correct: answer.choice === q.correct,
          attempts: Number.isInteger(answer.attempts) ? Math.min(Math.max(answer.attempts, 1), 100000) : 1,
          date: typeof answer.date === "string" ? answer.date.slice(0, 50) : ""};
      }
    }
    for (const card of course.recall) {
      const saved = value.recall?.[card.id];
      if (saved && ["again", "effort", "clear"].includes(saved.rating) && Number.isFinite(saved.due)) {
        clean.recall[card.id] = {rating: saved.rating, due: Math.max(0, Math.min(saved.due, Date.now() + 366 * 86400000)),
          interval: Number.isFinite(saved.interval) ? Math.min(Math.max(saved.interval, 0), 30) : 0,
          reviewedAt: Number.isFinite(saved.reviewedAt) ? saved.reviewedAt : 0};
      }
    }
    return clean;
  }

  try {
    const saved = localStorage.getItem(storageKey);
    if (saved) state = validateProgress(JSON.parse(saved));
  } catch (error) {
    storageWorks = false;
    notice("Browser storage is unavailable or its saved record could not be read. You can still use the whole course. Export progress before closing this page.");
  }

  function save() {
    try {
      localStorage.setItem(storageKey, JSON.stringify(state));
      storageWorks = true;
    } catch (error) {
      storageWorks = false;
      notice("Progress is currently saved only in this open tab. Use Export progress to keep a backup before closing it.");
    }
  }

  function navigate(chapter, mode = "read") {
    if (!byId.has(chapter)) return;
    const target = `chapter=${encodeURIComponent(chapter)}&view=${validViews.has(mode) ? mode : "read"}`;
    if (location.hash.slice(1) === target) renderRoute();
    else location.hash = target;
  }

  function renderRoute() {
    const raw = location.hash.slice(1);
    const chapterAnchor = raw.match(/^chapter-(\d+)$/);
    const params = new URLSearchParams(raw);
    const requested = chapterAnchor ? chapterAnchor[1] : params.get("chapter");
    if (byId.has(requested)) active = requested;
    view = validViews.has(params.get("view")) ? params.get("view") : "read";
    const chapter = byId.get(active);
    document.title = chapter.title + " · Tabular Fraud, Explained";
    $("chapter-number").textContent = `CHAPTER ${chapter.id} / ${course.chapters.length} OPEN CHAPTERS`;
    $("chapter-title").textContent = chapter.title;
    $("chapter-meta").textContent = `About ${chapter.minutes} minutes of reading, plus worked examples and recall. Take the time you need.`;
    $("chapter-content").innerHTML = chapter.html;
    $("teachback").value = state.notes[active] || "";
    $("notes-status").textContent = storageWorks ? "Your notes stay in this browser. Export progress to back them up." : "Notes stay in this open tab. Export progress to keep them.";
    document.querySelectorAll(".view").forEach(node => { node.hidden = node.id !== view + "-view"; });
    document.querySelectorAll("[data-view]").forEach(button => {
      if (button.dataset.view === view) button.setAttribute("aria-current", "page");
      else button.removeAttribute("aria-current");
    });
    const position = course.chapters.findIndex(item => item.id === active);
    $("previous-chapter").disabled = position === 0;
    $("next-chapter").disabled = position === course.chapters.length - 1;
    renderNavigation();
    updateProgress();
    if (view === "practice") renderQuizzes();
    if (view === "recall") renderRecall();
    $("sidebar").classList.remove("open");
    $("menu-toggle").setAttribute("aria-expanded", "false");
    window.scrollTo({top: 0, behavior: "instant"});
    $("main").focus({preventScroll: true});
  }

  function renderNavigation() {
    const query = $("search").value.trim().toLocaleLowerCase();
    const nav = $("chapter-nav");
    nav.replaceChildren();
    let matches = 0;
    for (const chapter of course.chapters) {
      const index = chapter.text.toLocaleLowerCase().indexOf(query);
      if (query && index < 0 && !chapter.title.toLocaleLowerCase().includes(query)) continue;
      matches += 1;
      const link = el("a", "chapter-link");
      link.href = `#chapter=${encodeURIComponent(chapter.id)}&view=read`;
      link.addEventListener("click", event => { event.preventDefault(); navigate(chapter.id); });
      if (chapter.id === active) link.setAttribute("aria-current", "page");
      link.append(el("span", "chapter-id", chapter.id));
      const name = el("span", "nav-title", chapter.title.replace(/^\s*(?:Chapter\s+)?\d+\s*[·:—–.\-]\s*/i, ""));
      if (query && index >= 0) {
        const start = Math.max(0, index - 35);
        name.append(el("span", "search-snippet", (start ? "…" : "") + chapter.text.slice(start, index + query.length + 65) + "…"));
      }
      link.append(name);
      if (state.read[chapter.id]) {
        const check = el("span", "nav-read", "✓");
        check.setAttribute("aria-label", "Marked read");
        link.append(check);
      }
      nav.append(link);
    }
    $("search-status").textContent = query ? `${matches} chapter${matches === 1 ? "" : "s"} contain “${$("search").value.trim()}”.` : "All chapters available";
    if (!matches) nav.append(el("p", "small muted", "No matches. Try a simpler term, such as loss or data."));
  }

  function updateProgress() {
    $("read-count").textContent = `${Object.values(state.read).filter(Boolean).length}/${course.chapters.length}`;
    const correct = course.quizzes.filter(q => state.answers[q.id]?.choice === q.correct).length;
    $("quiz-count").textContent = `${correct}/${course.quizzes.length}`;
    $("recall-count").textContent = `${course.recall.filter(card => state.recall[card.id]?.rating === "clear").length}/${course.recall.length}`;
    $("due-count").textContent = String(course.recall.filter(card => !state.recall[card.id] || state.recall[card.id].due <= Date.now()).length);
    $("mark-read").textContent = state.read[active] ? "✓ Marked read · undo" : "Mark chapter read";
    $("mark-read").setAttribute("aria-pressed", state.read[active] ? "true" : "false");
  }

  function repairButton(chapter) {
    const button = el("button", "secondary", `Repair this idea · chapter ${chapter}`);
    button.type = "button";
    button.addEventListener("click", () => navigate(chapter));
    return button;
  }

  function renderQuizzes() {
    const container = $("quiz-list");
    container.replaceChildren();
    const questions = course.quizzes.filter(q => q.chapter === active);
    if (!questions.length) {
      const empty = el("div", "empty-state");
      empty.append(el("h3", "", "Use this chapter’s teach-back exercise"), el("p", "", "This chapter has no multiple-choice set. Its reading exercises and your own explanation are the practice. Choose another chapter to practise its questions."));
      container.append(empty);
      return;
    }
    questions.forEach((q, index) => {
      const card = el("form", "quiz-card");
      const fieldset = el("fieldset");
      fieldset.append(el("legend", "", `${index + 1}. ${q.prompt}`));
      const saved = state.answers[q.id];
      q.options.forEach((option, optionIndex) => {
        const label = el("label", "answer-option");
        const input = el("input");
        input.type = "radio";
        input.name = q.id;
        input.value = String(optionIndex);
        input.checked = saved?.choice === optionIndex;
        label.append(input, el("span", "", option));
        fieldset.append(label);
      });
      const actions = el("div", "quiz-actions");
      const submit = el("button", "primary", saved ? "Check again" : "Check my reasoning");
      submit.type = "submit";
      actions.append(submit);
      if (saved) actions.append(el("span", "small muted", `${saved.attempts} attempt${saved.attempts === 1 ? "" : "s"}`));
      const feedback = el("div");
      feedback.setAttribute("role", "status");
      const showFeedback = answer => {
        feedback.className = "quiz-feedback" + (answer.choice === q.correct ? " correct" : "");
        feedback.replaceChildren(el("strong", "", answer.choice === q.correct ? "That reasoning fits." : "A useful idea to repair."), el("p", "", q.explanation));
        if (answer.choice !== q.correct) feedback.append(el("p", "small", `Best answer: ${q.options[q.correct]}`));
        feedback.append(repairButton(q.remediate));
      };
      if (saved) showFeedback(saved);
      card.append(fieldset, actions, feedback);
      card.addEventListener("submit", event => {
        event.preventDefault();
        const selected = card.querySelector("input:checked");
        if (!selected) {
          feedback.className = "quiz-feedback";
          feedback.textContent = "Choose the answer you think is best, then check your reasoning.";
          card.querySelector("input").focus();
          return;
        }
        const answer = {choice: Number(selected.value), correct: Number(selected.value) === q.correct,
          attempts: (state.answers[q.id]?.attempts || 0) + 1, date: new Date().toISOString()};
        state.answers[q.id] = answer;
        save();
        showFeedback(answer);
        submit.textContent = "Check again";
        let attempts = actions.querySelector("span");
        if (!attempts) { attempts = el("span", "small muted"); actions.append(attempts); }
        attempts.textContent = `${answer.attempts} attempt${answer.attempts === 1 ? "" : "s"}`;
        updateProgress();
      });
      container.append(card);
    });
  }

  function renderRecall() {
    const all = $("all-cards").checked;
    const now = Date.now();
    const cards = course.recall.filter(card => all || !state.recall[card.id] || state.recall[card.id].due <= now)
      .sort((a, b) => (state.recall[a.id]?.reviewedAt || 0) - (state.recall[b.id]?.reviewedAt || 0));
    const due = course.recall.filter(card => !state.recall[card.id] || state.recall[card.id].due <= now).length;
    $("recall-status").textContent = `${due} due or new across the whole course. ${cards.length} in this review queue. Cards are drawn from all chapters; skip unfamiliar ones and return after reading.`;
    const container = $("recall-card");
    container.replaceChildren();
    let available = cards.filter(card => !sessionSkipped.has(card.id));
    if (!available.length && cards.length) { sessionSkipped.clear(); available = cards; }
    currentCard = available[0] || null;
    recallRevealed = false;
    if (!currentCard) {
      const empty = el("div", "empty-state");
      empty.append(el("h3", "", "This queue is clear for now"), el("p", "", "Come back when cards are due, or include later cards for extra practice. Spend a minute drawing the whole project from memory."));
      container.append(empty);
      return;
    }
    const card = currentCard;
    const box = el("div", "recall-card");
    box.append(el("p", "eyebrow", `Chapter ${card.chapter} · Recall before recognition`), el("h3", "", card.prompt));
    const scratchLabel = el("label", "small", "Your answer before revealing (optional, temporary scratch space)");
    scratchLabel.htmlFor = "recall-scratch";
    const scratch = el("textarea", "recall-scratch");
    scratch.id = "recall-scratch";
    scratch.rows = 3;
    scratch.placeholder = "Explain why, and give an example…";
    const reveal = el("button", "primary", "Reveal explanation");
    const response = el("div");
    response.hidden = true;
    response.append(el("div", "recall-answer", card.answer), el("p", "small muted", "Rate the answer you recalled before revealing. Recognizing it after reading is a different skill."));
    const ratings = el("div", "recall-selfrating");
    for (const [rating, label] of [["again", "Need another try · 10 min"], ["effort", "Recalled with effort · 1 day"], ["clear", "Clear explanation · 3+ days"]]) {
      const button = el("button", "secondary", label);
      button.addEventListener("click", () => {
        if (!recallRevealed) return;
        const previous = state.recall[card.id];
        const interval = rating === "again" ? 1 / 144 : rating === "effort" ? 1 : Math.min(30, Math.max(3, (previous?.interval || 1.5) * 2));
        state.recall[card.id] = {rating, interval, due: Date.now() + interval * 86400000, reviewedAt: Date.now()};
        save();
        updateProgress();
        renderRecall();
      });
      ratings.append(button);
    }
    response.append(ratings, repairButton(card.chapter));
    reveal.addEventListener("click", () => { response.hidden = false; reveal.hidden = true; recallRevealed = true; });
    const skip = el("button", "secondary", "Skip this card for now");
    skip.addEventListener("click", () => {
      // Session-only queue change; skipping is not a recall attempt.
      sessionSkipped.add(card.id);
      renderRecall();
    });
    const actions = el("div", "button-row");
    actions.append(reveal, skip);
    box.append(scratchLabel, scratch, actions, response);
    if (state.recall[card.id]) box.append(el("p", "small muted", `Scheduled due: ${new Date(state.recall[card.id].due).toLocaleString()}`));
    container.append(box);
  }

  function renderEvidence() {
    const all = $("all-evidence").checked;
    $("sources-title").textContent = all ? "Source evidence · all chapters" : `Source evidence · chapter ${active}`;
    const container = $("evidence-list");
    container.replaceChildren();
    const records = course.evidence.filter(record => all || record.chapter === active);
    if (!records.length) container.append(el("p", "muted", "This chapter has no separate implementation evidence entries. Its foundations and synthetic examples are connected to source in later chapters."));
    for (const record of records) {
      const item = el("section", "evidence-item");
      item.append(el("span", "evidence-status", record.status || "Source checked"), el("p", "", record.claim || ""));
      const lines = String(record.lines || "");
      item.append(el("span", "source-locator", `Chapter ${record.chapter} · ${record.file || ""} · ${record.symbol || ""} · lines ${lines}`));
      if (course.sourceUrl && record.file) {
        const link = el("a", "small", "Open source snapshot (repository access required)");
        const lineStart = lines.match(/\d+/)?.[0];
        link.href = course.sourceUrl + "/" + record.file.split("/").map(encodeURIComponent).join("/") + (lineStart ? "#L" + lineStart : "");
        link.target = "_blank";
        link.rel = "noopener noreferrer";
        item.append(link);
      }
      container.append(item);
    }
  }

  const stages = [
    {title: "Raw row", chapter: "01", detail: "A row describes one transaction. Its input fields are the facts available to the model; its label is the later-known answer used for learning or evaluation. A useful-looking field can still be forbidden if it reveals the future."},
    {title: "Frozen preprocessing", chapter: "06", detail: "The project turns the selected fields into a stable numerical representation. Fitting preprocessing learns mappings and numerical statistics from the permitted training data. Transforming validation or test data reuses those frozen choices."},
    {title: "Strict earlier history", chapter: "07", detail: "For a target transaction, only permitted earlier events from its account can become history. The target is excluded. Time, source and split rules prevent the model from reading information it would not have had at prediction time."},
    {title: "Feature tokens", chapter: "08", detail: "Each selected feature becomes a learned vector, a short list of numbers. Numerical and categorical features take different embedding routes. Together, feature tokens make one transaction available to attention."},
    {title: "A / B attention", chapter: "10", detail: "Flat A places features from the history and target into a joint attention sequence. Hierarchical B first summarizes each transaction, then reasons across transactions. Both paths use information masks; their tensor structures differ."},
    {title: "Head → score", chapter: "11", detail: "The REF, A and B prediction heads produce two logits: an unbounded numerical output for each class. Softmax converts the two outputs into scores that sum to 1; the positive-class score is used for fraud. With two logits this equals a sigmoid of their difference. A score or a high ranking alone does not prove calibrated fraud probability."},
    {title: "Training: update", chapter: "04", detail: "When training, compare the output with the known label using a loss. Backpropagation computes how weights affect that loss; an optimizer changes the weights. Repeat on allowed training examples. This weight update is not part of ordinary held-out evaluation."},
    {title: "Evaluation: metrics", chapter: "15", detail: "When evaluating, keep the trained weights fixed. Save predictions with the appropriate labels and grouping information, then compute metrics under the declared protocol. Interpret operating thresholds, sampling uncertainty and leakage controls before making claims."}
  ];
  function renderJourney(selected = 0) {
    const container = $("journey-steps");
    container.replaceChildren();
    stages.forEach((stage, index) => {
      const button = el("button");
      button.append(el("span", "", index < 6 ? `STEP ${index + 1}` : index === 6 ? "TRAINING BRANCH" : "EVALUATION BRANCH"), document.createTextNode(stage.title));
      button.setAttribute("aria-pressed", String(index === selected));
      button.addEventListener("click", () => renderJourney(index));
      container.append(button);
    });
    const stage = stages[selected];
    const detail = $("journey-detail");
    detail.replaceChildren(el("h4", "", stage.title), el("p", "", stage.detail));
    const jump = el("button", "secondary", `Learn this step · chapter ${stage.chapter}`);
    jump.disabled = !byId.has(stage.chapter);
    jump.addEventListener("click", () => navigate(stage.chapter));
    detail.append(jump);
    if (selected === 4 && byId.has("11")) {
      const b = el("button", "secondary", "Hierarchical B · chapter 11");
      b.addEventListener("click", () => navigate("11"));
      detail.append(document.createTextNode(" "), b);
    }
  }

  function numeric(id, fallback, min, max) {
    const parsed = Number($(id).value);
    return Number.isFinite(parsed) ? Math.min(max, Math.max(min, parsed)) : fallback;
  }
  function neuronValues() {
    const x = numeric("lab-x", 2, -5, 5), w = numeric("lab-w", -.6, -20, 20), b = numeric("lab-b", .2, -20, 20);
    const y = Number($("lab-y").value), rate = numeric("lab-lr", .1, .01, 1);
    const z = w * x + b;
    const p = 1 / (1 + Math.exp(-z));
    const loss = Math.max(z, 0) - z * y + Math.log1p(Math.exp(-Math.abs(z)));
    return {x, w, b, y, rate, z, p, loss, gradW: (p - y) * x, gradB: p - y};
  }
  const number = value => (Math.abs(value) < .00005 ? 0 : value).toFixed(4);
  function renderNeuron() {
    const n = neuronValues();
    const output = $("learning-output");
    output.replaceChildren();
    const rows = [
      ["1 / Forward propagation", `z = w × x + b = ${number(n.w)} × ${number(n.x)} + ${number(n.b)} = ${number(n.z)}. Score p = 1 / (1 + exp(−z)) = ${number(n.p)}.`],
      ["2 / Loss: how costly was this answer?", `Known label y = ${n.y}. Binary cross-entropy = −[y ln(p) + (1−y) ln(1−p)] = ${number(n.loss)}. ln means natural logarithm. Lower loss rewards a score closer to the known binary label.`],
      ["3 / Backpropagation: which direction changes the loss?", `For this neuron, ∂loss/∂w = (p−y) × x = ${number(n.gradW)}; ∂loss/∂b = p−y = ${number(n.gradB)}. A positive derivative means increasing that parameter slightly increases loss at this point; a negative derivative means it decreases loss.`],
      ["4 / Optimizer: choose the size of the change", `With learning rate η = ${number(n.rate)}, next w = w − η × gradient = ${number(n.w - n.rate * n.gradW)}. Next b = ${number(n.b - n.rate * n.gradB)}. Click below to apply both changes.`]
    ];
    for (const [title, body] of rows) { const row = el("div", "math-step"); row.append(el("strong", "", title), document.createTextNode(body)); output.append(row); }
  }
  $("gradient-step").addEventListener("click", () => {
    const before = neuronValues();
    const nextW = before.w - before.rate * before.gradW, nextB = before.b - before.rate * before.gradB;
    // Inputs are bounded for a readable demonstration, never silently clip an update.
    if (Math.abs(nextW) > 20 || Math.abs(nextB) > 20) { $("gradient-result").textContent = "This step would leave the demonstration’s −20 to 20 parameter range. Lower the learning rate or reset the example."; return; }
    $("lab-w").value = nextW.toFixed(8);
    $("lab-b").value = nextB.toFixed(8);
    renderNeuron();
    const after = neuronValues();
    $("gradient-result").textContent = `One update applied. Loss moved from ${number(before.loss)} to ${number(after.loss)}; score moved from ${number(before.p)} to ${number(after.p)}. The table now shows the next possible step.`;
  });
  $("gradient-reset").addEventListener("click", () => {
    for (const [id, value] of [["lab-x", 2], ["lab-w", -.6], ["lab-b", .2], ["lab-y", 1], ["lab-lr", .1]]) $(id).value = value;
    $("gradient-result").textContent = "Example reset.";
    renderNeuron();
  });
  for (const id of ["lab-x", "lab-w", "lab-b", "lab-y", "lab-lr"]) {
    $(id).addEventListener("input", () => { $("gradient-result").textContent = ""; renderNeuron(); });
    $(id).addEventListener("change", () => {
      const n = neuronValues();
      const values = {"lab-x": n.x, "lab-w": n.w, "lab-b": n.b, "lab-y": n.y, "lab-lr": n.rate};
      $(id).value = values[id];
      renderNeuron();
    });
  }

  const syntheticRows = [{score: .9, y: 1}, {score: .8, y: 0}, {score: .65, y: 0}, {score: .55, y: 1}, {score: .45, y: 0}, {score: .3, y: 0}, {score: .25, y: 0}, {score: .2, y: 1}, {score: .15, y: 0}, {score: .1, y: 0}, {score: .07, y: 0}, {score: .02, y: 0}];
  function renderThreshold() {
    const threshold = Number($("threshold").value);
    $("threshold-value").textContent = threshold.toFixed(2);
    const counts = {tp: 0, fp: 0, tn: 0, fn: 0};
    for (const row of syntheticRows) counts[row.score >= threshold ? (row.y ? "tp" : "fp") : (row.y ? "fn" : "tn")] += 1;
    const percent = value => (value * 100).toFixed(1) + "%";
    const metrics = [[counts.tp + counts.fp ? percent(counts.tp / (counts.tp + counts.fp)) : "n/a", "Precision · fraud among alerts"], [percent(counts.tp / 3), "Recall · fraud caught"], [percent(counts.fp / 9), "False-positive rate"]];
    const grid = $("threshold-metrics");
    grid.replaceChildren();
    for (const [value, label] of metrics) { const metric = el("div", "metric"); metric.append(el("strong", "", value), el("span", "", label)); grid.append(metric); }
    const body = $("confusion-body");
    body.replaceChildren();
    for (const cells of [["Alert", `${counts.tp} true positives · caught fraud`, `${counts.fp} false positives · legitimate alerts`], ["No alert", `${counts.fn} false negatives · missed fraud`, `${counts.tn} true negatives · legitimate passes`]]) {
      const row = el("tr");
      cells.forEach((text, index) => { const cell = el(index ? "td" : "th", "", text); if (!index) cell.scope = "row"; row.append(cell); });
      body.append(row);
    }
    const rows = $("synthetic-rows");
    rows.replaceChildren();
    syntheticRows.forEach((row, index) => {
      const alert = row.score >= threshold;
      const item = el("div", "synthetic-row" + (alert ? " alert" : ""));
      item.append(el("strong", "", `Example ${index + 1} · ${row.score.toFixed(2)}`), document.createTextNode(`${row.y ? "Fraud" : "Legitimate"} → ${alert ? "ALERT" : "pass"}`));
      rows.append(item);
    });
  }

  function buildPrintBook() {
    const book = $("print-book");
    book.replaceChildren();
    const cover = el("section", "print-cover");
    cover.append(el("p", "eyebrow", "The offline learning book"), el("h1", "", course.title), el("p", "", "Learn the project from first principles. Predict, explain, practise and recall."), el("p", "", "This print edition includes every chapter, exercise and answer block. Interactive labs, quiz feedback, notes and recall scheduling are available in index.html."), el("p", "small", `Source snapshot: ${course.sourceSnapshot}. Course built ${course.built}. Synthetic examples are not research results.`));
    book.append(cover);
    for (const chapter of course.chapters) {
      const section = el("section", "print-chapter");
      section.innerHTML = chapter.html;
      section.querySelectorAll("details").forEach(details => { details.open = true; });
      // Printed duplicate heading IDs must not intercept on-screen anchor jumps.
      section.querySelectorAll("[id]").forEach(node => { node.id = "print-" + chapter.id + "-" + node.id; });
      book.append(section);
    }
    const assessmentSection = el("section", "print-chapter");
    assessmentSection.append(el("h1", "", "Practice questions and explanations"));
    for (const chapter of course.chapters) {
      const questions = course.quizzes.filter(q => q.chapter === chapter.id);
      if (!questions.length) continue;
      assessmentSection.append(el("h2", "", `Chapter ${chapter.id}`));
      for (const q of questions) {
        assessmentSection.append(el("h3", "", q.prompt));
        const list = el("ol");
        q.options.forEach(option => list.append(el("li", "", option)));
        assessmentSection.append(list, el("p", "", `Answer ${q.correct + 1}: ${q.explanation} Repair route: chapter ${q.remediate}.`));
      }
    }
    book.append(assessmentSection);
  }

  $("mark-read").addEventListener("click", () => { state.read[active] = !state.read[active]; save(); renderNavigation(); updateProgress(); });
  $("teachback").addEventListener("input", () => {
    state.notes[active] = $("teachback").value;
    save();
    $("notes-status").textContent = storageWorks ? "Saved locally. Export progress for a portable backup." : "Kept in this tab. Export progress before closing.";
  });
  $("search").addEventListener("input", renderNavigation);
  $("all-cards").addEventListener("change", renderRecall);
  $("all-evidence").addEventListener("change", renderEvidence);
  $("threshold").addEventListener("input", renderThreshold);
  $("chapter-practice").addEventListener("click", () => navigate(active, "practice"));
  $("previous-chapter").addEventListener("click", () => { const position = course.chapters.findIndex(c => c.id === active); if (position > 0) navigate(course.chapters[position - 1].id); });
  $("next-chapter").addEventListener("click", () => { const position = course.chapters.findIndex(c => c.id === active); if (position < course.chapters.length - 1) navigate(course.chapters[position + 1].id); });
  document.querySelectorAll("[data-view]").forEach(button => button.addEventListener("click", () => navigate(active, button.dataset.view)));
  document.querySelectorAll("[data-jump]").forEach(button => button.addEventListener("click", () => navigate(button.dataset.jump)));
  $("menu-toggle").addEventListener("click", () => { const open = $("sidebar").classList.toggle("open"); $("menu-toggle").setAttribute("aria-expanded", String(open)); });
  $("open-sources").addEventListener("click", () => { $("all-evidence").checked = false; renderEvidence(); $("sources-dialog").showModal(); });
  $("sidebar-sources").addEventListener("click", () => { $("all-evidence").checked = true; renderEvidence(); $("sources-dialog").showModal(); });
  $("close-sources").addEventListener("click", () => $("sources-dialog").close());
  $("sources-dialog").addEventListener("click", event => { if (event.target === $("sources-dialog")) { const rect = $("sources-dialog").getBoundingClientRect(); if (event.clientX < rect.left || event.clientX > rect.right || event.clientY < rect.top || event.clientY > rect.bottom) $("sources-dialog").close(); } });
  $("export-progress").addEventListener("click", () => {
    const output = {...state, exportedAt: new Date().toISOString()};
    const url = URL.createObjectURL(new Blob([JSON.stringify(output, null, 2)], {type: "application/json"}));
    const link = el("a");
    link.href = url;
    link.download = "tabular-fraud-learning-progress-" + new Date().toISOString().slice(0, 10) + ".json";
    document.body.append(link);
    link.click();
    link.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  });
  $("import-progress").addEventListener("click", () => $("import-file").click());
  $("import-file").addEventListener("change", async () => {
    const file = $("import-file").files[0];
    if (!file) return;
    try {
      if (file.size > 5000000) throw new Error("The file is too large for a progress backup (maximum 5 MB).");
      const imported = validateProgress(JSON.parse(await file.text()));
      // Merge notes and records in the backup; retain entries absent from it.
      state = {version: 1, courseId: course.id, read: {...state.read, ...imported.read}, answers: {...state.answers, ...imported.answers}, recall: {...state.recall, ...imported.recall}, notes: {...state.notes, ...imported.notes}};
      save();
      renderRoute();
      notice("Progress imported. Matching notes and practice records were restored from the backup; other local entries were kept.");
    } catch (error) { notice("Could not import progress: " + error.message); }
    $("import-file").value = "";
  });
  $("print-all").addEventListener("click", () => { buildPrintBook(); window.print(); });
  window.addEventListener("beforeprint", buildPrintBook);
  window.addEventListener("hashchange", renderRoute);
  document.addEventListener("click", event => {
    const link = event.target.closest("#chapter-content a");
    if (!link) return;
    const href = link.getAttribute("href") || "";
    const chapterMatch = href.match(/^#chapter-(\d+)$/) || href.match(/(?:^|\/)(\d{2})(?:[-_][^/#]*)?\.md(?:#.*)?$/);
    if (chapterMatch && byId.has(chapterMatch[1])) { event.preventDefault(); navigate(chapterMatch[1]); return; }
    if (href.startsWith("#") && !href.startsWith("#chapter=")) {
      const target = $("chapter-content").querySelector("[id='" + CSS.escape(decodeURIComponent(href.slice(1))) + "']");
      if (target) { event.preventDefault(); target.scrollIntoView({block: "start"}); }
    }
  });
  $("snapshot").textContent = `Code snapshot ${course.sourceSnapshot.slice(0, 12)} · built ${course.built}`;
  renderJourney();
  renderNeuron();
  renderThreshold();
  renderRoute();
})();
