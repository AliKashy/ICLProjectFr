# Course review and validation

Reviewed on 15 October 2026 against project snapshot `aa14bc9357401fe51e21c20580002b19fa53e5d9`.

## Content review

Four authors covered foundations, data, models, and training/evaluation. Each content group was then reviewed by a different author for beginner clarity, arithmetic, misconceptions, and connection to the actual code. A separate source reviewer inspected all 20 chapters, all 83 practice questions, the 30 additional recall cards, and 126 source-evidence entries. The coordinating author added the learning route, project atlas, capstone, and glossary and integrated the corrections.

The independent technical pass recorded 16 findings and verified their resolution. Repairs included exact class names and source locations, preprocessing leakage wording, tokenizer shape transitions, the distinction between an offline scorer and live serving, and clearer mathematical prerequisites. Cross-reviews also expanded query/key/value arithmetic, the classifier head, residual/normalization calculations, reference input BatchNorm, contrastive normalization, and confidence-interval interpretation.

Reviewers independently recomputed the complete teaching neural-network update, attention examples, preprocessing values, time gaps, confusion matrices, AP, and AUROC. Every question's answer key and explanation was read. Source files and line ranges in evidence.json were checked against the pinned snapshot.

These were independent internal agents within this course task. They were not external collaborator approval or a new audit of the whole application's security or production behavior.

## Executed learning and interface checks

- Four synthetic standard-library Python labs executed successfully, with captured expected output.
- Independent checks included reversing the learning update, changing a score ranking, admitting a same-time transaction, and verifying identical/swapped-model paired differences.
- Chromium rendered every chapter and exercised all 83 questions using both incorrect and correct responses.
- Reading marks, notes, quiz state, reload, export and clean-browser import were checked.
- Recall reveal, skip, self-rating and scheduling were checked.
- The transaction journey, gradient-step arithmetic and alert-threshold calculations were checked.
- All source records were accessible in the reader.
- A 390-pixel mobile viewport had no page-wide horizontal overflow; desktop and mobile screenshots were inspected.
- Print output included every chapter and expanded answers; book.html worked with JavaScript disabled.
- No browser errors or HTTP(S) requests occurred during the browser checks.

## Evidence boundaries

This build did not train or score bank models, read native bank transaction rows, rerun the full repository test suite, reproduce current bank performance, or establish production deployment. The synthetic examples teach mechanisms. Descriptions of implemented code are tied to the stated source snapshot; historical, reported, parked, and proposed work are identified separately.

Progress counts represent reading, quiz practice, and self-assessed recall. They do not certify professional mastery. The capstones and oral-defence questions provide additional ways to test whether you can explain and transfer the ideas.

The package manifest records the delivered file fingerprints. Source locators refer to the private application's files, which are not included in this public learning archive.
