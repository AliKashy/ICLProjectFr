# 00 · Your mission: explain one transaction from beginning to end

You do not need to know a neural network, an optimizer, or a line of Python before starting. Those are things this course teaches. Your goal is to be able to draw the project from memory, follow a transaction through it, explain why each step exists, and challenge a misleading result.

This is **Tabular Fraud Explained**, built from the project source at commit `aa14bc9357401fe51e21c20580002b19fa53e5d9`, reviewed on 15 October 2026. A commit is a saved version of the repository, the project's collection of files. Fixing the version tells you which implementation this explanation describes. The public repository hosting this course is called ICLProjectFr; that does not make this fraud model an in-context-learning language-model experiment. The implemented fraud models here learn numerical parameters from transaction data.

The course takes you from the business question to the point where you can understand how results are produced, tested, and interpreted. It does not launch training or announce a new winning model. All little transactions, arithmetic examples, and interactive demonstrations in the lessons are **invented teaching examples**, not bank records or measured project results.

## A different way to work through it

Treat the course as learning to take over a small fraud research lab. At each stop, do four things:

1. **See it:** read a worked example and follow each intermediate number or transformation.
2. **Predict it:** stop before the answer, make a small prediction, then check what happened.
3. **Repair it:** explain what went wrong in a deliberately flawed example.
4. **Teach it:** close the explanation and answer aloud, in your own words.

The interactive reader gives feedback on practice questions and sends you back to the relevant chapter when an answer exposes a gap. You can always open any chapter. Reading a page, answering a quiz, and remembering it tomorrow are different achievements; the progress display keeps them separate. A correct multiple-choice answer is evidence of one answer, not certification that you can run a bank system.

Use the notes box to write a short explanation before revealing the worked answer. A useful note sounds like: “The missing-value flag tells the model that the filled-in amount was originally absent.” A less useful note is just “missingness indicator.” You are practising the explanation, not collecting terminology.

After a session, try three recall cards. Rate an answer “remembered” only if you could explain the reasoning before revealing it. Revisit material after roughly a day, a few days, and a week. Those intervals are a practical suggestion, not a scientific guarantee for every learner. The review queue helps you return to things you found difficult. Progress stays in your browser; export the JSON backup if you change browsers or machines. Nothing needs a GPU or sends your answers to a server.

## The whole project, before the details

Imagine a new transaction arrives. The research question is whether its details, and optionally earlier transactions from its account, help rank how likely it is to be fraud. A high score might later help an operational system decide which transactions to investigate. This repository's training and evaluation do not themselves prove that such an operational system has been deployed.

```text
Past examples with known outcomes
          |
          v
Define usable inputs and separate learning from assessment
          |
          v
Apply saved rules for missing values and categories
          |
          +-------------------+--------------------+
          |                   |                    |
   REF: one transaction   A: all feature      B: each transaction
                          tokens together     summarized, then history
          |                   |                    |
          +-------------------+--------------------+
                              |
                       Two class scores
                              |
                Convert to a fraud-class score
                              |
                  +-----------+-----------+
                  |                       |
          During training:         During evaluation:
          compare with label,      save predictions from
          calculate error,         a chosen checkpoint,
          adjust parameters        compare with outcomes
```

For now, “parameter” means an adjustable number inside the model. “Label” means the known training answer, such as fraud or not fraud. “Checkpoint” means a saved model state. Later chapters unpack every arrow.

The most valuable distinction in this picture is the bottom fork. During training, known answers help adjust the model. When predicting a transaction, its answer is not an input. You may subsequently compare the prediction with the outcome to measure performance. Feeding the answer into the predictor would defeat the purpose.

## Your chapter route

| Mission | Chapters | What you should be able to do afterward |
|---|---|---|
| Understand the question and the mathematics | 01–04 | Describe a row, calculate a tiny model's prediction, and explain learning as parameter updates |
| Know exactly what the model may see | 05–07 | Build a legal history, explain frozen preprocessing, and catch a data leak |
| Visualize the three main model routes | 08–11 | Draw tokens, attention, flat A, hierarchical B, and the all-position exception |
| Run a fair investigation in your head | 12–15 | Explain a training run, a comparison, an uncertainty range, and a useful fraud metric |
| Test and take ownership | 16–18 | Run small CPU exercises, locate the relevant implementation, and defend the project under questions |
| Look up a forgotten term | 19 | Recover a definition and return to the chapter that teaches it |

Each chapter is a stopping place, not a demand to finish the entire course in one sitting. A useful session can be one worked example and one teach-back. If a section feels hard, return to the particular dependency it names. Do not restart the whole course just because one word is unfamiliar.

## Three kinds of statement to keep separate

**Implemented** means the checked source contains a mechanism. **Measured** means a recorded execution produced an observation, subject to the quality of that record. **Proposed** means something is being considered or developed and does not establish a performance gain.

The repository contains old plans, historical findings, corrected copies, current runs, and parked experiments. They cannot all describe “the current model” simultaneously. The main training paths are the corrected single-transaction reference, flat A, and hierarchical B. Phase 5 pretraining is present as parked work. Later feature and optimizer work must not be described as an established V1 improvement. Chapter 17 is your map through those layers.

The existing evaluation cohort has been consulted during development. A label saying “evaluation” is not a magic guarantee of an untouched final test. Chapter 05 explains the boundary, and Chapters 14–15 explain the consequences for claims.

## First checkpoint: make a prediction before studying

You are given an amount, a merchant category, an account's recent transactions, and a column saying whether the current transaction was eventually confirmed as fraud. Which information should the predictor receive when deciding about the current transaction?

<details markdown="1">
<summary>Reveal the reasoning</summary>

It may receive authorized details available at that decision time and eligible earlier history. It must not receive the current transaction's future fraud outcome. That outcome is useful as a training target and later for evaluation. Even apparently ordinary inputs require an availability check: a field filled in after the decision can leak later information.

You do not yet need to explain how attention works. If you can separate inputs from the answer, you have the first piece of the project.
</details>

**Your first teach-back:** “We want to predict ___ using ___ that was available ___. We learn from ___ and test on ___.” Fill the blanks in plain language. Revisit this sentence after Chapter 05; your answer should become more precise.

**Next useful stop:** Chapter 01. If you already understand a section, use its challenge instead of simply marking it read.


---

# 01 — What problem are we trying to solve?

## Start with a decision, not a model name

**Prerequisite refresher:** none. A *transaction* is an event such as a payment. A *table* organizes events into rows and their properties into columns. Every number in this chapter is invented for learning; none is a bank result.

Your question for this chapter is: **When a transaction arrives, what information can we use to decide whether it deserves attention?**

Imagine that you help a team review payments. Most are legitimate. A few are fraudulent. Reviewing every payment would be expensive and slow. Ignoring every payment would miss fraud. You need a way to prioritize attention using information available when each payment occurs.

A simple human rule might be: “Review every payment above 500.” That is easy to explain, but it would flag an ordinary large purchase and miss a small fraudulent one. A more useful assessment could combine amount, payment channel, time and relevant earlier behavior. A *model* is a calculation that takes such information and produces an output. In this project, the output supports ranking transactions by suspected fraud.

A model is only one part of the decision system. A *score* is a number used to order cases. A *threshold* is the cutoff for an action. For example, “review scores at least 0.70” is a policy applied to model scores. Investigators, operating costs and capacity still matter. A score is not itself a verdict, an investigation or a guarantee.

## Read one row correctly

Consider this fictional table:

| Transaction | Account | Time | Amount | Channel | Later confirmed fraud? |
|---|---|---|---:|---|---:|
| Example A | Customer Red | 09:00 | 20 | In person | 0 |
| Example B | Customer Red | 09:10 | 80 | Online | 0 |
| Example C | Customer Red | 09:20 | 200 | Online | 1 |
| Example D | Customer Blue | 09:25 | 40 | In person | 0 |

A **row** is one transaction. A **feature**, also called a predictor or input, is a property supplied to the model. Amount and channel could be features. The **label**, also called the target or outcome, is the answer used to teach or evaluate the model. Here `1` means fraud and `0` means non-fraud.

Those digits are a convention, not a statement that fraud is “bigger” than non-fraud. A **binary classification** task chooses between two classes. The word *classification* means assigning or scoring membership in categories. *Binary* means there are two categories.

Not every table column belongs in the model. Account references may help assemble a customer's earlier transactions. Transaction identifiers may help reconcile records. An identifier used to join or check records need not be a predictor. Most importantly, the later confirmed outcome is not an input when making the original prediction. Giving the answer to the model would make a practice exercise look impressive while making it unusable for real decisions.

For Example C, the practical question is:

> Using information available by 09:20, how suspicious is this transaction?

The later label teaches us whether the prediction was useful. It does not travel backward in time to help produce the prediction. Chapter 05 will make that boundary precise.

## What “tabular” and “history-aware” mean here

**Tabular** means the original information is organized like a table. It does not mean the model is an ordinary spreadsheet formula or that every column is a number.

There are two broad views of Example C:

1. **Single transaction:** assess the current row using its available predictors.
2. **Transaction history:** assess the current row together with selected earlier transactions belonging to the relevant account.

In the fictional example, a history-aware model might receive A, B and C while predicting C. D belongs to a different account and is later anyway. A history length of two means up to two earlier transactions, plus the current transaction. It does not mean “two days.” If the customer has only one earlier transaction, the system must represent the missing slot safely rather than inventing a payment.

The project contains a single-transaction reference called **REF**, and two history-model structures called **A** and **B**. A processes feature representations from the sequence together in a flat arrangement. B first builds a representation for each transaction and then combines information across transactions. A *representation* is simply a collection of numbers the model uses internally to carry information. You will build this idea gradually in Chapters 03 and 08–11.

The models use a family of neural networks called FT-Transformer. For now, read that name as a label on a box whose behavior we will unpack. You do not need to know what a neural network, token or attention mechanism is yet. Chapters 03, 08 and 09 teach those concepts before relying on them.

More history is a hypothesis, not an automatic improvement. It may provide useful context, or it may add distracting patterns and computational work. A bigger model can learn more useful structure, but it can also learn accidental patterns in the examples it saw. We need comparable experiments to find out.

## The whole project as one journey

Picture a transaction moving along this route:

**Recorded events → permitted inputs → consistent numerical form → current row plus allowed history → model → two class scores → fraud score → evaluation → human interpretation.**

Each arrow represents work. “Consistent numerical form” means that the same category and amount receive the same interpretation during training and later scoring. “Allowed history” means past information that satisfies the project's time and account rules. “Two class scores” means the model makes a numerical output for each of the two classes; we will convert these into a fraud score in Chapter 03.

There is also a separate learning loop:

**Training examples + known labels → predictions → a numerical penalty for mistakes → calculated parameter changes → updated model.**

A **parameter** is an adjustable number inside the model. Training changes these numbers. A **training example** is the input presented for one prediction together with its known target when available. A history-aware example can contain several transaction rows while still predicting one target transaction.

After learning, **inference** means using the model to calculate outputs for inputs. In ordinary scoring, parameters are fixed: the model does not automatically learn from each payment as it arrives. A **checkpoint** saves learned model state so a particular version can be loaded again. A file called “best” is not automatically the best possible fraud model; it records the selection rule used in that experiment.

Training, checking development choices and evaluating final performance serve different purposes. **Training data** supply the examples used to change parameters. **Validation data** help choose settings or checkpoints. **Evaluation/test data** support an assessment of the selected procedure. Their exact roles and boundaries matter more than the names on the files. We will return to them in Chapters 05, 12 and 14.

## Worked business example: accuracy can flatter a useless system

Suppose a fictional set contains 1,000 transactions: 10 fraudulent and 990 legitimate. A system that predicts “legitimate” for every transaction gets 990 correct.

Its **accuracy**, the fraction of all predictions that are correct, is:

`990 ÷ 1,000 = 0.99 = 99%`.

That sounds excellent until you ask how much fraud it found. It found `0 ÷ 10 = 0%` of the fraudulent transactions. A high percentage can answer the wrong business question.

Now imagine a model whose chosen threshold flags 20 transactions. Of those, eight are fraudulent and 12 are legitimate. Two fraudulent transactions remain unflagged.

- **Precision** asks: of the cases we flagged, how many were fraud? `8 ÷ 20 = 40%`.
- **Recall** asks: of all the fraudulent cases, how many did we flag? `8 ÷ 10 = 80%`.
- Review workload is 20 transactions, or `20 ÷ 1,000 = 2%` of this fictional set.

Precision and recall have different denominators because they answer different questions. Precision helps describe the quality of the review queue. Recall helps describe the coverage of fraud. Neither alone gives financial value. Missing one large fraudulent payment may cost more than missing several tiny ones; reviewing legitimate customers also has costs.

Do not attach these figures to REF, A or B. They are an arithmetic exercise. Chapter 15 teaches the project's measured metrics and how to read actual outputs without turning a small difference into an unsupported claim.

## Where this connects to the actual implementation

The course is grounded in the source snapshot identified in Chapter 00. Relative paths below locate source in the original repository; access to that repository may be required.

- `fraud/data/feature_list.py`, `FeatureList` and `load_feature_list`, lines 25–37 and 57–104: the project loads a versioned predictor list and separates continuous and categorical predictors. This is the code counterpart of deciding which columns have which role.
- `waqas/base/streaming_model.py`, `build_inferred_config`, lines 36–51: the reference builder specifies two output classes. `build_streaming_model`, lines 54–116, constructs its FT-Transformer from configuration and already prepared inputs.
- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 21–68: A stores `history_len + 1` transaction positions and builds a two-output prediction head. Its `forward`, lines 146–173, turns a batch into class scores.

These references establish implemented behavior. They do not establish which model wins on bank data. The course treats executed evidence, implementation and proposed experiments separately. Current results interpretation is covered later; no GPU run is needed to understand this chapter.

## Common wrong mental model

**Wrong:** “The model identifies fraud, so a score of 0.80 proves the transaction is fraudulent with an 80% real-world probability.”

**Repair:** The score is model output on a probability-like scale. Whether values correspond to observed frequencies is a separate question called **calibration**. Even a well-calibrated 0.80 score describes uncertainty; it is not certainty for one transaction. Training choices, population changes and data quality can all affect how useful a score is.

Another common mistake is “the latest architecture must be the strongest.” Model comparisons require the same intended evaluation task and carefully tracked differences. Complexity is a property of a design, not evidence of usefulness.

## Your case-room challenge

Before opening the answer, say your reasoning aloud or write it in the chapter's teach-back box.

**Predict:** You have 500 transactions, including five frauds. A rule flags ten transactions and catches four frauds. What are its precision and recall? Why would always saying “non-fraud” be a weak alternative even though its accuracy is high?

**Repair:** A colleague includes “investigator confirmed fraud next week” as a predictor for today's transaction. Explain the problem in one sentence.

**Teach back:** Trace Example C from its row to a review decision. Use the words input, label, score and threshold correctly. Explain how using history changes the input, and name one thing history does not guarantee.

<details><summary>Open after attempting: answer and a self-check rubric</summary>

Precision is `4 ÷ 10 = 40%`. Recall is `4 ÷ 5 = 80%`. The always-non-fraud rule gets `495 ÷ 500 = 99%` accuracy while finding no fraud. The future investigator outcome is unavailable at decision time, so using it gives the model information it would not have when deployed.

A strong teach-back says that permitted properties of C, and perhaps strictly earlier relevant history, become inputs. The model produces a score. A policy compares the score with a threshold to decide whether to review. The later known outcome is the label used for learning or evaluation. More history may help, but its value must be tested. You do not need to name any neural-network component yet.

If you mixed up precision and recall, circle the words “flagged” and “all fraud” before choosing a denominator. If you treated a score as a verdict, restate the distinction between model output and the action policy.

</details>

**Recall without looking:** draw the two journeys: producing a score, and training a model. Explain why they are different. **Repair route:** revisit this chapter for input/label/decision confusion; go to Chapter 02 for fractions and shapes, Chapter 05 for time boundaries, and Chapter 15 for evaluation measures.


---

# 02 — The numbers and tiny programs underneath the project

## The minimum toolkit

**Prerequisite refresher:** a feature is an input, a label is the known answer, and a model converts inputs into scores. Training changes adjustable numbers called parameters. Scoring normally uses those numbers without changing them.

Your question is: **How do numbers and a few lines of code describe that process precisely?**

You do not need to finish a mathematics degree or a Python course before continuing. You do need to recognize a small set of ideas that recur everywhere in this project. We will practice each with invented values and explicitly name what every dimension means.

## Fractions, percentages and signs

A **fraction** expresses one quantity relative to another. If four of ten alerts are fraud, the fraction is `4/10`. Division gives `0.4`; multiplying by 100 gives `40%`. These are three ways of writing the same proportion.

A percentage increase has a different meaning from a percentage-point increase. Moving recall from 40% to 50% is an increase of ten **percentage points**. Relative to the original 40%, the increase is `10 ÷ 40 = 25%`. Keeping these separate prevents an experiment report from sounding larger or smaller than it is.

A negative number is below zero. Negative values inside a model are ordinary; they do not mean “negative money.” A standardized amount can be negative because it is below a reference average. A weight can be negative because increasing its input reduces the next calculated value, with everything else held fixed.

Multiplication happens before addition unless parentheses specify otherwise. Thus `2 + 3 × 4 = 14`, while `(2 + 3) × 4 = 20`. We use `×` in prose and `*` in Python-like code. We use `÷` in prose and `/` in code.

## Variables, functions and adjustable parameters

A **variable** is a name attached to a value. In a tiny program:

```python
amount = 200
amount_in_hundreds = amount / 100
```

The second value is `2`. The equals sign here means “assign this value to this name.” It is an instruction, rather than a claim that two expressions are forever equal. A later instruction could assign a new value.

A **function** is a reusable calculation with inputs and an output. Here is conceptual teaching code, not copied project runtime:

```python
def simple_score(amount_in_hundreds, online_flag):
    raw_score = 0.5 * amount_in_hundreds + 0.2 * online_flag - 0.3
    return raw_score
```

`def` introduces the function. Indentation places the next two lines inside it. `return` gives its result back. An online flag of `1` means online in this example; `0` means not online. Calling `simple_score(2, 1)` calculates `0.5 × 2 + 0.2 × 1 − 0.3 = 0.9`.

The two inputs change from transaction to transaction. In a learned model, numbers like `0.5`, `0.2` and `−0.3` would be parameters that training can change. A **weight** multiplies an input. A **bias** is an added offset. You will see both repeatedly in Chapter 03.

A **hyperparameter** is a setting chosen for the learning procedure or architecture rather than learned by that ordinary parameter-update step. The learning rate, number of model layers and requested history length are examples. A configuration file records settings. A learned parameter lives in model state. Changing a configuration name does not automatically retrain an existing checkpoint.

## Collections: list, dictionary and table

A **list** holds items in order. In Python notation, `[20, 80, 200]` contains three amounts. Python counts positions starting at zero, so element `0` is `20`, element `1` is `80`, and element `2` is `200`.

A **dictionary** associates names with values:

```python
example = {
    "continuous": [2.0, 0.5],
    "categorical": [1, 3],
    "target": 1,
}
```

`example["target"]` retrieves `1`. The keys help the program distinguish input kinds and labels. **Continuous** inputs are numerical quantities for which magnitude is meaningful, such as a transformed amount. **Categorical** inputs encode membership in categories, such as a channel. Category number `3` does not generally mean three times category `1`. Often these numbers are lookup addresses rather than quantities to multiply directly.

A table can contain strings, numbers and missing entries. The model's numerical arrays have more specific layouts. Preparing those layouts is part of preprocessing, which Chapter 06 teaches. A missing value means the source information is absent; it is not automatically the same as a genuine value of zero.

## Scalar, vector, matrix and tensor

These words describe how numbers are organized.

| Word | Plain meaning | Invented example | Shape |
|---|---|---|---|
| Scalar | One number | `0.7` | No axes |
| Vector | An ordered line of numbers | `[2, 1]` | `(2,)` |
| Matrix | A rectangular grid | `[[2, 1], [0.5, 0]]` | `(2, 2)` |
| Tensor | A general numerical array; it may have any number of axes | Two histories, three rows each, two features per row | `(2, 3, 2)` |

An **axis** is a direction along which you index the array. A **shape** records the length of each axis. A matrix with two rows and three columns has shape `(2, 3)` and contains `2 × 3 = 6` numbers. A tensor with shape `(2, 3, 2)` contains `2 × 3 × 2 = 12` numbers.

“Tensor” does not mean a mysterious kind of number. A PyTorch tensor is a software object that stores values, their shape and properties such as numerical type and where computations occur. A **floating-point** value supports approximations to decimal numbers. An **integer** stores a whole number, often used for category indices. A **Boolean** stores true or false, useful for masks. Type matters: a category lookup expects valid integer addresses.

A **batch** groups examples so the computer can process them together. Suppose two examples each contain one current transaction plus two earlier slots, with two continuous features per transaction. Their continuous tensor has shape:

`(B, T, C) = (2, 3, 2)`.

Here `B` is batch size, `T` is the number of transaction positions including the target, and `C` is the count of continuous features. These letters are labels, not fixed universal values. Another file may use different letters. Always identify the meaning before manipulating the shape.

## Follow an exact shape transformation

Imagine the continuous values are:

```text
Example 0: [[0.2, 1.0], [0.8, 0.0], [2.0, 1.0]]
Example 1: [[0.0, 0.0], [0.0, 0.0], [0.5, 0.0]]
```

This is a synthetic `(2, 3, 2)` array. Example 1's first two slots are placeholders in this illustration. A separate **mask** says which slots are real:

```text
Example 0: [True, True, True]
Example 1: [False, False, True]
```

The mask has shape `(2, 3)`. Merely seeing zeros cannot tell you whether a slot is padding or a real transaction with zero-valued transformed features. The mask carries that distinction.

**Reshape** changes how the same values are grouped. Flattening the first two axes changes `(2, 3, 2)` into `(6, 2)`: six transaction slots with two features each. Both shapes contain 12 numbers. It does not average them, remove them or learn anything. After a per-transaction operation, the program can regroup the slots by example.

**Concatenation** joins arrays along an existing axis. Joining two continuous feature vectors and three categorical feature vectors for each transaction gives five feature vectors, provided their other dimensions agree. **Stacking** introduces a new axis. You will see both operations in the tokenizer code later.

**Broadcasting** lets a smaller array participate in a calculation across matching positions of a larger array. For example, adding `[10, 20]` to every row of `[[1, 2], [3, 4]]` gives `[[11, 22], [13, 24]]`. The program reuses the two offsets for each row. Broadcasting is convenient, but a mistaken shape can silently apply values to the wrong axis. Always explain the intended meaning, not just whether the program runs.

## A dot product is a weighted total

A **dot product** multiplies matching entries of two equal-length vectors and adds the products. For inputs `[2, 1]` and weights `[0.5, −0.5]`:

`2 × 0.5 + 1 × (−0.5) = 1 − 0.5 = 0.5`.

The order matters: the amount weight must multiply the amount input. Swapping column order while keeping weights fixed changes the calculation. This is one reason the project needs a stable feature order.

A **matrix multiplication** performs many such weighted totals. If a layer needs two outputs from two inputs, it can use two rows of weights:

```text
Input:       [2, 1]
Weight row 1: [ 0.50, -0.50] →  0.50
Weight row 2: [-0.25,  1.00] →  0.50
```

Each output is a separate dot product. Adding a bias to each output completes what the project often calls a linear layer. The term “linear” is conventional in code even when a bias makes the full operation affine in strict mathematics. You only need the calculation: weighted totals plus offsets.

A CPU is a general-purpose processor. A GPU can perform many suitable numerical operations in parallel, making large batches of matrix calculations faster. It does not supply labels, decide whether an experiment is fair, or make the underlying method correct. The small arithmetic in this chapter can be done on paper or a CPU while GPUs are unavailable.

## Read a miniature loop

A **loop** repeats instructions. An `if` statement chooses instructions based on a condition. This conceptual example combines both:

```python
scores = [0.2, 0.8, 0.6]
alerts = 0
for score in scores:
    if score >= 0.6:
        alerts = alerts + 1
```

Start at zero alerts. `0.2` is below the threshold, so the count stays zero. `0.8` qualifies, so it becomes one. `0.6` also qualifies because `>=` means “greater than or equal,” so the final count is two. `==` checks equality in Python; it differs from assignment `=`.

A **class** groups related state and functions. A model class can hold its weights and provide a `forward` method to compute outputs. `self` means the current instance of that class. You do not need to write an entire class now; recognizing these roles makes repository code easier to read.

## Where this appears in the actual project

- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.forward`, lines 146–156: reads named batch entries, unpacks `(B, T, C)`, reshapes transaction slots and later restores their grouping. Lines 161–164 expand a transaction mask into a feature-token mask.
- `waqas/phase4a/tokenizer.py`, `FeatureTokenizer.forward`, lines 32–40: transforms numerical values, looks up categorical representations and concatenates the results. This chapter explains the array operations; Chapter 08 explains their modeling purpose.
- `fraud/data/feature_list.py`, `FeatureList.all_features`, lines 35–37, and `load_feature_list`, lines 80–90: records a consistent continuous/categorical ordering and selects the requested feature version.

## Common wrong mental model

**Wrong:** “A tensor with more dimensions contains more advanced intelligence.”

**Repair:** Axes organize values. A `(B, T, C)` tensor explicitly records examples, transaction positions and features. Intelligence is not added by reshaping an array. Similarly, making category codes larger does not give those categories more meaning.

## Your shape-detective challenge

**Predict:** Three examples each contain four historical slots plus the target, and each transaction has six continuous features. Give the continuous tensor's shape and its total number of stored values. How many labels are needed if you predict only the target of each example?

**Repair:** A colleague changes `(3, 5, 6)` to `(15, 6)` and says the dataset has gained 12 new customers. Explain what actually happened.

**Teach back:** Calculate the two weighted totals above without looking, then explain input, weight and bias using one sentence each.

<details><summary>Open after attempting: answers and repair hints</summary>

The shape is `(3, 5, 6)` because the four historical slots plus the target make five transaction positions. It stores `3 × 5 × 6 = 90` continuous values, including any padded slots. Target-only prediction needs three labels, one per example. The reshape stores the same 90 values as 15 transaction slots; it creates no new information or customers.

The weighted totals are both `0.5`: `2 × 0.5 + 1 × (−0.5)` and `2 × (−0.25) + 1 × 1`. Inputs describe the example. Weights control how inputs contribute to a calculation. Biases shift calculated values even when inputs are zero.

If you gave 15 labels, you confused transaction positions with target predictions. Some later models can supervise more positions, but that is an explicit change in the task, not a consequence of storing a history tensor.

</details>

**Recall without looking:** explain `(B, T, C)` to someone who has never programmed. Then name one thing a reshape preserves and one thing it changes. **Repair route:** repeat this chapter's tiny examples for arithmetic or shape confusion; revisit Chapter 01 for examples versus rows; continue to Chapter 03 to turn weighted totals into a neural network.


---

# 03 — Build a neural network you can calculate by hand

## Start with something you already know

**Prerequisite refresher:** an input vector is an ordered list of values. A weight multiplies an input; a bias adds an offset. A dot product adds matching input–weight products. A batch groups examples without changing what each example means.

Your question is: **What is a neural network actually doing when it produces a score?**

The name can make the idea sound more mysterious than it is. A **neural network** is a collection of connected numerical calculations with adjustable parameters. One calculation produces values that feed the next. Training adjusts the parameters so those calculations become more useful for a task.

The word “neural” is historical inspiration, not a claim that this software thinks like a human brain. For this project, you can picture a trainable calculation pipeline. Once you understand one small pipeline, the larger model becomes a question of organizing more calculations, not an entirely different kind of magic.

## One unit: weighted total, then activation

A simple **unit**, sometimes called a neuron, first calculates a weighted total plus a bias. It then applies an **activation function**, a rule that transforms that total. An activation can change which patterns a network is able to represent.

Our teaching network uses **ReLU**, short for rectified linear unit. Its rule is easy:

`ReLU(a) = a if a is positive; otherwise 0`.

So `ReLU(2) = 2`, `ReLU(−3) = 0`, and `ReLU(0) = 0`. The symbol `a` is just the number entering that activation.

Why transform a perfectly good weighted total? If you keep stacking only weighted totals and biases, the entire stack can be collapsed into one weighted-total calculation. Nonlinear activations, such as ReLU, break that restriction and allow more varied input–output patterns. **Nonlinear** here means the transformation is not one straight-line relationship across its full input range.

ReLU is a teaching choice, not a claim that every component of this project's Transformer uses it. The current A encoder explicitly uses another activation, GELU, which makes a smoother transformation rather than a hard cut at zero. The detailed Transformer computation comes in Chapter 09. The central idea is the same: combine values, then apply transformations that permit richer relationships.

## Our complete fictional model

We will follow one invented transaction through a network small enough to do by hand. It has:

- Two inputs: `x1 = 2`, a fictional amount measured in hundreds, and `x2 = 1`, a fictional online-channel flag.
- Two intermediate units, called a **hidden layer** because these are internal values rather than observed labels or final outputs.
- One final learned raw score and one fixed reference raw score, which together produce a fraud score.

This is conceptual teaching arithmetic. The real project has more inputs, learned feature representations and Transformer blocks. In particular, its current preprocessing is not “divide every amount by 100,” and its categorical features use learned lookup representations rather than this example's simple flag rule.

Here are all nine adjustable parameters in our tiny network:

| Calculation | Weight on first input | Weight on second input | Bias |
|---|---:|---:|---:|
| Hidden unit 1 | 0.50 | −0.50 | 0 |
| Hidden unit 2 | −0.25 | 1.00 | 0 |
| Fraud raw score, using the two hidden values | 1.00 | 2.00 | −0.50 |

The parameters are chosen by hand for this lesson. A real training run starts from an initialization procedure and learns parameter values. A learned weight's meaning depends on the rest of the model and the input transformation; it is rarely a direct standalone business explanation.

## Step 1: calculate hidden unit 1

Call the weighted total before activation `a1`:

`a1 = 0.50 × x1 + (−0.50) × x2 + 0`.

Insert our values:

`a1 = 0.50 × 2 − 0.50 × 1 = 1 − 0.5 = 0.5`.

Apply ReLU to get hidden value `h1`:

`h1 = ReLU(0.5) = 0.5`.

The distinction between `a1` and `h1` matters. `a1` is the input to the activation. `h1` is its output. They happen to match here because `a1` is positive. If `a1` had been `−0.5`, `h1` would have been zero.

## Step 2: calculate hidden unit 2

`a2 = (−0.25) × x1 + 1.00 × x2 + 0`.

`a2 = −0.25 × 2 + 1 × 1 = −0.5 + 1 = 0.5`.

`h2 = ReLU(0.5) = 0.5`.

The hidden representation of this transaction is now the vector `[0.5, 0.5]`. These are not new measured facts about the customer. They are intermediate values calculated from the inputs using the current parameters. Another set of parameters could represent the same transaction differently.

This is the seed of the **representation learning** idea: the model learns useful internal ways to encode inputs, as part of learning its final prediction task.

## Step 3: calculate the raw output

Call the fraud raw score `z1`:

`z1 = 1.00 × h1 + 2.00 × h2 − 0.50`.

`z1 = 1 × 0.5 + 2 × 0.5 − 0.5 = 1.0`.

For this tiny example only, set the non-fraud raw score `z0 = 0`. The output vector is `[z0, z1] = [0, 1]`.

A raw class score is called a **logit**. A logit can be any real number, including a negative number or a number larger than one. It is not yet a probability. The project's classifiers generally produce two logits per example, with both learned through their prediction head. We fixed one to zero only to make our arithmetic manageable.

A **prediction head** is the final part of the model that turns its internal representation into task outputs. The earlier calculations are often called the **backbone**. In this example, the two hidden units form the tiny backbone, and the last weighted total forms the head.

## Step 4: turn two logits into two class scores

**Softmax** turns a vector of logits into positive values that sum to one. For two classes, its fraud output is:

`p = exp(z1) ÷ [exp(z0) + exp(z1)]`.

`exp(a)` means the exponential of `a`, also written `e` raised to the power `a`. The constant `e` is approximately 2.71828. You do not need to derive it; a calculator provides `exp`. Useful values are `exp(0) = 1` and `exp(1) ≈ 2.71828`. Exponentials convert any finite logit into a positive number, and dividing by their total makes the class scores sum to one.

For `[0, 1]`:

`p = 2.71828 ÷ (1 + 2.71828) ≈ 0.73106`.

The non-fraud output is `1 ÷ 3.71828 ≈ 0.26894`. Their sum is one, apart from rounding.

For two logits, the same fraud score can be written:

`p = 1 ÷ [1 + exp(−(z1 − z0))]`.

That function is called the **sigmoid** of the logit difference. This is why some binary models use one logit and a sigmoid while others use two logits and softmax. Our actual project uses two-output classification paths. The algebra helps you recognize their relationship without assuming their training implementations are identical.

Softmax depends on relative logits. `[0, 1]` and `[10, 11]` produce the same class scores because their difference is the same. The magnitude of one logit alone is not enough to interpret a two-logit output.

## What has, and has not, happened

The complete **forward propagation**, often called a forward pass, was:

`[2, 1] → [a1, a2] = [0.5, 0.5] → [h1, h2] = [0.5, 0.5] → logits [0, 1] → fraud score 0.73106`.

“Propagation” means values are passed through the connected calculations. No parameter changed. No label was needed to calculate this score. We have computed a prediction, not performed a learning step.

If a fictional review policy flags scores at least 0.70, this example is flagged. At a threshold of 0.80, it is not. The network's parameters and output are identical in both cases; only the action policy changed.

The value 0.73106 lies on a probability scale, but calibration still needs checking. It does not by itself prove that roughly 73% of similar real-world transactions are fraudulent. It certainly does not prove that this one transaction is fraudulent.

## A small change you can predict

Keep the parameters fixed but change the channel flag from `1` to `0`, holding `x1 = 2`.

Hidden unit 1 receives `0.5 × 2 − 0.5 × 0 = 1`, so `h1 = 1`. Hidden unit 2 receives `−0.25 × 2 + 1 × 0 = −0.5`, so ReLU makes `h2 = 0`. The fraud logit becomes `1 × 1 + 2 × 0 − 0.5 = 0.5`. The fraud score becomes `1 ÷ [1 + exp(−0.5)] ≈ 0.62246`.

The input change affected different hidden units differently. One rose; the other dropped to zero. Their combined effect lowered the fraud score. This illustrates why interpreting a hidden network through one isolated weight can be misleading. It also illustrates why a network can be calculated exactly, even when it contains several moving parts.

## How this becomes the project's much larger model

The project shares the same broad pattern: inputs become internal numerical representations, several learned transformations combine them, and a head emits class logits. It uses **feature tokens**, one representation per feature, and **attention**, a learned way to combine information across representations. Those terms are previews; Chapters 08 and 09 explain their mechanics with their own worked examples.

Actual implementation connections:

- `src/pytorch_tabular/models/base_model.py`, `BaseModel.forward`, lines 396–404: the reference path explicitly calls input embedding, backbone computation and the head. `compute_head`, lines 383–394, constructs the output.
- `src/pytorch_tabular/models/ft_transformer/ft_transformer.py`, `FTTransformerModel._build_network`, lines 113–119: builds those three parts. `FTTransformerBackbone.forward`, lines 69–82, processes representations through its blocks and selects a summary representation.
- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 51–68: A creates its input representation machinery, Transformer encoder, linear two-output head and loss. Its `forward`, lines 146–173, ends by returning head logits. It does not end by making a business decision.

These are architecture facts. They do not turn our two-unit arithmetic exercise into an execution of the project model.

## Common wrong mental model

**Wrong:** “A neural network means every unit corresponds to an understandable fraud rule, and forward propagation improves those rules.”

**Repair:** Hidden units carry intermediate calculations that need not correspond to named rules. A forward pass calculates outputs using current parameters. Learning requires a label-based loss and a parameter-update procedure, which Chapter 04 will teach.

## Your prediction challenge

**Predict:** With the original parameters, calculate both hidden values for `[x1, x2] = [0, 0]`. Then calculate the logits and fraud score. You may use `exp(0.5) ≈ 1.64872`.

**Repair:** Someone calls `z1 = 1.0` a “100% fraud probability.” Explain the missing step and give the actual probability-scale score for our original `[0, 1]` logits.

**Teach back:** Without using the word “AI,” explain a neural network, a hidden representation and a forward pass to a colleague.

<details><summary>Open after attempting: worked answer and rubric</summary>

Both hidden weighted totals are zero, so both hidden outputs are zero. The fraud logit is `−0.5`, and the reference logit is zero. The fraud score is `1 ÷ [1 + exp(0.5)] ≈ 0.37754`. Zero-valued inputs do not require a zero logit because the head has a bias.

A logit is an unrestricted raw score. Softmax converts the two logits `[0, 1]` into about `[0.26894, 0.73106]`. Calling `1.0` “100%” skips that transformation and ignores the other class logit.

A good teach-back describes connected adjustable calculations, intermediate numerical representations and the passage of inputs through those calculations. It explicitly says that a forward pass alone does not update the parameters. If you forgot an activation, place separate boxes for weighted total and activation on your drawing.

</details>

**Recall without looking:** draw this network and recreate the original score 0.73106 from its nine parameters. **Repair route:** Chapter 02 for weighted totals or vectors; this chapter for logits and forward propagation; Chapter 04 for learning; Chapters 08–11 for the actual model's representations and structure.


---

# 04 — How a model learns: loss, backpropagation and optimizers

## Pick up the same transaction

**Prerequisite refresher:** our fictional network takes `[2, 1]`, calculates hidden values `[0.5, 0.5]`, produces logits `[0, 1]`, and assigns a fraud score `p ≈ 0.73106`. Its parameters have not changed. A forward pass needs inputs; learning also needs a way to judge its output.

Your question is: **How does “that prediction was wrong” become a specific numerical change to the model?**

Suppose the example's known label is `y = 1`, meaning fraud. Training uses three distinct pieces:

1. A **loss function** assigns a numerical penalty to the prediction relative to the label.
2. **Backpropagation** calculates how that penalty would change if each learned parameter changed slightly.
3. An **optimizer** uses those calculated sensitivities to update the parameters.

Keep the three jobs separate. The loss defines the immediate training objective. Backpropagation calculates gradients. The optimizer decides the update. None by itself establishes that the model will work on new transactions.

## Loss: a penalty that responds to confidence

If we scored predictions only as “right” or “wrong,” a model could move from a fraud score of 0.10 to 0.40 on a fraudulent transaction and get no credit until it crossed a threshold. Training benefits from a penalty that changes smoothly as the score changes.

For an unweighted binary example, **cross-entropy loss** is:

- If the actual label is fraud, `loss = −ln(p)`.
- If the actual label is non-fraud, `loss = −ln(1 − p)`.

`ln` is the **natural logarithm**, the inverse of the exponential used in Chapter 03. If `exp(a) = b`, then `ln(b) = a`. For a probability between zero and one, its logarithm is negative; the minus sign makes the loss positive. You may use a calculator rather than memorize logarithm values.

The core behavior is more important than the notation:

| Probability assigned to the correct class | Loss, approximately |
|---:|---:|
| 0.90 | 0.105 |
| 0.73 | 0.315 |
| 0.50 | 0.693 |
| 0.10 | 2.303 |
| 0.01 | 4.605 |

Confident correct predictions have a small penalty. Confident wrong predictions have a large one. For our fraud example, `−ln(0.73106) ≈ 0.31326`. If the label had been non-fraud with the identical output, the loss would be `−ln(0.26894) ≈ 1.31326`.

For several unweighted examples, an average loss adds their losses and divides by their count. Two fraud examples with scores 0.9 and 0.1 have average loss `(0.10536 + 2.30259) ÷ 2 ≈ 1.20397`. The confident error dominates the average. This number is an optimization objective, not “120% error” and not a direct amount of money lost.

The project supports weighting the fraud class more heavily. A **class weight** changes the loss contribution attached to a label. It differs from a learned network weight and from a review threshold. PyTorch's weighted mean cross-entropy divides by the sum of selected target-class weights, so “multiply fraud loss by ten” alone is not a complete description of batch reduction. The configured V1 A base recipe uses `pos_weight: 1.0`; our arithmetic here is unweighted.

The project passes raw logits into `CrossEntropyLoss`. That function handles the log-probability calculation stably. Do not add an extra softmax before it because this chapter displayed probabilities to explain the arithmetic.

## Gradient: “which way, and how sensitive?”

A **derivative** describes how one quantity changes when another changes by a very small amount. Picture standing on a sloped surface: the slope tells you whether a small move raises or lowers your height. Here the “height” is loss, and a direction is a change in a parameter.

A **gradient** collects the derivative with respect to each parameter. Its sign tells you which direction increases loss locally; its size describes the local sensitivity. If a parameter's gradient is positive, a small increase tends to increase loss, so decreasing the parameter is the downhill direction. If the gradient is negative, increasing the parameter is the downhill direction.

This is a local statement, not a guarantee that an arbitrarily large move improves the model. A surface can curve. The direction that helps near your current position can overshoot if you move too far.

For a binary sigmoid score with unweighted cross-entropy, a useful derivative simplifies to:

`change in loss per small change in fraud logit = p − y`.

For our example, `p − y = 0.73106 − 1 = −0.26894`. The negative sign makes sense: because the example is fraud, increasing its fraud logit should reduce its loss. If its label were zero, the derivative would be `+0.73106`, pointing toward lowering that logit instead.

This formula is the derivative with respect to the single variable logit in our teaching network. The actual two-logit cross-entropy has a derivative for each output logit. For class `k`, it is the predicted class score minus one if `k` is the correct class, otherwise minus zero, before any weighting or reduction factors.

## Backpropagation: trace responsibility backward

**Backpropagation** applies the **chain rule** through the calculation. The chain rule says that when a change travels through a sequence of calculations, multiply the local sensitivities along that path. When one parameter affects the outcome through several paths, add those path contributions.

You already understand a simple chain rule without calculus. If each extra reviewed transaction adds three minutes of work, and expanding a review queue by one batch adds two transactions, that batch adds `2 × 3 = 6` minutes. The two local effects combine by multiplication. Neural networks use derivatives for infinitesimal rather than coarse changes, but the responsibility-tracing idea is similar.

Name our final weights `v1 = 1`, `v2 = 2`, and final bias `c = −0.5`. The fraud logit is:

`z = v1 × h1 + v2 × h2 + c`.

Changing `v1` by a tiny amount changes `z` by that amount times `h1`. Therefore:

`gradient of v1 = (p − y) × h1 = −0.26894 × 0.5 = −0.13447`.

The gradient of `v2` is also `−0.13447`. The gradient of `c` is `−0.26894`, because adding to the bias adds the same amount to `z`.

Now trace backward into the hidden units. A small change in `h1` is multiplied by `v1 = 1` on the way to `z`, so its loss sensitivity is `−0.26894 × 1 = −0.26894`. A small change in `h2` is multiplied by `v2 = 2`, so its loss sensitivity is `−0.53788`.

Both pre-activation totals are positive in this example. ReLU therefore has local derivative one: a small increase in its input gives the same increase in its output. A negative pre-activation would have derivative zero for this ReLU path; at exactly zero the implementation uses a convention. We chose positive values to avoid that boundary in this worked update.

Finally, hidden unit 1's first weight multiplies `x1 = 2`, so its gradient is `−0.26894 × 1 × 2 = −0.53788`. Its second weight multiplies `x2 = 1`, so its gradient is `−0.26894`. The same method gives every parameter's gradient:

| Parameter | Old value | Gradient on this example |
|---|---:|---:|
| Unit 1 weight on x1 | 0.50000 | −0.53788 |
| Unit 1 weight on x2 | −0.50000 | −0.26894 |
| Unit 1 bias | 0.00000 | −0.26894 |
| Unit 2 weight on x1 | −0.25000 | −1.07577 |
| Unit 2 weight on x2 | 1.00000 | −0.53788 |
| Unit 2 bias | 0.00000 | −0.53788 |
| Head weight on h1 | 1.00000 | −0.13447 |
| Head weight on h2 | 2.00000 | −0.13447 |
| Head bias | −0.50000 | −0.26894 |

All gradients refer to the same old parameter state. Backpropagation does not update a layer and then use its new weights to compute the previous layer's gradients. Mixing old and updated values would change the procedure.

## One complete update with simple gradient descent

An **optimizer** turns gradients into parameter changes. Start with the simplest rule, gradient descent:

`new parameter = old parameter − learning rate × gradient`.

The **learning rate** controls the size of the move. For teaching, choose `0.1`. This is an illustrative setting, not the project's recommended rate.

The first hidden weight becomes:

`0.5 − 0.1 × (−0.53788) = 0.553788`.

Subtracting a negative means adding. Applying the same rule simultaneously to all nine parameters gives:

| Parameter group | New first weight | New second weight | New bias |
|---|---:|---:|---:|
| Hidden unit 1 | 0.553788 | −0.473106 | 0.026894 |
| Hidden unit 2 | −0.142423 | 1.053788 | 0.053788 |
| Head | 1.013447 | 2.013447 | −0.473106 |

Run the same transaction forward again using unrounded update values. The hidden outputs become approximately `[0.661365, 0.822730]`. The fraud logit becomes `1.853675`, the fraud score becomes `0.864558`, and the loss becomes `0.145537`.

The loss for this one training example fell from about `0.313262` to `0.145537`. That is evidence that this toy step helped this example. It is not evidence of improved bank performance, improved recall, or improved predictions on unseen transactions. A change that helps one example can harm another. Training on batches combines their gradient contributions, and evaluation checks whether the learned behavior transfers.

## What AdamW adds in the actual project

The current default optimizer is **AdamW**, not the simple gradient-descent rule we just used. Understanding the simple rule makes AdamW's purpose easier to see.

AdamW keeps two moving summaries for each parameter:

- An average of recent gradients, which carries a sense of direction and smooths fluctuations.
- An average of recent squared gradients, which estimates the scale of that parameter's recent gradients.

A moving average combines an older summary with a little of the new value. If the old gradient average is `0.2` and the new gradient is `0.6`, a 90%/10% blend is `0.9 × 0.2 + 0.1 × 0.6 = 0.24`. It remembers earlier steps while responding to the latest one.

To **square** a number, multiply it by itself: `0.6² = 0.6 × 0.6 = 0.36`. Squaring `−0.6` also gives `0.36`. A **square root** reverses that operation for a nonnegative number: `sqrt(0.36) = 0.6`. Averaging squared gradients tracks their size even when positive and negative gradients would cancel in their ordinary average.

The update uses the first summary divided by the square root of the second, with a tiny stabilizing number in the denominator. A correction accounts for the fact that these moving summaries start at zero. **Momentum** refers broadly to carrying information from previous gradient directions. **Adaptive** means Adam adjusts its effective step scaling separately for parameters based on their gradient history.

For an optional concrete first-step calculation, take our first weight's gradient `g = −0.53788`. With conventional Adam defaults, the first moving average is `m = 0.1 × g`, and the first squared-gradient average is `v = 0.001 × g²`. Correcting their zero-start bias recovers `g` and `g²`. Ignoring the tiny stabilizer, the normalized direction is `g ÷ sqrt(g²) = −1`. With the illustrative learning rate `0.1`, the gradient part of the update therefore adds approximately `0.1`, rather than gradient descent's `0.053788`.

The **W** refers to **decoupled weight decay**. This separately shrinks parameters toward zero in proportion to the learning rate, decay setting and current value. With teaching values `weight = 0.5`, learning rate `0.1`, and decay `0.01`, that shrinkage is `0.1 × 0.01 × 0.5 = 0.0005`. Combining the illustrative first Adam step and decay gives approximately `0.5 − 0.0005 + 0.1 = 0.5995`. This is a single-parameter demonstration; it is not the full-network update calculated in the table above.

Weight decay can discourage unnecessarily large parameters. It does not guarantee generalization, remove data leakage or automatically pick the right model. AdamW is an update algorithm, not a separate fraud classifier.

The A base configuration uses learning rate `0.0003` and decay `0.00001`. The reference builder's defaults use learning rate `0.001` and decay `0.00001`. Actual experiment overrides must still be checked; a default is not proof of every executed setting.

## The learning loop and the controls around it

Conceptual teaching pseudocode:

```python
for batch in training_batches:
    optimizer.zero_grad()
    logits = model(batch_inputs)
    loss = cross_entropy(logits, batch_labels)
    loss.backward()
    optimizer.step()
```

`zero_grad()` clears earlier stored gradients. The forward pass produces logits. The loss compares them with labels. `backward()` calculates gradients by automatic differentiation, which records the calculation graph and applies the relevant derivative rules. `step()` updates parameters. Libraries such as PyTorch and the project's training framework automate these operations; automation does not change their meaning.

A **training step** commonly means one optimizer update, though logs can also count batches. **Gradient accumulation** deliberately combines gradients from several smaller batches before an update. That is why clearing gradients after every tiny batch is not always the intended implementation. An **epoch** is one intended pass through the training examples; streaming loaders and limits require checking actual coverage.

A **learning-rate scheduler** changes the learning rate during training. The current A scheduler reduces the rate when validation loss stops improving according to its rules. **Early stopping** ends training when the monitored development measure fails to improve sufficiently. A **checkpoint-selection rule** decides which saved state to keep. These are distinct controls and may monitor different quantities. Chapter 12 will trace the actual training configuration and its validation metrics.

**Overfitting** means adapting too closely to training-specific patterns so performance on other relevant examples suffers. Falling training loss is compatible with overfitting. A model that memorizes known examples has not necessarily learned a useful general rule.

## Actual implementation anchors

- `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 63–68: two-output head and optional weighted cross-entropy. `_step` and `training_step`, lines 181–191: calculate logits, labels and loss. `configure_optimizers`, lines 197–201: builds the optimizer and a `ReduceLROnPlateau` scheduler monitored on `valid_loss`.
- `waqas/phase4a/optim.py`, `build_optimizer`, lines 19–34: selects the named optimizer; lines 9–15 map `adamw` to PyTorch AdamW. Available names are implementation options, not evidence that alternatives have improved this project's results.
- `waqas/phase4a/configs/sequential.yaml`, `training`, lines 60–78: records A's base training settings, including AdamW, learning rate, decay, class weight and early-stopping monitor. A scheduler's `valid_loss` monitor is distinct from the configured checkpoint/early-stopping `valid_ap` monitor.
- `waqas/base/streaming_model.py`, `build_streaming_model`, lines 54–70 and 88–115: specifies reference optimizer defaults, scheduler configuration and optional class-weighted loss.

## Common wrong mental model

**Wrong:** “Backpropagation is the optimizer, lower loss proves higher fraud recall, and scoring keeps improving the model.”

**Repair:** Backpropagation computes gradients. The optimizer uses them to change parameters during training. Loss and recall answer different questions. Ordinary scoring calculates outputs from fixed parameters. Each distinction matters when you explain what a run actually did.

## Your learning-step challenge

**Predict:** A parameter is `0.4`, its gradient is `+0.6`, and the learning rate is `0.05`. What does one simple gradient-descent step produce? Explain the direction before calculating.

**Repair:** A colleague reduces the review threshold and says, “I retrained the network.” Explain what changed, and name what a real learning step requires.

**Teach back:** Explain the original toy example's journey from fraud label to lower training loss. Include the loss, the sign of `p − y`, the chain rule and the optimizer. Then give one reason that this is not yet evidence of better performance on future data.

<details><summary>Open after attempting: answers and rubric</summary>

A positive gradient points toward increasing loss if the parameter increases. Gradient descent therefore lowers it: `0.4 − 0.05 × 0.6 = 0.37`. Changing the review threshold changes which scores trigger action, not learned parameters. A learning step requires a training objective, gradient calculation and a parameter update, with the relevant inputs and supervision.

For the toy fraud example, cross-entropy loss is `−ln(p)`. The derivative `p − y` is negative, so increasing the fraud logit locally helps. The chain rule traces that sensitivity through the head and hidden units to each weight and bias. The optimizer then updates parameters. A second forward pass shows lower loss for that example. This may fail to transfer because other transactions differ, because the example is not representative, or because the model overfits training data.

If you said the gradient itself changes the weights, separate the gradient table from the update table. If you used the new head weight when deriving an old hidden gradient, repeat the rule that all gradients come from the same forward calculation state.

</details>

**Recall without looking:** give a sixty-second explanation of forward pass, loss, backpropagation and optimizer as four separate jobs. Then recreate one gradient from the network drawing. **Repair route:** Chapter 03 for the forward values; Chapter 02 for multiplication or signs; this chapter for gradients; Chapter 12 for training controls; Chapters 14–15 for what evidence is needed beyond training loss.


---

# 05 — Decide what the model is allowed to know

**Your question:** When we ask, “Is this transaction fraudulent?”, which facts may we show the model, and which facts must we hide?

**Prerequisite refresher.** A feature is an input used to make a prediction. A label is the answer used to teach or judge it. A model's weights are adjustable numbers; training changes them to reduce a loss, a numerical measure of prediction error. You do not need to calculate a gradient in this chapter. You need the distinction between *information used to predict* and *information used afterward to check the prediction*. Repair that distinction in Chapter 01 if necessary.

Imagine you are standing beside a payment terminal. The clock says **10:00:12**. A transaction arrives for **150 currency units**. Your job is to decide now. A customer complaint received tomorrow cannot travel backward in time to help today's decision. Much of this project is the work of enforcing that apparently simple rule.

All transactions and numbers in this chapter's worked examples are invented. They are not bank records or project performance results.

## The row we will follow

Our synthetic account is **Ember**. The transaction we want to score is **Target**, at **2026-10-15 10:00:12**. The account also has these records:

| Synthetic record | Account | Recorded time | Amount | What it means for Target |
|---|---|---|---:|---|
| Old | Ember | 09:59:50 | 20 | Earlier information |
| Recent | Ember | 10:00:05 | 40 | Earlier information |
| Peer | Ember | 10:00:12 | 900 | Same recorded instant; order unknown |
| Target | Ember | 10:00:12 | 150 | The transaction to predict |
| Later | Ember | 10:00:20 | 800 | Future information |
| Other | Cedar | 10:00:04 | 10 | Another account's transaction |

For the current A/B **strict history rule**, Target may use Old and Recent. A and B are the two history-model designs explored in Chapters 10 and 11. Target may not use Peer, Later, or Other. “Strict” means an earlier timestamp, rather than an earlier row in a sorted table. In the bank's whole-second data, two events recorded at 10:00:12 have the same time. Sorting their identifiers alphabetically makes the file reproducible; it does not establish which event was available first.

There are two distinct facts here. Target's own amount is allowed because this is the transaction being assessed. Target's own eventual fraud label is withheld from prediction. The current transaction is an input; its answer is not.

## A label is an outcome, with a reporting clock

The configured target column is `frd_tag`. The positive value is `1`, meaning the declared fraud class. The current encoder produces numerical 1 for values equal to the configured positive label and 0 for other observed, nonmissing values. It rejects missing labels. This is a configurable comparison, so inspecting actual label values and their types matters: a text value and a numeric value must not be assumed interchangeable.

In a training example the program carries both inputs and the answer. It first computes a prediction from the inputs, then compares it with the answer to calculate loss. Carrying a label in a training batch is necessary; using that label as a predictive feature would defeat the exercise.

The forward prediction itself does not need an answer. However, the current offline loaders and scoring workflow still read the target column and require nonmissing labels, because they prepare labelled training/evaluation data. A model capable of prediction and a complete production service for unlabeled live payments are different deliverables; this course does not claim the latter already exists.

**Label maturity** is the time needed for an outcome to become sufficiently settled. A purchase might look legitimate on Monday and be disputed later. That gives us two clocks: when the transaction occurred, and when its outcome became known. The project does not feed previous transactions' fraud labels into the ordinary A/B history features. This avoids treating a later investigation as if it had been known at the earlier decision.

That rule does not solve every maturity problem. Training and evaluation still need trustworthy target labels. A recent transaction with an unresolved outcome can make a good score look wrong or a wrong score look good. A loader can verify “the label is present”; it cannot establish “the customer's outcome has finished developing.” No universal maturity delay is proved by the source code. A statement such as “all labels are final after exactly 30 days” would need upstream evidence, so we do not make it here.

**Try the distinction.** On October 15 you score Target. Its final fraud label becomes available on October 29. Can that October 29 label ever be used?

<details markdown="1"><summary>Reveal the reasoning</summary>

Yes, afterward as Target's supervised training answer or evaluation outcome, if the dataset and evaluation design properly account for when labels become available. It cannot be inserted into the October 15 prediction inputs. Whether a past transaction's label is usable as an input in some different system depends on its actual availability at prediction time; this project's ordinary history inputs omit it.

</details>

## Three datasets have three jobs

A **split** is a designated group of examples with a particular role:

| Split | Job | What changes because of it? |
|---|---|---|
| Training | Practice examples with answers | The optimizer adjusts model weights |
| Validation | Check progress and compare planned settings | Decisions such as which saved epoch to keep |
| Evaluation/test | Measure the selected procedure on held-out examples | The reported assessment; it should not become an unlimited tuning target |

“Held out” means withheld from fitting the particular component being assessed. A model can overfit the training examples by learning details that do not carry over to other examples. Validation provides a separate check. Repeatedly choosing settings because they look best on evaluation gradually turns evaluation into another tuning set, even if no optimizer directly reads its labels. Chapter 14 explains how to compare experiments without confusing selection with proof.

The reported V1 experiment specifications use training file numbers **1–10**, validation **4950–4954**, and evaluation **8000–8010**. Inclusive ranges matter: 8000 through 8010 contains **11**, not 10, files, because `8010 - 8000 + 1 = 11`. Base configurations can have different default ranges; the experiment specification's overrides determine the effective run. Chapter 12 explains configuration resolution.

These numbers are **account buckets, not dates**. A bucket is a storage grouping of accounts. File 9 is not “day 9”; file 100 does not mean “a later period than file 10.” Expanding from 10 files to 100 changes the selected account population and amount of data. The number alone does not establish a tenfold transaction count, a longer time horizon, or a proportionate training cost.

The source extract description separates a training period from an evaluation extract containing a later testing month and an earlier history month. The current owner-selected V1 reporting scope uses the supplied training, validation, and evaluation files in their assigned roles and the overall evaluation cohort. Do not silently redefine that cohort while explaining results. It is still useful to understand that account separation and time separation are different properties; neither follows merely from a filename.

## Sampling, splitting, and shuffling are different actions

**Sampling** selects which records or entities to include. Selecting account buckets can preserve much of each selected account's observed sequence. Randomly selecting individual rows can remove the prior transactions that a history model needs. However, even account-based selection does not prove that the extract contains every transaction the account ever made.

**Splitting** assigns included data to training, validation, and evaluation roles. Suppose synthetic Ember has 100 transactions and Cedar has 80. Putting Ember in training and Cedar in evaluation creates an account-separated test. Putting Ember's earlier 70 transactions in training and later 30 in evaluation instead tests a different question: prediction later in time for a previously observed account. Neither description can be substituted for the other.

**Shuffling** reorders examples inside a designated split. It can reduce the chance that successive updates see only one account's very similar transactions. In this project, history windows are formed using chronological rules before the training window buffer is shuffled. Shuffling finished windows does not grant Target access to Later. Shuffling raw rows and then calling the previous table row “history” would be a different, incorrect procedure.

## Four ways information can cross the wrong boundary

**1. Future-feature leakage.** Leakage means information unavailable for the intended prediction enters model construction or assessment in a way that makes performance misleading. If “remaining balance” is accidentally measured after the transaction instead of immediately before it, its meaning has changed. If an investigation outcome is inserted as a predictor, the answer itself has leaked. The feature list describes intended meanings, but code alone cannot certify the upstream system's timing.

**2. History leakage.** Including Later is plainly wrong. Including Peer can also be wrong when its same-second ordering is unknown. An identifier can order records consistently without ordering their real-world availability. A/B defaults therefore exclude equal timestamps from Target's history.

**3. Preprocessing leakage.** Preprocessing converts raw values to model inputs. Suppose the training amounts are 50 and 150, whose mean is `(50 + 150) / 2 = 100`. A held-out amount of 1,000 changes the combined mean to `1,200 / 3 = 400`. If you calculate the mean using all three values, training now uses a scale influenced by held-out information. No label was needed for this boundary violation. Chapter 06 shows why the fitted conversion rules are saved and reused.

**4. Repeated-transaction leakage.** If the same transaction appears in both training and evaluation, a strong evaluation score may partly measure familiarity. Account overlap and repeated-transaction overlap are different checks. A shared account can have genuinely different transactions; a repeated account-plus-transaction identity can be the same target appearing twice. The preflight code reports both properties.

An account-disjoint evaluation can still have preprocessing leakage. A correctly frozen preprocessor can still receive future features. A strict history builder can still operate on labels whose maturity is unknown. These checks answer different questions; passing one does not answer all the others.

## Where this is implemented

Use these as source coordinates in the private project snapshot; this course does not include raw bank files.

| Claim to inspect | Source and checked lines |
|---|---|
| Nonmissing labels, account membership, and parseable time are checked before encoding | `waqas/base/data/input_contracts.py`, `encode_binary_target`, `require_account_ids`, `parse_required_timestamps`, lines 13–60 |
| A only selects strictly earlier history by default | `waqas/phase4a/sequence_builder.py`, constructor and `_windows_for_file`, lines 164–192 and 280–321 |
| B's ordinary single-target windows use the corresponding rule | `waqas/phase4b/sequence_builder.py`, `_windows_for_file`, lines 367–414 |
| V1 reference cohort and seed are explicit overrides | `waqas/base/configs/ref_single.yaml`, lines 20–34 |
| Artifact fitting provenance is checked against held-out files | `runbook/2026-10-07/preflight_pod.py`, `check_artifacts`, lines 1013–1027 |
| Account overlap and transaction overlap are distinct reports | `runbook/2026-10-07/preflight_pod.py`, lines 1250–1268 |

The older `fraud/` implementation and the corrected older sequence reference are not interchangeable with the current A/B builders. Some older paths select the previous rows in sorted order. When someone says “the project is causal,” ask which loader, configuration, and model mode they mean. Chapter 07 makes this precise.

## Checkpoint: defend the boundary

**Predict.** If Peer gets a smaller identifier than Target, should it enter Target's strict history?

**Repair.** A colleague fits category dictionaries using training plus evaluation, then says this is harmless because they never used evaluation labels. Explain the repair.

**Teach back.** In four sentences, explain training, validation, evaluation, and why a bucket number cannot prove temporal separation.

<details markdown="1"><summary>Answers and a self-check rubric</summary>

Peer stays excluded: its timestamp is still equal, and an identifier is not evidence of availability. Fit category dictionaries and numerical statistics on the designated fitting data, save them, and apply those saved rules to held-out examples. A valid teach-back assigns a distinct role to each split and says that account buckets are storage groups rather than calendar periods. Give yourself one point for each of those four facts. Below four, revisit “Three datasets have three jobs” and “Sampling, splitting, and shuffling.”

</details>

**Recall without looking:** Draw the decision clock, put the current features on one side and eventual label on the other, then name one leakage path that strict history alone cannot prevent. If features and answers blur together, repair Chapter 01. If fitting preprocessing is unclear, continue to Chapter 06 and return here afterward.


---

# 06 — Turn the 23 predictors into consistent model inputs

**Your question:** How does a transaction containing amounts, codes, missing values, and a date become numbers a neural network can use?

**Prerequisite refresher.** A row is one transaction. Features are the fields allowed to help predict its outcome. Training data teaches the model; held-out data assesses it. Learned conversion rules must be fitted on the designated fitting data, then reused. Chapter 05 explains why calculating those rules afresh on evaluation data changes the experiment.

**Preprocessing** is the conversion between the original record and the model's input numbers. It is not the neural network learning a fraud rule. For example, turning the category “card absent” into integer 3 is preprocessing; learning what that category suggests in combination with amount and history belongs to the model.

We will continue the invented **Target** transaction from Chapter 05: account Ember, **2026-10-15 10:00:12**, amount **150**. All values, category names, dictionaries, and statistics below are synthetic teaching examples, not actual bank encodings.

## The complete original input list

The source of truth for the original version is `fraud/configs/predictors.csv`. It lists **6 continuous**, **13 raw categorical**, and **4 derived calendar** features: `6 + 13 + 4 = 23`.

**Continuous** means numerical magnitude is meaningful. A balance of 200 is twice a balance of 100, if the units match. **Categorical** means a value names a kind or state. Category code 7 is not necessarily “more” than category code 3. The model uses a separate learned lookup representation for categories, introduced in Chapter 08.

| # | Original feature | Meaning you should be able to explain | Synthetic Target value |
|---:|---|---|---|
| 1 | `transaction_amt` | Amount in the transaction currency | 150 |
| 2 | `external_1_scr` | An externally supplied card-network fraud-risk score; a pre-existing signal, not this model's answer | Missing |
| 3 | `avlble_merch_day_cash_lmt_amt` | Available daily merchandise limit, as described in the predictor list | 800 |
| 4 | `available_daily_cash_limit_amt` | Remaining daily ATM cash limit before this transaction | 200 |
| 5 | `remain_day_merchandise_lmt_amt` | Remaining daily merchandise limit before the transaction, documented in USD | 700 |
| 6 | `total_available_balance_amt` | Available balance for the accessed account immediately before the transaction | 2,000 |
| 7 | `transaction_type_xcd` | Transaction type | `PURCHASE` |
| 8 | `segment` | Transaction category/group | `RETAIL` |
| 9 | `transaction_category_xcd` | Method used for the transaction | `ONLINE` |
| 10 | `transaction_pos_condition_xcd` | Point-of-sale/service conditions; POS means point of sale | `REMOTE` |
| 11 | `avs_request_xcd` | Address Verification Service request indicator | `REQUESTED` |
| 12 | `pos_security_xflg` | Transaction security indicator | `SECURE` |
| 13 | `transaction_pin_verify_xcd` | Personal identification number verification information | Missing |
| 14 | `cardholder_present_xflg` | Whether the cardholder was present | `ABSENT` |
| 15 | `pos_card_capture_xflg` | Terminal's capability to retain a card | `NO` |
| 16 | `cvv_verify_xcd` | Card Verification Value outcome for the entry mode | `NEW_OUTCOME` |
| 17 | `authzn_rqst_crypto_valid_xflg` | Authorization-request cryptogram result; a cryptogram is a transaction security value | `VALID` |
| 18 | `pos_off_premises_xflg` | Off-premises terminal indicator | `NO` |
| 19 | `pos_terminal_attend_xflg` | Unattended-terminal indicator | `UNATTENDED` |
| 20 | `month` | Month derived from the transaction timestamp | 10 |
| 21 | `day` | Day of month derived from the timestamp | 15 |
| 22 | `hour` | Hour derived from the timestamp | 10 |
| 23 | `day_of_week` | Monday = 0 through Sunday = 6 | 3, Thursday |

The names can be awkward. Learn the meaning before memorizing spelling. Do not invent extra precision the feature description does not provide. For example, the available-merchandise-limit description does not establish every accounting relationship among the three limit fields. Transaction amount and one limit also explicitly use different currency descriptions, so a raw ratio is not automatically meaningful. The published predictor list specifies the original features; adding merchant categories or engineered ratios belongs to a separately checked feature change.

Neither the account identifier nor transaction identifier is one of these 23 features. They support grouping, ordering, or matching output records. The raw timestamp is an ordering source and generates calendar features; it is not itself one of the original 23 predictive fields. The fraud label is the answer, also outside this list.

## First conversion: replace a missing number

**Imputation** means filling a missing input with a defined substitute. The saved continuous statistics use the **median**, the middle observed value after sorting. For observed values `[20, 40, 60, 80, 100]`, the median is 60. It is not a guess that the true missing value was definitely 60; it is a consistent way to make the numeric input usable.

The **mean** is the total divided by the number of observations. The same five values have mean `(20 + 40 + 60 + 80 + 100) / 5 = 60`. The median and mean need not match. For `[20, 40, 60, 80, 1000]`, the median stays 60 but the mean becomes 240. The middle is less moved by that one extreme amount.

If all values for a continuous feature are missing in the fitting data, the helper falls back to a fill and mean of zero. If the stored standard deviation is zero or undefined, it uses 1. Those are implementation fallbacks, not evidence that an all-missing field is informative.

Target's external score is missing. Suppose the **saved training-derived median is 480**. Its imputed score becomes 480. We also preserve the fact that it was missing with a separate indicator, explained shortly.

## Second conversion: put numbers on a consistent scale

**Standardization** expresses a value relative to a saved center and spread:

`standardized value = (filled value - saved mean) / saved standard deviation`

The **standard deviation** is a measure of typical distance from the mean. You need its practical role here before memorizing its full formula: a larger deviation means values vary more. The preprocessing helper calculates it from the nonmissing fitting values using the population convention: add the squared deviations, divide by the number of observed values, then take the square root.

With values `[50, 150]`, mean is 100. Deviations are `[-50, 50]`; squared deviations are `[2500, 2500]`. Their average is 2500. The square root is 50, so the population standard deviation is 50. The standardized values are then -1 and +1. Negative standardized amount does **not** mean a negative payment; it means below the saved mean.

Here is a complete synthetic conversion for Target's six numerical predictors. We deliberately choose simple saved statistics to expose the arithmetic.

| Field | Raw | Saved median | Saved mean | Saved standard deviation | Model number |
|---|---:|---:|---:|---:|---:|
| Amount | 150 | 100 | 100 | 50 | `(150 - 100) / 50 = 1` |
| External score | Missing | 480 | 500 | 100 | `(480 - 500) / 100 = -0.2` |
| Available merchandise limit | 800 | 600 | 600 | 200 | `(800 - 600) / 200 = 1` |
| Remaining cash limit | 200 | 300 | 300 | 100 | `(200 - 300) / 100 = -1` |
| Remaining merchandise limit | 700 | 500 | 500 | 100 | `(700 - 500) / 100 = 2` |
| Available balance | 2,000 | 1,000 | 1,000 | 500 | `(2000 - 1000) / 500 = 2` |

Target's six-number continuous vector is therefore `[1, -0.2, 1, -1, 2, 2]`. A **vector** is an ordered list of numbers. Order matters: swapping external score and balance changes what the numbers mean to the model.

Standardization does not force values between 0 and 1, remove outliers, or prove that all features now have equal predictive importance. A value can legitimately standardize to 8. The network still has to learn which patterns matter.

## Missing versus unfamiliar categories

A **vocabulary** is a saved dictionary from a category's text representation to an integer index. Each categorical feature has its own dictionary. The implementation reserves:

| Index | Meaning |
|---:|---|
| 0 | Unknown/out of vocabulary: a present value absent from the fitted dictionary |
| 1 | Missing: no value is available |
| 2 onward | Known fitted categories |

For a synthetic cardholder-present dictionary, imagine `PRESENT → 2`, `ABSENT → 3`. Target's `ABSENT` becomes 3. A newly encountered text `NOT_RECORDED_BY_THIS_VENDOR` becomes 0 if it is not in the dictionary; an actual null/missing value becomes 1. An empty text string is still a present string unless upstream parsing converted it to a missing value. The integer 3 is a lookup address, not “three units of absence.”

Our synthetic Target has a missing PIN-verification value, so that feature becomes **1**. Its CVV text `NEW_OUTCOME` is present but absent from the synthetic saved dictionary, so it becomes **0**. These are distinct conditions, and the network receives distinct lookup indices for them. Known values are assigned indices beginning at 2 based on the fitted category-count ordering; you should not expect a universal `ABSENT = 3` mapping across arbitrary artifacts.

There are 17 original categorical fields: 13 raw and four calendar fields. Although hour is written as an integer such as 10, the default model treats it as a category and looks it up through its saved vocabulary. A calendar category absent during fitting can therefore map to unknown at scoring time. Merely calling a value a month does not guarantee that every month was observed in fitting data.

The source also offers cyclical calendar encoding using sine and cosine, but it is a different configured conversion. Do not silently switch a trained categorical model to it. Chapter 13 separates current inputs from candidates.

## Why 23 predictors becomes 29 or 30 inputs

For each of the six continuous fields, the active configuration adds a **missing flag**: 1 if the raw value is missing, 0 otherwise. These six flags are appended to the categorical inputs as two-valued categories. They do not use the unknown/missing vocabulary scheme; each flag has exactly two choices, 0 and 1.

Target's missing flags, in the same order as its six continuous features, are `[0, 1, 0, 0, 0, 0]`. Filling the external score with its median did not erase the evidence that the original value was absent. Another transaction whose observed score was exactly 480 would receive the same standardized score, -0.2, but a missing flag of 0.

The count is now **6 continuous + 17 categorical + 6 flags = 29** scalar input fields per transaction. A history model with the optional time-gap feature adds one continuous field, making **7 continuous + 23 categorical = 30**. That extra field describes timing relative to the history window and is explained in Chapter 07. “23 original predictors” and “30 fields reaching a history tokenizer” can both be correct because they count different things.

One precision point: the active loaders build flags from raw `isna()` checks, while numeric conversion can also turn malformed numeric strings into missing values for imputation. Thus raw missingness and “failed numeric conversion” are not guaranteed to have the same flag. This is a reason to check source types and malformed values, not to assume every imputed value must have flag 1.

## Frozen means saved and reused

An **artifact** is a saved product of a computation. Here it means the numerical statistics and category dictionaries, not a mysterious extra model. The builder writes a manifest plus one JSON file per feature, using filenames such as `feature__transaction_amt.json`. The manifest records the feature names, version, creation date, and fitting file names.

The configured original artifact-building default uses files 1–5 in full, processing selected feature groups to limit memory. That is a default recipe, not proof that a particular saved artifact was built with it. The active artifact contents and recorded provenance must be inspected. The runtime's job is to **load** those saved conversions and reuse them across training, validation, and scoring, rather than refitting each batch.

Imagine two scoring batches with amounts `[50, 150]` and `[150, 250]`. If each batch fitted its own mean and standard deviation, the same amount 150 would become +1 in the first batch and -1 in the second. Frozen statistics stop the meaning of an input from moving merely because different rows happen to share its batch.

The checkpoint's **input contract** records the ordered input columns, category sizes, date conversion settings, and a content fingerprint of the active artifacts. A fingerprint is a compact identifier computed from contents. Matching the label “version 1” is weaker than matching those contents: someone could replace a file without changing its version label. The contract helps detect that mismatch. It cannot prove that the original upstream data was correct.

## Source trail and practice

| What to inspect | Exact source coordinates |
|---|---|
| All 23 original predictors | `fraud/configs/predictors.csv`, lines 2–24 |
| Fitted statistics and vocabularies | `fraud/data/preprocessing.py`, `fit_continuous_stats` and `fit_categorical_stats`, lines 89–134 |
| Apply saved categorical and numerical conversions | `fraud/data/preprocessing.py`, `encode_categorical` and `standardize_continuous`, lines 165–180 |
| Calendar extraction | `fraud/data/datetime_features.py`, `_extract_field` and `derive_datetime_features`, lines 48–94 |
| Missing-flag order and two-choice sizes | `waqas/base/data/parquet_loader.py`, lines 33–53 and 151–166 |
| Artifact builder and manifest provenance | `fraud/scripts/build_preprocessing_artifacts.py`, `main`, lines 76–116 |
| Contents bound into the input contract | `waqas/base/data/contracts.py`, `build_input_contract`, lines 8–38 |

**Predict.** An observed amount is 50, with saved mean 100 and deviation 50. What are its standardized amount and missing flag?

**Repair.** Someone proposes adding a new category to the vocabulary during evaluation so it will no longer be unknown. Explain why the saved checkpoint may no longer match.

**Teach back.** Explain why median imputation does not claim to know the true missing value, then explain why its flag is still useful.

<details markdown="1"><summary>Answers and self-check rubric</summary>

The amount is `(50 - 100) / 50 = -1`; its flag is 0 because it was observed. Changing the vocabulary can change its size or the meaning of embedding indices. The trained model learned its category representations against a particular mapping, so reuse the saved mapping and handle unfamiliar categories with its unknown index. A sound teach-back says imputation supplies a consistent usable number, while the flag distinguishes a substitute from an actually observed value. Check all four ideas: arithmetic, raw missingness, dictionary identity, and imputation uncertainty.

</details>

**Recall without looking:** Reconstruct the path “raw → fill → scale” for a number and “raw → saved lookup” for a category. Explain the counts 23, 29, and 30. If the arithmetic is the obstacle, repair Chapter 02. If you can calculate but cannot explain why fitting is restricted, repair Chapter 05. Chapter 08 will show what the neural network does with these numbers.


---

# 07 — Build one history window, then feed millions of them

**Your question:** How does the program turn the prepared transactions into exactly the history Target is allowed to see, without loading the entire project dataset at once?

**Prerequisite refresher.** Chapter 05 established availability: current features and strictly earlier transactions from the same account are allowed, future and equal-time peers are excluded by the current strict rule. Chapter 06 converted a transaction into six continuous numbers and 23 categorical indices including missing flags. The optional history time feature adds a seventh continuous number. If “category index” still sounds like a fraud score, repair Chapter 06 first.

We will build a complete synthetic example by hand, then connect it to the actual loaders. You should be able to explain this chapter with paper and a pencil; a GPU is unnecessary.

## A file, a block, a batch, and a window

A **Parquet file** stores table data in a form that lets programs read selected columns efficiently. It is a storage format, not a neural network. A **read block** is a collection of rows brought into memory from a file. A **mini-batch** is a group of model examples processed together. A **window** is one history example: allowed earlier transactions plus the current target.

The corrected single-transaction reference, **REF**, streams read blocks and divides them into mini-batches of independent transaction rows. It does not construct transaction histories. Its continuous input has shape `[B, 6]`, where `B` is the number of transactions in the batch. Its categorical input has shape `[B, 23]` when the six missing flags are enabled.

The A/B single-target loaders work differently: they read one selected file's required columns, encode the file's rows, group them by account, and construct windows. They collect windows in a bounded shuffle buffer before emitting mini-batches. They avoid keeping the whole multi-file dataset in memory, but **they do hold a whole selected file's needed columns**, its encoded arrays, and buffered windows. “Streaming” does not mean constant tiny memory or one raw row at a time in every path.

**Shape** means the sizes of a numbered container's dimensions. A **tensor** is such a container; it can be a list, a grid, or a stack of grids. `[B, T, C]` means `B` examples, each containing `T` transaction slots, each slot containing `C` continuous values. No new mathematics is hidden in the brackets.

## Construct Target's window by hand

Let **history length H = 3**. This means up to **three previous transactions**, plus the current transaction, so the total number of slots is `T = H + 1 = 4`. It does not mean three days or three transactions including the target.

Reuse Chapter 05's synthetic records. For Target at 10:00:12, Old at 09:59:50 and Recent at 10:00:05 are eligible. Peer at 10:00:12 is excluded, as is Later at 10:00:20 and every Cedar-account row. Only two eligible prior transactions exist, so one empty slot is needed.

| Slot | Content | Why this slot exists | Real-row mask |
|---:|---|---|---|
| 0 | Padding | One of the three requested prior rows is unavailable | False |
| 1 | Old, 09:59:50 | Earlier Ember transaction | True |
| 2 | Recent, 10:00:05 | Latest eligible Ember transaction | True |
| 3 | Target, 10:00:12 | The current transaction being scored | True |

**Padding** is a placeholder that makes examples the same size. These ordinary A/B windows are **left-padded**, so the target always occupies the final slot. The **mask** marks real transactions separately from placeholders. The loader fills padded numerical and categorical arrays with zeros, but the mask is what identifies them as padding. A genuine amount may standardize to zero and an unknown real category may have index zero; neither fact makes a real transaction a placeholder.

If Ember had five strictly earlier transactions instead, H = 3 would keep the **three most recent**. The model cannot use the other two through this window. A long-lived account can still have a short effective history if the extract is incomplete, the file boundary cuts context, or same-time peers do not qualify.

## Add a clock to each real slot

For ordinary single-target windows, the optional `time_delta` input is:

`log1p(seconds from this slot's transaction to Target)`

`log1p(x)` means the natural logarithm of `1 + x`. The natural logarithm is a compression of positive numerical size: increasing an already large interval changes its encoded value less than the same increase near zero. The `+1` makes zero seconds valid and gives `log1p(0) = 0`. You do not need to calculate logarithms mentally; know what the number describes and why it is compressed.

| Slot | Seconds to Target | Encoded time input, rounded |
|---|---:|---:|
| Padding | No actual time | 0, ignored as padding |
| Old | `22` | `log(23) ≈ 3.1355` |
| Recent | `7` | `log(8) ≈ 2.0794` |
| Target | `0` | `log(1) = 0` |

This is **distance to the current target**, not distance to the previous row. Old's encoded time can change when it appears in a different target's window. Its amount and other frozen transaction features stay the same, but its age relative to the question has changed.

One source detail matters: history eligibility compares parsed timestamps at their stored precision, while this gap channel uses timestamps converted to whole seconds. With whole-second source records, that is straightforward. If a different source supplied fractional seconds, strictly earlier rows within one second could be eligible yet receive a zero whole-second gap. Do not infer perfect temporal resolution from the name `time_delta`.

Target's six continuous values from Chapter 06 were `[1, -0.2, 1, -1, 2, 2]`. In its own target slot the optional gap adds zero, producing `[1, -0.2, 1, -1, 2, 2, 0]`. Its 17 categorical indices plus six missing flags form the 23 categorical entries in that slot. This is the bridge from raw transaction to actual model input.

## Put two examples in a batch

Suppose a mini-batch holds two target windows, each with H = 3 and the time feature enabled. The shapes are:

| Batch entry | Shape | Read it aloud |
|---|---|---|
| Continuous | `[2, 4, 7]` | Two examples, four transaction slots, seven numbers per slot |
| Categorical | `[2, 4, 23]` | Two examples, four slots, 23 category/flag indices per slot |
| Mask | `[2, 4]` | One real-or-padding decision per slot |
| Target | `[2, 1]` | One fraud answer for each example's current transaction |

There are `2 × 4 × 7 = 56` stored continuous numbers, some belonging to padding. That is not 56 separate predictions. The ordinary mode predicts **two targets**, one per window. A/B have different neural-network architectures, but their ordinary single-target examples share this data organization.

The loader carries current target labels for loss or evaluation. Prior transaction labels are not appended to the feature arrays. The account and transaction identifiers can travel as **metadata**, supporting output alignment, but do not become extra learned predictors just because they accompany a batch. **Metadata** is information about the example's identity or handling rather than part of its predictive vector.

## Chronology first, shuffling afterward

The builder groups rows by account and sorts each group by time, then a configured tie-break identifier. Under `history_time_order: strict`, it finds the beginning of Target's equal-timestamp group and selects history ending before that group. This excludes all peers with Target's same timestamp, even those that sorted before Target.

Here is conceptual teaching pseudocode, not copied runtime code:

```text
for each target in an account's chronological records:
    eligible = records with time strictly earlier than target.time
    history = the latest H eligible records available in this file
    slots = left_padding + history + current_target
    emit features(slots), real_row_mask, current_target_label
```

Once windows are correctly built, the training loader can shuffle their order. That improves mixing between similar account examples without changing what any example is allowed to contain. If Target and the next transaction share most of their historical inputs, their windows overlap. This does not make their target labels the same; it means their examples are statistically related, a point that matters for uncertainty in Chapter 14.

A setting called **stride** can skip some nonfraud targets while preserving fraud targets. The active ordinary configurations use training and evaluation stride 1, which selects every target. If stride were 3, the code would select positions 0, 3, 6, and so on in the full sorted account sequence, plus every fraud target at any other position. It counts positions across all account rows, not only nonfraud rows. This changes training composition; it is not simply “run the identical experiment three times faster.” Rows skipped as targets can still exist in another target's history.

## Separate workers must divide the files correctly

A **data-loader worker** is a helper process preparing input while the model does other work. With four files `[A, B, C, D]` and two workers, a clean assignment could be worker 0 → `[A, C]`, worker 1 → `[B, D]`.

If both workers independently shuffle the entire list *before* taking their positions, the assignment can overlap. Suppose worker 0's list is `[A, B, C, D]`, so it takes `[A, C]`. Worker 1's list is `[B, A, D, C]`, so it takes positions 1 and 3, also `[A, C]`. B and D are skipped while A and C are repeated. Each worker looks locally reasonable; together they do not cover the intended dataset.

The current corrected REF loader first partitions the common list, then lets workers shuffle their assigned portions. Current A/B instead construct the same seeded permutation in every worker and then take disjoint positions from it. Both produce a genuine partition. A **seed** sets a repeatable starting state for pseudo-random choices. A/B's file-order permutation repeats for the same shard seed; their window-buffer shuffle is a separate operation. Do not claim all shuffle orders are identical every epoch merely because the file partition is repeatable.

The original `fraud/` loader used independent shuffling before slicing. Its preserved presence does not mean the current REF experiment executes that path: REF uses the corrected `waqas/base/` loader. Source locations and run entry points matter more than a broad folder name.

## Know where context stops

The ordinary builder constructs histories **within one selected file**. It does not maintain a cross-file account-history service. If an account is divided across files, a target will not automatically recover a previous transaction from a different file. Account bucketing supports locality, but it is not evidence that all possible histories are complete. You should explain the actual available context, not an ideal unlimited customer history.

The **all-position B** mode is also different. Instead of one left-padded history window for every target, it constructs disjoint account-local chunks and predicts every real position. Under its strict policy, chunks count distinct whole seconds and do not split a same-second group. They can contain more rows than `H + 1` when times tie. Context resets at chunk and file boundaries, and gaps are measured to the latest strictly earlier timestamp *inside the chunk*. Chapter 11 explains this architecture and why the same H or batch size does not imply the same amount of usable context or work. Do not apply the single-target gap diagram above to all-position mode.

## Source trail and practical inspection

| Claim | Source coordinates |
|---|---|
| REF reads blocks and emits already batched row tensors | `waqas/base/data/parquet_loader.py`, `__iter__`, lines 168–184 |
| REF partitions worker files before local shuffling | Same file, `_get_worker_files`, lines 127–136 |
| A/B share a seeded file permutation before worker slicing | `waqas/phase4a/sequence_builder.py`, `_get_worker_files`, lines 214–225; `waqas/phase4b/sequence_builder.py`, lines 290–300 |
| A builds strict windows, pads left, and adds target-relative gaps | `waqas/phase4a/sequence_builder.py`, `_windows_for_file`, lines 280–321 |
| A emits tensors after a window shuffle and reads each file as a whole selected table | Same file, `_emit_batches` and `__iter__`, lines 324–355 |
| Ordinary B mirrors the single-target construction | `waqas/phase4b/sequence_builder.py`, `_windows_for_file`, lines 367–414 |
| B all-position chunk boundary and time semantics differ | Same file, `_chunks_for_file`, lines 416–460; `waqas/phase4b/ALL_POSITION_CONTRACT.md`, lines 12–28 |

**Predict.** Target has two eligible prior transactions. If H changes from 3 to 5, how many slots and padding positions will it have? Does this change create three extra real transactions?

**Repair.** A reviewer calls zero categorical indices padding without reading the mask. Describe a real transaction this would incorrectly discard.

**Teach back.** Explain Target's entire journey in this order: file → account grouping → time eligibility → latest H → padding → encoded gap → batch. Then state which label is predicted.

<details markdown="1"><summary>Answers and self-check rubric</summary>

H = 5 creates six total slots, with three padding positions, two prior rows, and Target. It creates no real history. A real unfamiliar category has index 0, so zeros alone cannot identify padding; the mask does. A complete teach-back preserves the same account, excludes equal and later timestamps, selects the latest eligible rows, pads on the left, measures ordinary gaps to Target, and produces one answer for Target. If you said “previous row” for the ordinary gap or included Peer, repair the corresponding section before moving on.

</details>

**Recall without looking:** Draw `[pad, Old, Recent, Target]`, its mask, and the gaps `[ignored, 22, 7, 0]`. Explain why shuffling those finished examples is compatible with strict histories. Repair chronology in Chapter 05, numeric encoding in Chapter 06, and shape notation in Chapter 02. You are now ready for Chapter 08: how these arrays become learned feature representations.


---

# 08 · Turn a transaction into feature tokens

**Prerequisite refresher.** A row describes a transaction. A feature is an input the model may use, such as an amount or a category. A label is the answer used during training. Preprocessing turns raw values into consistent numbers using rules fitted on training data. A neural network contains adjustable numbers called parameters; training changes those parameters to reduce an error measure. If those ideas are blurry, revisit Chapters 03, 04 and 06 before the worked example.

**Your concrete question:** how can a transformer process a mixture of amounts, category codes and missing-value flags when those inputs mean different things?

The answer starts with a small translation layer. It turns each input feature into a list of learned numbers. Those lists are called **feature tokens**. The transformer will later mix information between them. A token here is a representation of one field, not a word, a transaction label or a fraud verdict.

## First picture: one row becomes several cards

Imagine a synthetic transaction described by three already-preprocessed inputs:

| Input | Value entering the model | Meaning |
|---|---:|---|
| Amount | 2 | An amount transformed using the frozen scaling rule |
| Time-related quantity | 0.5 | Another numerical input |
| Channel code | 3 | An integer identifying one category |

The value 2 is not necessarily two dollars. Chapter 06 explains why the model may receive a standardized value. Likewise, category code 3 does not mean three times as risky as code 1. It is a lookup address.

Give each field a card containing four numbers. The transaction now has three cards, each four numbers wide. In the real model that width is controlled by `input_embed_dim`, passed to the local tokenizer as `embed_dim`. We use width four for arithmetic; these numbers are synthetic and are not fitted project parameters.

A **vector** is simply an ordered list of numbers. **Embedding** means representing something by such a vector. It does not mean we have discovered its true meaning or assigned a human-readable interpretation to each coordinate. Training can make the vector useful for prediction without making coordinate 1 equal “risk” and coordinate 2 equal “trust.”

## Numerical features: multiplication plus an offset

The local linear tokenizer gives each numerical feature its own weight vector and bias vector. A **bias** is an adjustable offset added after multiplication. For one feature, the operation is:

```text
feature token = numerical value × that feature's weight vector + that feature's bias vector
```

For the synthetic amount input, choose:

```text
value  = 2
weight = [0.5, -1, 0.25, 0]
bias   = [0.1, 0.2, 0, 0.3]
```

Multiply 2 by each weight, then add the corresponding bias:

```text
[2×0.5+0.1, 2×(-1)+0.2, 2×0.25+0, 2×0+0.3]
= [1.1, -1.8, 0.5, 0.3]
```

The other numerical feature has a different learned weight and bias. Consequently, equal input values in different columns can produce different tokens. This is how field identity enters this representation: each numerical field owns its own parameters.

The linear operation by itself cannot express every curved relationship between input and outcome. That does not make the entire model linear. Later attention, activation functions and layers add nonlinear operations. “Linear numerical embedding” describes this first translation step, not the whole fraud model.

The multiplication expands one scalar into several coordinates. It does **not** create four independent observations or four extra historical transactions. All four numbers came from the same input and its learned parameters.

## Categories: selecting a learned row

A categorical feature uses an **embedding table**. Each category code selects one row of numbers. If the channel table contains this synthetic entry:

```text
channel_table[3] = [-0.2, 0.7, 1.1, 0.0]
```

then code 3 produces exactly that vector. It is a lookup, not “3 multiplied by the channel weights.” Every categorical feature has its own table, so code 3 for channel need not resemble code 3 for another field.

**Cardinality** is the number of legal codes that the table must accommodate. Frozen preprocessing determines the vocabulary and the reserved codes; the model creates tables of the required size. Missing and unknown values need the correct reserved treatment from Chapter 06. An integer outside the legal table range is not a new useful category; it is an invalid lookup.

At initialization, these table entries contain starting values. During training, the loss gradient reaches the looked-up entries and the optimizer updates them. The vocabulary mapping stays fixed while the model's vector for a code can change. This distinction is essential:

- Frozen preprocessing says which code corresponds to a category.
- Trainable embedding parameters say what vector that code contributes to the model.

If you silently rebuild the category vocabulary in a different order, old model parameters may be attached to the wrong categories. Matching array dimensions would not rescue that mistake. Chapter 12 explains why checkpoints record input contracts.

## Shapes: what the brackets count

A **tensor** is an array with one or more axes. Its **shape** lists how many entries lie along each axis. The phase-local tokenizer accepts:

```text
continuous:  [N, C]
categorical: [N, K]
output:      [N, C+K, d]
```

Read this out loud: “N rows; C numerical features; K categorical features; d coordinates per feature token.” Here `N` is the number of rows processed together, not the number of neurons. In later history models, several transactions from several windows are temporarily combined into this row axis.

For two transactions, two numerical fields, one categorical field and width four:

```text
continuous shape  [2, 2]
categorical shape [2, 1]
token shape       [2, 3, 4]
```

That final array contains `2 × 3 × 4 = 24` scalar numbers. The phase tokenizer puts numerical tokens first, then categorical tokens. Each transaction remains separate at this point. No attention has happened, and no past transaction has informed another transaction.

A **reshape** changes how existing entries are grouped into axes; it does not itself learn, summarize or shuffle their intended order. A model can temporarily reshape `[batch, time, features]` into `[batch×time, features]` to tokenize every row with the same function, then restore the time axis. That is bookkeeping, not memory across transactions.

## Periodic embeddings: another implemented translation choice

The repository also implements a numerical embedding using repeating waves. **Sine** and **cosine** describe two coordinated waves. You can picture a point moving around a circle: cosine is its horizontal coordinate and sine its vertical coordinate. One complete turn brings the coordinates back to their starting values.

For a numerical input `x`, the code first constructs angles `2π × x × c`, where `c` is a learned frequency coefficient. “Frequency” controls how many turns happen as the input increases. It computes sine and cosine for each frequency, joins those numbers together, then applies a learned linear projection to obtain a width-`d` token. Here π is approximately 3.14159, so `2π` means one full circle in radians, the angle unit used by the functions.

Use one frequency, `c=1`, and `x=0.25`:

```text
angle = 2π × 0.25 × 1 = π/2, a quarter turn
[sin(angle), cos(angle)] = [1, 0]
```

For `x=0`, the pair is `[0,1]`. A **projection** here is another weighted-total-plus-bias calculation. For a tiny width-two example, define its outputs as `[2×s+c, −s+0.5×c+0.1]`, where `s` and `c` are the sine and cosine values. The quarter-turn pair `[1,0]` produces `[2×1+0, −1+0.5×0+0.1]=[2,−0.9]`. Those projection weights and its bias are learned in a real model; ours are chosen only to show the arithmetic. With `F` frequencies, the intermediate representation has `2F` numbers: `F` sine values followed by `F` cosine values. In this implementation, the frequency coefficients are specific to each numerical feature, while the final linear projection is shared across features.

Why consider this? A richer input representation may help a network describe changing numerical relationships. Why be careful? It adds parameters and assumptions, may fit noise, and repeating waves can map separated values to similar coordinates. A single frequency with `c=1` gives the same pair for `x=0.25` and `x=1.25`. Multiple learned frequencies can change that behavior, but do not prove better fraud detection.

This option is **implemented**, with `linear` as the local model default. Its existence is not evidence that it is the proven V1 choice. The repository also has future experiment specifications; Chapter 13 explains their status. Do not confuse this general numeric representation with deliberately encoding a known clock cycle, such as hour of day, using a fixed period. Those are different feature design decisions.

## Where the actual source performs these operations

These references identify the checked source snapshot, not code you must memorize.

| Source location | What to inspect |
|---|---|
| `waqas/phase4a/tokenizer.py`, `FeatureTokenizer`, lines 15–40 | Per-feature numerical weights/biases, separate category tables, numerical-then-categorical output |
| `waqas/phase4b/tokenizer.py`, `FeatureTokenizer`, lines 15–40 | B's corresponding local tokenizer |
| `waqas/phase4a/numerical_embeddings.py`, `PeriodicNumericalEmbedding`, lines 13–25 | Learned feature-specific frequencies, sine/cosine concatenation and shared projection |
| `waqas/phase4b/numerical_embeddings.py`, `PeriodicNumericalEmbedding`, lines 13–25 | B's corresponding periodic option |
| `src/pytorch_tabular/models/common/layers/embeddings.py`, `Embedding2dLayer`, lines 224–310 | Reference FT embedding implementation, with configurable shared category components, biases, normalization and dropout |

The reference FT path and local A/B tokenizers serve a similar purpose but are not interchangeable implementations. For example, the reference embedding machinery supports a column-shared component inside categorical embeddings; local A/B use plain category tables. A **shared component** means some vector information is common to all categories of the same field. It helps identify the column, while category-specific parameters distinguish values. You should check the resolved model configuration before claiming which optional mechanism is active.

## Prediction, repair and teach-back

**Predict.** You have three transactions, five numerical fields, two categorical fields and embedding width eight. What is the tokenizer output shape? How many feature tokens does one transaction have?

<details><summary>Reveal the worked answer</summary>

The shape is `[3,7,8]`, because `5+2=7` features become seven tokens per transaction. There are `3×7×8=168` scalar coordinates in the complete output. Width eight is not eight transactions or eight original features.

</details>

**Repair.** Someone says, “Category code 8 must be twice as risky as category code 4. Also, once preprocessing is frozen, embeddings cannot learn.” Correct both claims.

<details><summary>Reveal the repair</summary>

Codes select rows from a table; numeric distance between codes does not impose a risk ordering. Frozen preprocessing fixes the code mapping and numerical transformations. Training still updates the model's embedding vectors. Confusing mapping with model parameters would hide a major part of learning.

</details>

**Teach back without looking.** Use the three-card picture to explain why the model knows that amount and channel are different fields, and why their tokens can have the same width.

<details><summary>Check your explanation</summary>

Give yourself one point each for: numerical fields have their own weights/biases; categorical fields have their own lookup tables; a common vector width makes later interaction possible; token coordinates are learned representations, not guaranteed human meanings. If you miss the frozen/trainable distinction, revisit Chapter 06 and then repeat this chapter's category example.

</details>

**Recall prompt for later:** draw the path from one standardized number and one category code to two tokens. Do the multiplication and the lookup from memory. Repair vector arithmetic in Chapter 02, learning in Chapter 04, and vocabulary handling in Chapter 06 before moving to attention in Chapter 09.


---

# 09 · Attention and the single-transaction FT-Transformer

**Prerequisite refresher.** Each feature token is a vector: a list of learned numbers representing one field. A forward pass transforms the current inputs into scores. A classification head converts the model's final representation into one score per class. None of those operations updates weights by itself; training adds loss, backward propagation and an optimizer step. Review Chapters 03, 04 and 08 if needed.

**Your concrete question:** how can the model decide that a transaction's amount should be interpreted together with its channel or other available fields?

It needs a way for one token to receive information from other tokens. **Attention** performs a learned, input-dependent weighted combination. It does not contain a fraud analyst, and the word does not imply human understanding. It names a calculation.

## Three roles for every token

Attention makes three transformed versions of each input token, using learned weights:

- A **query** describes what this token is currently seeking.
- A **key** describes what another token offers for matching.
- A **value** contains the information that can be combined into the answer.

Those descriptions are memory aids. In the program, queries, keys and values are numerical vectors created by linear layers. They are not English questions or database keys.

For a given query, the model compares it with each allowed key using a **dot product**: multiply matching coordinates and add the products. For example, `[1,2]` dotted with `[3,4]` is `1×3 + 2×4 = 11`. A larger match score tends to produce greater weight for that key, after a scaling and normalization step.

The score is divided by the square root of the query/key width. With width four, that divisor is two. This helps keep the score scale manageable as width changes; it is not a fraud-specific risk adjustment.

Then **softmax** turns the collection of match scores into positive weights that sum to one. For scores `s1, s2, ...`, each weight is `exp(si)` divided by the sum of all `exp(s)`. “exp” raises the constant `e≈2.718` to a power. You do not need to calculate exponentials by hand to understand the effect: larger scores receive larger weights, and changing one score changes the relative share of the others.

Finally, the model multiplies each value vector by its attention weight and adds them. That is the information the querying token receives from this attention head.

## Work a complete tiny attention calculation

Assume learned projections have produced a width-two query `[sqrt(2),0]`, two allowed width-two keys `[0,0]` and `[ln(3),0]`, and the width-two values below. Here `sqrt(2)≈1.4142` and `ln(3)≈1.0986`. The dot products are `sqrt(2)×0 + 0×0 = 0` and `sqrt(2)×ln(3) + 0×0 ≈ 1.5537`. Divide by the square root of the query width, `sqrt(2)`, to obtain scaled scores `0` and `ln(3)≈1.0986`. Their exponentials are 1 and 3. This is conceptual attention arithmetic, not a real project output; the numbers are chosen so every step remains traceable.

```text
softmax weights = [1/(1+3), 3/(1+3)] = [0.25, 0.75]
value 1 = [2, 0]
value 2 = [0, 4]
weighted result = 0.25×[2,0] + 0.75×[0,4] = [0.5, 3]
```

The result contains information from both values. It is not simply “pick the largest.” If the second key becomes disallowed by an attention mask, its weight becomes zero; the first allowed key receives weight one. The result becomes `[2,0]`.

A **mask** is a rule restricting which positions may provide information. Implementations can express a forbidden match as negative infinity before softmax, whose resulting weight is zero. If every key is forbidden, normalizing becomes invalid: there is no allowed share to allocate. Chapters 10 and 11 explain the project's padding safeguard for this case.

During training, **dropout** may randomly zero some attention contributions. Ordinary softmax weights sum to one before this dropout; a particular training-time dropped-and-rescaled realization need not. Dropout discourages reliance on the same exact path on every training example. It is disabled in evaluation mode.

## Multiple heads, then repeated blocks

One **attention head** is one set of query/key/value transformations and weighted combinations. **Multi-head attention** performs several such calculations in parallel. It joins their outputs and projects them back to the model width. Different heads can learn different interaction patterns. There is no promise that head 1 becomes “amount” and head 2 becomes “time.” Those are interpretations you would need to test.

A **transformer block** combines attention with additional operations. The following is a conceptual list of their jobs, not the exact execution order of every implementation:

1. Attention mixes information across tokens.
2. A residual or **skip connection** adds an earlier representation to a new contribution, giving information another route through the network.
3. **Layer normalization** rescales the coordinates within a token and applies learned scale/offset parameters. It helps control intermediate numerical behavior. It is different from preprocessing an amount with a training-set mean.
4. A **feed-forward network** transforms each token's coordinates using the same small neural network at every token position. It can expand the vector to a wider intermediate size, apply an activation, and shrink it back.

For concrete residual arithmetic, adding an earlier vector `[1,2]` to a new contribution `[0.5,3]` gives `[1.5,5]`. A simplified layer-normalization calculation has mean `(1.5+5)/2=3.25`, deviations `[-1.75,1.75]`, mean squared deviation `3.0625` and square root `1.75`. Dividing the deviations by 1.75 gives `[-1,1]`. The real operation adds a tiny stabilizer to its variance and applies learned scale/offset parameters; this example omits the stabilizer and uses scale one and offset zero. It normalizes coordinates **within one token**, not amounts across the training dataset. Chapter 06 explains the separate frozen preprocessing statistics.

A nonlinear **activation** allows the transformation to do more than another straight weighted sum. The local A/B models use GELU, a smooth function that passes positive values strongly and suppresses negative values more gradually than a hard cutoff. The reference FT implementation uses a gated GELU feed-forward module by default. A **gate** multiplies one learned transformation by another, allowing the contribution to vary with the input.

The precise ordering matters. Repeating blocks lets later computations use information already combined by earlier blocks. A multi-layer attention system can therefore transmit information indirectly, even when two tokens never interact directly in the first layer. That fact will matter for causal masks.

## The CLS collector and the fraud head

The reference model adds a learned special token called **CLS**, short for classification. It starts as the same learned vector for every row in a forward pass. After attention, it can contain an input-specific summary of that transaction's feature tokens.

This is **pooling**: turning multiple token representations into one representation for prediction. CLS pooling is learned; it is not the arithmetic mean of all feature values. The reference implementation appends CLS at the end and returns the final token representation to its prediction head.

With two transactions, three feature tokens per transaction and embedding width four:

```text
feature tokens             [2, 3, 4]
after adding one CLS each  [2, 4, 4]
transformer block outputs  [2, 4, 4]
select each CLS            [2, 4]
binary classification head [2, 2]
```

The two output numbers for a row are **logits**, unnormalized class scores. Their positions correspond to classes 0 and 1; fraud is the positive class in this project. Softmax across those two logits gives class probabilities. A fraud probability is a model score, not a guarantee that a single event is fraudulent. Calibration and decision thresholds arrive in Chapter 15.

To make the head concrete, suppose the CLS vector is `[1,2]`. Give class 0 head weights `[0,0]` and bias 0, producing `0×1+0×2+0=0`. Give class 1 weights `[1,0]` and bias `0.0986`, producing `1×1+0×2+0.0986=1.0986`. The logits are `[0,1.0986]`, so softmax gives approximately `[0.25,0.75]`. These synthetic head parameters are chosen for arithmetic. No 75% label was input; the model produced a score from available features. During training, the known label supplies the loss signal that can change all these learned transformations.

## What “FT” means in this project

**FT-Transformer** means a transformer using feature tokenization for tabular inputs. The single-transaction reference path processes one transaction's feature tokens. It does not receive an A/B sequence of several raw transactions through this architecture. An individual input field could itself summarize previous activity if such a feature is in the approved predictor set; that is different from adding a sequence transformer over past rows.

The reference streaming builder constructs the model from frozen preprocessing dimensions. “Streaming” describes how batches arrive; it does not magically give the network long-term memory. Once a batch is scored, the model does not retain an account's preceding rows unless a surrounding system explicitly supplies them.

One additional reference detail matters: frozen preprocessing and model **batch normalization** are separate. In the checked vendored reference configuration, `batch_norm_continuous_input` defaults to true. Its embedding layer applies this to numerical inputs even though the streaming builder disables another preprocessing normalization pass. Batch normalization uses statistics across a batch for each numerical field during training, updates stored running statistics, and normally uses those stored statistics during evaluation. It also has learned scale and offset parameters. For intuition, a two-row numerical column `[2,4]` has batch mean 3 and standard deviation 1, giving approximately `[-1,1]` before learned scale/offset; the real formula includes a small stabilizer. This differs from LayerNorm across one token's coordinates and from the frozen training-set preprocessing artifacts. A/B's local feature tokenizer does not add this input BatchNorm layer. Model evaluation mode therefore matters for more than switching off dropout. Source: `src/pytorch_tabular/config/config.py`, lines 815–818; `src/pytorch_tabular/models/common/layers/embeddings.py`, lines 280–291; and `src/pytorch_tabular/models/common/layers/batch_norm.py`, lines 27–40.

The checked reference recipe uses token width 32, eight heads and three blocks. Do not assume it is identical to A with history zero. A and B are separate model implementations, with different encoder structure and defaults. Their zero-history cases are useful controls within their families, but they do not automatically reproduce the reference model.

## Source facts that prevent a misleading textbook story

| Source location | Implemented fact |
|---|---|
| `waqas/base/streaming_model.py`, `build_streaming_model`, lines 54–116 | Constructs the single-row FT model with frozen dimensions, two output classes and the training recipe |
| `waqas/base/configs/streaming.yaml`, `model`, lines 41–47 | Reference base recipe: width 32, eight heads, three attention blocks |
| `src/pytorch_tabular/models/ft_transformer/ft_transformer.py`, `FTTransformerBackbone`, lines 30–82 | Appends CLS, runs blocks and selects the last token |
| `src/pytorch_tabular/models/common/layers/transformers.py`, `MultiHeadedAttention`, lines 34–69 | Query/key/value projections, scaled dot products, softmax, weighted values and output projection |
| Same file, `TransformerEncoderBlock.forward`, lines 124–128 | Exact reference block data flow |
| `src/pytorch_tabular/models/common/layers/gated_units.py`, `PositionWiseFeedForward.forward` and `GEGLU`, lines 142–185 | Activation, multiplicative gate and output linear layer |

There are two details worth being able to explain under questioning. First, this reference attention implementation defaults each head's width to the full input embedding width. With width 32 and eight heads, its internal concatenated head width is `8×32=256`, before projection back to 32. The A/B PyTorch encoder instead divides its model width across heads: width 48 with eight heads gives width six per head. The head count alone is not a fair capacity comparison.

Second, the checked reference block applies normalization **after** adding contributions. Its feed-forward branch receives the attention result `y` in the actual source, while the residual branch contains the normalized sum. A/B use the PyTorch encoder with normalization **before** its attention/feed-forward sublayers. You do not need to memorize these formulas on the first pass. You should remember that the source, rather than a generic transformer diagram, determines the architecture actually compared. This course describes the implemented reference faithfully; it does not silently rewrite it into a more familiar design.

Attention weights also are not a complete causal explanation of a prediction. Value vectors, multiple heads, residual connections, nonlinear layers and subsequent blocks all affect the result. “This token received 0.75 attention” is a statement about one calculation; “this business field caused 75% of the fraud decision” does not follow. The repository's reference feature-importance helper is explicitly marked as not thoroughly tested in its source.

## Prediction, repair and teach-back

**Predict.** Attention weights are `[0.2,0.8]` and the values are `[10,0]` and `[0,5]`. What combined vector results? If a mask forbids the second key, what should happen?

<details><summary>Reveal the calculation</summary>

The weighted sum is `[2,4]`. If the second key is forbidden before softmax and the first remains allowed, the remaining key receives weight one and the result becomes `[10,0]`. Merely zeroing the already-computed second contribution without renormalizing would give a different calculation.

</details>

**Repair.** A colleague says, “We have eight heads, so we have eight fraud models; the largest attention weight tells us the reason; A at H=0 must equal REF.”

<details><summary>Reveal the repair</summary>

Heads are learned parallel information-combination operations inside one network, not eight independently trained complete models. Attention weights alone do not prove causal importance. H=0 removes historical rows from A but does not change A into the reference implementation: embedding details, block data flow, head width and training recipe still matter.

</details>

**Teach back.** Explain the path from feature tokens to a fraud score using only a calculator and index cards. Include what learns and what stays fixed during one forward pass.

<details><summary>Use this rubric</summary>

One point each: learned projections produce queries/keys/values; matching scores become normalized weights; values are combined; blocks transform and preserve representations through additional paths; CLS collects information; a head produces logits and softmax produces probabilities; parameters stay fixed during the forward calculation but can be updated during training. If you cannot distinguish a parameter from an intermediate attention weight, return to Chapter 04, then work the two-value example again.

</details>

**Recall prompt:** redraw `features → tokens + CLS → attention blocks → CLS vector → two logits → fraud score`, then say why a batch of independent rows is not account history. Repair token shapes in Chapter 08 and score/loss concepts in Chapters 03–04. Chapter 10 adds history explicitly.


---

# 10 · Architecture A: one attention table over transaction history

**Prerequisite refresher.** Chapter 07 built a window containing earlier transactions and a target transaction. Padding fills absent history slots, while a mask identifies which slots contain real rows. Chapter 08 made a vector token for each feature. Chapter 09 explained attention as a learned weighted combination and CLS as a collector used for prediction.

**Your concrete question:** how does Architecture A allow the target transaction to be interpreted using previous transactions from the same account?

A puts every feature token from the window into one long sequence. Attention can then combine feature-level information across transactions. The output is one prediction for the target, not one label for every historical row.

## Start with the data contract, not the architecture name

Let `H` mean the requested maximum number of earlier rows, and `T=H+1` mean the number of transaction slots including the target. In the ordinary strict sliding-window path, a target gets up to `H` rows with strictly earlier parsed timestamps from the same account within the file being processed. The target itself occupies the final slot. If fewer than `H` eligible rows exist, the missing slots are padded on the left.

For a synthetic account, suppose the eligible earlier rows are at seconds 10 and 20, and the target is at second 40. With `H=2`, the window is:

```text
slot             0       1       2
time            10      20      40
role         history history  target
real mask       True    True    True
```

The **label** for the row at 40 is stored separately for training or evaluation. It is not fed as a feature token. Target means “the transaction whose fraud status we are trying to predict,” not “the answer placed in the input.”

If only the row at 20 is available, the window becomes `[padding, row20, row40]` with real mask `[False, True, True]`. A padded zero vector and a genuine transaction containing zero-valued inputs are different cases because the mask identifies which is real.

## Walk the entire forward pass with shapes

Use a tiny teaching model with `B=2` windows in a batch, `T=3` slots, `C=2` numerical fields, `K=1` categorical field, and embedding width `d=4`. Here `B` counts windows, not transaction rows. Let `F=C+K=3` tokens per transaction.

| Step | Shape | What it means |
|---|---|---|
| Numerical inputs | `[2,3,2]` | Two windows, three slots, two numerical fields |
| Categorical inputs | `[2,3,1]` | Corresponding category codes |
| Temporarily combine batch and time | `[6,2]`, `[6,1]` | Six transactions to tokenize with shared parameters |
| Feature tokenizer | `[6,3,4]` | Three width-four tokens for each transaction |
| Restore the window axes | `[2,3,3,4]` | Window, transaction slot, feature, coordinate |
| Add transaction position | `[2,3,3,4]` | Every feature in one slot receives that slot's position vector |
| Flatten time and feature axes | `[2,9,4]` | Nine tokens per window |
| Prepend one CLS | `[2,10,4]` | One collector plus nine feature tokens |
| Transformer encoder | `[2,10,4]` | Updated token representations |
| Select CLS | `[2,4]` | One representation per window |
| Classification head | `[2,2]` | Two class logits for each target |

“Flatten” here means joining the time and feature positions into one ordered list. It does not average them. The sequence conceptually looks like:

```text
CLS, row10.feature1, row10.feature2, row10.feature3,
     row20.feature1, row20.feature2, row20.feature3,
     row40.feature1, row40.feature2, row40.feature3
```

Despite historical “SEP/CLS” wording in comments, the checked A forward pass does **not** insert a special separator token between transactions. Group boundaries are represented by the known layout, learned transaction-position vectors and any applicable attention mask.

## Position and elapsed time answer different questions

A **position embedding** is a learned vector looked up by slot number. Every feature token in slot 1 gets the same slot-1 position vector added to it. A model can then distinguish a feature from the older slot from the corresponding feature in the target slot.

Slot position does not tell you whether the rows were one second or one week apart. When the time-gap input is enabled, the builder appends another numerical feature to each row. For single-target A, it is:

```text
log(1 + seconds from that row to the target)
```

`log` here is the natural logarithm, the inverse of raising `e` to a power. It compresses large gaps: each equal-sized increase in the logarithm corresponds to a multiplicative increase in `1+gap`. The added 1 makes a zero-second gap legal and maps it to zero.

For times `[10,20,40]`, gaps to the target are `[30,20,0]`. Their transformed values are approximately `[3.434,3.045,0]`. These are a separate channel, then tokenized like the other numerical inputs. Position tells the model which slot; the gap supplies elapsed-time information relative to this prediction target.

A row at time 20 can therefore have different time-gap inputs when used in a window targeting 40 versus a window targeting 100. This is intentional for a model making a decision at the final target time. It is **not** a safe reusable input representation for pretending to score that historical row at time 20. A causal attention mask does not undo a future-relative feature already present in an input. Chapter 11 changes the time-gap contract for all-position prediction.

## Two masks address two different concerns

A **padding mask** tells attention not to read nonexistent transaction slots. It is expanded from `[B,T]` transaction validity to every feature token belonging to those transactions. CLS is always valid. This protects real outputs from treating the filler as real account activity.

An **attention mask** controls information flow among real tokens. A supports two modes:

**Bidirectional:** tokens may exchange information across the entire supplied valid window. If every supplied historical row was available before the final target, and only the final target is scored, this is not automatically future leakage. The target-time decision is allowed to use its own available fields and the supplied earlier history. Historical token representations may contain information from the target; they are internal parts of a target-time calculation.

**Causal:** feature tokens for transaction slot `i` can read feature tokens in the same slot and earlier slots, not later slots. This is transaction-level block causality: all feature tokens within one transaction can interact. It does not mean feature 2 is forbidden to read feature 3 of the same transaction.

The builder's strict timestamp selection and the encoder's causal attention are separate safeguards. The first decides which rows enter a target's history. The second controls how tokens already inside the window exchange information. Flipping the encoder setting does not reconstruct the dataset.

## Why the collector must be one-way in causal mode

Here is the causal rule with one vector standing in for each transaction group. Rows are readers (queries); columns are sources (keys). “Yes” means the reader may receive information from the source.

| Reader ↓ / Source → | Earlier 0 | Earlier 1 | Target | CLS |
|---|---|---|---|---|
| Earlier 0 | Yes | No | No | No |
| Earlier 1 | Yes | Yes | No | No |
| Target | Yes | Yes | Yes | No |
| CLS | Yes | Yes | Yes | Yes |

Although CLS is physically placed first in the array, the mask assigns it a logical time **after** every transaction. Array placement and causal position are different ideas.

Why prevent earlier tokens from reading CLS? Imagine two layers. In layer 1, CLS collects information from the target. If an earlier token reads CLS in layer 2, target information travels back to the earlier representation through the collector. A direct earlier-to-target block would not stop this indirect route. The checked implementation blocks real tokens from reading CLS in causal mode, while CLS remains able to summarize the entire window.

This fixes a historical causal-mask issue recorded in source comments. We teach the current implementation, not the old faulty graph. Do not infer that every historical experiment used the current checkpoint semantics; Chapter 12 covers why run provenance matters.

Padding creates a second subtlety. A left-padded query could otherwise have no allowed keys once both causal and padding restrictions are combined. An all-forbidden softmax can produce invalid numbers, which can contaminate gradients even if the padded output is not the chosen prediction. The current causal mask leaves a query's own diagonal entry available. This lets a padded query attend to its own unused token; other real queries still cannot read that padded key. Allowing this computational self-route does not convert padding into a real transaction.

## What A learns, and what its cost depends on

A learns feature embeddings, transaction-position embeddings, the CLS starting vector, attention transformations, feed-forward transformations and the classification head. The target loss sends training gradients through these components. `embed()` returns the pre-head CLS representation for the whole account-at-target window; it is not a fraud probability. That vector can be useful to inspect or export, but it still belongs to the window's target-time context.

A's attention sequence length is `L=1+T×F`. An ordinary full attention table has roughly `L×L` pairwise entries per head per layer per window. In the toy example, `L=10`, so there are 100 entries. If `T` rises from 3 to 6 while `F=3`, `L` becomes 19 and the table has 361 entries. Doubling history-related length can increase pairwise work by almost four times.

For the current schema described in Chapter 06, the 23 selected predictor fields expand to 29 feature tokens because six numerical missing-value flags are appended as categorical inputs. Enabling the sequence time-gap adds one numerical token, giving `F=30`. A time-gap-enabled `H=15` window therefore has `1+16×30=481` tokens, including CLS. Always derive this from the encoded input contract: the original predictor count is not the final token count.

That calculation describes the attention term, not a measured runtime prediction. Projection layers, embedding width, batch size, number of heads, number of blocks, feed-forward networks, precision, implementation and padding also affect time and memory. Causal masking does not guarantee that a dense implementation avoids computing the forbidden entries. The local code creates a per-batch, per-head causal mask, which itself uses memory.

`H=0` leaves one target transaction slot. That is a no-history A control; it still has A's tokenizer, PyTorch encoder and CLS/head. It is not automatically the reference FT model from Chapter 09. More history, more parameters or more attention links may help, hurt or do nothing on held-out data. The architecture does not settle the result.

## Source trail

| Source location | What the checked code does |
|---|---|
| `waqas/phase4a/sequential.py`, `FTTransformerSeqModel.__init__`, lines 21–68 | Sets `T`, tokenizer, position embeddings, CLS, PyTorch encoder and two-class head |
| Same file, `forward`, lines 146–173 | Reshapes, tokenizes, adds position, flattens, prepends CLS, applies masks and produces target logits |
| Same file, `_build_causal_mask`, lines 105–144 | CLS logical-time rule and padded-query diagonal safeguard |
| Same file, `embed`, lines 175–179 | Returns the target-window CLS vector |
| `waqas/phase4a/sequence_builder.py`, `_windows_for_file`, lines 280–321 | Strict earlier history selection, left padding and target-relative logarithmic gap |
| `waqas/phase4a/sequential.py`, `sequence_contract` and checkpoint hooks, lines 70–103 | Records architecture and input semantics; legacy checkpoints cannot verify all artifact identity |

## Prediction, repair and teach-back

**Predict.** A window has `H=4` and six features per transaction. How many tokens enter A's encoder including CLS? If two historical transaction slots are padding, how many feature-token keys must be hidden from real readers?

<details><summary>Reveal the arithmetic</summary>

`T=H+1=5`. The sequence has `1+5×6=31` tokens. Two padded slots contribute `2×6=12` padded feature-token keys. The sequence still has those positions in memory; masking controls their use. CLS stays valid.

</details>

**Repair.** Someone adds a causal mask but leaves historical tokens able to read CLS. They test one layer and see no direct future edge. Why is their argument incomplete?

<details><summary>Reveal the repair</summary>

Across two layers, target information can enter CLS and then flow back into an earlier token. A mask must restrict indirect paths across layers, not only direct edges at layer 1. The current implementation places CLS logically after all transactions and forbids transaction queries from reading it.

</details>

**Teach back.** Draw one target window. Explain the real mask, position vector, time-gap feature, encoder mask and output label separately. Then explain why bidirectional attention can be valid for the final target without making earlier internal representations valid decision-time scores.

<details><summary>Check your explanation</summary>

You should distinguish five jobs: real mask excludes padding; position identifies slot order; time-gap supplies elapsed time; attention mask restricts exchange among tokens; label supplies the training answer outside the input. Bidirectional exchange uses the final target's available context to produce its one score. Historical representations may contain later-within-window information and target-relative gaps, so they should not be repurposed as earlier decisions. Repair any missing distinction in Chapters 05, 07 or 09.

</details>

**Recall prompt:** explain A in 90 seconds from a raw target window to two logits, including the formula `1+(H+1)F` and the one-way CLS rule. If your drawing loses an axis, return to Chapter 08; if time availability is unclear, return to Chapter 07. Next, Chapter 11 changes where the first summary happens.


---

# 11 · Architecture B: summarize rows, then history

**Prerequisite refresher.** A feature tokenizer creates one vector per input field. Attention combines allowed value vectors using learned weights. CLS is a learned collector. Architecture A places all feature tokens from a window into one attention sequence and scores its final target. A causal mask blocks later-to-earlier information flow, but input construction must also respect what was available at the decision time.

**Your concrete question:** can we compare a long transaction history without making every feature token attend directly to every feature token in every other row?

Architecture B uses two stages. First, it summarizes the features **within each transaction**. Then it compares the resulting transaction vectors **across the history**. “Hierarchical” means this two-level organization. It does not mean a hierarchy of employee roles, classes of fraud or separately trained models.

## Stage 1: one shared transaction reader

Suppose each transaction has three feature tokens of width four. B adds a transaction CLS token to those three tokens, runs a token-level transformer, and keeps that transaction's CLS result. The output is one width-four vector summarizing the row.

It repeats this operation for all transaction slots, using the **same learned weights**. Sharing weights means that amount and channel are processed by the same function whether the row is old or current. There is not a separate feature encoder trained for each account or slot.

During stage 1, one row's feature tokens do not attend to another row's tokens. In ordinary single-target B, a supplied time-gap feature may already refer to the target time, as Chapter 10 explained. Thus “independently encoded” means there is no cross-row attention at this stage; it does not claim every supplied input was constructed without reference to the window.

## Stage 2: compare the transaction summaries

B restores the history axis, adds a learned transaction-position vector to each row summary, prepends a **sequence CLS**, and runs another transformer over those transaction vectors. The sequence CLS is different from the transaction CLS:

- The transaction CLS collects feature information within one row.
- The sequence CLS collects information across rows in a window or chunk.

In default single-target B, the classification head reads sequence CLS and produces two logits for the final target. The target's label remains outside the inputs.

Use the same toy dimensions as Chapter 10: two windows, three transaction slots, three feature tokens per transaction and width four.

| Operation | Shape |
|---|---|
| Tokenize six transaction slots | `[6,3,4]` |
| Add transaction CLS to each | `[6,4,4]` |
| Token encoder and select transaction CLS | `[6,4]` |
| Restore windows | `[2,3,4]` |
| Add position, prepend sequence CLS | `[2,4,4]` |
| Sequence encoder | `[2,4,4]` |
| Select sequence CLS, apply head | `[2,2]` |

A stage-2 attention link therefore compares two learned transaction summaries. It does not directly compare one historical amount token with one target channel token at that stage. Useful feature information must survive the stage-1 summary. This is a tradeoff: it reduces cross-transaction attention size, while asking a fixed-width vector to carry the relevant contents of each row.

## Count the attention work, then state the limits

A has roughly `(1+T×F)²` attention entries per head per layer per window. B has a within-row term `T×(F+1)²` for each transaction-encoder layer and a sequence term `(T+1)²` for each sequence-encoder layer. The `+1` terms are the appropriate CLS tokens.

With `T=3` and `F=3`, A's table has `10²=100` entries. One layer at each of B's stages has `3×4² + 4² = 48+16=64` entries. This toy comparison does not compare complete configured models: B may use different numbers of layers at its two stages, different widths, and additional projection/feed-forward work.

Using the current time-gap-enabled schema from Chapter 06, `F=30`. With `H=15`, ordinary windows have `T=16`: A has `(1+16×30)²=481²=231,361` entries. B has `16×31² + 17² = 15,376+289=15,665` for one layer in each stage. These are attention-table counts, not measured speedups. In the checked B base configuration, stage 1 has two blocks and stage 2 has four; a fair accounting applies those depths and the rest of the computation. Do not advertise a ratio of table entries as a benchmark result.

Default B and A can both use bidirectional attention for a final target, or causal sequence information flow. B's causal sequence CLS follows the same one-way collector rule: it may read all valid rows, while row vectors cannot read sequence CLS. Padding is hidden from real readers, with the same diagonal safeguard for otherwise fully masked padded queries. Stage 1 has no temporal cross-row attention to mask.

## All-position B is a different data and prediction contract

The optional `predict_every_transaction` mode attaches the head to every output transaction vector rather than only sequence CLS. That sounds like a small output change, but making the predictions honest requires a different dataset construction.

Default B uses **sliding target windows**: one window per chosen target, with up to H earlier rows. Those windows overlap. If you simply trained on all labels in every overlapping window, a row could become a training target multiple times, and its supplied features could include time gaps to a later final target. “One loss per row” would then be false.

The implemented all-position contract instead uses **nonoverlapping chunks**. A chunk is a disjoint consecutive group of rows from one account within one file. Each real row owns one prediction and one target label. There is no history carried across chunk or file boundaries. Early rows in a chunk have less context than late rows. This is an actual change in the experiment, not a faster implementation of exactly the same H-history task.

The configuration must explicitly opt in to nonoverlapping chunks and causal attention. It also requires stride one, so every real row is a target. **Stride** controls which ordinary target positions are selected; using stride greater than one would violate this all-row ownership contract.

The output shape becomes `[B,W,2]`: `B` is the number of chunks in the batch, `W` is the padded number of row slots per chunk, and 2 counts class logits per slot. The shape letter `B` means batch size here; it is not a reference to the architecture name. `W` is explained below; in strict mode it is not always `H+1`.

## Strict all-position time policy: work a tied-timestamp example

In the strict policy, row `i` can read itself and real rows in its chunk whose parsed timestamps are strictly earlier. Two rows with exactly equal timestamps cannot read one another, even if a tie-break sort puts one first. A deterministic display order does not prove information availability.

Consider synthetic timestamps `[10,20,20,30]`, denoting whole seconds for this example. Give the tied rows descriptive names “first row at 20” and “second row at 20”; these are not actual transaction identifiers.

| Row | Can read other real rows | Backward gap | Strictly earlier row count |
|---|---|---:|---:|
| At 10 | None | 0 | 0 |
| First at 20 | At 10 | 10 | 1 |
| Second at 20 | At 10 | 10 | 1 |
| At 30 | At 10 and both at 20 | 10 | 3 |

Every row may also read itself. The gap is seconds since the latest strictly earlier timestamp **inside the chunk**, or zero when none exists. Its input is `log(1+gap)`, giving `[0,2.398,2.398,2.398]` approximately. It is not a gap to the final row in the chunk.

Why give both tied rows the same position index? If their position embeddings were simple slot numbers 1 and 2, adding a same-time sibling could change the second row's representation even though attention forbids reading that sibling. The code instead indexes the position table using the number of real rows with strictly earlier timestamps, capped at H. With `H=2`, the example indices are `[0,1,1,2]`: the final count 3 is capped at 2 because the table has indices 0 through 2.

Capping merges some later positions into the same learned position vector. It does not drop the earlier rows or change the timestamp mask. It is a defined representation choice that should stay in the checkpoint's recorded contract.

The word “strict” compares the parsed timestamp at its stored precision, represented internally in nanoseconds. **Nanoseconds** are billionths of a second; this integer representation can distinguish subsecond timestamps when present. The gap channel is expressed in whole seconds. Two timestamps in one whole second can therefore be strictly ordered yet have a zero-second gap. Do not confuse whole-second gap arithmetic with the exact equality test used for visibility.

## Why strict chunks can contain more than H+1 rows

Strict chunk boundaries are cut between whole seconds. Each strict chunk contains at most `H+1` distinct whole-second values for an account. It does **not** have a hard maximum of `H+1` transaction rows.

With `H=2`, the example `[10,20,20,30]` contains three distinct seconds and therefore fits into one strict chunk of four rows. The next new second begins the next chunk. This avoids moving a row into a different chunk merely because a same-second sibling was added or removed.

The builder emits a width of at least `H+1`, expands when a chunk has more rows, and right-pads each batch to its widest chunk. If one chunk has four rows and another has two, a width-four batch represents the second as `[real,real,pad,pad]`. This differs from the left padding of ordinary target windows.

Strict chunk context can exceed H earlier **rows**, because earlier seconds can contain many transactions. It is bounded by the selected distinct-second grouping, not by the ordinary sliding-window row count. Dense activity can therefore make W large. The sequence attention and its per-batch, per-head mask then grow roughly with `W²`. An optional `max_chunk_rows` cap raises an error when exceeded; it does not silently truncate or discard rows. This is a memory guard to configure from measured widths, not a promise that arbitrary data fits.

A separate supported `tiebreak` policy uses earlier chunk positions as availability order, chunks of `H+1` rows, ordinary slot positions, and previous-row gaps. For `[10,20,20]`, those gaps are `[0,10,0]`, versus strict `[0,10,10]`. It is an explicitly different policy requiring a justified availability interpretation. The current strict path must not be described using old positional semantics.

## How all-position labels contribute to loss

The builder supplies `target_seq` with one label for each real row and a sentinel value `-100` for padding. A **sentinel** is a reserved marker, not a genuine class. The real mask and label availability must agree exactly.

The model selects only real-row logits and labels. It sums their class-weighted cross-entropy terms and divides by the number of actual real transactions. For synthetic per-row terms `[0.2,0.6,1.0]`, the loss is `(0.2+0.6+1.0)/3=0.6`. Two padded slots do not change the denominator to five. A batch containing no real targets is rejected.

One subtle difference: default single-target B uses the library's usual weighted cross-entropy mean, whose denominator is the sum of selected class weights when class weights are enabled. All-position B deliberately divides its summed weighted terms by the number of real rows. When weights are all one, the distinction disappears. With non-unit class weights, raw loss scales should not be casually compared across modes. The all-position logging uses the real-target count so epoch aggregation also weights the actual predictions correctly.

All-position `embed()` still returns **sequence CLS**, a summary that can read the whole chunk. That is appropriate as a chunk-end representation. It must not be used as an earlier row's decision-time embedding. The safe per-row outputs are produced from their causally restricted transaction positions; a convenient summary export is not a substitute.

## Current implementation, historical paths and evidence

The source includes both default B and the explicit all-position contract. The V1 experiment set contains an all-position comparison, but the presence of a path or a reported comparison is not proof of general superiority. Results belong to the exact configuration, data, checkpoint and selection protocol described in Chapters 12–15.

Checkpoint loading compares a recorded **sequence contract**: architecture settings, layout, gap reference, input artifact identity and all-position time policy. Matching tensor shapes cannot reveal a changed vocabulary, shifted feature order or old tie policy. Old all-position checkpoints lacking the required contract are rejected; a historical checkpoint cannot be renamed into the corrected experiment. Legacy default single-target loading has narrower checks and warns about unverifiable artifact identity.

| Source location | Source-checked operation |
|---|---|
| `waqas/phase4b/sequential_hier.py`, constructor and `forward`, lines 96–170 and 276–325 | Shared transaction encoder, sequence encoder, two CLS roles and prediction head selection |
| Same file, `_build_causal_mask`, lines 226–274 | Causal collector rule, exact-time visibility and padding safeguard |
| Same file, `forward` and `_checked_times`, lines 297–348 | Strict earlier-count positions, width/time validation and distinct-second limit |
| Same file, `embed` and `_step`, lines 350–379 | Chunk-end summary limitation, exact target ownership and real-row loss denominator |
| Same file, `sequence_contract` and checkpoint hooks, lines 172–224 | Mode/time policy compatibility and legacy behavior |
| `waqas/phase4b/sequence_builder.py`, `_chunks_for_file`, `_chunk_spans`, `_chunk_gaps`, lines 415–512 | Disjoint targets, distinct-second chunks, backward gaps and row cap |
| `waqas/phase4b/factory.py`, `sequence_dataset_options`, lines 11–34 | Explicit mode, causal mask, layout, stride and time-gap requirements |

## Prediction, repair and teach-back

**Predict.** With `H=2`, a strict chunk contains times `[10,10,20,30]`. Can it contain four rows? What position indices and backward gaps does it use?

<details><summary>Reveal the worked answer</summary>

Yes: it has three distinct whole seconds, so it fits the `H+1=3` distinct-second budget. Strict earlier counts are `[0,0,2,3]`, capped to indices `[0,0,2,2]`. Backward gaps are `[0,0,10,10]`: neither first tied row has a strictly earlier row in this chunk; the row at 20 looks back to time 10. Attention excludes same-exact-time siblings but includes all strictly earlier real rows. The gap values are then transformed with `log1p`.

</details>

**Repair.** “All-position B is just default B with more labels. Its `embed()` gives the right vector for every transaction, and H=15 means no more than 15 earlier rows.”

<details><summary>Reveal the repair</summary>

All-position changes target ownership, overlap, chunk boundaries, time gaps, output positions and the loss calculation. `embed()` gives a whole-chunk summary, which includes later context relative to early rows. Strict chunks have a distinct-second budget; tied seconds can produce more than H earlier rows for a later prediction. Ordinary sliding-window H and strict chunk H must not be treated as identical context definitions.

</details>

**Teach back.** Draw A, default B and all-position B. Explain where feature information is summarized, which output receives the loss, and when each row's inputs were available.

<details><summary>Use this rubric</summary>

For A: feature-level flat sequence and one target CLS loss. For default B: independent shared row encoder, sequence encoder, one target sequence-CLS loss. For all-position B: disjoint chunks, causal per-row sequence outputs, backward gaps, strict tie handling, one real target per row and no padding targets. Include the whole-chunk CLS caveat and the fact that context resets. Missing either availability or ownership means the comparison is not yet defensible; return to Chapters 05, 07 and 10 before explaining the speed tradeoff.

</details>

**Recall prompt:** explain why B can reduce attention work yet still needs a fair experiment; then reconstruct the tied-time example without looking. Repair attention in Chapter 09 and target-time semantics in Chapter 10. Chapter 12 follows these forward calculations into training, checkpoints and reproducible runs.


---

# 12 · From one learning step to a reproducible experiment

**Prerequisite refresher.** Chapter 04 separated a forward pass (make a prediction), loss (measure its error), backpropagation (calculate gradients: how small parameter changes would affect loss), and optimizer (use those gradients to update parameters). Chapters 10–11 explained the models that produce the prediction. Here you become the person who can explain how those steps become a complete run.

**Your concrete question:** “What exactly happens after I start training, and which saved model do I eventually evaluate?”

## Follow one example around the loop

Imagine a synthetic training set of 12 transactions. A **batch** is a group processed together. With batch size 4, the loader supplies three batches. The network predicts four pairs of logits, converts their errors into one loss, and computes gradients. Ordinarily, the optimizer then updates its parameters. The next batch sees those changed parameters. After all three batches, the training data has been visited once: that is one **epoch**. Another epoch revisits the data; it does not mean acquiring new transactions.

Training mode matters. **Dropout** randomly suppresses some internal activations during training, encouraging the network not to rely too heavily on a particular route. At validation and scoring, dropout is disabled. The model is still the same learned model, operating in its evaluation mode. A prediction can therefore differ between training mode and evaluation mode even before any parameter update.

At the end of a training epoch, the validation loader supplies held-out examples. The model predicts without using those labels for gradient updates. Validation labels are used to calculate metrics and make training decisions. This means validation influences model selection even though it does not provide ordinary training gradients. “Not used in backpropagation” is not the same as “never used in development.”

The framework **PyTorch Lightning** handles the repeated loop. A framework is reusable software that calls your model's functions at the right time. In this project, `training_step` returns loss, `validation_step` returns logits and labels, and callbacks handle shared work. A **callback** is a function invoked at a particular event, such as the end of validation; it is not another neural network.

## What the knobs actually mean

The **learning rate** controls the scale of optimizer updates. An excessively large step can overshoot useful parameter settings; an excessively small step can make learning slow. That intuition is useful, but AdamW also adapts updates using running information about past gradients, so a learning rate is not literally “move each weight this many units.” Chapter 04 gives the simpler gradient-descent calculation.

**Weight decay** discourages large parameter magnitudes as part of optimization. AdamW separates that decay from its adaptive gradient calculation. It is a training choice intended to help generalization; it does not guarantee a more accurate fraud model. **Generalization** means useful behavior on relevant examples beyond those used for fitting.

A **scheduler** changes the learning rate while training. A and B use `ReduceLROnPlateau`, which watches validation loss and reduces the learning rate by a factor of 0.5 after its configured non-improvement patience. If the learning rate is 0.0003, one reduction produces 0.00015. It does not halve the model size or the number of examples. The configured scheduler patience is 3; its exact trigger includes the library's definition of improvement and bad epochs.

**Early stopping** ends training when a monitored validation metric stops improving for the configured patience. The current A/B settings watch validation average precision, abbreviated `valid_ap`, maximize it, and use patience 5. **Checkpoint selection** also maximizes `valid_ap`. These decisions differ from the scheduler, which watches `valid_loss`. There is no contradiction: one measure guides update size, another selects the saved ranking model. Chapter 15 will calculate average precision by hand.

The maximum epoch setting is an upper bound, not a promise to complete that many epochs. A run with `max_epochs=10` can stop earlier. Nor does completing ten epochs mean epoch ten is the best checkpoint.

## Checkpoint selection: a small worked example

Suppose a synthetic run records:

| Completed epoch | Training loss | Validation loss | Validation AP |
|---|---:|---:|---:|
| 1 | 0.50 | 0.46 | 0.20 |
| 2 | 0.40 | 0.43 | 0.26 |
| 3 | 0.34 | 0.44 | 0.24 |

The best checkpoint is from epoch 2 because 0.26 is the highest validation AP. The last checkpoint is from epoch 3. Training loss improving from 0.40 to 0.34 does not override the selection criterion. A checkpoint contains saved model state; a results row is only a summary of measurements. You cannot recreate the model from its AP number.

The scorer must load the selected checkpoint and compatible feature/preprocessing/history settings. A **hash** is a compact fingerprint of file contents. It helps establish which checkpoint produced which predictions. It does not prove that the model was well designed. Changing a checkpoint's filename does not change its contents; changing its contents without changing its filename does change the hash.

## When a batch does not fit in memory

Longer histories make larger internal arrays, particularly for flat attention. **Gradient accumulation** processes several small batches before the optimizer update. A small batch here is often called a **micro-batch**.

With 1,024 examples per micro-batch and accumulation 4, the nominal number of examples contributing to an update is:

`1,024 × 4 = 4,096`.

The checked A-H10 specification uses that combination. A-H15's checked specification uses `256 × 16 = 4,096`; A-H20's uses `128 × 32 = 4,096`. The returned V1 records describe different micro-batch overrides for some runs while retaining the same nominal total. Learn to read the resolved run configuration, not only the template. The **resolved configuration** is the final set of settings after defaults and overrides have been combined.

Equal nominal batch size does not prove bitwise identical training. Final partial groups can contain fewer examples; dropout draws, floating-point arithmetic, and actual grouping can differ. All-position B additionally uses chunks containing multiple scored rows, so “256 chunks” does not mean “256 target transactions.” Record both the meaning of a batch and the accumulation policy.

**Mixed precision** performs selected calculations with lower precision to reduce memory and speed supported hardware. A/B configuration uses `bf16-mixed`. This is a numerical implementation choice, not extra training data or a different label definition. The reference trainer has its own recipe; do not infer its precision from A/B defaults.

## Randomness and reproducibility

A **seed** initializes a pseudorandom number generator: software that produces a repeatable sequence of seemingly random numbers. Parameter initialization, dropout and shuffling can use randomness. V1 uses seed 42. A seed is a recipe ingredient, not a certificate that two runs are identical.

For a meaningful reproduction, also match source version, resolved configuration, feature order, preprocessing artifacts, data cohort, checkpoint choice, package versions, and relevant hardware behavior. A **cohort** is the exact collection of examples being considered. Matching the same file count is weaker than matching the actual cohort.

The current training entry points explicitly reject unsupported distributed multi-process training because their iterable data are not partitioned by process rank. In plain terms, cooperating training processes would each need an assigned share of the data; otherwise they can repeat the same examples. A process's rank is its identifier within that cooperating group. Running independent experiments on separate GPUs is different: each GPU trains its own model. It does not automatically combine them into one larger training run.

## Optional EMA, explained without magic

**Exponential moving average**, or EMA, keeps a smoothed copy of parameters. With decay 0.9, old EMA weight 2.0 and new training weight 3.0:

`new EMA = 0.9 × 2.0 + 0.1 × 3.0 = 2.1`.

Most of the previous smoothed value remains; a little of the latest weight enters. EMA weights are not averaged transaction scores. The callback updates after completed optimizer steps, swaps EMA weights in for validation, and restores raw training weights afterward. Checkpoint handling preserves EMA inference weights plus raw and shadow state for resuming.

That lifecycle matters. Updating EMA on every micro-batch would smooth at a different rate when accumulation changes. Resuming training from the smoothed copy while retaining an optimizer state associated with raw weights would change the trajectory. The project has specific tests for these cases. EMA is implemented, but current A/B V1 configuration has `ema: false`. An available option is not a measured improvement.

## Where this is implemented

- `waqas/phase4a/scripts/train_sequential.py`, `main`, lines 59–115: seed, loaders, callbacks, one-device trainer and accumulation. The B entry point follows the corresponding phase-local structure.
- `waqas/phase4a/sequential.py`, `_step` through `configure_optimizers`, lines 181–201: loss, validation output and the loss-monitored scheduler. `waqas/phase4b/sequential_hier.py`, lines 389–395: B optimizer/scheduler.
- `waqas/phase4a/configs/sequential.yaml`, `training`, lines 60–78: A defaults, including AP selection and disabled EMA. A run specification can override these.
- `fraud/callbacks.py`, `StreamingBinaryMetrics`, lines 43–79: collect the complete validation stream before calculating ranking metrics.
- `waqas/phase4a/callbacks.py`, `EMACallback`, lines 39–107: step-aware smoothing, weight swapping and checkpoint state.
- `waqas/base/scripts/train_streaming.py`, `main`, lines 114–158: the reference has its own trainer construction and frozen-input contract callback.

## Predict, repair, explain

**Predict.** A run has validation AP 0.20, 0.28, 0.25 across three epochs. Which checkpoint should the scorer use? Does lower training loss in epoch 3 change that?

**Repair.** Someone says, “Our two jobs both used seed 42 and effective batch 4,096, so they must be identical.” Identify four missing pieces of evidence.

**Teach back.** In one minute, explain the difference between the optimizer, learning-rate scheduler, early stopping and checkpoint selection.

<details><summary>Answers and self-check rubric</summary>

Use epoch 2 under the stated AP-maximizing selection rule. Training loss does not change that rule. Possible missing evidence includes actual source, cohort, frozen artifacts, feature order, micro-batch composition, numerical precision, software versions, and checkpoint identity. Full-credit teach-back: optimizer changes weights using gradients; scheduler changes learning rate; early stopping decides when to end; checkpoint selection decides which saved state is best under the chosen validation measure. Give each its own job and name AP versus loss correctly.

</details>

**Recall without looking:** sketch `batch → logits → loss → gradients → optimizer update`, then add validation, best checkpoint and scoring as separate stages. If gradients still feel mysterious, repair with Chapter 04. If selecting the best checkpoint by AP feels arbitrary, continue to Chapter 15 and calculate AP yourself.


---

# 13 · Pretraining and the ideas that are not yet results

**Prerequisite refresher.** An encoder turns inputs into a learned vector; a head turns that vector into an output such as fraud logits. Training changes parameters to reduce a chosen loss. A frozen preprocessing artifact is different: it records earlier fitted transformations and is reused consistently. If these pieces blur together, revisit Chapters 04, 06 and 08 before this chapter.

**Your concrete question:** “Can the model learn useful transaction structure before it is trained to predict fraud?”

Yes, that is a possible research strategy. The repository contains implementations of two such strategies under `waqas/future_experiments/pretrain/`. Their existence does not establish that they help the current fraud task. Phase 5 is parked in the current project state. This chapter teaches the mechanisms so you can explain the whole repository without presenting future experiments as completed V1 results.

## What “pretraining” adds

Ordinary supervised fraud learning begins with input features and known fraud labels. **Supervised** means labels guide learning. **Pretraining** means first training some parameters on an earlier objective, then using those parameters to start a later task. The earlier objective can use labels, ignore them, or use different labels. “Pretrained” alone does not tell you which.

Think of learning to recognize spreadsheet patterns before being asked to identify suspicious transactions. The analogy has limits: the network does not understand a business explanation as a person does. It finds parameter settings that reduce a mathematical objective. The only reliable way to know whether the earlier learning helps fraud ranking is a properly controlled downstream experiment.

The reusable component here is `TabularEncoder`. Its output is a vector with a configured number of coordinates. A coordinate is one number in that vector. The numbers jointly represent useful distinctions learned under the training objective; coordinate 12 is not automatically “customer honesty” or “merchant risk.”

## Route A: hide a field and reconstruct it

The **masked autoencoder** takes a transaction, hides selected feature tokens, and tries to reconstruct their original values. “Autoencoder” describes learning to reconstruct information from the input itself. **Self-supervised** means the training targets are derived from the input data, rather than requiring separate fraud labels for that objective.

Suppose a synthetic row contains normalized amount 0.6, normalized limit 0.9, and merchant category “travel.” Hide the amount token. The network sees the other features and a learned mask token at the amount position, then predicts the missing amount. The mask token signals that the value is hidden; feature identity tells it which field needs reconstruction. Without feature identity, “a value is missing somewhere” would be a much less useful task.

The implementation masks tokens randomly and ensures each row has at least one masked token. With mask ratio 0.3, each token is initially selected with probability 0.3. That is a probability, not a rule that exactly 30% of every row must be hidden. The fallback for empty masks also changes the final distribution slightly. This distinction matters when there are few features or a small final batch.

Continuous values use **mean squared error**, or MSE: subtract prediction from target, square the difference, and average. If two masked targets are 0.6 and 0.2 and predictions are 0.4 and 0.5:

`MSE = ((0.4 − 0.6)² + (0.5 − 0.2)²) / 2`

`= (0.04 + 0.09) / 2 = 0.065`.

Squaring makes positive and negative errors contribute positively, and gives larger misses more weight. The values are in the model's transformed feature space. A reconstruction error of 0.2 here is not necessarily a monetary error of 20 cents.

Categorical fields use cross-entropy because predicting a category is a classification problem. If the true category is “travel,” a prediction assigning travel probability 0.8 has loss `−log(0.8)`, approximately 0.223; assigning probability 0.2 has loss about 1.609. The model is penalized for failing to support the actual category.

The code adds the continuous reconstruction term and available categorical reconstruction terms. That loss is not fraud AP. A model can get better at reconstructing common transaction patterns while doing nothing useful for rare fraud. A high-cardinality field or noisy field can also complicate the objective. Treat objective design as a hypothesis.

## Route B: supervised contrastive learning

**Contrastive learning** learns a representation by comparing examples. In this project's **supervised contrastive** implementation, fraud labels decide which comparisons should be similar: views with the same class are positives, and different classes compete in the denominator. “Positive pair” here means a pair encouraged to be close; it does not necessarily mean two fraudulent transactions. Two legitimate examples are also a positive pair.

Each transaction produces two **views**, which are altered copies. The corruption function randomly replaces selected feature values with values from a randomly sampled batch row, sometimes the same row itself. It creates a learning challenge; it does not claim those altered transactions really occurred. The two altered copies retain the original transaction's label for this objective. That design assumes the corruption does not destroy the useful class information too often, something experiments must assess.

The encoder produces a representation, then a **projection head** transforms it for the contrastive loss. A projection head is a small additional neural network. It is separate from the eventual two-class fraud head. The contrastive representation is normalized so vector direction drives similarity. For vector `[3,4]`, length is `√(3²+4²)=5`; dividing each coordinate by 5 gives `[0.6,0.8]`, with length 1. The dot product multiplies matching coordinates and adds: this vector with itself gives `0.6²+0.8²=1`. With perpendicular vector `[-0.8,0.6]`, it gives `−0.48+0.48=0`. The dot product of normalized vectors is **cosine similarity**: 1 for the same direction, 0 for perpendicular directions, and −1 for opposite directions. An **anchor** is the view currently being compared with the other views.

For an intuitive arithmetic example, let one anchor have a same-class comparison with similarity 1 and a different-class comparison with similarity 0. At a toy temperature of 1, their exponentiated scores are approximately 2.718 and 1. The same-class comparison receives relative probability:

`2.718 / (2.718 + 1) ≈ 0.731`.

Its negative log contribution is about 0.313. If the two similarities were equal, the probability would be 0.5 and the loss about 0.693. The objective rewards the anchor putting more relative similarity on the same-class comparison. Real batches contain many comparisons; the code averages over eligible same-class comparisons and excludes self-comparison.

**Temperature** divides similarity before the probability calculation. A smaller positive temperature makes differences in similarity more influential. It is an objective parameter, not GPU temperature. The implementation uses a stable `logsumexp` calculation to avoid numerical problems in exponentiation; that computes the same kind of log-normalization more reliably.

Class imbalance still matters. In a batch dominated by legitimate transactions, the pattern of available same-class and different-class comparisons differs from a balanced batch. “We used contrastive learning” is not a sufficient explanation of how rare fraud is handled. Inspect the batch, labels and objective.

## Transfer, freezing and fine-tuning

After pretraining, the fraud classifier loads the encoder parameters and attaches a two-output head. **Fine-tuning** means continuing learning for the downstream fraud task. There are two useful experiment conditions:

| Condition | Encoder parameters | Fraud head parameters | Question |
|---|---|---|---|
| Frozen encoder, often called a linear probe here | Fixed | Learned | Does the representation already contain useful fraud information? |
| Full fine-tuning | Learned further | Learned | Does that starting point help after adapting the encoder? |

Freezing must also keep the encoder in evaluation mode; otherwise dropout could keep altering a supposedly fixed representation. The implementation explicitly handles that. A pretrained encoder checkpoint must be compatible and complete. The loader uses strict state loading and rejects a missing checkpoint unless an explicitly named scratch control permits it. A **scratch control** starts with fresh parameters so the comparison can isolate the value of pretraining.

Fair comparison requires more than “same final head.” Check data access, total training effort, feature definitions, validation selection and target cohort. Even an unlabeled pretraining dataset can introduce inappropriate information if it includes future distributions unavailable at the intended deployment time. “No labels” does not automatically mean “no leakage.”

## Exporting a vector is not finishing a new model

The export script can save per-transaction embeddings for downstream study. Possible consumers include a gradient-boosted tree model or nearest-neighbor classifier. A **gradient-boosted tree model** combines many decision trees added sequentially to improve predictions. A **nearest-neighbor classifier** predicts using nearby labeled examples in a chosen representation. Those names describe possible later consumers; their downstream training pipelines are not implemented by the export script.

Likewise, an exported embedding does not automatically become an input to the current A/B history models. That integration would need a defined feature contract, as-of timing, matching training/scoring behavior and a controlled experiment.

## Other future knobs: explain the proposed cause

An optimizer changes how parameters move. A numerical embedding changes how numbers are represented before attention. More attention blocks change the amount of computation and parameter capacity. Added merchant-category or account-velocity features change the information available. More training files change the data seen. Each intervention answers a different question.

A **velocity feature** summarizes activity in an earlier time window, such as the count of transactions during the preceding hour. It is not physical speed. Its definition must specify the entity, window, boundary, and whether the current row is included. A useful-looking feature available only after a decision is not a usable decision-time input.

The current update prioritizes a smaller-data screening sweep before the deferred 100-file fits. The H5 reader—a history-five evidence reader, not the HDF5 file format—and package 006 were delivered; that does not mean those fits or a full optimizer/feature sweep have produced bank results. The package-delivery record is separate from the runtime files tracked in the course's source snapshot. Optimizer candidates and feature proposals remain candidates. A paper showing an improvement on other datasets or another model family motivates a trial; it cannot supply this project's missing measurement.

## Where the mechanisms live

- `waqas/future_experiments/pretrain/ssl_pretrain.py`, `MaskedTabularAutoencoder._reconstruct`, lines 62–97: token masking and reconstruction losses.
- `waqas/future_experiments/pretrain/supcon.py`, `SupConLoss.forward`, lines 36–59, and `SupConPretrainer._corrupt`/`_views`, lines 93–114: labels define comparison pairs; corrupted views feed contrastive learning.
- `waqas/future_experiments/pretrain/ssl_finetune.py`, lines 48–83 and 102–137: freezing, strict encoder transfer, scratch-control handling and fraud training.
- `waqas/future_experiments/pretrain/scripts/export_embeddings.py`, module description, lines 1–6: embedding export exists; downstream consumers are possible experiments.
- `bridge/plans/CH/2026-10-14-improvement-pathway/SWEEP_FIRST_UPDATE.md`, lines 7–33: current proposed sequence and limits, rather than completed experimental gains.

## Predict, repair, explain

**Predict.** Reconstruction MSE falls, but held-out fraud AP is unchanged. Has pretraining succeeded for the business task?

**Repair.** A slide says, “Contrastive learning uses no labels; exported embeddings are our production classifier.” Correct both parts for this repository.

**Teach back.** Explain masked reconstruction, supervised contrastive learning, a frozen probe and full fine-tuning using one transaction as the story.

<details><summary>Answers and self-check rubric</summary>

The reconstruction objective improved; a downstream fraud improvement has not been demonstrated. This implementation's contrastive positives use fraud labels. Exported embeddings are representations, not a complete deployed fraud classifier. Full credit distinguishes inputs, target/objective, learned parameters and downstream evaluation in each route. Also say that Phase 5 is parked and these mechanisms are not evidence of a V1 gain.

</details>

**Recall without looking:** draw two roads into the same encoder—masked reconstruction and labeled contrastive comparisons—then draw frozen and fine-tuned fraud heads. If you cannot explain how either objective moves weights, repair with Chapter 04. To design the experiment that would establish a benefit, proceed to Chapter 14.


---

# 14 · Ask a fair question, then measure how uncertain the answer is

**Prerequisite refresher.** A model turns inputs into scores; training uses labels to learn parameters; validation selects settings or checkpoints; evaluation measures chosen models on a separate cohort. A history length of five means a target may use up to five eligible earlier transactions, not that every target possesses five. Chapters 05–07 explain eligibility. Chapter 12 explains why the resolved run settings matter.

**Your concrete question:** “If B scores higher than A, can I say the hierarchical model is better?”

Sometimes the evidence supports a narrower statement. First ask what changed, which examples were compared, how the models were selected, and how uncertain the difference is. These are not formalities added after the result. They determine what the result means.

## A hypothesis needs an exact comparison

A **hypothesis** is a testable expectation, such as “adding eligible history improves fraud ranking.” An **experiment condition**, also called a cell, is one fully specified run recipe. An **ablation** changes or removes a component to study its contribution. A **contrast** is the numerical difference between specified conditions, with a stated direction such as `A-H05 minus A-H00`.

To ask whether history helps flat A, compare A at history five with A at history zero while matching the other intended settings. A-H00 still uses A's architecture and recipe; it is not automatically the same model as REF-SINGLE. REF has its own dimensions, depth, batch size and learning rate. Comparing A-H05 against REF asks whether one complete recipe beats another practical reference. It does not isolate history as the only cause.

The V1 plan contains 15 conditions:

| Family | Conditions | Main question |
|---|---|---|
| REF | Single-transaction reference | What is the existing recipe's benchmark on the matched cohort? |
| A | H0, H5, H10, H15, H20 | How does flat A behave across requested history lengths? |
| Default B | H0, H5, H10, H15, H20 | How does hierarchical B behave across requested history lengths? |
| A controls | Causal mask at H5; gap off at H5 and H10 | What changes with these information/computation choices? |
| All-position B | H5-labeled chunk condition | How does this distinct training/scoring mode behave? |

All use the current V1 seed 42. Config files for additional seeds or capacity sweeps exist, but files on disk are not proof those experiments belong to the completed V1 study. The results are reported as completed; this course does not rerun their bank workloads.

## “Only one change” requires inspection

A **confound** is another difference that makes the intended causal explanation ambiguous. Suppose GAP-OFF uses a different micro-batch size from GAP-ON. Both may have the same nominal effective batch after accumulation. Their actual grouping and stochastic computation can still differ. The observed difference cannot be attributed to the gap alone with the strongest possible interpretation. That is a qualification to report, not a reason to discard every measurement.

All-position B changes several things together: chunk construction, information masks, gap reference, which positions carry loss, and batch meaning. A depth-matched subset compares selected targets with a comparable amount of eligible context. It does not make the entire training procedures identical. Its result answers a subset question, not “all-position training alone caused the difference.”

The word **matched** must name what matches: same target rows, labels, history availability, preprocessing, seed, architecture, compute budget or training recipe. These are separate properties. Two models can be matched on evaluation rows and deliberately differ in architecture.

## Match the actual predictions before comparing scores

Suppose model X predicts synthetic targets `{a,b,c,d}` and model Y predicts `{a,b,c}`. Computing AP on each set compares different exams. Keeping only `{a,b,c}` silently changes the target cohort and hides the missing prediction. The current paired report instead counts mismatches and marks the affected contrast invalid for numeric comparison.

The project uses a composite key formed from transaction identity and account identity to align predictions. A **join** matches records using keys. Keys are bookkeeping for alignment; their role in joining does not make them model features. Duplicate keys, missing keys, extra keys, nonbinary labels, nonfinite scores and label disagreements must be checked. A **finite** score excludes values such as infinity or “not a number.”

After a clean join, both models must be measured on the same labels in the same aligned row order. A high AP attached to the wrong rows is not useful evidence.

## Sampling uncertainty: what another group of accounts might show

A measured score depends on which examples were available. **Sampling uncertainty** describes how an estimate might vary across plausible samples from the population represented by the observed data. The **bootstrap** approximates that variability by repeatedly resampling the observed units with replacement and recomputing the statistic.

“With replacement” means a selected unit can appear again. If the observed accounts are A, B and C, one bootstrap draw might select `B, B, C`. Every transaction belonging to B then has multiplicity two, C multiplicity one and A multiplicity zero. This keeps each account's transactions together.

Why accounts? Transactions from one account can be related. Treating every transaction as independent can give a misleading sense of how much independent information the dataset contains. Whole-account resampling preserves within-account bundles. It still makes assumptions: account clusters should represent meaningful sampling units, and it does not model every shared merchant, calendar or future shift.

For a paired comparison, use the **same account draw for both models**, then subtract their statistics inside that draw. If X AP is 0.24 and Y AP is 0.21 in one draw, the difference is `0.24 − 0.21 = +0.03`. Another draw might give `0.18 − 0.20 = −0.02`. Collect many such differences. You are measuring the variability of the difference directly.

This is stronger reasoning than separately drawing unrelated samples for X and Y or subtracting the endpoints of two individual intervals. Those methods do not preserve the shared easy/hard cases in the same way. Pairing uses the fact that both models answered the same exam.

## Read an interval with the right claim

A 95% **percentile bootstrap interval** takes lower and upper percentiles of the bootstrap difference distribution. With many draws, the 2.5th and 97.5th percentiles give the usual 95% interval. “Percentile” means the value below which a specified fraction of ordered draws falls.

Consider three entirely synthetic examples:

| AP difference X − Y | Interval | Defensible reading |
|---:|---|---|
| +0.012 | [−0.006, +0.030] | The observed difference is positive; this interval includes both signs. |
| +0.012 | [+0.004, +0.020] | This account-resampling interval supports a positive difference for these fixed models and cohort assumptions. |
| −0.010 | [−0.018, −0.002] | The interval supports a negative difference under those same limits. |

An interval crossing zero does not prove equality, no benefit, or noninferiority. **Noninferiority** is a separately designed claim that a method is not worse by more than a predefined acceptable margin. An interval entirely above zero does not prove production value or immunity to future drift.

A confidence interval is also not a guarantee that 95% of future transactions fall between its endpoints. Its endpoints concern a population-level statistic or difference, not individual scores. The repeated-sampling intuition is that a well-behaved 95% interval procedure, under appropriate assumptions, would cover the target in about 95% of repeated comparable studies. That nominal coverage relies on the method and assumptions; do not read it as a direct probability statement that a fixed unknown difference is inside this particular interval.

## Which uncertainty is missing?

These account bootstrap intervals keep the trained checkpoints fixed. They do not retrain the network on each draw. Therefore they do not capture **training-seed uncertainty**: how random initialization and training variation affect the outcome. Seed 42 alone cannot estimate the distribution across training seeds. **Standard deviation** summarizes how spread out values are around their mean; for seed results, it measures observed run-to-run spread. An output displaying a seed standard deviation of zero when only one seed exists means there is no observed seed spread to estimate, not that training is deterministic.

They also do not capture future temporal shifts, repeated architecture selection, or the possibility that another split would tell a different story. **Pointwise** means each interval applies to its own comparison. If you inspect many comparisons and celebrate whichever is largest, the ordinary individual intervals do not automatically correct for that search.

A **post-hoc** comparison is chosen after looking at the data. It can be useful for exploration, but it should be labeled. A fresh confirmation should use an appropriate untouched cohort. Once evaluation results repeatedly guide model choice, that evaluation set has become development evidence. Renaming it “test” does not restore independence.

## The report's study rule is more specific than “interval above zero”

The paired report has a decision rule that combines validation direction with evaluation intervals. In current one-seed V1, a positive conclusion requires the relevant validation difference to be positive and the evaluation interval to be wholly positive, with extra validation-interval requirements only when validation predictions are supplied. Missing or incomplete validation evidence is explicitly qualified. The richer multi-seed machinery remains available for later studies.

This rule is a project convention, not a law of statistics. Report a numeric evaluation difference honestly even when the combined study label remains “not resolved.” A disagreement between validation and evaluation deserves investigation; it is not automatically proof that validation is useless.

The latest reviewed status retains REF as the benchmark and B-H15 as a provisional research candidate. The finalist contrasts against REF remain unresolved. That is the boundary for this course: learn how to interpret the evidence, without inventing a new winner or rerunning results.

## Where to verify the claims

- `runbook/2026-10-07/analysis_runs.py`, `V1_RUNS`, lines 32–53: the 15 named conditions and source specifications.
- `runbook/2026-10-07/tests/test_v1_matrix.py`, `BATCH1`/`BATCH2`, lines 20–38: expected condition matrix.
- `waqas/base/configs/ref_single.yaml`, lines 1–10: REF's distinct recipe and matched cohort intent.
- `runbook/2026-10-07/paired_report.py`, module contract, lines 28–63; `map_run`, lines 202–230; `draw_multiplicities`, lines 236–251: alignment rules, shared account draws and inference limits.
- `bridge/reviews/CH/2026-10-14-v1-results-next/README.md`, lines 5–11 and 29–58: reported study status, unresolved finalist comparisons and run-configuration qualifications.

## Predict, repair, explain

**Predict.** The measured difference is +0.004 with interval [−0.003,+0.011]. Which claim is supported: X is proven better, X and Y are equal, or the comparison remains uncertain?

**Repair.** A colleague chooses the best evaluation result from 40 variants and presents its ordinary interval as an untouched confirmatory experiment. Explain the selection problem and an appropriate next step.

**Teach back.** Use three fictional accounts to explain one paired bootstrap draw and name three kinds of uncertainty it does not measure.

<details><summary>Answers and self-check rubric</summary>

The comparison remains uncertain; the observed estimate is positive, but the interval includes zero and negative differences. The chosen result benefited from evaluation-guided selection. Label it exploratory and confirm the chosen hypothesis using a suitable untouched cohort and prespecified comparison; additional seeds address a different uncertainty. Full-credit bootstrap explanation keeps every account's rows together, uses identical draws for both models, subtracts within each draw, and distinguishes account sampling from training randomness, future time shifts and selection uncertainty.

</details>

**Recall without looking:** complete the sentence, “This interval measures ___ while holding ___ fixed; it does not prove ___.” If AP itself is still a black box, repair with Chapter 15. If cohort equality is unclear, return to Chapter 05.


---

# 15 · Turn scores into metrics you can explain by hand

**Prerequisite refresher.** A label is the known target, here 1 for fraud and 0 for legitimate. A logit is an unrestricted model output before probability conversion. A score is a number used to rank or decide. Chapter 04 explained loss; Chapter 14 explained comparisons and uncertainty. You now learn what the main numbers actually measure.

**Your concrete question:** “How can a fraud model have 99.9% accuracy and still be useless?”

If only 10 of 10,000 transactions are fraudulent, predicting every transaction legitimate produces `9,990 / 10,000 = 99.9%` accuracy while catching zero fraud. **Class imbalance** means the class frequencies are very unequal. It makes ordinary accuracy a poor headline measure for many fraud decisions. The right metric depends on what action the scores support.

## From logits to scores, then decisions

The current A/B binary classifiers produce two logits per scored transaction. **Softmax** exponentiates each logit and divides by the sum, producing two nonnegative values that add to one. For synthetic logits `[0, log(3)]`, the exponentiated values are `[1,3]`; the fraud-class score is `3 / (1 + 3) = 0.75`.

That arithmetic does not prove “75% of these transactions will be fraud.” Such a probability interpretation requires calibration evidence. The output is usable as a ranking score even when its probability scale is imperfect. **Calibration** means that among cases assigned a given risk level, the observed event rate broadly matches that level in the relevant population.

A **threshold** turns a score into an action rule: for example, alert when score is at least 0.60. A threshold is a policy choice; 0.50 is not automatically appropriate for rare fraud or limited investigation capacity. A business may instead choose a fixed **alert budget**: investigate the highest-scoring 200 transactions each day, or the top 1%.

## A single synthetic example for several metrics

Use the same six fictional transactions throughout this section. They are already sorted from highest to lowest score:

| Rank | Label | Score |
|---:|---:|---:|
| 1 | 1 | 0.90 |
| 2 | 0 | 0.80 |
| 3 | 1 | 0.70 |
| 4 | 0 | 0.40 |
| 5 | 1 | 0.30 |
| 6 | 0 | 0.10 |

At threshold 0.60, the top three alert. Two are fraud; one is legitimate. Of the bottom three, one is fraud and two are legitimate. The **confusion matrix** names these four counts:

| | Actually fraud | Actually legitimate |
|---|---:|---:|
| Alert | True positive: 2 | False positive: 1 |
| No alert | False negative: 1 | True negative: 2 |

“Positive” means the event class being detected. A false positive is a legitimate transaction flagged as fraud. A false negative is fraud that was missed. The terms describe the rule relative to known labels, not moral judgments about a customer.

**Precision** asks, “Of the alerts, what fraction are fraud?” Here it is `2 / (2 + 1) = 2/3 ≈ 0.667`. **Recall**, also called true positive rate, asks, “Of all fraud, what fraction did we alert?” It is `2 / (2 + 1) = 2/3` here too. The equal numbers are a coincidence caused by this tiny table.

The **false positive rate** asks, “Of legitimate transactions, what fraction were alerted?” It is `1 / (1 + 2) = 1/3`. Its denominator is legitimate transactions; precision's denominator is alerts. Mixing those denominators is a common interview error.

At threshold 0.85, only the first row alerts: precision becomes 1/1 = 1, recall becomes 1/3. At threshold 0.25, the top five alert: precision is 3/5 = 0.6 and recall is 3/3 = 1. Lowering a threshold cannot remove alerts from the same fixed score set. Recall therefore cannot decrease, though precision need not change monotonically at every threshold.

## Average precision: reward finding fraud early in the ranking

**Average precision**, or AP, summarizes precision as recall increases across the ranking. With distinct scores, a convenient calculation is to record precision at each positive row and average those values. In our table, fraud appears at ranks 1, 3 and 5:

- At rank 1, precision is `1/1 = 1`.
- At rank 3, precision is `2/3`.
- At rank 5, precision is `3/5`.

`AP = (1 + 2/3 + 3/5) / 3 = 34/45 ≈ 0.7556`.

Why average those positions? Each newly encountered positive increases recall by one third in this example. AP adds `precision × increase in recall`. The general expression is the sum of those precision-weighted recall increases. It handles the curve's steps rather than drawing arbitrary straight lines between points.

With tied scores, process the tied score group together. Arbitrarily sorting positives first within a tie would manufacture performance the model did not provide. The project's `average_precision_score` handles ties by threshold groups. The learning lab implements the same grouped-score concept for tiny examples.

Some project outputs call AP `pr_auc`. Read the implementation: the core metric is scikit-learn's **average precision**, not a generic trapezoidal area under a precision-recall curve. Those calculations can differ. “PR-AUC” without defining the computation is ambiguous.

Fraud prevalence is the fraction of rows with label 1. Here it is 3/6 = 0.5. In real rare-event data it is much lower. Prevalence provides a useful rough no-skill reference for a precision-recall curve; finite-sample random AP can deviate. AP values across cohorts with different prevalences and difficulty are not directly interchangeable.

## AUROC: compare a fraud case with a legitimate case

**AUROC**, area under the receiver operating characteristic curve, summarizes true positive rate against false positive rate over thresholds. A particularly useful interpretation is pairwise ranking: choose one fraud and one legitimate example. How often does fraud receive the higher score? A tie counts as half a win.

Our three fraud scores are 0.90, 0.70 and 0.30. The legitimate scores are 0.80, 0.40 and 0.10. There are `3 × 3 = 9` fraud–legitimate pairs. The 0.90 fraud wins all three comparisons, 0.70 wins two, and 0.30 wins one:

`AUROC = (3 + 2 + 1) / 9 = 6/9 ≈ 0.6667`.

AP and AUROC differ because they summarize different properties. AP emphasizes precision as fraud is recovered in the ranked list. AUROC measures all positive-negative pair ordering. Under severe imbalance, a strong AUROC does not guarantee an attractive precision at a small alert budget. Read both, and include the operating point the business can use.

If a cohort contains only one class, AUROC is undefined: there are no fraud-legitimate pairs. The project's ranking reporting requires both classes; the validation callback skips those metrics for a one-class validation stream. An undefined metric is not a score of zero.

## Alert budgets, dollars and costs

If investigators can handle two alerts from the six-row example, the top two contain one fraud: precision at that budget is 1/2 and recall is 1/3. If the cutoff intersects a tied score group, there must be an explicit tie policy. The project's budget utility reports expected metrics under uniform selection within a cutoff tie, rather than exploiting label order.

Transaction recall and fraud-dollar recall answer different questions. Catching one high-value fraud can dominate dollars while missing many smaller fraud transactions. To measure dollar recall, specify the amount field, valid units, available-at-decision semantics and numerator/denominator. Do not silently infer economic savings from AP.

A simple synthetic cost illustration: suppose each false alert costs 2 units to review, and each missed fraud costs 50 units, with all fraud equal for this toy example. Threshold 0.60 gives cost `1×2 + 1×50 = 52`. Threshold 0.25 gives `2×2 + 0×50 = 4`. This does not choose a real bank policy: real costs, recovered losses, customer friction, intervention effects and capacity all matter. It shows why a ranking metric is not a complete business decision.

## Probability quality and calibration

The **Brier score** averages squared differences between predicted probability and binary label. For predictions `[0.8,0.2]` with labels `[1,0]`:

`Brier = ((0.8−1)² + (0.2−0)²) / 2 = 0.04`.

Lower is better under this measure. Like other aggregate measures it must be interpreted with prevalence and a suitable baseline. A model can rank well while probabilities are too extreme, or produce conservative probabilities with a poor ranking.

The calibration utility can fit a sigmoid-based mapping or **isotonic regression**, a flexible nondecreasing mapping. It fits on validation predictions and applies to separate test predictions, checking identifier overlap. Calibration does not retrain the fraud encoder. Isotonic mapping may create score ties; changing ties or ordering can change ranking measures. Do not promise that calibration always preserves AP or improves every metric. This utility exists; it is not evidence that the V1 scores were calibrated or a deployed threshold was selected.

## Read a results row as a chain of evidence

Begin with run identity: which source, recipe, data cohort, artifact versions, seed and checkpoint? Then inspect row/fraud counts, missing or duplicate predictions, and score validity. Only after that compare AP, AUROC and applicable operating-point measures. For differences, read the paired interval and its assumptions from Chapter 14.

Next distinguish selection from evaluation. `valid_ap` may identify the best epoch; evaluation AP measures that chosen checkpoint on the evaluation cohort. A training-metrics CSV may round displayed values, so a formatted six-decimal number is not the full underlying value. “Best validation epoch” and “highest evaluation history setting” are different selections.

Finally read provenance. **Provenance** is the record of where an artifact or claim came from. An implemented scorer, a reported bank run, a returned aggregate file and an independently reproduced run are different evidence types. The course inspected source and available reported artifacts; it did not rerun native transaction joins or generate new bank performance. The current reviewed evidence does not establish a history-model winner over REF.

One implementation boundary matters for deployment questions. Mathematically, a forward pass uses features and learned parameters, not the unknown fraud label. The current offline loaders/scorers nevertheless require the target column in their input contract, even when metric computation is disabled. They are tools for labeled offline evaluation. An unlabeled live-serving input adapter and operational service are separate work; they are not already implemented merely because a `score` script exists.

## Where these calculations connect to code

- `fraud/callbacks.py`, `StreamingBinaryMetrics`, lines 62–79: softmax scores and whole-validation-stream AP/AUROC.
- `waqas/phase4a/scripts/score_sequential.py`, `main`, lines 103–170: load selected state, evaluate without gradients, align scores/labels/metadata, check probabilities and report checkpoint identity.
- `waqas/scoring/leaderboard.py`, lines 307–342: AP is computed by `average_precision_score` even where output uses `pr_auc` naming.
- `waqas/scoring/calibrate_and_report.py`, `_fit_calibrator`/`_calibrate`, lines 100–113, and `main`, lines 176–200: validation-fitted calibration, separate evaluation and Brier/budget reporting.
- `waqas/scoring/_prediction_utils.py`, `at_budget`, lines 112–134: the utility's tie-aware budget calculation.

## Predict, repair, explain

**Predict.** A model alerts nobody on a set with 0.1% fraud. What are accuracy and recall? Is precision meaningful with zero alerts?

**Repair.** Someone says, “AP 0.20 means exactly 20% of all predictions are correct, and a score of 0.80 proves an 80% fraud probability.” Correct both interpretations.

**Teach back.** Recompute AP and AUROC from the six-row table without looking at the worked answers, then explain one reason neither automatically chooses an alert threshold.

<details><summary>Answers and self-check rubric</summary>

Accuracy is 99.9%; recall is zero. Precision has a zero denominator with no alerts and needs an explicit undefined/reporting convention. AP summarizes precision over recall changes, not overall accuracy. Probability interpretation needs calibration evidence. The table gives AP 34/45 ≈ 0.7556 and AUROC 6/9 ≈ 0.6667. Full credit uses correct denominators, states the tie rule, and connects a threshold to costs or capacity rather than assuming 0.5.

</details>

**Recall without looking:** explain score, threshold, precision, recall, AP, AUROC and calibration as seven different things. If ratios remain difficult, repair with Chapter 02. If a small AP difference still feels like a proven win, return to Chapter 14. Chapter 16 turns these calculations into runnable CPU experiments.


---

# 16 · Learn and test while the GPUs are down

**Prerequisite refresher.** Chapter 04 gave you the learning step, Chapter 07 the history rule, Chapter 14 paired comparisons, and Chapter 15 the metrics. You do not need to train a large neural network to test those ideas. A **CPU** is a general-purpose processor. A **GPU** performs many numerical operations in parallel and is useful for large neural-network workloads. Python's ordinary arithmetic works on a CPU.

**Your concrete question:** “What can I meaningfully verify today, and what would still need real execution later?”

This chapter turns you into a small-scale investigator. Each mission has a prediction, an executable demonstration, a deliberate change and a verbal explanation. The included programs use only Python's standard library and synthetic values. They do not read bank data, load project checkpoints or run the actual Transformer. Their purpose is to make mechanisms visible. They are distinct from the repository's own tests of its real implementations.

## The test detective's four questions

Before running anything, ask:

1. **What property should hold?** For example, a future transaction must not alter an earlier target's available history.
2. **What input exposes a failure?** Use one earlier row, one same-time row and one later row instead of thousands of ordinary rows.
3. **What observation would refute the property?** A future row appearing in the target's selected history is a clear failure.
4. **What does a pass actually establish?** It establishes that this tested implementation behaved correctly on the checked cases; it does not prove all possible data, models and deployments are correct.

An **assertion** is a program statement that checks a condition and stops with an error if it is false. A useful test needs an independent expectation. Checking that a function returns exactly the same thing as a duplicate of its own implementation can repeat the same bug twice. Hand arithmetic, a different algorithm, and carefully designed counterexamples are stronger checks.

## Start the offline labs

Extract the course ZIP, open a terminal in its `Tabular-Fraud-Explained` folder, and check that Python 3 is available. A terminal accepts text commands; `python --version` prints the installed version. Some computers use `python3` instead of `python`; use that spelling consistently if needed. The commands below assume the extracted folder contains `labs/`.

```text
python labs/01_learning_step.py
python labs/02_metrics.py
python labs/03_paired_accounts.py
python labs/04_contracts.py
```

Each command runs one small file. No package installation, server or GPU is required. The course includes `labs/EXPECTED_OUTPUT.txt` for comparison. These scripts make no persistent changes to project data. If Python is unavailable, complete the arithmetic and prediction tasks by hand; the browser demos in this course also explain the learning step and threshold trade-off.

## Mission 1: prove that one learning step moves the right way

Open `labs/01_learning_step.py`. It is an original teaching program for a one-weight logistic model, not a copy of the fraud model. The input feature is 2, the label is 1, and the weight begins at 0. Its logit is `weight × feature = 0`. The sigmoid score is 0.5. Binary cross-entropy is `−log(0.5) ≈ 0.693147`.

For this model, the derivative of loss with respect to the weight is:

`gradient = (score − label) × feature`

`= (0.5 − 1) × 2 = −1`.

With learning rate 0.1, gradient descent makes `new weight = 0 − 0.1×(−1) = 0.1`. The new logit is 0.2, score approximately 0.549834, and loss approximately 0.598139. The model moved toward the positive label and reduced loss on this one example. It has not learned a general fraud detector.

The script independently checks the gradient using a **finite difference**: slightly increase and decrease the weight, calculate both losses, and divide their difference by the total weight change. This approximates local slope. Agreement is evidence that the analytic derivative is implemented correctly for this example.

**Before running:** predict the sign of the gradient. **After running:** change the label to 0 and predict the direction before rerunning. Then change the update from subtraction to addition. The assertions should expose the broken update. Restore your learning copy afterward; this exercise never edits project runtime.

<details><summary>Mission 1 repair answer</summary>

For label 0 at weight 0, the gradient is +1 and a descent step makes the weight −0.1, lowering the score toward 0. Adding the gradient instead of subtracting makes the loss worse here. A pass on one toy step verifies this arithmetic, not AdamW, Transformer backpropagation or model usefulness.

</details>

## Mission 2: own the confusion matrix and ranking metrics

Run `labs/02_metrics.py`. It uses Chapter 15's six synthetic transactions. Expect AP 0.755556 and AUROC 0.666667. At threshold 0.60, expect two true positives, one false positive, one false negative and two true negatives.

**Before running:** calculate recall at threshold 0.85 and precision at 0.25. **After running:** change the second score from 0.80 to 0.95. That legitimate transaction now outranks the first fraud. Predict whether AP improves or worsens before you look. The original arithmetic assertions will fail because the dataset has changed; update an expected value only after calculating the new answer independently.

The shared `toy_metrics.py` groups equal scores before computing AP. Its small implementation is intentionally readable. A separate tied-score assertion requires `[1,0]` with scores `[0.5,0.5]` to have AP 0.5 and AUROC 0.5. Neither tied example deserves to be placed ahead because of its hidden label.

<details><summary>Mission 2 repair answer</summary>

Recall at 0.85 is 1/3. Precision at 0.25 is 3/5. Moving the legitimate score to 0.95 changes positive ranks to 2,3,5, giving AP `(1/2 + 2/3 + 3/5)/3 = 53/90 ≈ 0.588889`. The fraud score 0.90 now loses to one negative, so AUROC becomes 5/9 ≈ 0.555556. You should explain the rank change, not only repeat the new number.

</details>

## Mission 3: see why paired account draws matter

Run `labs/03_paired_accounts.py`. Six fictional accounts contain two rows each, with fixed scores from toy model X and toy model Y. The script makes 1,000 whole-account draws with a fixed random seed, computes AP for both models on each identical draw, and stores `X − Y`.

The expected full-cohort difference is approximately −0.076587. The synthetic percentile interval is approximately [−0.392857,+0.125417]. One draw contains only one class and is counted as undefined, leaving 999 valid draws. The interval is deliberately wide: six accounts are very little evidence. These numbers say nothing about the project's V1 models.

**Before running:** say what `B,B,C` means. **After running:** describe why repeating B twice must repeat its rows in both X and Y. Change `draw_count` from 1,000 to 2,000 in a learning copy. Does this create more independent accounts? No: it refines the resampling calculation on the same six accounts. The displayed count and accounting assertion both read that same setting, so your intentional change stays internally consistent.

**Deeper repair task:** replace all X scores with the corresponding Y scores. Every valid difference must become zero. This is an **invariant**, a property that must hold under a stated transformation. It checks a comparison mechanism without requiring a known fraud-model performance number.

<details><summary>Mission 3 repair answer</summary>

`B,B,C` contains all B transactions twice and all C transactions once. Other accounts are absent. Both models receive exactly that same weighted exam. More bootstrap draws reduce simulation noise in the interval calculation; they do not add accounts, retrain models, or measure seed variation. Identical predictions must produce zero differences. A one-class draw must be reported using an explicit undefined convention, not silently treated as a poor model.

</details>

## Mission 4: break the rules on purpose

Run `labs/04_contracts.py`. Its target is account A at time 20. Candidate rows are A at time 10, A at time 20, A at time 30, and B at time 5. Under strict-earlier same-account history, only the first qualifies. Its amount is 3, so a simple history-sum toy score equals 3.

The program changes same-time and future amounts dramatically, then checks that the selected-history sum stays 3. This is a **perturbation test**: alter information that should be irrelevant and ensure the permitted output does not change. The real project performs stronger tests through actual model forward passes; this lab teaches the idea at the history-selection boundary.

**Before running:** name the reason each excluded row is excluded. **After running:** change `<` to `<=` in the eligibility test. Predict the failing assertion. That one character changes “earlier” into “earlier or simultaneous.” It is a semantic bug even if array shapes and model dimensions still look valid.

The same file tests cohort identity. Reordering `a,b,c` to `c,a,b` is acceptable once aligned by identity; dropping c, duplicating b, or adding d is rejected. A pure row-count check would miss replacing c with a second b. The test therefore checks the actual multiset and uniqueness, not just length.

<details><summary>Mission 4 repair answer</summary>

The same-time row fails strict-before; the future row fails past-only availability; the other-account row fails entity identity. Changing the inequality admits the peer and violates the expected history. The toy sum does not prove the real attention mask is correct. The real model needs perturbation tests that traverse preprocessing, history, masks and output computation as relevant.

</details>

## How the repository tests its real implementation

A **unit test** checks a relatively small component. An **integration test** checks components working together, such as loader → model → checkpoint → scorer. A **regression test** preserves a behavior after a bug has been fixed. A **smoke test** runs a small representative workflow to catch obvious failures before a costly run. These categories can overlap.

Useful existing examples include:

- `waqas/tests/test_training_loader_coverage.py`, `test_training_loader_preserves_all_targets`, lines 23–73: unequal files, multiple worker counts and epochs must not omit or duplicate targets.
- `waqas/tests/test_b_allposition_strict_time.py`, `test_changing_a_later_or_same_second_row_never_changes_an_earlier_or_same_second_score`, lines 261–281: perturb forbidden information and compare actual outputs.
- `waqas/tests/test_a_checkpoint_contract.py`, `test_shape_preserving_checkpoint_drift_is_rejected`, lines 64–86: settings can change meaning even when tensor shapes still match.
- `waqas/tests/test_ema_lifecycle.py`, lines 83–108: optimizer-step timing, partial accumulation and resumed versus uninterrupted raw/EMA state.
- `runbook/2026-10-07/tests/test_paired_report.py`, lines 48–88 and 254–277: compare AP against an independent library, check account versus row resampling, and ensure cohort mismatches are counted rather than hidden.

These source files demonstrate what the repository checks. Their presence is not a claim that this course reran the full repository suite. Running them needs the project's installed dependencies and environment; they are not required for the standard-library learning labs.

## What remains beyond a CPU lesson

No unit test proves the features carry useful fraud signal. No synthetic smoke test establishes bank throughput, GPU memory capacity, real-data quality, fairness across operational populations, or economic impact. Those need relevant data and execution evidence. Conversely, a high AP does not prove the data loader, as-of timing, checkpoint mapping or live service is correct.

The current scoring pipeline is offline labeled evaluation tooling. Although mathematical forward prediction does not need the unknown label, the existing input readers expect a label column. A production service would need an unlabeled input path, matching feature availability, latency and monitoring behavior, plus a defined business action. Do not tell an interviewer that offline scoring alone means deployment is finished.

Your completed-work statement should be precise: “I ran four synthetic CPU learning labs and checked their expected outputs.” A repository test run needs its own source version, environment and results. A bank training result needs its own run artifacts. Keep these three claims separate.

**Final teach-back:** explain one test you would write for each of these: label leakage, missing targets, wrong checkpoint, same-second history, misleading AP, and interrupted EMA training. State the failure observation and the limit of a passing result.

<details><summary>Capstone rubric for this chapter</summary>

Full credit gives six concrete properties: changing labels cannot alter model inputs; every intended target appears exactly once; incompatible input/model contracts fail loading; same-time peers remain invisible under strict mode; hand or independent metric calculations match; resume preserves relevant raw, optimizer and EMA states. Also state that passing finite tests is evidence, not a proof of all program behavior or business performance.

</details>

**Recall without looking:** tell the whole story `claim → revealing example → expected observation → deliberate failure → scope of evidence`. If your metric check is uncertain, return to Chapter 15. If your history check is uncertain, return to Chapter 07. Then use Chapter 18's oral defence to connect these mechanisms into one project explanation.


---

# 17 · The project atlas: find the code behind the idea

You now know the main ideas. This chapter joins them into a map you can use while reading the actual repository. A **repository** is a versioned collection of source code, configuration, tests, and documents. A **module** is a Python file that groups related definitions. An **entry point** is the script you start; it calls definitions in other files. A **configuration** supplies choices such as history length without rewriting the model.

The paths below are relative source locators in the private project, not files bundled with this public course. The ZIP contains teaching material and synthetic labs, not bank data, credentials, checkpoints, or the application's source tree. Source access is needed to open the implementation itself. Use the pinned commit in Chapter 00 so line references do not drift underneath you.

## First, separate four layers

| Layer | Where to look | What it means |
|---|---|---|
| Original project and common helpers | `fraud/`, `docs/` | Ya's original pipeline and design material; some helpers remain imported by the corrected paths |
| Corrected reference and history models | `waqas/base/`, `waqas/phase4a/`, `waqas/phase4b/` | The core implemented experiment paths explained in this course |
| Experiment launch and analysis | `runbook/2026-10-07/`, `waqas/scoring/` | Launches, records, scores, and compares experiments |
| Evidence, historical material, and future work | `bridge/`, `guide/`, `explainer/`, `waqas/future_experiments/` | Records and explanations of different dates, plus parked experiments; existence does not establish current adoption |

The `src/pytorch_tabular/` directory contains a local version of a tabular-model library. A **library** is reusable code. It contains many model families because it was brought into the repository as a library; this does not mean every family participates in the fraud experiments. The active reference uses FT-Transformer. A and B have their own implementation. You do not need to master unrelated library models to explain this project's execution path.

One source-reading trap is already visible in the top-level README: it describes the sequential model as “coming soon.” Current implementation files show that history models exist. Read a document as a statement made at a point in time, then verify against the current code and configuration.

## Follow the runtime, one call at a time

An entry point reads configuration, sets up data, creates a model and trainer, then starts the run. **Importing** a name makes a definition from another module available to use. Imports matter: an excellent fix in one file does nothing if the training script still imports the old implementation.

| Your question | Source entry or symbol | What to inspect |
|---|---|---|
| Which columns are inputs? | `fraud/configs/predictors.csv`, `fraud/data/feature_list.py` | Declared names and continuous/categorical grouping |
| What happens to missing values and categories? | `fraud/data/preprocessing.py` | Saved artifact loading and frame transformation |
| How are calendar features made? | `fraud/data/datetime_features.py` | Timestamp-derived fields, not arbitrary arithmetic on category codes |
| Which rows reach REF? | `waqas/base/data/parquet_loader.py` | Reading, worker ownership, batches, input validation |
| Which earlier rows reach A? | `waqas/phase4a/sequence_builder.py` | Strict history, padding, timestamps, labels returned separately |
| What changes for B's all-position mode? | `waqas/phase4b/sequence_builder.py` | Distinct-second chunks, per-row labels, actual history counts |
| How are values made into vectors? | `waqas/phase4a/tokenizer.py`, `numerical_embeddings.py`; corresponding B files | Numerical transformations and categorical lookups; the model adds its own CLS and transaction-position embeddings |
| Where is A's forward computation? | `waqas/phase4a/sequential.py` | `FTTransformerSeqModel`, masks, positional embeddings, `forward` and training steps |
| Where is B's computation? | `waqas/phase4b/sequential_hier.py` | `FTTransformerHierModel`, row encoder, temporal encoder, mode-specific masks and loss |
| Where does REF come from? | `waqas/base/streaming_model.py`, `src/pytorch_tabular/models/ft_transformer/ft_transformer.py` | Model construction and library backbone; it is not simply A with H set to zero |
| What starts training? | `waqas/base/scripts/train_streaming.py`; A/B `scripts/train_sequential.py` | Configuration overrides, data setup, callbacks, optimizer, trainer |
| What starts scoring? | `waqas/base/scripts/score_streaming.py`; A/B `scripts/score_sequential.py` | Load chosen checkpoint, restore input contract, produce scores and output records |
| Which comparisons exist in V1? | `runbook/2026-10-07/analysis_runs.py`, `v1_contrasts.csv` | Fifteen selected run names and the intended pairwise questions |
| How are comparisons calculated? | `runbook/2026-10-07/paired_report.py` | Pairing rules, account resampling, metric differences, qualification of labels |

You may see different definitions with similar names in original and corrected paths. Follow imports from the specific entry point rather than choosing whichever filename looks familiar. The model's forward computation does not need the target label, but the existing offline scoring loaders still expect labeled datasets. Conceptual label-free prediction is not proof that this repository already contains an unlabeled production-serving endpoint.

## A run creates a chain of evidence

Suppose you ask, “Does A benefit from five earlier transactions?” A credible answer needs more than a table cell:

```text
Question
  → two declared configurations
  → actual resolved settings and source version
  → data and frozen preprocessing identity
  → a training attempt for each
  → selected checkpoint for each
  → predictions for the same assessment rows
  → paired comparison
  → qualified interpretation
```

**Resolved settings** means the final settings after defaults and command-line changes are combined. **Identity** means enough information to distinguish the exact thing used from another version. A **hash** is a reproducible fingerprint of bytes; matching hashes support a claim that the bytes are the same, not that those bytes are scientifically correct.

An **attempt** is one execution of a run. If a run fails and you retry, those are two attempts at the same intended configuration. A **ledger** is a table tracking which attempts started, finished, failed, and produced outputs. Keeping these distinct prevents a failed run from being silently treated as a valid result or an older prediction file from being attached to a newer model.

The current runner and analysis files are designed to keep this chain explicit. In `analysis_runs.py`, the `V1_RUNS` list names the expected experiments. `find_runs` looks for successful attempts and associated evaluation predictions. `post_scored` checks that a later scoring record matches the recorded checkpoint and has not silently changed the evaluation range. A missing output leads to a missing comparison; it should not be filled with a guess.

This is useful even without GPUs. Given an existing run record, you can ask whether its checkpoint, predictions, and configuration belong together. You are checking evidence already produced, not retraining the model.

## A short history of the design, without memorizing every meeting

The useful sequence is: single-transaction baseline, scalable reading and frozen preprocessing, history-aware models, corrections to the experimental machinery, then matched experiments. The reason to know this history is to understand why the repository has both original files and corrected copies.

The original single-transaction route establishes a reference: what can the current row tell us? Flat A tests learning interactions across feature tokens from a history window. Hierarchical B first summarizes individual transactions, then learns across those summaries. B's all-position mode asks a different training and context question, so it is reported separately rather than automatically treated as a longer-history equivalent.

Several corrections explain seemingly fussy pieces of code:

| Failure pattern | Why it matters | Mechanism to understand now |
|---|---|---|
| Workers independently shuffle before claiming files | Some files can be repeated while others are missed | Coordinate file ownership; current loaders use explicit partitioning rules |
| Earlier tokens can read a summary token that already read later tokens | Information can travel backward indirectly through multiple layers | Check the complete attention graph, including CLS |
| Same-time transactions are ordered by an arbitrary identifier | Sorting is deterministic but may not prove real arrival order | Strict earlier-time history in active A/B |
| Time gaps for an early prediction reference a later target | A numerical feature itself can reveal future information | Per-position legal time semantics in all-position B |
| A scorer uses a different feature/history configuration from training | The same weights receive a different meaning of input | Save and check the model's input contract |
| Metrics or predictions are mixed between attempts or epochs | The reported model does not correspond to one actual saved state | Associate checkpoint, predictions, settings, and metric records |

These are mechanisms, not a claim that every historical file is now safe to launch. For example, the corrected older sequence reference under `waqas/base/data/sequence_builder.py` and the active A/B builders do not have identical history semantics. Chapters 07, 10, and 11 identify the exact active path. Historical audit documents describe their own dated findings; this course does not turn them all into current open defects or current fixes.

## What “version 1” means at this snapshot

The current V1 analysis list has 15 cells and seed 42. A **cell** is one chosen combination of experiment settings. It includes REF-SINGLE, A and default-B history ladders at 0, 5, 10, 15, and 20, A time-gap-off controls at 5 and 10, A's causal-mask control at 5, and B's separate all-position H5 condition. That is 1 + 5 + 5 + 2 + 1 + 1 = 15.

It is not “15 independent confirmations of a winner.” Many cells answer different questions; one training seed does not measure sensitivity to different random initializations. REF and A/B retain recipe differences. Chapter 14 explains how to state those comparisons honestly.

Later feature, optimizer, data-size, and pretraining ideas belong to separate questions. At the checked snapshot, Phase 5 is parked. Candidate branches and a plan to try an optimizer are not evidence that it improves this fraud task. The latest project records also distinguish the delivered larger-data package from the subsequent choice to defer those fits while prioritizing smaller-data exploration. Those workflow records explain status; they do not substitute for run evidence.

The course ends at knowing how to interpret the results. It deliberately does not ask you to memorize a historical leaderboard. Results change; the ability to verify the chain above remains useful.

## Repair challenge: which file would you inspect?

A colleague says, “B at H5 must always receive exactly six real rows.” Another says, “A-H00 and REF-SINGLE are the same experiment.” A third says, “The best evaluation AP identifies the unbiased final winner.”

<details markdown="1">
<summary>Reveal the investigation, not just the answer</summary>

For the first claim, ask which B mode. Default B uses a target window with padding as needed. Strict all-position B groups distinct whole-second values and can contain more than H+1 rows because multiple transactions share a second; boundaries also affect available history. Inspect B's sequence builder and model contract. Return to Chapter 11.

For the second, compare REF's construction and configuration with A's. They differ in model implementation and training recipe, even with no historical rows. A-H00 is a within-A history control; REF is the retrained single-transaction benchmark. Return to Chapters 09–10 and 14.

For the third, repeated use of evaluation to choose models makes it development evidence. Use validation for intended selection and acknowledge reuse of evaluation and uncertainty. Return to Chapters 05 and 15.
</details>

**Teach-back:** without opening the table, point to the conceptual place you would investigate a missing-value error, a history leak, a bad checkpoint pairing, and an unfair metric comparison. Name the layer first, then the file. Remembering the exact spelling of a filename is less important than understanding why it is the right place.

**Source check:** `analysis_runs.py` lines 30–53 (`V1_RUNS`), 71–83 (`post_scored`), 86–110 (`find_runs`); `parallel_v1.py` lines 1–12 and 43–59 (execution/queue intent); `waqas/base/README.md` (copy structure). Model and data details are sourced in Chapters 05–12. Current/proposed status also uses the latest dated CH continuity record; it is reported workflow context, not observed bank execution in this course build. Package006 capabilities belong to its delivered branch/package; its `waqas/v2/` runtime is not present in this pinned main source tree.


---

# 18 · Take the controls: capstone and oral defence

This is where you turn recognition into explanation. You can reread a definition and feel that you know it, yet struggle when someone changes the example. The exercises here require you to connect the pieces, state assumptions, and recover when a claim is too strong.

Use paper, a blank note, or the course notes box. First answer without reading the worked response. Then score each answer:

| Score | What happened |
|---|---|
| 0 | I could not explain the mechanism, or my answer used information the model would not have |
| 1 | I got the basic idea but needed the answer, missed a step, or omitted an important qualification |
| 2 | I explained the mechanism, used a concrete example, and stated the limit without looking |

The score is a practice aid, not a competence certificate. A useful target is to explain each core topic twice on separate days, once with a changed example. If you get stuck, repair the specific chapter instead of memorizing the sample wording.

## Capstone A: draw the whole system from memory

Draw twelve boxes: business question; usable input fields; fraud label; data split; frozen preprocessing; legal history; feature tokens; chosen architecture; class scores; training loss and updates; saved checkpoint and predictions; evaluation and business interpretation.

Connect them. Put a large boundary between information used to make the current prediction and the answer used afterward to judge it. Draw separate training and scoring arrows. Now explain each box in one sentence to someone who has never studied data science.

<details markdown="1">
<summary>Check your diagram</summary>

Your diagram should make these relationships visible:

- A fraud label is a target for training and an outcome for assessment, not an input feature for the current prediction.
- Learned preprocessing rules are fitted on designated training/fitting data, without fitting to held-out feature values or answers, then reused consistently.
- A history includes only permitted earlier transactions from the appropriate account; padding is not an actual event.
- The reference uses a single transaction. A combines feature tokens across the window. Default B summarizes each transaction before attending across time.
- The head turns learned representations into class logits. Softmax converts the two logits to class shares summing to one; the fraud share is used as the score. The score's calibration requires checking.
- Training measures prediction error and backpropagates derivatives so an optimizer can adjust parameters. Scoring loads the chosen parameters without updating them.
- Predictions must remain paired with their outcomes and identity before computing metrics or model differences.
- A useful metric does not alone establish business value or deployment readiness.

If you connected the current fraud label to the input tokens, return to Chapter 05. If you cannot explain the arrow from loss to parameters, return to Chapter 04. If you drew A and B as identical, return to Chapters 10–11.
</details>

## Capstone B: be the history builder

All of the following rows are invented. The target is account Maple's transaction at 10:05:00. History limit H is 3. You have these candidate transactions:

| Account | Time | Amount |
|---|---|---:|
| Maple | 09:50:00 | 12 |
| Maple | 10:00:00 | 18 |
| Birch | 10:01:00 | 22 |
| Maple | 10:05:00 | 40 |
| Maple | 10:06:00 | 70 |

The row at 10:05:00 in the table is a different transaction from the target but has the same timestamp. Which rows are eligible? Where does padding go? What are the eligible rows' time gaps to the target? Can a transaction identifier's alphabetical order resolve the same-time uncertainty?

<details markdown="1">
<summary>Reveal the answer and reasoning</summary>

Only Maple at 09:50 and 10:00 is eligible under the active strict-earlier rule. Birch belongs to another account. Maple at 10:05 is tied with the target and is excluded; 10:06 is later and is excluded. The ordinary left-padded window is `[PAD, Maple09:50, Maple10:00, target]`.

The real history gaps are 900 and 300 seconds; the target gap is zero. A log1p transformation gives log(901), log(301), and log(1)=0 before the numerical embedding. Padding needs a mask, even if its numerical values happen to be zero.

Sorting by an identifier can make repeated runs deterministic, but it does not prove that the same-time transaction was available earlier. The active strict rule does not infer chronology from that sort.

In a real extract, earlier eligible transactions may be absent because of file or extraction boundaries. The implementation cannot retrieve events that were not supplied. See Chapter 07.
</details>

Now change H to 1 and answer again. Then keep H=3 but give the tied row time 10:04:59. Those changes should alter the answer for specific reasons, not because “history is whatever came above it in the table.”

## Capstone C: diagnose a suspicious improvement

A colleague presents an invented comparison: Model A has AP 0.12 and Model B has AP 0.14. They say B catches “two percent more fraud” and is ready to replace the existing system. Their table does not state the evaluation rows, chosen checkpoint, input fields, batch recipe, or how many models they tried.

Write five questions that would materially change your interpretation. Then explain why 0.14 minus 0.12 is not a fraud-capture improvement at an alert budget.

<details markdown="1">
<summary>A strong investigation</summary>

Ask whether the models were evaluated on exactly the same eligible rows and outcomes; how their checkpoints were selected; whether every feature was available at decision time; what differed in the full training recipe; and how selection across many trials affected the reported comparison. Also ask about account-level uncertainty, training-seed variability, operating threshold or alert capacity, false-positive costs, fraud amounts, latency, and independent later evaluation.

The AP difference is 0.02, or two percentage points of the AP metric. AP summarizes ranking quality over recall changes. It is not the number or value of frauds captured at a particular threshold. To answer the operational question, compare recall and precision at a fixed review capacity or false-positive burden, using appropriate amounts and costs when available. A gain in AP may or may not be useful at the bank's working point.

If the comparison selected its own winner using this evaluation cohort, call that development evidence. Do not repair the wording by calling the same consulted cohort an untouched test. See Chapters 14–15.
</details>

## Capstone D: trace an actual source path

With repository access, choose the A training entry point. Find where it loads configuration, imports its dataset, creates its model, and sets up training. Then follow one batch to the tokenizer, encoder, head, loss, and optimizer. Use Chapter 17 only when needed.

For every function you inspect, write three things: what comes in, what goes out, and what could go wrong if an assumption fails. For example: “The model flattens a batch of windows into transaction rows for the tokenizer. The tokenizer receives category indices and continuous values, and produces learned feature vectors. The model then restores the window grouping. Indices outside the saved vocabulary range are invalid.” You are learning contracts between components, not trying to memorize the entire file.

You can complete the conceptual version from this course without repository access. Do not pretend that reading an explanation is the same as having executed the source. Chapter 16 provides small runnable labs for hands-on verification.

## The oral defence

Ask a friend or another assistant to choose questions out of order, wait for your answer, then ask one follow-up. Use the rubric above. These are explanations to understand, not lines to claim as personal achievements.

### 1. What is the actual research question?

<details markdown="1"><summary>Worked response</summary>
We want to know whether transaction details and eligible earlier history improve fraud ranking, and which model/training recipe does that under a fair comparison. We compare a corrected single-transaction reference, flat A, and hierarchical B with controlled history and time/mask variants. We must distinguish the question from a claim that a model already improves bank profit. Repair: Chapters 01 and 14.
</details>

### 2. What is a neural network, without using another unexplained label?

<details markdown="1"><summary>Worked response</summary>
It is a composition of numerical operations with adjustable parameters. Inputs are multiplied by weights, shifted by biases, transformed through nonlinear functions, and combined into outputs. Learning changes the adjustable numbers to reduce a defined error over examples. The project uses attention-based neural networks, a particular organization of these operations. Repair: Chapters 03–04.
</details>

### 3. What is the difference between forward propagation, backpropagation, and an optimizer?

<details markdown="1"><summary>Worked response</summary>
The forward pass computes outputs from inputs and current parameters. The loss measures error against known labels. Backpropagation uses the chain rule to calculate how changing each parameter would locally change the loss. The optimizer uses those derivatives and its update rules to change the parameters. Backpropagation computes a signal; it is not itself the optimizer. Repair: Chapter 04.
</details>

### 4. If the model makes a prediction, why do we need labels?

<details markdown="1"><summary>Worked response</summary>
Labels supply answers for supervised learning and evaluation. The model can produce a score without seeing the current answer, but we need outcomes to learn what patterns predict fraud and to assess whether the scores are useful. Fraud outcomes can arrive late or change, so label maturity matters. Repair: Chapters 01 and 05.
</details>

### 5. What is an embedding, and is it a probability?

<details markdown="1"><summary>Worked response</summary>
An embedding is a vector of numbers used to represent an input. A category selects a learned vector; a continuous feature is transformed into a vector by the numerical embedding. Its coordinates are not class probabilities. They are learned representations that later computations can combine. Repair: Chapter 08.
</details>

### 6. What does attention do?

<details markdown="1"><summary>Worked response</summary>
It computes compatibility between a token's query and permitted tokens' keys, normalizes those scores into weights, and forms a weighted combination of their value vectors. Learned projections determine the query/key/value spaces. Masks remove prohibited connections. Multiple heads allow different learned combinations. Attention weights alone are not a causal explanation of the prediction. Repair: Chapter 09.
</details>

### 7. Why use CLS? Can it cause leakage?

<details markdown="1"><summary>Worked response</summary>
CLS is a learned summary token used to collect information for prediction. In a causal design, if an early token can read CLS after CLS has read later tokens, later information can reach the early token indirectly. Preventing direct later-token access is not enough; the entire multilayer information path matters. The current relevant masks account for this. Repair: Chapters 09–11.
</details>

### 8. Is bidirectional attention always a data leak?

<details markdown="1"><summary>Worked response</summary>
No. For a prediction about the final target, all tokens in a correctly constructed window may represent information already available at that target's decision time. Letting those inputs interact does not automatically introduce future events. Predicting an earlier position in the same window is different: later-position inputs may then be unavailable and require strict masking and appropriate time features. Repair: Chapters 10–11.
</details>

### 9. How are A and B different?

<details markdown="1"><summary>Worked response</summary>
A puts feature tokens from multiple transactions into one attention sequence. B first summarizes the features within each transaction, then attends across the transaction summaries. This changes the routes by which information interacts and the computational cost; it does not guarantee B performs better. All-position B also changes the supervision and context available per row. Repair: Chapters 10–11.
</details>

### 10. Does H=5 mean six real events everywhere?

<details markdown="1"><summary>Worked response</summary>
For ordinary target windows, H=5 permits up to five earlier transactions plus the target; short histories require padding. In strict all-position B, the chunk groups distinct whole-second values, can contain more rows because of ties, and different positions have different actual earlier histories. The H setting is not sufficient to prove matched context. Repair: Chapters 07 and 11.
</details>

### 11. Is A-H00 the reference model?

<details markdown="1"><summary>Worked response</summary>
It is A's no-history control. REF-SINGLE is the separately constructed single-transaction benchmark. Even without historical rows, the architecture and recipe differ. A-H05 versus A-H00 helps examine history within A; A-H05 versus REF asks whether one overall recipe outperforms another on matched data. Repair: Chapters 09, 10, and 14.
</details>

### 12. Why freeze preprocessing?

<details markdown="1"><summary>Worked response</summary>
Saved medians, vocabularies, and feature ordering give inputs consistent meanings across training and scoring. Refitting on evaluation data lets assessment information influence the pipeline and may change what category indices or feature values mean. Frozen artifacts still need provenance and compatibility checks; the word frozen is not proof that their original fitting data was appropriate. Repair: Chapter 06.
</details>

### 13. Why can 99% accuracy be poor?

<details markdown="1"><summary>Worked response</summary>
If fraud is rarer than one percent, a model that predicts every transaction as nonfraud can exceed 99% accuracy while finding no fraud. We need metrics that expose positive-class detection and false-alert burden. Accuracy is not mathematically invalid; by itself it answers the wrong question for this rare-event decision. Repair: Chapters 01 and 15.
</details>

### 14. What do AP, AUROC, and calibration tell us?

<details markdown="1"><summary>Worked response</summary>
AP summarizes precision as recall increases over the ranked list. AUROC measures ranking across positive-negative pairs, with appropriate treatment of ties. Calibration asks whether groups receiving a score such as 0.2 actually have fraud rates near 20%. A model can rank well and be poorly calibrated. None alone gives business value at a fixed alert budget. Repair: Chapter 15.
</details>

### 15. How do you know an improvement is real?

<details markdown="1"><summary>Worked response</summary>
First verify comparable inputs, data, selected checkpoints, and paired rows. Then quantify uncertainty appropriate to related observations, such as account-cluster resampling. Check training-seed variability and later cohorts when the decision warrants them. A positive observed difference on one consulted cohort and one seed is not universal proof. Repair: Chapter 14.
</details>

### 16. Why resample accounts instead of individual transactions?

<details markdown="1"><summary>Worked response</summary>
Transactions from one account can be related. Redrawing entire accounts keeps those within-account groups together while varying which accounts are represented. Paired resampling applies the same draw to both models. It assesses a particular source of sampling variability under its assumptions, not every uncertainty about the experiment. Repair: Chapter 14.
</details>

### 17. Does an interval crossing zero prove the models are equal?

<details markdown="1"><summary>Worked response</summary>
No. It means the comparison remains unresolved by that analysis at that uncertainty level. Demonstrating practical equivalence would require a justified equivalence margin and a suitable design. Failure to establish a positive difference is not proof of no difference. Repair: Chapter 14.
</details>

### 18. What is the difference between validation and evaluation here?

<details markdown="1"><summary>Worked response</summary>
Validation is used during training and intended model/checkpoint selection. The separate evaluation data assesses those chosen models, but its repeated use in project development means it cannot simply be advertised as an untouched final holdout. Dataset names do not override how people actually used them. Repair: Chapters 05, 12, and 15.
</details>

### 19. Does gradient accumulation perfectly reproduce one large batch?

<details markdown="1"><summary>Worked response</summary>
It accumulates gradients across smaller pieces before an update, reducing memory needed for activations. Under suitable loss normalization and operations it can approximate the larger-batch update, but batch-dependent layers, stochastic operations, floating-point ordering, and final partial groups can differ. Compare the actual recipe, not just the product of two batch numbers. Repair: Chapter 12.
</details>

### 20. What can you test while GPUs are down?

<details markdown="1"><summary>Worked response</summary>
You can trace source, check arithmetic, test synthetic histories and leakage invariants, validate pairing and metric calculations, and run suitably small CPU tests when dependencies are installed. These checks can find correctness problems but do not establish full-scale GPU throughput, memory use, or bank performance. The bundled labs exercise concepts using invented data. Repair: Chapter 16.
</details>

### 21. Why not use XGBoost or a simpler model?

<details markdown="1"><summary>Worked response</summary>
A simpler method is a legitimate baseline. XGBoost is software for gradient-boosted decision trees: trees ask branching questions about features, and successive trees are trained to improve the combined prediction. The transformer family provides another way to learn feature and history interactions, but architecture popularity is not evidence of superiority for this dataset. A fair comparison needs matching usable features, data, tuning budgets, and operational metrics. The current V1 reference is the corrected single-transaction FT recipe; that fact is not a claim that a current matched XGBoost comparison has been completed. Repair: Chapters 01, 09, and 14.
</details>

### 22. Is pretraining already helping this project?

<details markdown="1"><summary>Worked response</summary>
The repository contains parked pretraining experiments, including reconstructing masked information and contrastive objectives. Their presence means there is code to study, not a demonstrated V1 gain. Pretraining would require its own leakage-safe data design and a matched downstream comparison. Repair: Chapter 13.
</details>

### 23. What would production require beyond a good experiment?

<details markdown="1"><summary>Worked response</summary>
Define the action the score controls, available features and label timing, latency (how long a response takes) and failure behavior, history storage, calibration and threshold policy, monitoring, feedback delays, versioning, and rollback (returning to a known earlier version after a problem). Validate on appropriate later data and measure costs and harms of false alerts and missed fraud. These are engineering and decision requirements, not proof this repository already implements them. Repair: Chapters 01, 05, and 15.
</details>

### 24. What is your most honest one-minute project explanation?

<details markdown="1"><summary>A structure to adapt after understanding it</summary>
“This project studies fraud prediction from tabular transaction data. We preprocess inputs with saved rules and compare a single-transaction FT-Transformer reference with two history-aware designs. A attends over feature tokens across the whole window; B summarizes each transaction before attending across history. We restrict history to information available at the target time, train with labeled examples, and select checkpoints using validation. We evaluate paired predictions and metrics suitable for rare fraud, with uncertainty and explicit limits from the data and experiment design. The current work is research evidence; deployment and a lasting business improvement need further validation.”

Do not use this as a claim that you personally implemented or ran every component. Your strongest answer names what you understand, what the records establish, and what remains unverified.
</details>

## The final memory test

Tomorrow, without opening the course, explain one transaction's journey and answer three questions chosen at random. A week later, change the example: a missing amount, an unseen category, two same-time events, or a suspiciously large AP improvement. If you can reason through those variations, you are developing the ability to defend the project rather than only repeat its vocabulary.

**Repair route:** choose the earliest point where your explanation became vague and return to that chapter's worked example. “It does transformer stuff” sends you to 08–09. “It learns from errors somehow” sends you to 03–04. “We got a better score” sends you to 14–15.


---

# 19 · The glossary you can actually use

Use this as a repair tool. Find the word, say the definition in your own words, then return to the chapter with the worked example. Definitions are reminders; the mechanisms and qualifications are taught in the linked chapters. A few words have a special meaning in this repository, so avoid substituting a familiar meaning from another project.

## Data and decisions

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Tabular | Arranged in rows and columns; here a row describes a transaction | [01](#chapter-01) |
| Observation / example | One item whose inputs and outcome we may learn from or evaluate | [01](#chapter-01) |
| Feature / predictor | An input used to make a prediction, such as an authorized amount field | [01](#chapter-01) |
| Target / label | The answer used for learning or judging a prediction; not the current answer fed into the predictor | [01](#chapter-01) |
| Positive class | The outcome designated 1; here fraud under the configured label mapping | [05](#chapter-05) |
| Continuous feature | A numerical quantity for which magnitude matters | [06](#chapter-06) |
| Categorical feature | Membership in a group, often represented by a code whose arithmetic distance has no natural meaning | [06](#chapter-06) |
| Cardinality | Number of categories represented in a categorical vocabulary, including reserved entries as implemented | [06](#chapter-06) |
| Missing | The original value is absent or recognized as missing by the pipeline | [06](#chapter-06) |
| Unknown category | A present category that has no entry in the fitted vocabulary | [06](#chapter-06) |
| Imputation | Filling a missing feature value with a defined replacement; not inventing a missing target or timestamp | [06](#chapter-06) |
| Median | The middle of ordered values, averaging the middle pair for an even-sized list | [06](#chapter-06) |
| Mean | The sum of values divided by the number of values | [06](#chapter-06) |
| Standard deviation | A measure of how spread out values are around their mean | [06](#chapter-06) |
| Standardization | Subtracting a saved mean and dividing by a saved standard deviation in this numerical pipeline | [06](#chapter-06) |
| Preprocessing artifact | A saved data-preparation object, such as a median or category vocabulary | [06](#chapter-06) |
| Frozen | Reused unchanged for a specified experiment; does not by itself prove correct original fitting | [06](#chapter-06) |
| As-of availability | Whether a value was actually available at the time the prediction would have been made | [05](#chapter-05) |
| Label maturity | Whether enough time has elapsed for outcomes such as confirmed fraud to become sufficiently settled | [05](#chapter-05) |
| Leakage | Information enters learning or prediction in a way that would be unavailable or improper for the claimed evaluation | [05](#chapter-05) |
| Cohort | The particular collection of rows included in an experiment or comparison | [05](#chapter-05) |
| Split | A separation of data into roles such as training, validation, and evaluation | [05](#chapter-05) |
| Entity split | Separating accounts or other entities between roles, rather than merely splitting their individual transactions | [05](#chapter-05) |
| Temporal split | Separating data using time; its exact dates, label timing, and overlap determine what claim it supports | [05](#chapter-05) |
| Account bucket | A grouping of accounts into source files here; a larger file number is not automatically a later date | [05](#chapter-05) |
| Distribution shift | The pattern of inputs or outcomes changes between settings or periods | [05](#chapter-05) |

## Learning and mathematics

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Scalar | One number | [02](#chapter-02) |
| Vector | An ordered list of numbers | [02](#chapter-02) |
| Matrix | A rectangular array of numbers | [02](#chapter-02) |
| Tensor / shape | A multidimensional numerical array / the sizes of its dimensions | [02](#chapter-02) |
| Dot product | Multiply corresponding coordinates and add the products | [02](#chapter-02), [09](#chapter-09) |
| Parameter | An adjustable value inside the model learned during training | [03](#chapter-03) |
| Hyperparameter | A setting such as learning rate or number of layers selected outside ordinary parameter updates | [12](#chapter-12) |
| Weight / bias | A learned multiplier / an added learned offset in a numerical layer | [03](#chapter-03) |
| Layer | A stage of numerical operations in a model | [03](#chapter-03) |
| Activation / nonlinearity | A transformation that lets stacked layers express more than a single linear transformation | [03](#chapter-03) |
| ReLU | The function that keeps positive inputs and replaces negative ones with zero | [03](#chapter-03) |
| GELU | A smooth activation used in the transformer; unlike ReLU, it does not sharply zero every negative input | [09](#chapter-09) |
| Logit | An unconstrained class score before conversion to a probability-style output | [03](#chapter-03) |
| Softmax | Exponentiate scores and divide each by their sum to obtain positive shares summing to one | [03](#chapter-03) |
| Sigmoid | A function mapping one logit to a number between zero and one; used in a teaching simplification | [03](#chapter-03) |
| Forward propagation | Calculating outputs from inputs through the current model | [03](#chapter-03) |
| Loss | A numerical penalty for predictions relative to known targets | [04](#chapter-04) |
| Cross-entropy | A loss that penalizes low probability assigned to the true class; severe confident errors get large penalties | [04](#chapter-04) |
| Derivative / gradient | Local sensitivity to one variable / the collection of sensitivities to many parameters | [04](#chapter-04) |
| Chain rule | The rule for combining sensitivities through a sequence of dependent operations | [04](#chapter-04) |
| Backpropagation | Efficiently applying that rule backward through the computation to obtain parameter gradients | [04](#chapter-04) |
| Optimizer | An algorithm that updates parameters using gradients and possibly stored update statistics | [04](#chapter-04) |
| Learning rate | A scale controlling the size of updates; not a direct measure of intelligence or learning speed | [04](#chapter-04) |
| SGD | Stochastic gradient descent; a basic update using gradients from sampled examples or batches | [04](#chapter-04) |
| AdamW | An optimizer with adaptive gradient statistics and decoupled weight decay; the current default route | [04](#chapter-04) |
| Weight decay | A rule shrinking selected weights during updates, discouraging uncontrolled parameter growth | [04](#chapter-04) |
| Regularization | A technique intended to reduce overfitting, such as weight decay or dropout | [04](#chapter-04) |
| Overfitting | Learning patterns that suit the training examples but do not transfer adequately to new examples | [04](#chapter-04) |
| Generalization | Performance beyond the examples used to fit or select the model | [05](#chapter-05) |
| Batch | A collection of examples processed together; all-position batches require special counting care | [12](#chapter-12) |
| Epoch | One traversal of the training data as implemented by the loader and sampling rules | [12](#chapter-12) |
| Gradient accumulation | Combining gradients from smaller batches before updating, reducing peak activation memory | [12](#chapter-12) |
| Scheduler | A rule that changes the learning rate over training, separately from the optimizer's parameter updates | [12](#chapter-12) |
| Early stopping | Ending training when a monitored validation criterion stops improving under a chosen rule | [12](#chapter-12) |
| Seed | A starting value for pseudorandom procedures; useful for reproducibility but not a universal determinism guarantee | [12](#chapter-12) |
| EMA | Exponential moving average of model weights, an optional smoothed copy; disabled in the V1 default recipe | [12](#chapter-12) |

## Transformer and history vocabulary

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Embedding | A vector representation of an input, usually learned here | [08](#chapter-08) |
| Token | One representation unit passed to attention; here typically a feature vector, not necessarily a word | [08](#chapter-08) |
| Tokenizer | Code turning the input feature values into those feature tokens | [08](#chapter-08) |
| FT-Transformer | Feature Tokenizer plus transformer processing for table-shaped input | [09](#chapter-09) |
| Query / key / value | Learned projected vectors used to request, match, and combine information in attention | [09](#chapter-09) |
| Attention head | One learned attention calculation; several heads can model different relationships | [09](#chapter-09) |
| CLS | A learned summary token, used to gather information for a prediction | [09](#chapter-09) |
| Residual connection | Adding a layer's input to a transformed version, providing a direct information and gradient path | [09](#chapter-09) |
| Layer normalization | Normalizing a token's internal coordinates with learned scale/shift, distinct from input standardization | [09](#chapter-09) |
| Feed-forward sublayer | A small neural network applied to each token within a transformer block | [09](#chapter-09) |
| Dropout | Randomly omitting selected contributions during training under a configured probability | [09](#chapter-09) |
| Position embedding | A representation of a token or transaction's place in the structure | [10](#chapter-10) |
| Mask | A rule marking connections or positions as allowed, prohibited, or padding; conventions differ by API | [10](#chapter-10) |
| Padding | Placeholder slots added to align shapes; they are not real transactions | [07](#chapter-07) |
| Causal attention | Attention constrained to respect the specified information order; mask and input features must both be safe | [10](#chapter-10) |
| Bidirectional attention | Permitting interaction in both positional directions among included inputs | [10](#chapter-10) |
| History length H | The configured history setting; actual available real history depends on data and mode | [07](#chapter-07) |
| Time gap / delta | Elapsed time used as an input; ordinary target-relative and all-position backward gaps differ | [07](#chapter-07), [11](#chapter-11) |
| Flat A | Attention over feature tokens from the whole window in one sequence | [10](#chapter-10) |
| Hierarchical B | Feature attention within each transaction, then attention across transaction summaries | [11](#chapter-11) |
| All-position | B mode predicting each real row in a nonoverlapping chunk under its own strict information contract | [11](#chapter-11) |
| H5 | History setting five in this project's experiment names; not an HDF5 file-format reference | [11](#chapter-11) |
| Pretraining | Learning parameters with an earlier objective before a later downstream task | [13](#chapter-13) |
| Self-supervised | Constructing learning targets from the data itself, such as hidden feature values | [13](#chapter-13) |
| Contrastive | An objective bringing chosen representations closer and separating others; pairing policy matters | [13](#chapter-13) |
| Fine-tuning | Updating a previously learned model for a later task | [13](#chapter-13) |
| ICL | In-context learning: adapting predictions from examples supplied in context; not the active fraud-transformer training method here | [00](#chapter-00) |

## Experiments, software, and results

| Term | Meaning in plain language | Learn it |
|---|---|---|
| Baseline / reference | A comparison method that makes an improvement claim meaningful | [14](#chapter-14) |
| Ablation | Deliberately remove or change a component to examine its contribution under specified conditions | [14](#chapter-14) |
| Interaction | The effect of one change depends on another setting | [14](#chapter-14) |
| Checkpoint | Saved training/model state from a particular point, selected under a stated rule | [12](#chapter-12) |
| Inference / scoring | Computing predictions with chosen parameters rather than updating them | [12](#chapter-12) |
| Threshold | A cutoff converting scores into actions or predicted classes | [15](#chapter-15) |
| Alert budget | A limit on the number of cases investigated; often a more meaningful comparison point than threshold 0.5 | [15](#chapter-15) |
| Precision | Of the cases flagged, the fraction actually positive | [15](#chapter-15) |
| Recall | Of the actual positives, the fraction flagged | [15](#chapter-15) |
| False positive / negative | A legitimate case flagged / a fraud case missed | [15](#chapter-15) |
| AP | Average precision: a ranking summary weighting precision by recall increments | [15](#chapter-15) |
| PR-AUC | An area under a precision-recall curve; the exact convention matters and may differ from AP | [15](#chapter-15) |
| AUROC | Area under the receiver-operating-characteristic curve; a positive-negative ranking interpretation is useful | [15](#chapter-15) |
| Calibration | Agreement between model scores and observed outcome frequencies for similarly scored cases | [15](#chapter-15) |
| Paired comparison | Compare predictions on the same rows with consistent outcomes | [14](#chapter-14) |
| Bootstrap | Resample observed units with replacement and recompute a quantity to study sampling uncertainty | [14](#chapter-14) |
| Account-cluster bootstrap | Resample whole accounts while keeping their transactions together | [14](#chapter-14) |
| Confidence interval | An interval produced by a procedure with a specified long-run coverage goal under assumptions | [14](#chapter-14) |
| Repository / commit | A versioned file collection / one saved version | [17](#chapter-17) |
| Configuration / override | Declared run settings / a later setting that replaces a default | [12](#chapter-12) |
| Provenance | Records of where an artifact came from and how it was produced | [17](#chapter-17) |
| Hash | A fingerprint of bytes; useful for identity, not a correctness proof | [17](#chapter-17) |
| Contract | An explicit expectation about inputs, outputs, or compatible settings | [16](#chapter-16) |
| Unit test / integration test | Check a small component / check several components interacting | [16](#chapter-16) |
| Smoke test | A small run checking that a path can execute; not a full quality or performance assessment | [16](#chapter-16) |
| CPU / GPU | General-purpose processor / processor suited to many parallel numerical operations | [02](#chapter-02), [16](#chapter-16) |
| Worker | A helper process reading data; not the same thing as a GPU or an independent research experiment | [07](#chapter-07) |
| Streaming | Reading data progressively rather than loading the whole dataset at once; exact memory behavior varies by loader | [07](#chapter-07) |
| Parquet | A column-oriented data-file format used for the transaction tables | [07](#chapter-07) |
| Attempt / ledger | One execution / a record of executions and their artifacts | [17](#chapter-17) |
| Production | The operational system making real decisions, with service and monitoring requirements beyond a research run | [18](#chapter-18) |

## A final retrieval exercise

Choose any three terms from different tables. Explain how they connect. For example: “A frozen vocabulary creates categorical indices; embeddings turn those indices into vectors; a checkpoint must be scored with a compatible vocabulary so the vectors still mean the same thing.”

If you can only recite three separate definitions, return to the transaction trace in Chapter 07 or the model trace in Chapter 10 and connect them to a concrete input.

