# ICL MASTER PACK


---

# FILE: 001_BASELINE_FREEZE.md

# 001 — Freeze the control

The current data setup is accepted.

## Fixed control inputs
- Use the existing frozen train cohort.
- Use the existing frozen OOT evaluation cohort.
- Use the existing 94 ordered model features.
- Use the existing 7 context columns.
- Use the existing 101-column baseline schema.
- Keep the existing feature descriptions and feature order.
- Do not resample while running experiments.

## Copilot command
```text
Treat the current train/OOT cohorts and 101-column schema as frozen controls. Do not resample or change feature order. Save the selected train and OOT transaction IDs, the 94-feature ordered manifest, and the current configuration so every later experiment uses exactly the same evaluation population.
```


---

# FILE: 002_PROMPT_ENGINEERING.md

# 002 — Prompt Engineering

There is no universal "perfect prompt." Treat prompt design as a controlled ablation.

Keep the current reference prompt unchanged as `P0`.

## P1 — Rewritten comparative risk prompt

```text
You are a binary transaction risk-scoring model.

TASK
Using only the labeled reference transactions and the target transaction supplied in this prompt, assign the target a continuous fraud-risk score from 0.0000 to 1.0000.

LABELS
1 = fraud
0 = non-fraud

HOW TO EVALUATE THE TARGET
- Compare the target against BOTH the fraud and non-fraud reference transactions.
- Look for combinations of signals rather than treating any one feature as decisive.
- Use only information explicitly present in the transaction descriptions.
- Consider differences in transaction amount, velocity, merchant behavior, geography, channel, timing, authentication/device signals, customer/account history, and other supplied features when they are relevant.
- Weigh confirming and contradicting evidence together.
- Missing or unknown values are not automatically evidence of fraud.
- Do not invent facts, rules, thresholds, or external knowledge that are not supported by the supplied data.
- The reference examples may be deliberately class-balanced. Their class frequency is for comparison and MUST NOT be interpreted as the real-world fraud prevalence.
- Use the examples to learn which feature patterns and feature interactions distinguish the two labels.
- Produce a continuous ranking score: stronger fraud evidence must receive a higher score than weaker fraud evidence.

OUTPUT
Return exactly one line and nothing else:

"<transaction ID>": "<fraud score with exactly 4 decimal places>"

The target transaction ID appears immediately after the words "This transaction" in the target description.
```

## P2 — Minimal prompt

```text
Classify the target transaction using only the labeled examples provided.

Label 1 means fraud. Label 0 means non-fraud.

Compare the target with both classes, consider interactions among the supplied features, and return a continuous fraud-risk score from 0.0000 to 1.0000. Do not use external information.

The examples may be class-balanced; do not treat their class frequency as the real-world fraud rate.

Return exactly:
"<transaction ID>": "<score with 4 decimal places>"
```

## P3 — Local-contrast prompt

```text
You are scoring one target transaction for fraud risk from labeled in-context examples.

Determine internally:
1. Which supplied fraud examples are most similar to the target.
2. Which supplied non-fraud examples are most similar to the target.
3. Which feature interactions separate the target from the closest examples in each class.
4. Whether the total evidence is stronger for fraud or non-fraud.

Do not reveal this analysis.

Use only the supplied transaction information. Do not assume that the class-balanced examples reflect real-world prevalence.

Return only:
"<transaction ID>": "<fraud-risk score from 0.0000 to 1.0000 with 4 decimals>"
```

## P4 — Prior-aware calibration experiment

Only run this after computing the class prior from the allowed training population.

Add to P1:
```text
The observed fraud prevalence in the allowed training population is <TRAIN_FRAUD_RATE>. Use this only as a calibration prior; transaction-specific evidence may move the score substantially above or below it.
```

## Copilot command
```text
Keep the current prompt as P0 unchanged. Add P1, P2, and P3 from this file as separate prompt builders. For a controlled prompt ablation, reuse the exact same target rows and exact same demonstration IDs for every prompt version; do not change representation, model settings, or retrieval. Save AUC, KS, PR-AUC, coverage, latency, and prompt-token estimates by prompt version.
```


---

# FILE: 003_ROW_COLUMN_REPRESENTATION.md

# 003 — Row / Column Representation Experiments

Question: does the model need every feature description repeated for every transaction, or can the table be represented more efficiently?

Use the same 94 features and exact same feature order for every version.

## R0 — Current natural-language representation
Control. Do not change it.

## R1 — Schema once + compact aliases
```text
SCHEMA
f01 = <description of feature 1>
...
f94 = <description of feature 94>

ID=<id>
X=f01:<v1>|f02:<v2>|...|f94:<v94>
Y=<label>
```

Target:
```text
ID=<id>
X=f01:<v1>|f02:<v2>|...|f94:<v94>
Y=?
```

## R2 — Header once + table rows
```text
COLUMNS
transaction_id|f01|f02|...|f94|label

ROWS
<id1>|<v1>|<v2>|...|<v94>|1
<id2>|<v1>|<v2>|...|<v94>|0

TARGET
<target_id>|<v1>|<v2>|...|<v94>|?
```

## R3 — Compact JSON
```json
{
  "schema": {"f01": "<description>", "f02": "<description>"},
  "examples": [
    {"id": "<id>", "x": {"f01": 0, "f02": 12.5}, "label": 1}
  ],
  "target": {"id": "<id>", "x": {"f01": 0, "f02": 9.1}}
}
```

## R4 — Native feature-name key/value
```text
<feature_name_1>=<value>|<feature_name_2>=<value>|...
```

## Measure
- AUC
- KS
- PR-AUC
- prompt characters
- estimated input tokens
- output tokens if available
- mean/p50/p95 latency
- parse success
- API success

## Critical control
Same targets, same demonstrations, same prompt instructions, same model/settings, same feature values.

## Copilot command
```text
Add representation versions R0-R4 without changing the frozen data or 94-feature order. R0 must remain the current text exactly. Implement schema-once aliases, header-once table rows, compact JSON, and native feature-name key/value. Run them with identical target/demo IDs and identical prompt instructions, and log predictive metrics plus prompt tokens and latency.
```


---

# FILE: 004_SIMILAR_EXAMPLES.md

# 004 — Similar-Transaction Demonstration Retrieval

Control:
- 10 random fraud examples
- 10 random non-fraud examples

Challenger:
- 10 nearest fraud examples
- 10 nearest non-fraud examples

## D1 — Mixed-type nearest-neighbor retrieval

Fit all preprocessing on the frozen training pool only.

### Numeric
- infer from actual dtypes/metadata
- median impute using Train only
- standardize using Train statistics only

### Categorical
- infer from actual dtypes/metadata
- most-frequent impute using Train only
- one-hot encode with unknown categories ignored

### Similarity
Use the 94 model features only and cosine distance for the first experiment.

Do not include:
- label
- target label
- transaction ID as a similarity feature
- customer ID as a similarity feature
- unverified existing model scores
- OOT-derived statistics

Build two indices:
```text
Train label=1 -> fraud index
Train label=0 -> non-fraud index
```

For each target:
```text
target
  +-> nearest 10 fraud
  +-> nearest 10 non-fraud
```

Save target ID, selected demo IDs, labels, and distances.

## D2 — Same-segment retrieval
Prefer same-segment candidates, then fall back to the global class pool.

## D3 — Temporal retrieval
Prefer historically appropriate training examples closer in time to the target. Never leak future information.

## D4 — Similarity + diversity
Retrieve top 50 candidates per class, then choose 10/class using Maximal Marginal Relevance so examples are relevant but less redundant.

## Later
Possible learned retrievers:
- supervised metric learned on Train only
- tree-leaf embeddings if an approved model artifact exists
- tabular-foundation-model embeddings
- graph/relational embeddings

## Copilot command
```text
Keep random balanced 10+10 selection as D0. Add D1 retrieval using only the 94 model features: fit preprocessing on Train only, median+standardize numeric features, impute+one-hot categorical features, cosine similarity, and build separate fraud/non-fraud nearest-neighbor pools. For each OOT target return the nearest 10 fraud and 10 non-fraud demo IDs plus distances. Do not use OOT labels, IDs as similarity features, or unverified score fields.
```


---

# FILE: 005_TABULAR_FM.md

# 005 — Tabular Foundation Model Track

This is a benchmark track, not a replacement for the current ICL experiment.

## Comparison
```text
General LLM + current text serialization
vs
General LLM + optimized serialization/retrieval
vs
Tabular foundation model
```

## Candidate A — TabFM
Relevant because it performs tabular classification/regression through in-context learning on structured rows instead of requiring ordinary natural-language serialization.

Current public implementation exposes default practical limits of 500 features and 100 context rows, so a 94-feature table is within the default feature limit.

Important:
- pretrained weights have separate non-commercial/non-production restrictions
- external model downloads may be required
- do not install, download, or send internal data anywhere without approval

## Candidate B — TabICLv2
A scalable tabular ICL foundation-model benchmark candidate. Verify package/model approval and licensing first.

## Candidate C — TabPFN family
Potential roles:
1. direct classifier benchmark
2. embedding generator for retrieval
3. retrieval-only helper feeding the general LLM

## Benchmark contract
If approved:
```text
X_train = same frozen Train 94-feature rows
y_train = Train labels
X_test = exact frozen OOT 94-feature rows
```

Report AUC, KS, PR-AUC, latency, memory, coverage, version, and governance/licensing notes.

## Copilot command
```text
Create an isolated tabular-foundation-model benchmark harness using the exact frozen 94-feature Train/OOT data and the existing metric functions. Do not install or download anything automatically. First inspect which approved packages/models are already available; otherwise generate only the harness and an approval/dependency checklist.
```


---

# FILE: 006_COMBINE.md

# 006 — Combine Winning Components

First identify the best individual version on each axis:
- Prompt: P0-P3
- Representation: R0-R4
- Retrieval: D0-D4

Then run:
```text
C0 = reference prompt + reference representation + random demos
C1 = best prompt only
C2 = best representation only
C3 = best retrieval only
C4 = best prompt + best representation
C5 = best prompt + best retrieval
C6 = best representation + best retrieval
C7 = best prompt + best representation + best retrieval
```

This tests whether gains are additive.

## Token-budget experiment
After compact representation works, compare fixed context budgets:
```text
94 features x fewer demos
50 features x more demos
25 features x many more demos
```
Any feature ranking must be fitted using Train only.

## Context ensemble
Score a target with several valid context sets:
```text
A -> score A
B -> score B
C -> score C

final = mean(scores)
uncertainty = std(scores)
```


---

# FILE: 007_END_TO_END.md

# 007 — End-to-End Detector

```text
Incoming transaction
        |
Point-in-time feature layer
        |
   +----+----------------+
   |                     |
Fast baseline       Context engine
   |                - similar examples
   |                - segment/time context
   |                - optional relational context
   +---------+-----------+
             |
         routing
        /       \
 clear case   ambiguous/high-value
    |              |
baseline score   compact ICL
                    |
                 LLM score
                    |
          calibration/uncertainty
                    |
               final score
                    |
             monitoring/logging
```

## Why hybrid routing matters
The expensive ICL path does not need to score every transaction. Clear cases can remain on the fast path while ambiguous cases are escalated.

## Relational / graph extension
Possible entities:
- customer/account
- card/token
- merchant
- device
- geography
- transaction

Do not send an entire graph to the LLM. Retrieve a compact point-in-time neighborhood summary and compare standard retrieved ICL against retrieved ICL + relational context.

## Final comparison
```text
reference structured model
reference random ICL
prompt-optimized ICL
representation-optimized ICL
retrieval-optimized ICL
combined ICL
tabular foundation model
hybrid/routed system
```


---

# FILE: 008_METRICS.md

# 008 — Evaluation Contract

## Predictive
- ROC AUC
- KS
- PR-AUC

## Operating
- recall at fixed false-positive rates
- precision at fixed review rates/top-k fractions
- score distributions

## Reliability
- scoring coverage
- parse success
- API failure rate
- ID mismatches
- invalid scores

## Efficiency
- input characters
- estimated input tokens
- output tokens if available
- mean/p50/p95 latency
- LLM call count
- retries

## Stability
Report by month and segment.

## Calibration
Later:
- Brier score
- reliability bins
- calibration error

Never fit calibration on final OOT.

## Experiment summary columns
```text
experiment_id
prompt_version
representation_version
retrieval_version
shots_per_class
feature_count
model
temperature
top_p
seed
n_targets
n_scored
coverage
auc
ks
pr_auc
avg_input_tokens
avg_latency
p95_latency
api_failures
parse_failures
notes
```

## Copilot command
```text
Create one reusable evaluation/logger function used by every experiment. Append one versioned row containing configuration, AUC, KS, PR-AUC, coverage, API/parse failures, estimated input tokens, and latency statistics. Never overwrite prior experiment rows.
```


---

# FILE: 009_MEETING.md

# 009 — Meeting Talk Track

## 20-second version
"I have the baseline experiment population and feature contract fixed now, so I'm moving into controlled ICL experiments. I'm separating the problem into three variables: how we instruct the model, how we serialize the rows and columns, and which labeled examples we put in context. The first retrieval experiment replaces random fraud/non-fraud examples with transactions that are actually similar to the target. I'm also measuring tokens and latency, and I'm looking at tabular foundation models as a structured-data benchmark."

## Prompt engineering
"There isn't one universal perfect prompt. I'm keeping the current prompt as the control and testing structured, concise, and local-comparison variants while holding the data and demonstrations fixed."

## Row/column conversion
"The current representation repeats feature descriptions for every example. I'm testing schema-once and table-style serializations so the model still understands the columns while using much less context."

## Similar examples
"The current few-shot baseline uses balanced random examples. I'm building a retrieval layer that uses the same model features to select the closest fraud and non-fraud examples for each target, giving the LLM a local decision boundary."

## Tabular foundation models
"I'm treating them as a benchmark rather than assuming they replace the current approach. They consume structured rows directly, so they let us compare text-based ICL against native tabular ICL."

## Best one-liner
"I'm turning the current few-shot notebook into a controlled ICL testbed: optimize the instructions, optimize the representation, optimize the examples, then combine the pieces that actually improve OOT performance."


---

# FILE: 010_COPILOT_QUEUE.md

# 010 — Copy/Paste Command Queue

## A — Freeze
```text
Treat the current train/OOT cohorts and 101-column schema as frozen controls. Save the selected train/OOT transaction IDs and ordered 94-feature manifest. Do not resample or change feature order in any experiment.
```

## B — Reference run
```text
Run the current prompt/representation/random balanced 10+10 ICL exactly as the reference control on the frozen OOT cohort. Save raw responses, parsed scores, IDs, latency, failures, AUC, KS, PR-AUC, and coverage as experiment C0. Do not change anything yet.
```

## C — Prompt variants
```text
Keep C0 unchanged. Add P1, P2, and P3 from 002_PROMPT_ENGINEERING.md. Run them with the exact same target rows and exact same demo IDs as C0 so prompt wording is the only variable. Log metrics, token estimates, and latency.
```

## D — Representation variants
```text
Keep prompt and demo IDs fixed. Implement R1 schema-once aliases, R2 header-once table rows, R3 compact JSON, and R4 native feature-name key/value from 003_ROW_COLUMN_REPRESENTATION.md. Preserve all 94 feature values/order and compare AUC/KS/PR-AUC, tokens, latency, and parse success.
```

## E — Similar examples
```text
Keep random balanced 10+10 selection as D0. Add D1 retrieval from 004_SIMILAR_EXAMPLES.md: Train-only preprocessing, numeric median+standardization, categorical impute+one-hot, cosine similarity, and separate fraud/non-fraud nearest-neighbor pools. Retrieve 10 fraud + 10 non-fraud per target and save demo IDs/distances.
```

## F — Retrieval comparison
```text
Run D0 random versus D1 nearest-neighbor demonstrations using the same prompt, representation, model settings, and frozen OOT targets. Log AUC, KS, PR-AUC, tokens, latency, and coverage.
```

## G — Same-segment retrieval
```text
Add D2: retrieve the nearest 10 fraud and 10 non-fraud from the same segment when possible, then fall back to the global class pool. Keep everything else identical and save selected IDs/distances.
```

## H — Similarity + diversity
```text
Add D4: retrieve the top 50 similar candidates per class, then choose 10/class with Maximal Marginal Relevance so examples remain target-relevant but less redundant. Compare against D0 and D1.
```

## I — Combine winners
```text
Identify the best validated prompt, representation, and retrieval versions. Run controlled combinations C1-C7 from 006_COMBINE.md on the same frozen OOT cohort. Do not alter the cohort or metric functions.
```

## J — Foundation-model feasibility
```text
Inspect the environment for already-approved tabular foundation-model packages. Do not install/download anything. If available, create a same-94-features/same-OOT benchmark; otherwise create only a dependency, licensing, compute, and approval checklist.
```

## K — Summary
```text
Build one comparison table from saved artifacts only: experiment ID, prompt, representation, retrieval, shots, AUC, KS, PR-AUC, coverage, average tokens, average/p95 latency, and failures. Highlight the best predictive result and best performance-per-token result without inventing missing values.
```


---

# FILE: 011_RESEARCH_NOTES.md

# 011 — Public Research Notes

## Prompt design
Current official guidance from major model providers emphasizes:
- clear, specific instructions
- consistent formatting
- few-shot examples
- explicit output constraints
- iterative evaluation rather than one universal "perfect prompt"

## Retrieval-augmented tabular ICL
Recent research specifically studies retrieval of useful tabular examples because plain-text table rows consume substantial context and arbitrary examples do not scale well.

## Tabular foundation models
Relevant current research directions include:
- TabFM
- TabICLv2
- TabPFN family

TabFM is directly relevant because it performs tabular classification/regression through in-context learning on rows rather than requiring natural-language serialization.

## Governance
Some public pretrained weights have non-commercial or other restrictive licenses and may require external downloads. Treat them as research candidates until approved.


---

# FILE: README.md

# ICL Experiment Pack

Use this repository as a command/specification bridge only.

## Order
1. Keep the current working baseline intact.
2. Freeze the current train and OOT IDs.
3. Run the reference prompt once and save results.
4. Run prompt-only experiments.
5. Run row/column representation experiments.
6. Run retrieved-example ICL.
7. Combine the best prompt + representation + retrieval.
8. Benchmark approved tabular foundation models if the environment allows it.
9. Build the final comparison table and end-to-end architecture.

## Experimental rule
For every controlled comparison, hold constant:
- frozen evaluation IDs
- model version
- model parameters
- feature set
- feature values
- metric code

Change only the variable being tested.

Never overwrite the reference result. Every experiment gets a unique version ID and saved output.
