# 008 — Evaluation Contract

## Predictive
- ROC AUC
- KS
- PR-AUC

## Operating
- recall at fixed false-positive rates
- precision at fixed review rates/top-k fractions
- score distributions

## Reliability
- scoring coverage
- parse success
- API failure rate
- ID mismatches
- invalid scores

## Efficiency
- input characters
- estimated input tokens
- output tokens if available
- mean/p50/p95 latency
- LLM call count
- retries

## Stability
Report by month and segment.

## Calibration
Later:
- Brier score
- reliability bins
- calibration error

Never fit calibration on final OOT.

## Experiment summary columns
```text
experiment_id
prompt_version
representation_version
retrieval_version
shots_per_class
feature_count
model
temperature
top_p
seed
n_targets
n_scored
coverage
auc
ks
pr_auc
avg_input_tokens
avg_latency
p95_latency
api_failures
parse_failures
notes
```

## Copilot command
```text
Create one reusable evaluation/logger function used by every experiment. Append one versioned row containing configuration, AUC, KS, PR-AUC, coverage, API/parse failures, estimated input tokens, and latency statistics. Never overwrite prior experiment rows.
```
