# 004 — Similar-Transaction Demonstration Retrieval

Control:
- 10 random fraud examples
- 10 random non-fraud examples

Challenger:
- 10 nearest fraud examples
- 10 nearest non-fraud examples

## D1 — Mixed-type nearest-neighbor retrieval

Fit all preprocessing on the frozen training pool only.

### Numeric
- infer from actual dtypes/metadata
- median impute using Train only
- standardize using Train statistics only

### Categorical
- infer from actual dtypes/metadata
- most-frequent impute using Train only
- one-hot encode with unknown categories ignored

### Similarity
Use the 94 model features only and cosine distance for the first experiment.

Do not include:
- label
- target label
- transaction ID as a similarity feature
- customer ID as a similarity feature
- unverified existing model scores
- OOT-derived statistics

Build two indices:
```text
Train label=1 -> fraud index
Train label=0 -> non-fraud index
```

For each target:
```text
target
  +-> nearest 10 fraud
  +-> nearest 10 non-fraud
```

Save target ID, selected demo IDs, labels, and distances.

## D2 — Same-segment retrieval
Prefer same-segment candidates, then fall back to the global class pool.

## D3 — Temporal retrieval
Prefer historically appropriate training examples closer in time to the target. Never leak future information.

## D4 — Similarity + diversity
Retrieve top 50 candidates per class, then choose 10/class using Maximal Marginal Relevance so examples are relevant but less redundant.

## Later
Possible learned retrievers:
- supervised metric learned on Train only
- tree-leaf embeddings if an approved model artifact exists
- tabular-foundation-model embeddings
- graph/relational embeddings

## Copilot command
```text
Keep random balanced 10+10 selection as D0. Add D1 retrieval using only the 94 model features: fit preprocessing on Train only, median+standardize numeric features, impute+one-hot categorical features, cosine similarity, and build separate fraud/non-fraud nearest-neighbor pools. For each OOT target return the nearest 10 fraud and 10 non-fraud demo IDs plus distances. Do not use OOT labels, IDs as similarity features, or unverified score fields.
```
