# 007 — End-to-End Detector

```text
Incoming transaction
        |
Point-in-time feature layer
        |
   +----+----------------+
   |                     |
Fast baseline       Context engine
   |                - similar examples
   |                - segment/time context
   |                - optional relational context
   +---------+-----------+
             |
         routing
        /       \
 clear case   ambiguous/high-value
    |              |
baseline score   compact ICL
                    |
                 LLM score
                    |
          calibration/uncertainty
                    |
               final score
                    |
             monitoring/logging
```

## Why hybrid routing matters
The expensive ICL path does not need to score every transaction. Clear cases can remain on the fast path while ambiguous cases are escalated.

## Relational / graph extension
Possible entities:
- customer/account
- card/token
- merchant
- device
- geography
- transaction

Do not send an entire graph to the LLM. Retrieve a compact point-in-time neighborhood summary and compare standard retrieved ICL against retrieved ICL + relational context.

## Final comparison
```text
reference structured model
reference random ICL
prompt-optimized ICL
representation-optimized ICL
retrieval-optimized ICL
combined ICL
tabular foundation model
hybrid/routed system
```
