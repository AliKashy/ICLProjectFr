# 011 — Public Research Notes

## Prompt design
Current official guidance from major model providers emphasizes:
- clear, specific instructions
- consistent formatting
- few-shot examples
- explicit output constraints
- iterative evaluation rather than one universal "perfect prompt"

## Retrieval-augmented tabular ICL
Recent research specifically studies retrieval of useful tabular examples because plain-text table rows consume substantial context and arbitrary examples do not scale well.

## Tabular foundation models
Relevant current research directions include:
- TabFM
- TabICLv2
- TabPFN family

TabFM is directly relevant because it performs tabular classification/regression through in-context learning on rows rather than requiring natural-language serialization.

## Governance
Some public pretrained weights have non-commercial or other restrictive licenses and may require external downloads. Treat them as research candidates until approved.
