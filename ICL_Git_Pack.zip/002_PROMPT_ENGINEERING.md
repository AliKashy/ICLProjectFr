# 002 — Prompt Engineering

There is no universal "perfect prompt." Treat prompt design as a controlled ablation.

Keep the current reference prompt unchanged as `P0`.

## P1 — Rewritten comparative risk prompt

```text
You are a binary transaction risk-scoring model.

TASK
Using only the labeled reference transactions and the target transaction supplied in this prompt, assign the target a continuous fraud-risk score from 0.0000 to 1.0000.

LABELS
1 = fraud
0 = non-fraud

HOW TO EVALUATE THE TARGET
- Compare the target against BOTH the fraud and non-fraud reference transactions.
- Look for combinations of signals rather than treating any one feature as decisive.
- Use only information explicitly present in the transaction descriptions.
- Consider differences in transaction amount, velocity, merchant behavior, geography, channel, timing, authentication/device signals, customer/account history, and other supplied features when they are relevant.
- Weigh confirming and contradicting evidence together.
- Missing or unknown values are not automatically evidence of fraud.
- Do not invent facts, rules, thresholds, or external knowledge that are not supported by the supplied data.
- The reference examples may be deliberately class-balanced. Their class frequency is for comparison and MUST NOT be interpreted as the real-world fraud prevalence.
- Use the examples to learn which feature patterns and feature interactions distinguish the two labels.
- Produce a continuous ranking score: stronger fraud evidence must receive a higher score than weaker fraud evidence.

OUTPUT
Return exactly one line and nothing else:

"<transaction ID>": "<fraud score with exactly 4 decimal places>"

The target transaction ID appears immediately after the words "This transaction" in the target description.
```

## P2 — Minimal prompt

```text
Classify the target transaction using only the labeled examples provided.

Label 1 means fraud. Label 0 means non-fraud.

Compare the target with both classes, consider interactions among the supplied features, and return a continuous fraud-risk score from 0.0000 to 1.0000. Do not use external information.

The examples may be class-balanced; do not treat their class frequency as the real-world fraud rate.

Return exactly:
"<transaction ID>": "<score with 4 decimal places>"
```

## P3 — Local-contrast prompt

```text
You are scoring one target transaction for fraud risk from labeled in-context examples.

Determine internally:
1. Which supplied fraud examples are most similar to the target.
2. Which supplied non-fraud examples are most similar to the target.
3. Which feature interactions separate the target from the closest examples in each class.
4. Whether the total evidence is stronger for fraud or non-fraud.

Do not reveal this analysis.

Use only the supplied transaction information. Do not assume that the class-balanced examples reflect real-world prevalence.

Return only:
"<transaction ID>": "<fraud-risk score from 0.0000 to 1.0000 with 4 decimals>"
```

## P4 — Prior-aware calibration experiment

Only run this after computing the class prior from the allowed training population.

Add to P1:
```text
The observed fraud prevalence in the allowed training population is <TRAIN_FRAUD_RATE>. Use this only as a calibration prior; transaction-specific evidence may move the score substantially above or below it.
```

## Copilot command
```text
Keep the current prompt as P0 unchanged. Add P1, P2, and P3 from this file as separate prompt builders. For a controlled prompt ablation, reuse the exact same target rows and exact same demonstration IDs for every prompt version; do not change representation, model settings, or retrieval. Save AUC, KS, PR-AUC, coverage, latency, and prompt-token estimates by prompt version.
```
