# 009 — Meeting Talk Track

## 20-second version
"I have the baseline experiment population and feature contract fixed now, so I'm moving into controlled ICL experiments. I'm separating the problem into three variables: how we instruct the model, how we serialize the rows and columns, and which labeled examples we put in context. The first retrieval experiment replaces random fraud/non-fraud examples with transactions that are actually similar to the target. I'm also measuring tokens and latency, and I'm looking at tabular foundation models as a structured-data benchmark."

## Prompt engineering
"There isn't one universal perfect prompt. I'm keeping the current prompt as the control and testing structured, concise, and local-comparison variants while holding the data and demonstrations fixed."

## Row/column conversion
"The current representation repeats feature descriptions for every example. I'm testing schema-once and table-style serializations so the model still understands the columns while using much less context."

## Similar examples
"The current few-shot baseline uses balanced random examples. I'm building a retrieval layer that uses the same model features to select the closest fraud and non-fraud examples for each target, giving the LLM a local decision boundary."

## Tabular foundation models
"I'm treating them as a benchmark rather than assuming they replace the current approach. They consume structured rows directly, so they let us compare text-based ICL against native tabular ICL."

## Best one-liner
"I'm turning the current few-shot notebook into a controlled ICL testbed: optimize the instructions, optimize the representation, optimize the examples, then combine the pieces that actually improve OOT performance."
