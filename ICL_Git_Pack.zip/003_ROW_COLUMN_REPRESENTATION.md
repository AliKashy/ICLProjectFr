# 003 — Row / Column Representation Experiments

Question: does the model need every feature description repeated for every transaction, or can the table be represented more efficiently?

Use the same 94 features and exact same feature order for every version.

## R0 — Current natural-language representation
Control. Do not change it.

## R1 — Schema once + compact aliases
```text
SCHEMA
f01 = <description of feature 1>
...
f94 = <description of feature 94>

ID=<id>
X=f01:<v1>|f02:<v2>|...|f94:<v94>
Y=<label>
```

Target:
```text
ID=<id>
X=f01:<v1>|f02:<v2>|...|f94:<v94>
Y=?
```

## R2 — Header once + table rows
```text
COLUMNS
transaction_id|f01|f02|...|f94|label

ROWS
<id1>|<v1>|<v2>|...|<v94>|1
<id2>|<v1>|<v2>|...|<v94>|0

TARGET
<target_id>|<v1>|<v2>|...|<v94>|?
```

## R3 — Compact JSON
```json
{
  "schema": {"f01": "<description>", "f02": "<description>"},
  "examples": [
    {"id": "<id>", "x": {"f01": 0, "f02": 12.5}, "label": 1}
  ],
  "target": {"id": "<id>", "x": {"f01": 0, "f02": 9.1}}
}
```

## R4 — Native feature-name key/value
```text
<feature_name_1>=<value>|<feature_name_2>=<value>|...
```

## Measure
- AUC
- KS
- PR-AUC
- prompt characters
- estimated input tokens
- output tokens if available
- mean/p50/p95 latency
- parse success
- API success

## Critical control
Same targets, same demonstrations, same prompt instructions, same model/settings, same feature values.

## Copilot command
```text
Add representation versions R0-R4 without changing the frozen data or 94-feature order. R0 must remain the current text exactly. Implement schema-once aliases, header-once table rows, compact JSON, and native feature-name key/value. Run them with identical target/demo IDs and identical prompt instructions, and log predictive metrics plus prompt tokens and latency.
```
