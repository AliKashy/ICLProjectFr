# 010 — Copy/Paste Command Queue

## A — Freeze
```text
Treat the current train/OOT cohorts and 101-column schema as frozen controls. Save the selected train/OOT transaction IDs and ordered 94-feature manifest. Do not resample or change feature order in any experiment.
```

## B — Reference run
```text
Run the current prompt/representation/random balanced 10+10 ICL exactly as the reference control on the frozen OOT cohort. Save raw responses, parsed scores, IDs, latency, failures, AUC, KS, PR-AUC, and coverage as experiment C0. Do not change anything yet.
```

## C — Prompt variants
```text
Keep C0 unchanged. Add P1, P2, and P3 from 002_PROMPT_ENGINEERING.md. Run them with the exact same target rows and exact same demo IDs as C0 so prompt wording is the only variable. Log metrics, token estimates, and latency.
```

## D — Representation variants
```text
Keep prompt and demo IDs fixed. Implement R1 schema-once aliases, R2 header-once table rows, R3 compact JSON, and R4 native feature-name key/value from 003_ROW_COLUMN_REPRESENTATION.md. Preserve all 94 feature values/order and compare AUC/KS/PR-AUC, tokens, latency, and parse success.
```

## E — Similar examples
```text
Keep random balanced 10+10 selection as D0. Add D1 retrieval from 004_SIMILAR_EXAMPLES.md: Train-only preprocessing, numeric median+standardization, categorical impute+one-hot, cosine similarity, and separate fraud/non-fraud nearest-neighbor pools. Retrieve 10 fraud + 10 non-fraud per target and save demo IDs/distances.
```

## F — Retrieval comparison
```text
Run D0 random versus D1 nearest-neighbor demonstrations using the same prompt, representation, model settings, and frozen OOT targets. Log AUC, KS, PR-AUC, tokens, latency, and coverage.
```

## G — Same-segment retrieval
```text
Add D2: retrieve the nearest 10 fraud and 10 non-fraud from the same segment when possible, then fall back to the global class pool. Keep everything else identical and save selected IDs/distances.
```

## H — Similarity + diversity
```text
Add D4: retrieve the top 50 similar candidates per class, then choose 10/class with Maximal Marginal Relevance so examples remain target-relevant but less redundant. Compare against D0 and D1.
```

## I — Combine winners
```text
Identify the best validated prompt, representation, and retrieval versions. Run controlled combinations C1-C7 from 006_COMBINE.md on the same frozen OOT cohort. Do not alter the cohort or metric functions.
```

## J — Foundation-model feasibility
```text
Inspect the environment for already-approved tabular foundation-model packages. Do not install/download anything. If available, create a same-94-features/same-OOT benchmark; otherwise create only a dependency, licensing, compute, and approval checklist.
```

## K — Summary
```text
Build one comparison table from saved artifacts only: experiment ID, prompt, representation, retrieval, shots, AUC, KS, PR-AUC, coverage, average tokens, average/p95 latency, and failures. Highlight the best predictive result and best performance-per-token result without inventing missing values.
```
