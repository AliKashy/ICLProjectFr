# 005 — Tabular Foundation Model Track

This is a benchmark track, not a replacement for the current ICL experiment.

## Comparison
```text
General LLM + current text serialization
vs
General LLM + optimized serialization/retrieval
vs
Tabular foundation model
```

## Candidate A — TabFM
Relevant because it performs tabular classification/regression through in-context learning on structured rows instead of requiring ordinary natural-language serialization.

Current public implementation exposes default practical limits of 500 features and 100 context rows, so a 94-feature table is within the default feature limit.

Important:
- pretrained weights have separate non-commercial/non-production restrictions
- external model downloads may be required
- do not install, download, or send internal data anywhere without approval

## Candidate B — TabICLv2
A scalable tabular ICL foundation-model benchmark candidate. Verify package/model approval and licensing first.

## Candidate C — TabPFN family
Potential roles:
1. direct classifier benchmark
2. embedding generator for retrieval
3. retrieval-only helper feeding the general LLM

## Benchmark contract
If approved:
```text
X_train = same frozen Train 94-feature rows
y_train = Train labels
X_test = exact frozen OOT 94-feature rows
```

Report AUC, KS, PR-AUC, latency, memory, coverage, version, and governance/licensing notes.

## Copilot command
```text
Create an isolated tabular-foundation-model benchmark harness using the exact frozen 94-feature Train/OOT data and the existing metric functions. Do not install or download anything automatically. First inspect which approved packages/models are already available; otherwise generate only the harness and an approval/dependency checklist.
```
