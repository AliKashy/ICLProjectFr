# ICL Experiment Pack

Use this repository as a command/specification bridge only.

## Order
1. Keep the current working baseline intact.
2. Freeze the current train and OOT IDs.
3. Run the reference prompt once and save results.
4. Run prompt-only experiments.
5. Run row/column representation experiments.
6. Run retrieved-example ICL.
7. Combine the best prompt + representation + retrieval.
8. Benchmark approved tabular foundation models if the environment allows it.
9. Build the final comparison table and end-to-end architecture.

## Experimental rule
For every controlled comparison, hold constant:
- frozen evaluation IDs
- model version
- model parameters
- feature set
- feature values
- metric code

Change only the variable being tested.

Never overwrite the reference result. Every experiment gets a unique version ID and saved output.
