# 001 — Freeze the control

The current data setup is accepted.

## Fixed control inputs
- Use the existing frozen train cohort.
- Use the existing frozen OOT evaluation cohort.
- Use the existing 94 ordered model features.
- Use the existing 7 context columns.
- Use the existing 101-column baseline schema.
- Keep the existing feature descriptions and feature order.
- Do not resample while running experiments.

## Copilot command
```text
Treat the current train/OOT cohorts and 101-column schema as frozen controls. Do not resample or change feature order. Save the selected train and OOT transaction IDs, the 94-feature ordered manifest, and the current configuration so every later experiment uses exactly the same evaluation population.
```
