# 006 — Combine Winning Components

First identify the best individual version on each axis:
- Prompt: P0-P3
- Representation: R0-R4
- Retrieval: D0-D4

Then run:
```text
C0 = reference prompt + reference representation + random demos
C1 = best prompt only
C2 = best representation only
C3 = best retrieval only
C4 = best prompt + best representation
C5 = best prompt + best retrieval
C6 = best representation + best retrieval
C7 = best prompt + best representation + best retrieval
```

This tests whether gains are additive.

## Token-budget experiment
After compact representation works, compare fixed context budgets:
```text
94 features x fewer demos
50 features x more demos
25 features x many more demos
```
Any feature ranking must be fitted using Train only.

## Context ensemble
Score a target with several valid context sets:
```text
A -> score A
B -> score B
C -> score C

final = mean(scores)
uncertainty = std(scores)
```
